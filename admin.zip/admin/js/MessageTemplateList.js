var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        processButtonMeta:[],
        searchModuleURL: '../messageTemplate/searchModuleService.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
    },

    methods: {
        initSubComponents: function(){
            "use strict";
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    formatClass: vm.displayForEdit,
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        searchModule: function () {
            listVar.searchModuleList();
        },

        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "MessageTemplateEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});

var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            messageTitle: "",
            messageContent: "",
            uuid: "",
            name: "",
            id: ""
        },
        label: MessageTemplateManager.label.messageTemplate,
        loadSystemCodeValueCollectionSelectListURL: '../SystemCodeValueCollection/loadModuleListService'
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
        });
    },
    methods: {}
});

var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label:MessageTemplateManager.label.messageTemplate,
        loadModuleListURL: '../messageTemplate/loadModuleListService.html',
        preLockURL: '../messageTemplate/preLockService.html'
    },

    created: function(){
        var vm = this;
        vm.setI18nProperties(processModel.initProcessButtonMeta);
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'MessageTemplate');
            this.loadModuleList();
        });
    },

    methods: {

        initSubComponents: function(){
            "use strict";
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties, serviceUIMeta: processModel.serviceUIMeta,
                fnCallback: fnCallback,
                label: [vm.label, processModel.label, searchModel.label], vm: processModel, errorHandle: vm.errorHandle,
                configList: [{
                    name: 'MessageTemplate',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        searchModuleList: function () {
            this.$refs.dataTableFrame.searchModuleList();
        },

        buildSearchData: function (data) {
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../messageTemplate/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'id',
                labelKey: 'id',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.MessageTemplate,
                    uuidFieldName: 'uuid'
                }
            }, {
                fieldName: 'name',
                labelKey: 'name',
                minWidth: '180px'
            },{
                fieldName: 'messageTitle',
                labelKey: 'messageTitle',
                maxLength: 13,
                minWidth: '180px'
            },{
                fieldName: 'messageContent',
                labelKey: 'messageContent',
                maxLength: 13,
                minWidth: '180px'
            },{
                fieldName: 'handlerClass',
                labelKey: 'handlerClass',
                maxLength: 13,
                minWidth: '180px'
            },{
                fieldName: 'searchModelClass',
                labelKey: 'searchModelClass',
                maxLength: 13,
                minWidth: '180px'
            }];
            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        },

        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                $http:vm.$http,
                author:processModel.author,
                editorPage:"MessageTemplateEditor.html",
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        }
    }
});
