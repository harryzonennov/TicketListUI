var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        processButtonMeta:[],
        author:{
            resourceId:'CorporateCustomer',
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        serviceUIMeta: {},
        downloadExcelURL: '../corporateCustomer/downloadExcel.html',
        searchModuleURL: '../corporateCustomer/searchModuleService.html'
    },

    created: function(){
        this.initAuthorResourceCheck();
        this.initSubComponents();
    },

    methods: {
        searchModule: function () {
            listVar.searchModuleList();
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    formatClass: vm.displayForEdit,
                    callback: vm.newModule
                },
                downloadExcel: {
                    formatClass: vm.displayForExcel,
                    callback: vm.downloadExcel
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        downloadExcel: function () {
            var vm = this;
            var excelType = ServiceUIMetaProxy.filterKeyValue(vm.serviceUIMeta, 'excelType');
            ServiceExcelHelper.downloadExcel({
                url: vm.downloadExcelURL,
                $http: vm.$http,
                excelType: excelType,
                busyLoader: vm.$refs.refBusyLoader,
                requestData: searchModel.content,
                reportTitle: listVar.label.modelTitle,
                errorHandle: listVar.errorHandle
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initAuthorResourceCheck: function () {
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm: vm,
                errorHandle: ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        displayForExcel: function(){
            "use strict";
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            "use strict";
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "CorporateCustomerEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },
        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            weiXinID: "",
            status: "",
            telephone: '',
            mobile:'',
            tags:'',
            contactPersonName:'',
            address:'',
            countryName:'',
            stateName:'',
            customerLevel:'',
            uuid: "",
            id: "",
            client: "",
            name: "",
            weiboID: "",
            cityName:'',
        },
        label: CorporateCustomerManager.label.corporateCustomer,
        customerLevelArray:[],
        eleTags:'#x_tags',
        eleCustomerLevel: '#x_customerLevel',
        getCustomerLevelMapURL:'../corporateCustomer/loadCustomerLevelMap.html'
    },

    mounted: function () {
        this.$nextTick(function () {
            this.initTagsInput();
            this.initSelectConfigure();
            this.getCustomerLevel();
        }.bind(this));
    },
    methods: {
        clearSearch: function(){
            clearSearchModel(this.content);
            $(this.eleTags).tagsinput('removeAll');
        },

        initSelectConfigure: function(){
            var vm = this;
            $(vm.eleCustomerLevel).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'customerLevel', $(vm.eleCustomerLevel).val());
            });
        },

        initTagsInput: function () {
            "use strict";
            $('#x_tags').tagsinput();
        },

        getCustomerLevel: function () {
            var vm = this;
            this.$http.get(this.getCustomerLevelMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                    return;
                }
                var customerLevelArray = JSON.parse(response.body).content;
                vm.$set(vm, 'customerLevelArray', customerLevelArray);
                var _formatCustomerLevel = ServiceUtilityHelper.genTemplateFormatFunction(customerLevelArray);
                var resultList = formatSelectResult(customerLevelArray, 'id', 'name');
                if( !resultList ){
                    return;
                }
                resultList.splice(0, 0, {'id':'0', 'text':' '});

                setTimeout(function () {
                    $(vm.eleCustomerLevel).select2({
                        data: resultList,
                        templateResult: _formatCustomerLevel,
                        templateSelection: _formatCustomerLevel
                    });
                }, 0);
            });
        }
    }
});

var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: CorporateCustomerManager.label.corporateCustomer,

        preLockURL: '../corporateCustomer/preLockService.html',
        deleteModuleURL: '../corporateCustomer/deleteModule.html'
    },

    created: function(){
        this.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('logistics', 'CorporateCustomer');
            this.setI18nProperties(processModel.initProcessButtonMeta);
            this.loadModuleList();
        }.bind(this));
    },

    methods: {

        initSubComponents: function(){
            "use strict";
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop);
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,serviceUIMeta: processModel.serviceUIMeta,
                fnCallback: fnCallback, modelId: 'CorporateCustomer', coreModelId: 'CorporateCustomer',
                label: [vm.label, searchModel.label, processModel.label], vm:processModel, errorHandle: vm.errorHandle,
                configList: [{
                    name: 'CorporateCustomer',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        searchModuleList: function(){
            this.$refs.dataTableFrame.searchModuleList();
        },

        buildSearchData: function(data){
            searchModel.content.tags = getMultSearchTags(searchModel.eleTags);
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },


        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../corporateCustomer/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'id',
                labelKey: 'id',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.CorporateCustomer,
                    uuidFieldName: 'uuid'
                }
            }, {
                fieldName: 'name',
                labelKey: 'name',
                minWidth: '180px'
            },{
                fieldName: 'telephone'
            }, {
                fieldName: 'address'
            }, {
                fieldName: 'customerLevelValue',
                labelKey: 'customerLevel',
                fieldKey: 'customerLevel',
                iconArrayRequest: {
                    url: '../corporateCustomer/loadCustomerLevelMap.html'
                }
            }];
            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        },



        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                $http:vm.$http,
                author:processModel.author,
                editorPage:"CorporateCustomerEditor.html",
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        _getTagsList: function(row, cellData, refreshFlag){
            var cellValue = cellData? cellData.split(','):null;
            var tagsList = refreshFlag ?
                this.items[row]["tags"] : cellValue;
            return tagsList;
        },


        _fnDrawTagsTd: function (td, tagsList) {
            var maxLength = 4;
            if (tagsList && tagsList.length > 0) {
                var i = 0, len = tagsList.length, codeUUID, codeUnion, ulElement;
                td.innerHTML = '';
                ulElement = document.createElement('div');
                // ulElement.setAttribute('class', 'select2-selection__rendered');
                for (i = 0; i < len; i++) {
                    if (i < maxLength) {
                        var liElement = document.createElement('div');
                        liElement.setAttribute('class', 'selection_choice');
                        liElement.setAttribute('title', tagsList[i]);
                        var textElement = document.createTextNode(tagsList[i] + ' ');
                        liElement.appendChild(textElement);
                        ulElement.appendChild(liElement);
                    } else {
                        var subElement = document.createElement('div');
                        subElement.setAttribute('class', 'selection_element');
                        var textNode = document.createTextNode(" ... ");
                        subElement.appendChild(textNode);
                        ulElement.appendChild(subElement);
                        break;
                    }
                }
                td.appendChild(ulElement);
            }
        },

        deleteModule: function (uuid) {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        // execution deletion
                        var item = ServiceCollectionsHelper.filterArray(uuid, 'uuid', vm.items);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, vm.items);
                        var requestData = {uuid: uuid};
                        vm.$http.post(vm.deleteModuleURL, requestData).then(function (response) {
                            var oData = JSON.parse(response.data);
                            if (!oData.errorCode || oData.errorCode * 1 > 299) {
                                vm.errorHandle(oData);
                                return;
                            }
                            $.Notification.notify('success', 'top center', this.label.msgDeleteOK, this.label.msgDeleteOKComment);
                            // remove the data from list
                            vm.searchModuleList();
                        });
                    } else {
                        // do nothing, just return
                    }
                });

        },


        preLock: function () {
        }
    }
});
