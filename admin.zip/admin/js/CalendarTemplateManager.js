/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var CalendarTemplateManager = function () {

};

CalendarTemplateManager.label={
    calendarTemplate:{
        id: '',
        name: '',
        year: '',
        endTime: '',
        startTime: '',
        advancedSearchCondition: '',
        calendarTemplateSection: '',
        calendarTempWorkScheduleSection: '',
        calendarTemplateItemSection: '',
        msgSaveOK: '',
        modelTitle:'',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        buttonEdit: '',
        buttonView: '',
        lockFailureMessage: '',
        save: '',
        quickEdit: '',
        buttonDelete: '',
        exit: '',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        cancel: '',
        commit: '',
        confirm: '',
        addCalendarTemplate: '',
        addCalendarTempWorkSchedule: '',
        addCalendarTemplateItem: ''
    },

    calendarTempWorkSchedule: {
        id: '',
        name: '',
        endTime: '',
        startTime: '',
        note: ''
    },
    calendarTemplateItem: {
        calendarTemplateItemSection: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        quickEdit: '',
        buttonDelete: '',
        exit: '',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        cancel: '',
        commit: '',
        confirm: '',
        addCalendarTemplateItem: '',
        name: '',
        startMonth: '',
        lastDays: '',
        startDay: '',
        note: ''
    }
};


CalendarTemplateManager.labelTemplate = {
    data: function() {
        return {
            label: {
                "calendarTempWorkSchedule":CalendarTemplateManager.label.calendarTempWorkSchedule,
                "calendarTemplateItem":CalendarTemplateManager.label.calendarTemplateItem,
            }
        };
    }
};


/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
CalendarTemplateManager.prototype.getI18nWrap = function (fnCallback) {
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "foundation/common/",
        fnCallback: fnCallback,
        commonCallback: CalendarTemplateManager.setI18nCommonProperties,
        configList: [{
            name: 'CalendarTemplate',
            callback: CalendarTemplateManager.setNodeI18nPropertiesCore
        },{
            name: 'CalendarTemplate',
            callback: CalendarTemplateManager.setNodeI18nPropertiesCore
        },{
            name: 'CalendarTemplate',
            callback: CalendarTemplateManager.setNodeI18nPropertiesCore
        }]
    });
};


CalendarTemplateManager.setI18nCommonProperties = function () {
    ServiceUtilityHelper.setI18nCommonReflective(CalendarTemplateManager.label.calendarTemplate, $.i18n.prop);
};

CalendarTemplateManager.setI18nWorkScheduleProperties = function () {
    ServiceUtilityHelper.setI18nCommonReflective(CalendarTemplateManager.label.calendarTempWorkSchedule, $.i18n.prop);
};

CalendarTemplateManager.setI18nTemplateItemProperties = function () {
    ServiceUtilityHelper.setI18nCommonReflective(CalendarTemplateManager.label.calendarTemplateItem, $.i18n.prop);
};

/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
CalendarTemplateManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../calendarTemplate/loadModuleViewService.html';
};

/**
 * @override Get Basic URL for load document list.
 * @returns {string}
 */
CalendarTemplateManager.prototype.getLoadSelectListURL = function () {
    "use strict";
    return '../calendarTemplate/loadModuleListService.html';
};


CalendarTemplateManager.prototype.getModelTitle = function(){
    return CalendarTemplateManager.label.calendarTemplate.modelTitle;
};


CalendarTemplateManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: "CalendarTemplateEditor.html",
        url: "../calendarTemplate/loadModuleViewService.html",
        label:CalendarTemplateManager.label.calendarTemplate,
        subPath:'calendarTemplateUIModel',
        getI18nWrap:this.getI18nWrap.bind(vm),
        docType:DocumentConstants.DummyDocumentType.CalendarTemplate
    });

    var fieldMetaList = [{
        fieldName:'id'
    },{
        fieldName:'name'
    },{
        fieldName:'year'
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};
