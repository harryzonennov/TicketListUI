var dataVar = new Vue({
    el: "#x_data",
    mixins: [WarehouseManager.labelTemplate],
    data: {
        warehouseAreaTableId: '#x_table_warehouseArea',
        warehouseAreaTable: {},
        storesettingTableId: '#x_table_storesetting',
        storesettingTable: {},
        label: WarehouseManager.label.warehouse,
        content: {
            warehouseUIModel: WarehouseManager.content.warehouseUIModel,
            warehouseAreaUIModelList: [],
            warehouseStoreSettingUIModelList:[]
        },
        author:{
            resourceId:'Warehouse',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        cache: {

            warehouseArea: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                id: '',
                name: '',
                storeType: '',
                note: ''
            },

            warehouseStoreSetting: {
                refMaterialSKUUUID:'',
                refMaterialSKUId:'',
                refMaterialSKUName:''
            }
        },
        processButtonMeta:[],
        areaInit: undefined,
        volumeInit: undefined,
        addressInfoInit: undefined,
        eleOperationMode: '#x_operationMode',
        eleSystemDefault: '#x_systemDefault',
        eleRefParentOrg: '#x_refParentOrg',
        eleRefMaterialCategory: '#x_refMaterialCategory',
        getOperationModeMapURL: '../warehouse/getOperationModeMap.html',
        getSystemDefaultMap: '../warehouse/getSystemDefaultMap.html',
        eleRefMaterialSKUUUID: '#x_refMaterialSKUUUID',
        loadModuleEditURL: '../warehouse/loadModuleEditService.html',
        loadModuleViewURL: '../warehouse/loadModuleViewService.html',
        saveModuleURL: '../warehouse/saveModuleService.html',
        getRefMaterialCategoryURL:'../warehouse/getRefMaterialCategoryMap.html',
        newWarehouseStoreSettingServiceURL: '../warehouseStoreSetting/newModuleService.html',
        eleEditWarehouseStoreSettingModal: '#x_eleEditWarehouseStoreSettingModal',
        newModuleServiceURL: '../warehouse/newModuleService.html',
        newWarehouseAreaServiceURL: '../warehouseArea/newModuleService.html',
        eleEditWarehouseAreaModal: '#x_eleEditWarehouseAreaModal',
        eleInitWarehouseStoreSettingModal: '#x_eleInitWarehouseStoreSettingModal',
        loadOrganizationSelectURL:'../organization/loadModuleSelectService.html',
        loadOrganizationModelURL:'../organization/loadModuleService.html',
        exitURL: 'WarehouseList.html',
        exitModuleURL: '../warehouse/exitEditor.html'
    },

    watch: {
        'content.warehouseUIModel.cityName': function (cityName) {
            this.updateAddressInfo({
                cityName: cityName,
                townZone: this.content.warehouseUIModel.townZone,
                streetName: this.content.warehouseUIModel.streetName,
                telephone:this.content.warehouseUIModel.contactTelephone
            });
        },
        'content.warehouseUIModel.townZone': function (townZone) {
            this.updateAddressInfo({
                cityName: this.content.warehouseUIModel.cityName,
                townZone: townZone,
                streetName: this.content.warehouseUIModel.streetName,
                telephone:this.content.warehouseUIModel.contactTelephone
            });
        },
        'content.warehouseUIModel.streetName': function (streetName) {
            this.updateAddressInfo({
                cityName: this.content.warehouseUIModel.cityName,
                townZone: this.content.warehouseUIModel.townZone,
                streetName: streetName,
                telephone:this.content.warehouseUIModel.contactTelephone
            });
        },
        'content.warehouseUIModel.contactTelephone': function (contactTelephone) {
            this.updateAddressInfo({
                cityName: this.content.warehouseUIModel.cityName,
                townZone: this.content.warehouseUIModel.townZone,
                streetName: this.content.warehouseUIModel.streetName,
                telephone:contactTelephone
            });
        },
        'content.warehouseUIModel.length': function (length) {
            var vm = this;
            this.updateArea({
                length: length,
                width: vm.content.warehouseUIModel.width
            });
            this.updateVolume({
                length: length,
                width: vm.content.warehouseUIModel.width,
                height: vm.content.warehouseUIModel.height
            });
        },
        'content.warehouseUIModel.width': function (width) {
            var vm = this;
            this.updateArea({
                length: vm.content.warehouseUIModel.length,
                width: width
            });
            this.updateVolume({
                length: vm.content.warehouseUIModel.length,
                width: width,
                height: vm.content.warehouseUIModel.height
            });
        },
        'content.warehouseUIModel.height': function (height) {
            var vm = this;
            this.updateVolume({
                length: vm.content.warehouseUIModel.length,
                width: vm.content.warehouseUIModel.width,
                height: height
            });
        }
    },

    created: function(){
        "use strict";
        var vm = this;
        vm.initAuthorResourceCheck();
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'Warehouse');
            this.setI18nProperties(vm.initProcessButtonMeta);
            this.storesettingTable = new ServiceDataTable(this.storesettingTableId);
            this.loadModuleEdit();
            this.initSelectConfigure();
            this.initSwitchery();
            this.loadMaterialSKUSelectList();
            this.warehouseAreaTable = new ServiceDataTable(this.warehouseAreaTableId);
        });
    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        getServiceManager: function () {
            return WarehouseManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "WarehouseEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.warehouseUIModel.uuid;
        },

        /**
         * @Overwrite: get document status from content
         */
        getStatus: function () {
            return this.content.warehouseUIModel.status;
        },

        updateAddressInfo: function (oSettings) {
            var vm = this;
            if( !vm.addressInfoInit ){
                var addressInfo = ServiceUtilityHelper.buildAddressInfo(oSettings);
                vm.$set(vm.content.warehouseUIModel, 'addressInfo', addressInfo);
            }
        },

        updateArea: function (oSettings) {
            var vm = this;
            if( !vm.areaInit ){
                var area = ServiceUtilityHelper.directCalculateArea(oSettings);
                vm.$set(vm.content.warehouseUIModel, 'area', area);
            }
        },

        updateVolume: function (oSettings) {
            var vm = this;
            if( !vm.volumeInit ){
                var volume = ServiceUtilityHelper.directCalculateVolume(oSettings);
                vm.$set(vm.content.warehouseUIModel, 'volume', volume);
            }
        },


        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        editWarehouseAreaModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.warehouseAreaUIModelList);
            if (!item) {
                return;
            }
            this.cache.warehouseArea = this.copyWarehouseArea(item);
            $(this.eleEditWarehouseAreaModal).modal('toggle');
        },

        initSwitchery: function () {
            var elems = Array.prototype.slice.call(document.querySelectorAll('#x_hasFootStep'));
            elems.forEach(function (html) {
                var switchery = new Switchery(html, {
                    color: '#00b19d',
                    secondaryColor: "#cad7e6"
                });
            });
        },

        initSetSwitch: function (content) {
            var eleHasFootStepArray = $("#x_hasFootStep");
            if (eleHasFootStepArray && eleHasFootStepArray.length > 0) {
                if (content.warehouseUIModel.hasFootStep && content.warehouseUIModel.hasFootStep === true) {
                    eleHasFootStepArray[0].setAttribute("checked", "true");
                    eleHasFootStepArray.trigger('click');
                }
            }
        },

        initStoreSettingMaterialConfig: function(){
            var vm = this;
            return {
                refMaterialSKUUUID:vm.cache.warehouseStoreSetting.refMaterialSKUUUID,
                eleRefMaterialSKUUUID:vm.eleRefMaterialSKUUUID,
                fnSetMaterialSKU:function(refMaterialSKU){
                    if(refMaterialSKU.refMaterialSKUUUID){
                        // In case registered product
                        vm.$set(vm.cache.warehouseStoreSetting, 'refMaterialSKUUUID', refMaterialSKU.refMaterialSKUUUID);
                    }
                    vm.$set(vm.cache.warehouseStoreSetting, 'refMaterialSKUName', content.name);
                }.bind(this),
                fnSetInitMaterialSKUUUID:function(refMaterialSKUUUID){
                    vm.$set(vm.cache.warehouseStoreSetting, 'refMaterialSKUUUID', refMaterialSKUUUID);
                }.bind(this)
            };
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleOperationMode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.warehouseUIModel, 'operationMode', $(vm.eleOperationMode).val());
            });

            $(vm.eleSystemDefault).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.warehouseUIModel, 'systemDefault', $(vm.eleSystemDefault).val());
            });

            MaterialStockKeepUnitManager.initMaterialSKUSelect(vm.initStoreSettingMaterialConfig());

            $(vm.eleRefParentOrg).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.warehouseUIModel, 'refParentOrgRefUUID',$(vm.eleRefParentOrg).val());
            });

            $(vm.eleRefMaterialCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.warehouseUIModel, 'refMaterialCategory',$(vm.eleRefMaterialCategory).val());
            });
        },

        setToWarehouseArea: function () {
            var item = this._filterItemByUUID(this.cache.warehouseArea.uuid, this.content.warehouseAreaUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copyWarehouseArea(this.cache.warehouseArea);
                this.content.warehouseAreaUIModelList.push(newItem);
            } else {
                this.copyWarehouseArea(this.cache.warehouseArea, item);
            }
            $(this.eleEditWarehouseAreaModal).modal('hide');
        },

        newWarehouseAreaModal: function (baseUUID) {
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:vm.newWarehouseAreaServiceURL,
                $http:vm.$http,
                method:'post',
                requestData: requestData,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    vm.cache.warehouseArea = vm.copyWarehouseArea(oData.content, vm.cache.warehouseArea);
                    $(vm.eleEditWarehouseAreaModal).modal('toggle');
                }.bind(this)
            });

        },

        addWarehouseStoreSetting: function () {
            var paras = {};
            $(this.eleInitWarehouseStoreSettingModal).modal('toggle');

        },

        confirmAddWarehouseStoreSetting: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.warehouseUIModel.uuid;
            paras.uuid = this.cache.warehouseStoreSetting.refMaterialSKUUUID;
            var resultURL = "WarehouseStoreSettingEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },

        editWarehouseStoreSetting: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            window.location.href = genCommonEditURL("WarehouseStoreSettingEditor.html", uuid);
        },

        deleteWarehouseStoreSetting: function (uuid) {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.warehouseStoreSettingUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, vm.content.warehouseStoreSettingUIModelList);
                        var requestData = {uuid: uuid};
                        // call back-end to execute back-end deletion
                        vm.$http.post(vm.deleteBillOfMaterialItemServiceURL, requestData).then(function (response) {
                            vm.refreshTreeView();
                        });
                    } else {
                        // do nothing, just return
                    }
                }.bind(this)
            );
        },

        addWarehouseArea: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.warehouseUIModel.uuid;
            var resultURL = "WarehouseAreaEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },

        editWarehouseArea: function (uuid) {
            var vm = this;
            window.location.href = genCommonEditURL("WarehouseAreaEditor.html", uuid);
        },

        deleteWarehouseArea: function(uuid){
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.warehouseAreaUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, vm.content.warehouseAreaUIModelList);
                        var requestData = {uuid: uuid};
                    } else {
                        // do nothing, just return
                    }
                }.bind(this)
            );
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nWarehouseAreaProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.warehouseArea, $.i18n.prop, true);
        },

        setI18nStoreSettingProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.warehouseStoreSetting, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: vm.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'Warehouse',
                    callback: vm.setNodeI18nPropertiesCore
                },{
                    name: 'WarehouseArea',
                    callback: vm.setI18nWarehouseAreaProperties
                },{
                    name: 'WarehouseStoreSetting',
                    callback: vm.setI18nStoreSettingProperties
                }]
            });
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },


        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if ( processMode * 1 === PROCESSMODE_NEW) {
                // in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                ServiceUtilityHelper.httpRequest({
                    url:vm.newModuleServiceURL,
                    $http:vm.$http,
                    method:'post',
                    requestData: requestData,
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        vm.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if ( processMode * 1 === PROCESSMODE_EDIT ) {
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    initAuthor: function(author){vm.$set(vm, 'author', author);},
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }
        },


        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }
        },


        copyWarehouseArea: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.storeType = origin.storeType;
            target.length = origin.length;
            target.volume = origin.volume;
            target.area = origin.area;
            target.note = origin.note;
            return target;
        },

        saveModule: function () {
            var vm = this;
            ServiceUtilityHelper.defSaveModuleWrapper({
                vm: vm,
                editorPage: "WarehouseEditor.html",
                fnGetBaseUUID: function (){
                    return vm.content.warehouseUIModel.uuid;
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.warehouseUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);

        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.warehouseUIModel.uuid;
            window.location.href = genCommonEditURL("WarehouseEditor.html", baseUUID, tabKey);

        },

        loadOperationModeSelectList: function (content) {
            var vm = this;
            this.$http.get(this.getOperationModeMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleOperationMode).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleOperationMode).val(content.warehouseUIModel.operationMode);
                    $(vm.eleOperationMode).trigger("change");
                }, 0);
            });
        },

        getSystemDefaultMapSelectList: function (content) {
            var vm = this;
            this.$http.get(this.getSystemDefaultMap).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleSystemDefault).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleSystemDefault).val(content.warehouseUIModel.systemDefault);
                    $(vm.eleSystemDefault).trigger("change");
                }, 0);
            });
        },

        getRefMaterialCategory: function (content) {
            var vm = this;
            this.$http.get(this.getRefMaterialCategoryURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleRefMaterialCategory).select2({
                        data: resultList,
                        templateResult: WarehouseManager.formatMatCategoryIcon,
                        templateSelection: WarehouseManager.formatMatCategoryIcon
                    });
                    // manually set initial value
                    $(vm.eleRefMaterialCategory).val(content.warehouseUIModel.refMaterialCategory);
                    $(vm.eleRefMaterialCategory).trigger("change");
                }, 0);
            });
        },

        loadMaterialSKUSelectList: function () {
            var vm = this;
            MaterialStockKeepUnitManager.loadMaterialSKUSelectList(vm.initStoreSettingMaterialConfig());
        },

        loadOrganizationSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadOrganizationSelectURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleRefParentOrg).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefParentOrg).val(content.warehouseUIModel.refParentOrgRefUUID);
                    $(vm.eleRefParentOrg).trigger("change");
                }, 0);
            });

        },


        setModuleToUI: function (content) {
            var vm = this;
            if(content.warehouseUIModel.area && content.warehouseUIModel.area > 0){
                vm.$set(vm, 'areaInit', true);
            }
            if(content.warehouseUIModel.volume && content.warehouseUIModel.volume > 0){
                vm.$set(vm, 'volumeInit', true);
            }
            if(content.warehouseUIModel.addressInfo){
                vm.$set(vm, 'addressInfoInit', true);
            }
            vm.$set(vm.content, 'warehouseUIModel', content.warehouseUIModel);
            vm.$set(vm.content, 'warehouseStoreSettingUIModelList', content.warehouseStoreSettingUIModelList);
            vm.$set(vm.content, 'warehouseAreaUIModelList', content.warehouseAreaUIModelList);
            vm.initSetSwitch(content);
            vm.getRefMaterialCategory(content);
            vm.loadOperationModeSelectList(content);
            vm.loadOrganizationSelectList(content);
            vm.getSystemDefaultMapSelectList(content);
        },


        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'WarehouseEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: WarehouseManager,
                coreModelId: 'Warehouse',
                i18nPath: 'coreFunction/',
                getDocActionNodeListURL: '../warehouse/getDocActionNodeList.html',
                helpDocumentName: ['WarehouseHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: 'displayForEdit',
                        callback: 'saveModule'
                    },
                    placeholder: {
                        category: ProcessButtonConstants.placeholderCategory.DOC_ACTION_BTN
                    },
                    exit: {
                        callback: 'exitModule'
                    }
                },
                tabMetaList: [{
                    tabId: 'warehouseSection',
                    tabTitleKey: 'warehouseSection',
                    titleLabelKey: 'warehouseSection',
                    titleHelpKey: 'warehouse.warehouseSection',
                    titleIcon: 'md md-texture content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'warehouseSection',
                        updatedByUidPath: 'updatedByUUID',
                        updatedByNamePath: 'updatedByName',
                        updatedDatePath: 'updatedDate',
                        messageResponsePath: 'meta.messageResponse',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'warehouseUIModel',
                        tabTitleKey: 'warehouseSection',
                        titleLabelKey: 'warehouseSection',
                        titleHelpKey: 'warehouse.warehouseSection',
                        titleIcon: 'md md-content-paste content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'id',
                            required: true,
                            newRow: true
                        }, {
                            required: true,
                            fieldName: 'name',
                        }, {
                            fieldName: 'systemDefault',
                            disabled: true,
                            helpKey: 'warehouse.systemDefault',
                            settings: {
                                getMetaDataUrl: vm.getSystemDefaultMap,
                                formatMeta: 'formatSystemDefault'
                            },
                            iconArray: 'getSystemDefaultArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'refMaterialCategory',
                            settings: {
                                getMetaDataUrl: vm.getRefMaterialCategoryURL,
                                formatMeta: 'formatMatCategoryIcon'
                            },
                            iconArray: 'getMatCategoryIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'upOrganizationName',
                            newRow: true
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        }]
                    }, {
                        sectionId: 'warehouseContactSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'warehouseUIModel',
                        tabTitleKey: 'warehouseContactSection',
                        titleLabelKey: 'warehouseContactSection',
                        titleHelpKey: 'warehouse.warehouseContactSection',
                        titleIcon: 'md md-quick-contacts-dialer content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'mobile',
                            newRow: true,
                        }, {
                            fieldName: 'telephone'
                        }, {
                            fieldName: 'fax',
                        }, {
                            newRow: true,
                            fieldName: 'stateName'
                        }, {
                            fieldName: 'cityName'
                        }, {
                            fieldName: 'townZone'
                        }, {
                            fieldName: 'streetName'
                        }, {
                            fieldName: 'address',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea,
                            setAutoValue: {
                                callbackTemplateId:"updateAddressInfo"
                            },
                        }]
                    }, {
                        sectionId: 'refTechSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'warehouseUIModel',
                        tabTitleKey: 'warehouseContactSection',
                        titleLabelKey: 'warehouseContactSection',
                        titleHelpKey: 'warehouse.warehouseContactSection',
                        titleIcon: 'md md-quick-contacts-dialer content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'length',
                            newRow: true,
                        }, {
                            fieldName: 'width'
                        }, {
                            fieldName: 'height',
                        }, {
                            newRow: true,
                            fieldName: 'area'
                        }, {
                            fieldName: 'volume'
                        },{
                            fieldName: 'operationMode',
                            settings: {
                                getMetaDataUrl: vm.getOperationModeMapURL,
                                formatMeta: 'formatOperationMode'
                            },
                            iconArray: 'getOperationModeIcon',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, ]
                    }]
                },{
                    tabId: 'warehouseAreaSection',
                    tabTitleKey: 'warehouseAreaSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'warehouseAreaSection',
                        parentContentPath: 'warehouseAreaUIModelList',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        detailedPageUrl: 'WarehouseOrgEditor.html',
                        refItemName: 'warehouseAreaPanel',
                        editModuleFlag: true,
                        editModuleModalFlag: true,
                        tabTitleKey: 'warehouseAreaSection',
                        titleLabelKey: 'warehouseAreaSection',
                        titleHelpKey: 'warehouse.warehouseAreaSection',
                        titleIcon: 'md md-nature-people content-portlet-title',
                        scrollX: true,
                        embedProcessButtonMeta: {
                            addTitle: 'newOrganization',
                            addLabel: 'newOrganization',
                            newModuleModalFlag: true
                        },
                        fieldMetaList: [{
                            fieldName: 'warehouseAreaUIModel.uuid'
                        }, {
                            fieldName: 'warehouseAreaUIModel.id',
                            labelKey: 'warehouseArea.id',
                            minWidth: '180px'
                        }, {
                            fieldName: 'warehouseAreaUIModel.name',
                            labelKey: 'warehouseArea.name',
                            minWidth: '180px'
                        }, {
                            fieldName: 'warehouseAreaUIModel.length',
                            labelKey: 'warehouseArea.length'
                        }, {
                            fieldName: 'warehouseAreaUIModel.area',
                            labelKey: 'warehouseArea.area'
                        }, {
                            fieldName: 'warehouseAreaUIModel.volume',
                            labelKey: 'warehouseArea.volume'
                        }]
                    }]
                },{
                    tabId: 'warehouseAttachmentSection',
                    tabTitleKey: 'warehouseAttachmentSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'warehouseAttachment',
                        sectionCategory: AsyncSection.sectionCategory.ATTACHMENT,
                        parentContentPath: 'warehouseAttachmentUIModelList',
                        errorHandle: 'errorHandle',
                        settings: {
                            configMetaPath: 'attachmentMeta'
                        }
                    }]
                }]
            };
        }

    }
});
