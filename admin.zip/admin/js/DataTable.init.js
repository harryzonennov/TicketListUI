/**
 * Basic table supports text sorting and paging
 * Created by Zhang,Hang on 11/23/2016.
 */

function ServiceDataTable(table){
    "use strict";
    this.table = table;
    this.dataTable = {};

    this.refreshTable = function(){
        var _self = this;

        setTimeout(function () {
            _self.build();
        }, 0);

    };

    /**
     * build a new data table or refresh datatable
     * @returns {{}|*|jQuery}
     */
    this.build = function(fnInitComplete){
        if ($.fn.dataTable.isDataTable($(this.table))) {
            // In  case table already exist
            // this.datatable.clear();
            // this.datatable.destroy();
            this.datatable = $(this.table).DataTable();
        } else {
            this.datatable = $(this.table).DataTable({
                "language": {
                    "decimal": "",
                    "emptyTable": "没有数据",
                    "info": "显示 _START_ 到 _END_   /共_TOTAL_ 条数据",
                    "infoEmpty": "显示 0 条数据",
                    "infoFiltered": "(总共 _MAX_ 条数据)",
                    "infoPostFix": "",
                    "thousands": ",",
                    "lengthMenu": "显示 _MENU_ 条",
                    "loadingRecords": "数据加载中...",
                    "processing": "处理...",
                    "search": "搜索:",
                    "zeroRecords": "找不到相关数据",
                    "paginate": {
                        "first": "首页",
                        "last": "尾页",
                        "next": "下一页",
                        "previous": "前一页"
                    }
                },
                "lengthMenu": [ [10, 15, 20, 50, -1], [10, 15, 20, 50, "All"] ],
                "pageLength": 15,
                //aaSorting: [[ 1, 'asc' ]],
                "initComplete": function(settings, json) {
                    if(fnInitComplete){
                        fnInitComplete(settings, json);
                    }
                }
            });
        }
        return this;
    };

    /**
     * Build dataTable without request to server, instead retrieve data from UI client cache.
     * @param {Object} settings
     *                 -{String} url: url to post request to server
     *                 -{Object} requestData: request payload object
     *                 -{Function} fnInitComplete: call back function for table is finished initial
     * @returns {ServiceDataTable}
     */
    this.buildWithCache = function(settings){
        var _settings = $.extend(true, {}, {
            "language": {
                "decimal": "",
                "emptyTable": "没有数据",
                "info": "显示 _START_ 到 _END_   /共_TOTAL_ 条数据",
                "infoEmpty": "显示 0 条数据",
                "infoFiltered": "(总共 _MAX_ 条数据)",
                "infoPostFix": "",
                "thousands": ",",
                "lengthMenu": "显示 _MENU_ 条",
                "loadingRecords": "数据加载中...",
                "processing": "处理...",
                "search": "搜索:",
                "zeroRecords": "找不到相关数据",
                "paginate": {
                    "first": "首页",
                    "last": "尾页",
                    "next": "下一页",
                    "previous": "前一页"
                }
            },
            "initComplete": settings.initComplete,
            "lengthMenu": [ [5, 10, 15, 20, 50, -1], [5, 10, 15, 20, 50, "All"] ],
            "pageLength": settings.pageLength ? settings.pageLength:15,
            "scrollX": settings.scrollX ? settings.scrollX : false,
            "deferRender": true,
            processing: true
        },  settings);
        if ($.fn.dataTable.isDataTable($(this.table))) {
            this.datatable = $(this.table).DataTable();
            // in case dataTable already exist, call draw back directly
            if(settings && settings.tableExistedCallback){
                settings.tableExistedCallback();
            }
        } else {
            this.datatable = $(this.table).DataTable(_settings);
        }
        return this;
    };

    this.adjustColumns = function(){
        if(this.datatable && this.datatable.columns){
            this.datatable.columns.adjust();
        }
    };


    /**
     * Build dataTable with request to server.
     * @param {Object} settings
     *                 -{String} url: url to post request to server
     *                 -{Object} requestData: request payload object
     *                 -{Function} fnInitComplete: call back function for table is finished initial
     * @returns {ServiceDataTable}
     */
    this.buildWithServer = function(settings, fnXhr){
        var _settings = $.extend(true, {}, {
            "language": {
                "decimal": "",
                "emptyTable": "没有数据",
                "info": "显示 _START_ 到 _END_   /共_TOTAL_ 条数据",
                "infoEmpty": "显示 0 条数据",
                "infoFiltered": "(总共 _MAX_ 条数据)",
                "infoPostFix": "",
                "thousands": ",",
                "lengthMenu": "显示 _MENU_ 条",
                "loadingRecords": "数据加载中...",
                "processing": "处理...",
                "search": "搜索:",
                "zeroRecords": "找不到相关数据",
                "paginate": {
                    "first": "首页",
                    "last": "尾页",
                    "next": "下一页",
                    "previous": "前一页"
                }
            },
            "lengthMenu": [ [10, 15, 20, 50, -1], [10, 15, 20, 50, "All"] ],
            "pageLength": settings.pageLength ? settings.pageLength:15,
            "scrollX": settings.scrollX ? settings.scrollX : false,
            aaSorting: [[ 1, 'asc' ]],
            processing: true,
            serverSide: true,
            ajax: {
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: function(json){
                    //alert(json);
                },
                url: settings.ajax.url
            }
        },  settings);
        if ($.fn.dataTable.isDataTable($(this.table))) {
            this.datatable = $(this.table).DataTable();
            // in case dataTable already exist, call draw back directly
            if(settings && settings.tableExistedCallback){
                settings.tableExistedCallback();
            }
        } else {

            if(settings.fnXhr && typeof  settings.fnXhr === 'function'){
                var _finXhr = settings.fnXhr;
                this.datatable = $(this.table).on('xhr.dt', function ( e, tableSettings, json, xhr ) {
                    _finXhr(e, tableSettings, json, xhr);
                }).DataTable(_settings);
            }else{
                this.datatable = $(this.table).on('xhr.dt', function ( e, tableSettings, json, xhr ) {
                    if(json && json.errorCode && settings.errorHandle){
                        settings.errorHandle(json);
                    }
                    if(json && json.error && settings.errorHandle){
                        settings.errorHandle({errorMessage:json.error});
                    }
                    // in case json is null
                    if(xhr && xhr.status * 1 > 299){
                        settings.errorHandle(xhr);
                    }
                }).DataTable(_settings);
            }
        }
        return this;
    };

    this.deleteRow = function($row){

    };
}

ServiceDataTable.TABLE_ATTR = {
    ID_MESSAGE_UUID : 'tsMTableMessageUUID',
    CLASS_COLUMN_UUID : 'tsMTableColumnUUID',
    CLASS_COLUMN_EDIT : 'tsMTableColumnEdit',
    CLASS_COLUMN_DELETE : 'tsMTableColumnDelete',
    CLASS_COLUMN_EDITMODAL: 'tsMTableColumnEditModal',
    ATTR_VALUE: 'value'
};

/**
 * Constants for different type icon in table
 * @type {{ICON_DELETE: string, ICON_EDITMODAL: string, ICON_EDIT: string}}
 */
ServiceDataTable.ICON_CLASS = {
    ICON_DELETE: 'glyphicon glyphicon-trash content-peach-red',
    ICON_EDITMODAL: 'glyphicon glyphicon-search content-yellow',
    ICON_EDIT: 'glyphicon glyphicon-pencil content-green'
};


/**
 * Utility method to check something with loop and timeout
 * @param oSettings
 *    --{String} tableId: table Id
 *    --{Array} dataItemList: data list inside the table
 *    --{function} postCallback: call back method
 *
 */
ServiceDataTable.traverseCheckTableDataRender = function (oSettings){
    var dataItemList = oSettings.dataItemList;
    if( dataItemList ){
        ServiceUtilityHelper.traverseCheckTimeout({
            maxLimit:300,
            checkCallback: function(){
                // Here is the logic how to check table row is rendered or not
                var rowOne = $('#' + oSettings.tableId).children('tbody').find('tr');
                var rowTh = $('#' + oSettings.tableId).children('thead').find('tr');
                if(rowOne && rowOne.length > 0 && rowTh && rowTh.length > 0){
                    return true;
                }
            },
            postCallback: oSettings.postCallback
        });
    }

};

/**
 * Using default simple parameters to generate dataTable Settings
 * This settings is for Server side processing
 * @param {Object} settings
 *                 -{String} url: url to post request to server
 *                 -{Array} items: items reference from caller
 *                 -{Function} fnAjaxData: call back function for ajax data call back
 *                 -{Function} fnDeleteModule: call back function for delete single model from list
 *                 -{Function} fnEditModule: call back function for edit single model in normal from list
 *                 -{Function} fnEditModuleModal: call back function  for edit single model in normal from list
 *                 -{Function} fnDrawCallback: other type of call back function When draw table call back
 */
ServiceDataTable.genDefServerSettingsTemplate = function(oSettings){
    var vm = this;
    var _ajax = {url: oSettings.url};
    if(oSettings.fnAjaxData){
        _ajax.data = oSettings.fnAjaxData;
    }
    var _createdRow = function(row, data, dataIndex) {
        if(oSettings.items){
            var item = ServiceCollectionsHelper.filterArray(data.uuid, 'uuid', oSettings.items);
            if(item){
                item = data;
            }else{
                oSettings.items.push(data);
            }
        }
    };

    var _drawCallback = function (settings){
        if(oSettings.fnEditModule && typeof oSettings.fnEditModule === 'function'){
            var editClassArray = "." + ServiceDataTable.TABLE_ATTR.CLASS_COLUMN_UUID + ' .' + ServiceDataTable.TABLE_ATTR.CLASS_COLUMN_EDIT;
            $(editClassArray).on('click', function(){
                var $this = $(this);
                var uuid = $(this)[0].getAttribute("value");

                oSettings.fnEditModule(uuid, {'source':$(this)[0]});
            });
        }
        if(oSettings.fnEditModuleModal && typeof oSettings.fnEditModuleModal === 'function'){
            var editModalClassArray = "." + ServiceDataTable.TABLE_ATTR.CLASS_COLUMN_UUID + ' .' + ServiceDataTable.TABLE_ATTR.CLASS_COLUMN_EDITMODAL;
            $(editModalClassArray).on('click', function(){
                var $this = $(this);
                var uuid = $(this)[0].getAttribute("value");
                oSettings.fnEditModuleModal(uuid, {'source':$(this)[0]});
            });
        }
        if(oSettings.fnDeleteModule && typeof oSettings.fnDeleteModule === 'function'){
            var deleteClassArray = "." + ServiceDataTable.TABLE_ATTR.CLASS_COLUMN_UUID + ' .' + ServiceDataTable.TABLE_ATTR.CLASS_COLUMN_DELETE;
            $(deleteClassArray).on('click', function(){
                var $this = $(this);
                var uuid = $(this)[0].getAttribute("value");
                oSettings.fnDeleteModule(uuid, {'source':$(this)[0]});
            });
        }
        if(oSettings.fnDrawCallback && typeof oSettings.fnDrawCallback === 'function'){
            oSettings.fnDrawCallback();
        }
    };


    var settings = {
        ajax: _ajax,
        "bAutoWidth": false,
        "deferRender": true,
        'createdRow': _createdRow,
        "drawCallback": _drawCallback,
        "tableExistedCallback": oSettings.tableExistedCallback,
    };

    return settings;
};

ServiceDataTable.getDent = function(document){
    var adent = document.createTextNode(' ');
    return adent;
};

/**
 * Internal method: draw table cell inner html by tags list
 * @param tagsList
 * @returns {HTMLDivElement | *}
 */
ServiceDataTable._fnGenInnerHtml = function(tagsList){
    var i = 0, len = tagsList.length, codeUUID, codeUnion, ulElement;
    var maxLength = 4;
    ulElement = document.createElement('div');
    // ulElement.setAttribute('class', 'select2-selection__rendered');
    for (i = 0; i < len; i++) {
        if (i < maxLength) {
            var liElement = document.createElement('div');
            liElement.setAttribute('class', 'selection_choice');
            liElement.setAttribute('title', tagsList[i]);
            var textElement = document.createTextNode(tagsList[i] + ' ');
            liElement.appendChild(textElement);
            ulElement.appendChild(liElement);
        } else {
            var subElement = document.createElement('div');
            subElement.setAttribute('class', 'selection_element');
            var textNode = document.createTextNode(" ... ");
            subElement.appendChild(textNode);
            ulElement.appendChild(subElement);
            break;
        }
    }
    return ulElement;
};

/**
 * Service Table default way to draw Tags inside table
 * @param td:{Dom element}:Table td element
 * @param tagsList:{array} tags list
 */
ServiceDataTable.fnDrawTagsTd = function (td, tagsList) {
    "use strict";
    if (tagsList && tagsList.length > 0) {
        td.innerHTML = '';
        var ulElement = ServiceDataTable._fnGenInnerHtml(tagsList);
        td.appendChild(ulElement);
    }
};

/**
 * Provide default logic to get tagList
 * @param cellData
 * @returns {any}
 */
ServiceDataTable.getTagListBySeperator = function(cellData){
    "use strict";
    return cellData? cellData.split(','):null;
};

/**
 * Provide default logic to build the value - style class inner html for table cells.
 * @param document
 * @param td
 * @param value
 * @param valueClassMap
 * @param defaultClass
 */
ServiceDataTable.buildDefValueStyleTd = function(document, td, value, valueClassMap, defaultClass){
    "use strict";

    var classValue = defaultClass;
    if(valueClassMap && valueClassMap.length > 0){
        valueClassMap.forEach(function(valueClassPair){
            if(value == valueClassPair.value){
                if(valueClassPair.styleClass){
                    classValue = valueClassPair.styleClass;
                }
                if(valueClassPair.iconClass){
                    classValue = valueClassPair.iconClass;
                }
            }
            if(value == valueClassPair.id){
                if(valueClassPair.styleClass){
                    classValue = valueClassPair.styleClass;
                }
                if(valueClassPair.iconClass){
                    classValue = valueClassPair.iconClass;
                }
            }
        });
    }
    ServiceDataTable.buildValueStyleCore(document, td, classValue);
};

ServiceDataTable.buildDefTableLabel = function(label){
    $('a .edit').tooltip({title: label.editTitle});
    $('a .quickEdit').tooltip({title: label.quickEditTitle});
};

ServiceDataTable.buildValueStyleCore = function(document, td, classValue){
    "use strict";
    var adent = document.createTextNode(" ");
    var labelDom = document.createElement('label');
    labelDom.setAttribute("class", 'control-label');
    var iconElement = document.createElement('i');
    iconElement.setAttribute("class", classValue);
    labelDom.appendChild(iconElement);
    var _innerHtml = td.innerHTML;
    td.innerHTML = '';
    td.appendChild(iconElement);
    if (typeof _innerHtml === 'object') {
        td.appendChild(adent);
        td.appendChild(_innerHtml);
    }
    if (typeof  _innerHtml === 'string') {
        var textNode = document.createTextNode(_innerHtml);
        td.appendChild(adent);
        td.appendChild(textNode);
    }
};

ServiceDataTable.buildDefPriceInfoUnit = function(document, td, actionCodePrice, price){
    if(actionCodePrice === true){
        td.innerHTML = price;
        ServiceDataTable.buildValueStyleCore(document, td, 'nmd nmd-lock-outline content-red');
    }
};

/**
 * Provide default logic to build the value - style class inner html for table cells.
 * @param document
 * @param td
 * @param value
 * @param valueClassMap
 * @param defaultClass
 */
ServiceDataTable.buildPopDocumentUnion = function(td, documentType, documentId, uuidValue, oSettings){
    "use strict";
    var _innerHtml = td.innerHTML;

    var popoverElement = ServiceDOMUtilityHelper.createDefElement({
        element: 'pop-document-union'
    });
    popoverElement.setAttribute(":target-uid", uuidValue);
    popoverElement.setAttribute(":document-type", documentType);
    popoverElement.setAttribute(":document-id", documentId);
    td.innerHTML = '';
    td.appendChild(popoverElement);
};

/**
 * Provide default logic to build the value - style class inner html for table cells.
 * @param document
 * @param td
 * @param value
 * @param valueClassMap
 * @param defaultClass
 */
ServiceDataTable.buildDefPopoverElement = function(document, td, uuidValue, oSettings){
    "use strict";
    var _innerHtml = td.innerHTML;
    var popClass = (oSettings && oSettings.popClass)?oSettings.popClass: 'popover-info';
    var popoverElement = document.createElement('div');
    popoverElement.setAttribute("class", popClass);
    popoverElement.setAttribute("data-original-title", "");
    popoverElement.setAttribute("title", "");
    if(!!(_innerHtml && _innerHtml != "")){
        var popIconElement = document.createElement('i');
        popIconElement.setAttribute("class", "md md-chat content-green");
        popoverElement.appendChild(popIconElement);
    }

    var inputUUIDElement = document.createElement('input');
    inputUUIDElement.setAttribute("value", uuidValue);
    inputUUIDElement.setAttribute("class", 'input-UUID');
    inputUUIDElement.setAttribute("type", "hidden");
    popoverElement.appendChild(inputUUIDElement);

    if(oSettings && oSettings.documentTypeValue){
        var inputDocTypeElement = document.createElement('input');
        inputDocTypeElement.setAttribute("class", 'input-documentType');
        inputDocTypeElement.setAttribute("value", oSettings.documentTypeValue);
        inputDocTypeElement.setAttribute("type", "hidden");
        popoverElement.appendChild(inputDocTypeElement);
    }

    var seperate = document.createTextNode(' ');
    var innerText = document.createTextNode(_innerHtml);
    popoverElement.appendChild(seperate);
    popoverElement.appendChild(innerText);

    td.innerHTML = '';
    td.appendChild(popoverElement);
};

ServiceDataTable.getFirstColumnId = function(uuid){
    return ServiceDataTable.TABLE_ATTR.ID_MESSAGE_UUID + uuid;
};

/**
 * Generate default Table's first Column, including the edit, delete, editModal icon and ahref.
 * @param {Object} oSettings
 *                 -{Function} fnDeleteModule: call back function for delete single model from list
 *                 -{Function} fnEditModule: call back function for edit single model in normal from list
 *                 -{Function} fnEditModuleModal: call back function  for edit single model in normal from list
 * @param td
 * @param cellData
 * @param rowData
 * @param row
 * @param col
 */
ServiceDataTable.genDefFirstColumnContent = function(oSettings, td, cellData, rowData, row, directUUID){
    // Build common 'space' element
    "use strict";
    td.innerHTML = '';
    var aIndexNode = document.createTextNode(row + 1 + ' ');
    td.setAttribute("class", ServiceDataTable.TABLE_ATTR.CLASS_COLUMN_UUID);
    td.append(aIndexNode);
    var uuid = rowData['uuid'];
    if( directUUID ){
        uuid = directUUID;
    }

    if(oSettings.fnEditModule){
        var aEdithref = document.createElement('a');
        aEdithref.setAttribute("class", ServiceDataTable.TABLE_ATTR.CLASS_COLUMN_EDIT);
        var iconModelEdit = document.createElement('i');
        var iconClass = oSettings.fnEditIconClass ? oSettings.fnEditIconClass : ServiceDataTable.ICON_CLASS.ICON_EDIT;
        iconModelEdit.setAttribute("class", iconClass);
        if(oSettings.titleIconEdit){
            iconModelEdit.setAttribute("title", oSettings.titleIconEdit);
        }
        aEdithref.appendChild(ServiceDataTable.getDent(document));
        aEdithref.appendChild(iconModelEdit);
        aEdithref.appendChild(ServiceDataTable.getDent(document));

        aEdithref.setAttribute(ServiceDataTable.TABLE_ATTR.ATTR_VALUE, uuid);
        td.appendChild(aEdithref);
    }
    if(oSettings.fnEditModuleModal){
        var aEditModalhref = document.createElement('a');
        aEditModalhref.setAttribute("class", ServiceDataTable.TABLE_ATTR.CLASS_COLUMN_EDITMODAL);
        var iconModelEditModal = document.createElement('i');
        iconModelEditModal.setAttribute("class", ServiceDataTable.ICON_CLASS.ICON_EDITMODAL);
        if(oSettings.titleIconEditModal){
            iconModelEditModal.setAttribute("title", oSettings.titleIconEditModal);
        }
        aEditModalhref.appendChild(ServiceDataTable.getDent(document));
        aEditModalhref.appendChild(iconModelEditModal);
        aEditModalhref.appendChild(ServiceDataTable.getDent(document));
        aEditModalhref.setAttribute(ServiceDataTable.TABLE_ATTR.ATTR_VALUE, uuid);
        td.appendChild(aEditModalhref);
        td.appendChild(ServiceDataTable.getDent(document));
    }
    if(oSettings.fnDeleteModule){
        var aDeletehref = document.createElement('a');
        aDeletehref.setAttribute("class", ServiceDataTable.TABLE_ATTR.CLASS_COLUMN_DELETE);
        aDeletehref.setAttribute("v-if", "author.actionCode.Delete === true");
        var iconModelDelete = document.createElement('i');
        iconModelDelete.setAttribute("class", ServiceDataTable.ICON_CLASS.ICON_DELETE);
        if(oSettings.titleIconDelete){
            iconModelDelete.setAttribute("title", oSettings.titleIconDelete);
        }

        aDeletehref.appendChild(iconModelDelete);
        aDeletehref.appendChild(ServiceDataTable.getDent(document));
        aDeletehref.setAttribute(ServiceDataTable.TABLE_ATTR.ATTR_VALUE, uuid);
        td.appendChild(aDeletehref);
        td.appendChild(ServiceDataTable.getDent(document));
    }

    var containerId = ServiceDataTable.getFirstColumnId(uuid);
    var messageHook = ServiceDOMUtilityHelper.createDefElement({
        element: 'span',
        id:containerId
    });
    td.append(messageHook);



};
