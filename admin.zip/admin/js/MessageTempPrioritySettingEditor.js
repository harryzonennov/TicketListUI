var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: {
            iconStyle: '',
            endValue: '',
            colorStyle: '',
            startValue: '',
            priorityCode: '',
            actionCode:'',
            fieldName: '',
            logicOperator: '',
            searchOperator: '',
            messageLevelCode:'',
            fieldValue: '',
            note: '',
            messageTitle:'',
            messageContent:'',
            dataSourceProviderId:'',
            refPrioritySettingUUID: '',
            addMessageTempPrioritySetting: '',
            addSystemCodeValueCollection: '',
            parentPageTitle:'',
            dataOffsetUnit:'',
            dataOffsetValue:'',
            dataOffsetDirection:'',
            pageTitle:'',
            messageTempPrioritySettingSection: '',
            systemCodeValueCollectionSection: '',
            msgSaveOK: '',
            msgSaveOKComment: '',
            msgConnectFailure: '',
            msgUnknowSystemFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            save: '',
            quickEdit: '',
            buttonDelete: '',
            exit: '',
            close: '',
            deleteWarnTitle: '',
            deleteWarnText: '',
            cancel: '',
            commit: '',
            confirm: ''
        },
        content: {
            parentNodeUUID:'',
            uuid: '',
            client: '',
            iconStyle: '',
            parentNodeId: '',
            messageTitle:'',
            messageContent:'',
            messageLevelCode:'',
            dataOffsetUnit:'',
            dataOffsetValue:'',
            actionCode:'',
            dataOffsetDirection:'',
            dataSourceProviderId:'',
            endValue: '',
            colorStyle: '',
            startValue: '',
            priorityCode: '',
            refPrioritySettingUUID: ''
        },
        author: {
            resourceId: ServiceModuleConstants.MessageTemplate,
            actionCode: {
                Edit: false,
                View: false,
                PriceInfo: false,
                Delete: false,
                Excel: false
            }
        },
        meta:{
            providerOffsetUnitVisible: false,
            providerOffsetValueVisible: false,
            providerOffsetDirection:false
        },
        eleFieldName: '#x_fieldName',
        eleDataProvider: '#x_dataProvider',
        eleProviderOffsetUnit: '#x_providerOffsetUnit',
        eleProviderDirection: '#x_providerOffsetDirection',
        eleLogicOperator: '#x_logicOperator',
        eleMessageLevelCode: '#x_messageLevelCode',
        eleActionCode:'#x_actionCode',
        eleRefPrioritySettingUUID: '#x_refPrioritySettingUUID',
        getPageHeaderModelListURL: '../messageTempPrioritySetting/getPageHeaderModelList.html',
        loadModuleEditURL: '../messageTempPrioritySetting/loadModuleEditService.html',
        getLogicOperatorURL: '../messageTempSearchCondition/getLogicOperator.html',
        getMessageLevelCodeURL: '../messageTempPrioritySetting/getMessageLevelCode.html',
        getExtActionCodeMapURL: '../messageTempPrioritySetting/getExtActionCodeMap.html',
        saveModuleURL: '../messageTempPrioritySetting/saveModuleService.html',
        exitModuleURL: '../messageTempPrioritySetting/exitEditor.html',
        newModuleServiceURL: '../messageTempPrioritySetting/newModuleService.html',
        getSearchFieldNameListURL: '../messageTempSearchCondition/getSearchFieldNameList.html',
        getDataProviderMapURL: '../messageTemplate/getDataProviderMap.html',
        getProviderOffsetUnitURL: '../messageTemplate/getProviderOffsetUnit.html',
        getProviderOffsetDirectionURL: '../messageTemplate/getProviderOffsetDirection.html',
        getProviderOffsetDirectionTemplateURL: '../messageTemplate/getProviderOffsetDirectionTemplate.html',
        getProviderOffsetUnitTemplateURL:'../messageTemplate/getProviderOffsetUnitTemplate.html',
        loadSystemCodeValueCollectionSelectListURL: '../systemCodeValueCollection/loadModuleListService',
        loadSystemCodeValueCollectionURL: '../ssystemCodeValueCollection/loadModule.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
        vm.initAuthorResourceCheck();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'MessageTemplate');
            this.setI18nProperties();
            this.loadModuleEdit();
            this.initSelectConfigure();
        });
    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function () {
            "use strict";
            Vue.component("page-header-union", PageHeaderUnion);
        },


        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.quickEdit = $.i18n.prop('quickEdit');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.deleteWarnTitle = $.i18n.prop('deleteWarnTitle');
            this.label.deleteWarnText = $.i18n.prop('deleteWarnText');
            this.label.cancel = $.i18n.prop('cancel');
            this.label.commit = $.i18n.prop('commit');
            this.label.confirm = $.i18n.prop('confirm');
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            this.label.iconStyle = $.i18n.prop('iconStyle');
            this.label.endValue = $.i18n.prop('endValue');
            this.label.colorStyle = $.i18n.prop('colorStyle');
            this.label.startValue = $.i18n.prop('startValue');
            this.label.priorityCode = $.i18n.prop('priorityCode');
            this.label.refPrioritySettingUUID = $.i18n.prop('refPrioritySettingUUID');
            this.label.parentPageTitle = $.i18n.prop('parentPageTitle');
            this.label.pageTitle = $.i18n.prop('pageTitle');
            this.label.fieldName = $.i18n.prop('fieldName');
            this.label.messageLevelCode = $.i18n.prop('messageLevelCode');
            this.label.logicOperator = $.i18n.prop('logicOperator');
            this.label.searchOperator = $.i18n.prop('searchOperator');
            this.label.fieldValue = $.i18n.prop('fieldValue');
            this.label.messageTitle = $.i18n.prop('messageTitle');
            this.label.actionCode = $.i18n.prop('actionCode');
            this.label.messageContent = $.i18n.prop('messageContent');
            this.label.dataSourceProviderId = $.i18n.prop('dataSourceProviderId');
            this.label.dataOffsetUnit = $.i18n.prop('dataOffsetUnit');
            this.label.dataOffsetValue = $.i18n.prop('dataOffsetValue');
            this.label.dataOffsetDirection = $.i18n.prop('dataOffsetDirection');
            this.label.addMessageTempPrioritySetting = $.i18n.prop('addMessageTempPrioritySetting');
            this.label.addSystemCodeValueCollection = $.i18n.prop('addSystemCodeValueCollection');
            this.label.messageTempPrioritySettingSection = $.i18n.prop('messageTempPrioritySettingSection');
            this.label.systemCodeValueCollectionSection = $.i18n.prop('systemCodeValueCollectionSection');

        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'MessageTempPrioritySetting', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleRefPrioritySettingUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refPrioritySettingUUID', $(vm.eleRefPrioritySettingUUID).val());
                var url = vm.loadSystemCodeValueCollectionURL + "?uuid=" + $(vm.eleRefPrioritySettingUUID).val();
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                }.bind(this));
            });
            $(vm.eleLogicOperator).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'logicOperator', $(vm.eleLogicOperator).val());
            });
            $(vm.eleMessageLevelCode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'messageLevelCode', $(vm.eleMessageLevelCode).val());
            });
            $(vm.eleFieldName).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'fieldName', $(vm.eleFieldName).val());
            });
            $(vm.eleDataProvider).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                var providerId = $(vm.eleDataProvider).val();
                vm.$set(vm.content, 'dataSourceProviderId', providerId);
                vm.getProviderOffsetUnit(providerId);
                vm.getProviderOffsetDirection(providerId);
            });
            $(vm.eleProviderDirection).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'dataOffsetDirection', $(vm.eleProviderDirection).val());
            });
            $(vm.eleProviderOffsetUnit).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'dataOffsetUnit', $(vm.eleProviderOffsetUnit).val());
            });
            $(vm.eleActionCode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'actionCode', $(vm.eleActionCode).val());
            });

        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            if (processMode === PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                ServiceUtilityHelper.httpRequest({
                    url:this.newModuleServiceURL,
                    $http:vm.$http,
                    method:'post',
                    requestData: requestData,
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        this.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if (processMode === PROCESSMODE_EDIT) {
// In case [Edit mode]
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    errorHandle:vm.errorHandle,
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }
        },

        getPageHeaderModelList: function(uuid, baseUUID){
            var vm = this;
            vm.$refs.pageHeader.initPageHeader({
                uuid:uuid,
                baseUUID: baseUUID,
                pageHeaderListUrl:vm.getPageHeaderModelListURL,
                fnPageHeaderModel:vm.fnPageHeaderModel
            });
        },

        fnPageHeaderModel:function(pageHeaderModel){
            var vm = this;
            if (pageHeaderModel.nodeInstId === 'messageTemplate'){
                var targetTab = MessageTempPriorityManager.documentTab.messageTempPrioritySection;
                baseDocURL = genCommonEditURL("MessageTemplateEditor.html", pageHeaderModel.uuid, targetTab);
                pageHeaderModel.pageLink = baseDocURL;
                pageHeaderModel.pageTitle = vm.label.parentPageTitle + ":" + vm.content.parentNodeId;
                return pageHeaderModel;
            }
        },

        saveModule: function () {
            var vm = this;
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            ServiceUtilityHelper.httpRequest({
                url:this.saveModuleURL,
                $http:vm.$http,
                method:'post',
                requestData: vm.content,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    $.Notification.notify('success', 'top center', vm.label.msgSaveOK, vm.label.msgSaveOKComment);
                    vm.setModuleToUI(oData.content);
                    var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
                    if (processMode && processMode === PROCESSMODE_NEW) {
                        var baseUUID = vm.content.uuid;
                        if (baseUUID) {
                            window.location.href = genCommonEditURL("MessageTempPrioritySettingEditor.html", baseUUID);
                        }
                    }
                }.bind(this)
            });
        },

        getSearchFieldNameList: function (content) {
            var vm = this;
            var baseUUID = vm.content.parentNodeUUID;
            this.$http.get(this.getSearchFieldNameListURL + "?baseUUID=" + baseUUID).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    return;
                }
                var resultList = formatSelectResult(oData.content, 'fieldName', 'fieldName');
                setTimeout(function () {
                    $(vm.eleFieldName).select2({
                        data: resultList,
                    });
                    // manually set initial value
                    $(vm.eleFieldName).val(content.fieldName);
                    $(vm.eleFieldName).trigger("change");
                }, 0);
            });
        },

        getDataProvider: function (content) {
            var vm = this;
            this.$http.get(this.getDataProviderMapURL).then(function (response) {
                var oData = JSON.parse(response.data);
                setTimeout(function () {
                    $(vm.eleDataProvider).select2({
                        data: oData
                    });
                    // manually set initial value
                    $(vm.eleDataProvider).val(content.dataSourceProviderId);
                    $(vm.eleDataProvider).trigger("change");
                    // Also trigger
                    vm.getProviderOffsetUnit(content.dataSourceProviderId);
                    vm.getProviderOffsetDirection(content.dataSourceProviderId);
                }, 0);
            });
        },

        getProviderOffsetDirection: function (providerId) {
            var vm = this;
            var metaSettings = {metaUrl:this.getProviderOffsetDirectionTemplateURL, $http:vm.$http};
            var directionTemplatePromise = MessageTempPriorityManager.getProviderMetaTemplate(providerId, metaSettings);
            this.$http.get(this.getProviderOffsetDirectionURL + "?providerId=" + providerId).then(function (response) {
                var oData = JSON.parse(response.data);
                if(oData && oData.length > 0){
                    vm.$set(vm.meta, 'providerOffsetValueVisible', true);
                    vm.$set(vm.meta, 'providerOffsetDirectionVisible', true);
                }
                directionTemplatePromise.then(function(metaTemplate){
                    setTimeout(function () {
                        $(vm.eleProviderDirection).select2({
                            data: oData,
                            templateResult:metaTemplate,
                            templateSelection:metaTemplate
                        });
                        // manually set initial value
                        $(vm.eleProviderDirection).val(vm.content.dataOffsetDirection);
                        $(vm.eleProviderDirection).trigger("change");
                    }, 0);
                });
            });
        },


        getProviderOffsetUnit: function (providerId) {
            var vm = this;
            var metaSettings = {metaUrl:this.getProviderOffsetUnitTemplateURL, $http:vm.$http};
            var offsetUnitTemplatePromise = MessageTempPriorityManager.getProviderMetaTemplate(providerId, metaSettings);
            this.$http.get(this.getProviderOffsetUnitURL + "?providerId=" + providerId).then(function (response) {
                var oData = JSON.parse(response.data);
                offsetUnitTemplatePromise.then(function(metaTemplate){
                    setTimeout(function () {
                        $(vm.eleProviderOffsetUnit).select2({
                            data: oData,
                            templateResult:metaTemplate,
                            templateSelection:metaTemplate
                        });
                        if(oData && oData.length > 0){
                            vm.$set(vm.meta, 'providerOffsetUnitVisible', true);
                        }
                        // manually set initial value
                        $(vm.eleProviderOffsetUnit).val(vm.content.dataOffsetUnit);
                        $(vm.eleProviderOffsetUnit).trigger("change");
                    }, 0);
                });

            }.bind(this));
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.parentNodeUUID;
            window.location.href = genCommonEditURL("MessageTemplateEditor.html", baseUUID);
        },

        refreshEditView: function () {
            var baseUUID = this.content.uuid;
            window.location.href = genCommonEditURL("MessageTempPrioritySettingEditor.html", baseUUID);
        },

        getLogicOperator: function () {
            var vm = this;
            ServiceUtilityHelper.loadMetaRequest({
                url: vm.getLogicOperatorURL,
                $http: vm.$http,
                formatMeta:SystemStandrdMetadataProxy.formatLogicOperator,
                initValue: vm.content.logicOperator,
                element: vm.eleLogicOperator,
                errorHandle: vm.errorHandle
            });
        },

        getMessageLevelCode: function () {
            var vm = this;
            ServiceUtilityHelper.loadMetaRequest({
                url: vm.getMessageLevelCodeURL,
                $http: vm.$http,
                formatMeta:MessageTempPriorityManager.formatMessageLevel,
                initValue: vm.content.messageLevelCode,
                element: vm.eleMessageLevelCode,
                errorHandle: vm.errorHandle
            });
        },

        getActionCode: function () {
            var vm = this;
            ServiceUtilityHelper.loadMetaRequest({
                url: vm.getExtActionCodeMapURL,
                $http: vm.$http,
                initValue: vm.content.actionCode,
                formatMeta:ServiceUtilityHelper.formatActionCode,
                element: vm.eleActionCode,
                errorHandle: vm.errorHandle
            });
        },

        loadSystemCodeValueCollectionSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadSystemCodeValueCollectionSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleRefPrioritySettingUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefPrioritySettingUUID).val(content.refPrioritySettingUUID);
                    $(vm.eleRefPrioritySettingUUID).trigger("change");
                }, 0);
            });


        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm, 'content', content);
            vm.getPageHeaderModelList(content.uuid, content.parentNodeUUID);
            vm.loadSystemCodeValueCollectionSelectList(content);
            //this.setPageHeaderLink();
            this.getLogicOperator(content);
            vm.getSearchFieldNameList(content);
            vm.getDataProvider(content);
            vm.getMessageLevelCode(content);
            vm.getActionCode();

        }

    }
});
