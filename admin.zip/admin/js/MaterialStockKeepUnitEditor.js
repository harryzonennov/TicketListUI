var dataVar = new Vue({
    el: "#x_data",
    mixins: [MaterialStockKeepUnitManager.labelTemplate, SerDocumentControlHelper.defControlMinxin],
    data: {
        label: MaterialStockKeepUnitManager.label.materialStockKeepUnit,
        content: {
            materialStockKeepUnitUIModel: MaterialStockKeepUnitManager.content.materialStockKeepUnitUIModel,
            materialSKUUnitUIModelList: [],
            materialSKUAttachmentUIModelList: []
        },
        executeDocActionURL: '../materialStockKeepUnit/executeDocAction.html',
        getDocActionConfigureListURL: '../materialStockKeepUnit/getDocActionConfigureList.html',
        getActionCodeMapURL:'../materialStockKeepUnit/getActionCodeMap.html',
        searchStandardUnitURL: '../standardMaterialUnit/searchModuleService.html',
        newModuleServiceURL: '../materialStockKeepUnit/newModuleService.html',
        newMaterialUnitServiceURL: '../materialUnit/newModuleService.html',
        loadStandardUnitSelectListURL: '../material/getStandardUnit.html',
        loadMaterialCategoryURL: '../material/getMaterialCategory.html',
        loadPackageMaterialTypeURL: '../material/getPackageMaterialType.html',
        loadMaterialTypeURL: '../materialType/loadModule.html',
        exitURL: 'MaterialStockKeepUnitList.html'
    },


    mounted: function () {
        NavigationPanelIns.initNavigation('logistics', 'MaterialStockKeepUnit');
    },

    methods: {

        initSubComponents: function () {
            "use strict";
            var vm = this;
            vm.initSubComponentService();
            vm.initSubComponentDoc();
            Vue.component("material-sku-unit-panel", MaterialSkuUnitPanel);
        },

        /**
         * @Overwrite: Get document type for each edit controller
         */
        getDocumentType: function () {
            return DocumentConstants.DummyDocumentType.MaterialStockKeepUnit;
        },

        getServiceManager: function () {
            return MaterialStockKeepUnitManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "MaterialStockKeepUnitEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.materialStockKeepUnitUIModel.uuid;
        },

        /**
         * @Overwrite: get document status from content
         */
        getStatus: function () {
            return this.content.materialStockKeepUnitUIModel.status;
        },

        /**
         * @Overwrite get document action code icon map
         * @return {*}
         */
        getActionCodeIconMap: function(){
            return MaterialStockKeepUnitManager.getActionCodeIconMap();
        },

        /**
         * @Overwrite provide doc action code matrix
         * @return {*}
         */
        getActionCodeMatrix: function () {
            return {
                submit: {actionCode: MaterialStockKeepUnitManager.DOC_ACTION_CODE.SUBMIT},
                revokeSubmit: {actionCode: MaterialStockKeepUnitManager.DOC_ACTION_CODE.REVOKE_SUBMIT},
                approve: {actionCode: MaterialStockKeepUnitManager.DOC_ACTION_CODE.APPROVE},
                active: {actionCode: MaterialStockKeepUnitManager.DOC_ACTION_CODE.ACTIVE},
                rejectApprove: {actionCode: MaterialStockKeepUnitManager.DOC_ACTION_CODE.REJECT_APPROVE},
                processDone: {actionCode: MaterialStockKeepUnitManager.DOC_ACTION_CODE.PROCESS_DONE},
                reInit: {actionCode: MaterialStockKeepUnitManager.DOC_ACTION_CODE.REINIT},
                archive: {actionCode: MaterialStockKeepUnitManager.DOC_ACTION_CODE.ARCHIVE}
            };
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'materialStockKeepUnitUIModel', content.materialStockKeepUnitUIModel);
            vm.$set(vm.content, 'materialSKUUnitUIModelList', content.materialSKUUnitUIModelList);
            vm.$set(vm.content, 'materialSKUAttachmentUIModelList', content.materialSKUAttachmentUIModelList);
            vm.postUpdateUIModel();
        },
        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'MaterialStockKeepUnitEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: MaterialStockKeepUnitManager,
                coreModelId: 'MaterialStockKeepUnit',
                i18nPath: 'coreFunction/',
                getDocActionNodeListURL: '../material/getDocActionNodeList.html',
                helpDocumentName: ['MaterialStockKeepUnitHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: 'displayForEdit',
                        callback: 'saveModule'
                    },
                    placeholder: {
                        category: ProcessButtonConstants.placeholderCategory.DOC_ACTION_BTN
                    },
                    exit: {
                        callback: 'exitModule'
                    }
                },
                tabMetaList: [{
                    tabId: 'materialSection',
                    tabTitleKey: 'materialSection',
                    titleLabelKey: 'materialSection',
                    titleHelpKey: 'materialStockKeepUnit.materialSection',
                    titleIcon: 'md md-texture content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'materialSection',
                        updatedByUidPath: 'updatedByUUID',
                        updatedByNamePath: 'updatedByName',
                        updatedDatePath: 'updatedDate',
                        messageResponsePath: 'meta.messageResponse',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'materialStockKeepUnitUIModel',
                        tabTitleKey: 'materialSection',
                        titleLabelKey: 'materialSection',
                        titleHelpKey: 'materialStockKeepUnit.materialSection',
                        titleIcon: 'md md-texture content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'refMaterialId',
                            labelKey: 'refMaterialId',
                            disabled: true,
                            newRow: true,
                            popupConfigure: {
                                popupLabelClass: "popup-material",
                                documentFunction: "getDocumentPopoverContent",
                                documentType: "Material",
                                targetUidPath: 'refMaterialUUID',
                                popupTitlePath: 'refMaterialName',
                                headerTitlePath: 'refMaterialName'
                            },
                        }, {
                            disabled: true,
                            fieldName: 'refMaterialName',
                        }, {
                            fieldName: 'id',
                            required: true,
                            newRow: true
                        }, {
                            required: true,
                            fieldName: 'name',
                        }, {
                            fieldName: 'packageStandard',
                        }, {
                            fieldName: 'materialTypeName',
                            labelKey: 'refMaterialTypeName',
                            disabled: true,
                            newRow: true,
                            popupConfigure: {
                                popupLabelClass: "popup-material-sku",
                                documentFunction: "getDocumentPopoverContent",
                                documentType: "MaterialType",
                                targetUidPath: 'refMaterialType',
                                popupTitlePath: 'refMaterialTypeName',
                                headerTitlePath: 'refMaterialTypeName'
                            },
                        }, {
                            disabled: true,
                            labelKey: 'cargoType',
                            fieldName: 'cargoTypeValue',
                        }, {
                            fieldName: 'status',
                            disabled: true,
                            helpKey: 'materialStockKeepUnit.status',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getStatusURL,
                                formatMeta: 'formatStatus'
                            },
                            iconArray: 'getStatusIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        }]
                    }, {
                        sectionId: 'materialAttachment',
                        sectionCategory: AsyncSection.sectionCategory.ATTACHMENT,
                        parentContentPath: 'materialSKUAttachmentUIModelList',
                        errorHandle: 'errorHandle',
                        settings: {
                            configMetaPath: 'attachmentMeta'
                        }
                    }]
                }, {
                    tabId: 'materialSizeSection',
                    tabTitleKey: 'materialSizeSection',
                    titleHelpKey: 'materialSizeSection',
                    titleLabelKey: 'materialSizeSection',
                    titleIcon: 'md md-straighten content-portlet-title',
                    sectionMetaList: [
                        {
                            sectionId: 'materialSizeSection',
                            sectionCategory: AsyncSection.sectionCategory.EDIT,
                            parentContentPath: 'materialStockKeepUnitUIModel',
                            tabTitleKey: 'materialSection',
                            titleLabelKey: 'materialSection',
                            titleHelpKey: 'materialStockKeepUnit.materialSection',
                            titleIcon: 'md md-straighten content-portlet-title',
                            disabled: 'disableNotInInit',
                            fieldMetaList: [{
                                fieldName: 'mainMaterialUnitName',
                                labelKey: 'mainMaterialUnit',
                                required: true,
                                newRow: true,
                                settings: {
                                    getMetaDataUrl: vm.loadStandardUnitSelectListURL,
                                    idField: 'uuid',
                                    textField: 'name',
                                    formatMeta: SystemStandrdMetadataProxy.formatCargoType
                                },
                                fieldType: AbsInput.FIELDTYPE.TypeAhead
                            }, {
                                fieldName: 'packageMaterialType',
                                settings: {
                                    getMetaDataUrl: MaterialManager.constants.loadPackageMaterialTypeURL,
                                },
                                fieldType: AbsInput.FIELDTYPE.Select2
                            }, {
                                fieldName: 'length',
                                newRow: true,
                                postFieldMeta: [{
                                    fieldName: 'refLengthUnit',
                                    settings: {
                                        getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                        requestData: {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.LENGTH},
                                        method: 'post',
                                        idField: 'uuid',
                                        textField: 'name'
                                    },
                                    fieldType: AbsInput.FIELDTYPE.Select2
                                }]
                            }, {
                                fieldName: 'width',
                            }, {
                                fieldName: 'height',
                            }, {
                                fieldName: 'volume',
                                newRow: true,
                                postFieldMeta: [{
                                    fieldName: 'refVolumeUnit',
                                    settings: {
                                        getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                        requestData: {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.VOLUME},
                                        method: 'post',
                                        idField: 'uuid',
                                        textField: 'name'
                                    },
                                    fieldType: AbsInput.FIELDTYPE.Select2
                                }]
                            }, {
                                fieldName: 'netWeight',
                                postFieldMeta: [{
                                    fieldName: 'refWeightUnit',
                                    settings: {
                                        getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                        requestData: {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.WEIGHT},
                                        method: 'post',
                                        idField: 'uuid',
                                        textField: 'name'
                                    },
                                    fieldType: AbsInput.FIELDTYPE.Select2
                                }]
                            }, {
                                fieldName: 'grossWeight'
                            }, {
                                fieldName: 'minStoreNumber'
                            }]
                        },
                        {
                            sectionId: 'materialPriceSection',
                            sectionCategory: AsyncSection.sectionCategory.EDIT,
                            parentContentPath: 'materialStockKeepUnitUIModel',
                            tabTitleKey: 'materialPriceSection',
                            titleLabelKey: 'materialPriceSection',
                            titleHelpKey: 'materialStockKeepUnit.materialPriceSection',
                            titleIcon: 'md md-attach-money content-portlet-title',
                            disabled: 'disableNotInInit',
                            fieldMetaList: [{
                                fieldName: 'purchasePrice',
                                newRow: true,
                                helpKey: 'materialStockKeepUnit.purchasePrice'
                            }, {
                                fieldName: 'purchasePriceDisplay',
                                helpKey: 'materialStockKeepUnit.purchasePriceDisplay'
                            }, {
                                fieldName: 'retailPrice',
                                newRow: true,
                                helpKey: 'materialStockKeepUnit.retailPrice'
                            }, {
                                fieldName: 'retailPriceDisplay',
                                helpKey: 'materialStockKeepUnit.retailPriceDisplay'
                            }, {
                                fieldName: 'unitCost',
                                newRow: true,
                                helpKey: 'materialStockKeepUnit.unitCost'
                            }, {
                                fieldName: 'unitCostDisplay',
                                helpKey: 'materialStockKeepUnit.unitCostDisplay'
                            }]
                        }
                    ]
                }, {
                    tabId: 'materialProductionSection',
                    tabTitleKey: 'materialProductionSection',
                    titleLabelKey: 'materialProductionSection',
                    titleHelpKey: 'materialStockKeepUnit.materialProductionSection',
                    titleIcon: 'md md-alarm-on  content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'materialCategory',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'materialStockKeepUnitUIModel',
                        tabTitleKey: 'materialProductionSection',
                        titleLabelKey: 'materialProductionSection',
                        titleHelpKey: 'materialStockKeepUnit.materialProductionSection',
                        titleIcon: 'md md-alarm-on  content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'materialCategory',
                            newRow: true,
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.loadMaterialCategoryURL,
                                formatMeta: MaterialManager.formatMaterialCategory
                            },
                            helpKey: 'materialStockKeepUnit.materialCategory',
                            iconArray: MaterialManager.getMaterialCategoryIconArray(),
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'supplyType',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getSupplyTypeURL,
                                formatMeta: MaterialManager.formatSupplyType
                            },
                            helpKey: 'materialStockKeepUnit.supplyType',
                            iconArray: MaterialManager.getSupplyTypeIconArray(),
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'qualityInspectFlag',
                            helpKey: 'materialStockKeepUnit.qualityInspectFlag',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getQualityInspectFlagMapURL,
                                formatMeta: SystemStandrdMetadataProxy.formatDefaultSwitchCode,
                            },
                            iconArray: SystemStandrdMetadataProxy.getDefaultSwitchIconArray(),
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            refControl: {
                                id: RefControl.Ids.Separator
                            }
                        }, {
                            fieldName: 'fixLeadTime',
                            newRow: true,
                            helpKey: 'materialStockKeepUnit.fixLeadTime',
                            helpBlockKey: 'fixLeadTimeTitle'
                        }, {
                            fieldName: 'variableLeadTime',
                            helpKey: 'materialStockKeepUnit.variableLeadTime',
                            helpBlockKey: 'variableLeadTimeTitle'
                        }, {
                            fieldName: 'amountForVarLeadTime',
                            helpKey: 'materialStockKeepUnit.amountForVarLeadTime',
                            helpBlockKey: 'amountForVarLeadTimeTitle'
                        }, {
                            fieldName: 'traceMode',
                            helpKey: 'materialStockKeepUnit.traceMode',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.loadTraceModeListURL,
                                formatMeta: 'formatTraceModeIconClass',
                            },
                            iconArray: 'getTraceModeArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        },{
                            fieldName: 'operationMode',
                            helpKey: 'materialStockKeepUnit.operationMode',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getOperationModeURL,
                                formatMeta: 'formatOperationMode',
                            },
                            iconArray: 'getOperationModeIconMap',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }]
                    }]
                }, {
                    tabId: 'materialUnitSection',
                    tabTitleKey: 'materialUnitSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'materialUnitSection',
                        parentContentPath: 'materialSKUUnitUIModelList',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        editModule: 'editMaterialUnit',
                        refItemName: 'materialSkuUnitPanel',
                        editModuleFlag: true,
                        editModuleModalFlag: true,
                        deleteModuleFlag:'checkEditInInit',
                        deleteModuleUrl:'../materialSKUUnit/deleteModule.html',
                        detailedPageUrl:'MaterialSKUUnitEditor.html',
                        tabTitleKey: 'materialUnitSection',
                        titleLabelKey: 'materialUnitSection',
                        titleHelpKey: 'materialStockKeepUnit.materialUnitSection',
                        titleIcon: 'md md-my-library-books content-portlet-title',
                        scrollX: true,
                        embedProcessButtonMeta: {
                            addDisableFlag: 'disableNotInInit',
                            addTitle: 'addMaterialUnitTitle',
                            newModuleFlag: true,
                            addLabel: 'addMaterialUnit'
                        },
                        fieldMetaList: [{
                            fieldName: 'materialSKUUnitUIModel.uuid'
                        }, {
                            fieldName: 'materialSKUUnitUIModel.unitName',
                            labelKey: 'materialSKUUnit.unitName',
                            minWidth: '180px'
                        }, {
                            fieldName: 'materialSKUUnitUIModel.ratioToStandard',
                            labelKey: 'materialSKUUnit.ratioToStandard',
                            minWidth: '180px'
                        }, {
                            fieldName: 'materialSKUUnitUIModel.retailPrice',
                            labelKey: 'materialSKUUnit.retailPrice',
                        }, {
                            fieldName: 'materialSKUUnitUIModel.netWeight',
                            labelKey: 'materialSKUUnit.netWeight',
                        }, {
                            fieldName: 'materialSKUUnitUIModel.note',
                            labelKey: 'materialSKUUnit.note',
                            minWidth: '180px'
                        }]
                    }]
                }]
            };
        }

    }
});
