/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var MessageTempPriorityManager = function () {

};
/**
 * Definition of Tab on UI
 * @type {{}}
 */
MessageTempPriorityManager.documentTab = {
    messageTempPrioritySection: 'tabMessageTempPrioritySection',
    messageTemplateSection: 'tabMessageTemplateSection',
};


MessageTempPriorityManager.getMessageLevelCodeIconArray = function () {
    "use strict";
    return MessageConstant.getMessageLevelCodeIconArray();
};

MessageTempPriorityManager.formatMessageLevelCodeIconClass = function (messageLevel) {
    "use strict";
    return MessageConstant.formatMessageLevelCodeIconClass(messageLevel);
};

MessageTempPriorityManager.formatMessageLevel = function (messageLevel) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(messageLevel, MessageTempPriorityManager.getMessageLevelCodeIconArray(), true);
    return $element;
};



MessageTempPriorityManager.getProviderMetaTemplate = function (providerId, oSettings) {
    var promise = new Promise(function(resolve){
        oSettings.$http.get(oSettings.metaUrl + "?providerId=" + providerId).then(function (response) {
            var oData = JSON.parse(response.data);
            if(!oData){
                resolve();
            }
            oData.forEach(function(iconUnion){
                iconUnion.iconClass = iconUnion.text;
            });
            var convertTemplate = function (status) {
                var $element = ServiceUtilityHelper.formatSelectWithIcon(status, oData, true);
                return $element;
            };
            resolve(convertTemplate);
        }).catch(function(){
            resolve();
        });
    }.bind(this));
    return promise;
};
