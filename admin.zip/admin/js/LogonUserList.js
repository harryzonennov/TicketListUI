var processModel = new Vue({
    el:"#x_process_model",
    data:{
        label:{
            add: '',
            search: ''
        },
        author: {
            resourceId: ServiceModuleConstants.LogonUser,
            actionCode: {
                Edit:false,
                PriceInfo: false,
                AuditDoc: false,
                View:false,
                Delete: false,
                Excel:false
            }
        },
        processButtonMeta:[],
        searchModuleURL: '../logonUser/searchModuleService.html'
    },

    created: function(){
        this.initAuthorResourceCheck();
        this.initSubComponents();
    },

    methods: {
        searchModule: function () {
            listVar.searchModuleList();
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    formatClass:vm.displayForEdit,
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        newModule:function() {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "LogonUserEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        }
    }
});

var searchModel = new Vue({
    el: "#x_data_search",
    data:{
        content:{
            id: "",
            userType: "",
            name: "",
            status:""
        },

        label:{
            advancedSearchCondition: '',
            id: "",
            name:'',
            userType:'',
            clearSearch:'',
            clearSearchComment:''
        },
        eleStatus: '#x_status',
        getStatusURL: '../logonUser/getStatus.html'
    },

    mounted:function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            vm.getStatus();
        });
    },

    methods: {
        clearSearch: function () {
            clearSearchModel(this.content);
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleStatus).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'status', $(vm.eleStatus).val());
            });
        },

        getStatus: function () {
            var vm = this;
            ServiceUtilityHelper.loadMetaRequest({
                url: vm.getStatusURL,
                $http: vm.$http,
                addEmptyFlag: true,
                formatMeta:LogonUserManager.formatStatus,
                initValue: vm.content.status,
                element: vm.eleStatus,
                errorHandle: vm.errorHandle
            });
        }
    }
});

var listVar = new Vue({
    el: "#x_data_List",
    data:{
        label:LogonUserManager.label.logonUser,
        author:{
            resourceId:'LogonUser',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        tableId:'#x_table_logonUser',
        datatable: '',
        items: [],
        classObject:'glyphicon glyphicon-ok content-green',
        loadModuleListURL: '../logonUser/loadModuleListService.html',
        preLockURL:'../logonUser/preLockService.html',
        deleteModuleURL: '../logonUser/deleteModule.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
        this.setI18nProperties(processModel.initProcessButtonMeta);
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'LogonUser');
            this.datatable = new ServiceDataTable(this.tableId);
            this.loadModuleList();
        });
    },

    methods: {

        initSubComponents: function(){
            "use strict";
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        clearSearch: function(){
            clearSearchModel(this.content);
        },

        setI18nCommonProperties:function() {
            ServiceUtilityHelper.setI18nCommonReflective(this.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nCommonReflective(searchModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nCommonReflective(processModel.label, $.i18n.prop, true);
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        exitHandler: function(){
            console.log("remove User");
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setI18nProperties: function (fnCallback) {
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "/foundation/common/",
                commonCallback:this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList:[{
                    name: 'LogonUser',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        editModule:function(uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            this.$http.post(vm.preLockURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.RC) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                if (oData.RC == HttpStatus.SC_OK) {
                    window.location.href = genCommonEditURL("LogonUserEditor.html", uuid); }else{
                    swal(this.label.lockFailureMessage,  JSON.parse(response.data).MSG);}
            });
        },

        deleteModule: function (uuid) {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        // execution deletion
                        var item = ServiceCollectionsHelper.filterArray(uuid, 'uuid', vm.items);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, vm.items);
                        //vm.refreshTableItems(vm.items);
                        var requestData = {uuid: uuid};
                        vm.$http.post(vm.deleteModuleURL, requestData).then(function (response) {
                            var oData = JSON.parse(response.data);
                            if (!oData.errorCode || oData.errorCode * 1 > 299) {
                                ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                                return;
                            }
                            $.Notification.notify('success', 'top center', this.label.msgDeleteOK, this.label.msgDeleteOKComment);
                            // remove the data from list
                        });
                    } else {
                        // do nothing, just return
                    }
                });
        },

        searchModuleList: function () {
            this.$refs.dataTableFrame.searchModuleList();
        },

        buildSearchData: function(data){
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../logonUser/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'id',
                labelKey: 'id',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.LogonUser,
                    uuidFieldName: 'uuid'
                }
            }, {
                fieldName: 'name',
                labelKey: 'name',
                minWidth: '180px'
            },{
                fieldName: 'statusValue',
                fieldKey: 'status',
                labelKey: 'status',
                iconArray: LogonUserManager.getStatusIconArray()
            }, {
                fieldName: 'organizationName',
                labelKey: 'organizationName',
                fieldKey: 'organizationName',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.Organization,
                    uuidFieldName: 'organizationUUID'
                }
            },{
                fieldName: 'roleId',
                labelKey: 'roleId',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.Role,
                    uuidFieldName: 'roleUUID'
                },
                minWidth: '180px'
            },{
                fieldName: 'roleName',
                labelKey: 'roleName',
                minWidth: '180px'
            }];
            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        },


        loadModuleList2: function () {
            var vm = this;
            var _oInitSettings = {
                items: vm.items,
                url:'../logonUser/searchTableService.html',
                fnAjaxData:vm.buildSearchData,
                fnEditModule:vm.editModule,
                fnDeleteModule:vm.deleteModule
            };

            var settings = ServiceDataTable.genDefServerSettingsTemplate(_oInitSettings);

            $.extend(true, settings, {
                'errorHandle' : vm.errorHandle,
                "columnDefs": [
                    {
                        "targets": 0,
                        "createdCell": function (td, cellData, rowData, row, col) {
                            ServiceDataTable.genDefFirstColumnContent(_oInitSettings, td,cellData, rowData, row, col);
                        }
                    },
                    {
                        "targets": 3,
                        "createdCell": function (td, cellData, rowData, row, col) {
                            ServiceDataTable.buildDefValueStyleTd(document, td, rowData['status'],
                                LogonUserManager.getStatusIconArray());
                        }
                    }
                ],
                "columns": [
                    { "data": "id", "orderable" : true },
                    { "data": "id", "orderable" : true },
                    { "data": "name", "orderable" : true },
                    { "data": "statusValue", "orderable": true },
                    { "data": "organizationName", "orderable": true },
                    { "data": "roleId", "orderable": true },
                    { "data": "roleName", "orderable": true }
                    ]

            });
            vm.datatable.buildWithServer(settings);
        },

        preLock:function() {
        }
    }
});
