/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var HostCompanyManager = function () {

};

HostCompanyManager.label = {
    hostCompany:{
        id: '',
        streetName: '',
        fullName: '',
        name: '',
        cityName: '',
        webPage: '',
        latitude: '',
        regularType: '',
        cancel:'',
        confirm:'',
        organType: '',
        mobile: '',
        houseNumber: '',
        address: '',
        comReportTitle: '',
        comLogo: '',
        addressInfo: '',
        modelTitle:'',
        buttonEdit: '',
        quickEdit:'',
        fax: '',
        townZone: '',
        organizationFunction: '',
        addressOnMap: '',
        postcode: '',
        contactTelephone: '',
        contactMobileNumber: '',
        accountType: '',
        refOrganizationFunction: '',
        subArea: '',
        telephone: '',
        longitude: '',
        organLevel: '',
        note: '',
        email: '',
        hostCompanySection: '',
        contactInfoSection: '',
        client: '',
        parentOrganizationUUID: '',
        buttonView: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        exit: '',
        close: '',
        commit: ''
    },
    employeeOrg: {
        employeeRole: '',
        organizationId: '',
        organizationName: '',
        organizationFunction: '',
        addressInfo: ''
    },
};



/**
 * Definition of Tab on UI
 * @type {{}}
 */
HostCompanyManager.documentTab = {
    employeeSection:'tabEmployeeSection',
    organizationSection: 'tabOrganizationSection'
};


HostCompanyManager.prototype.getModelTitle = function(){
    return HostCompanyManager.label.hostCompany.modelTitle;
};
/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
HostCompanyManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../hostCompany/loadModuleViewService.html';
};


EmployeeManager.prototype.getDefaultDocumentEditorPage = function(){
    "use strict";
    return "HostCompanyEditor.html";
};

HostCompanyManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: vm.getDefaultDocumentEditorPage(),
        url: vm.getLoadDocumentBaseURL(),
        docType : DocumentConstants.DummyDocumentType.HostCompany,
        label:HostCompanyManager.label.hostCompany,
        getI18nWrap:vm.getI18nWrap.bind(vm)
    });

    var fieldMetaList = [{
        fieldName:'id',
    },{
        fieldName:'name',
    },{
        fieldName:'mobile',
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};


