var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: {
            id: '',
            name: '',
            note: '',
            valueSettingName: '',
            rawValue: '',
            valueUsage: '',
            refUnitUUID:'',
            matDecisionValueSettingNote: '',
            addRegisteredProductExtendProperty: '',
            addMatDecisionValueSetting: '',
            parentPageTitle:'',
            registeredProductExtendPropertySection: '',
            matDecisionValueSettingSection: '',

            msgSaveOK: '',
            msgSaveOKComment: '',
            msgConnectFailure: '',
            msgUnknowSystemFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            save: '',
            quickEdit: '',
            buttonDelete: '',
            exit: '',
            close: '',
            deleteWarnTitle: '',
            deleteWarnText: '',
            cancel: '',
            commit: '',
            confirm: ''
        },
        content: {
            id: '',
            name: '',
            note: '',
            parentNodeUUID:'',
            pageTitle:'',
            refValueSettingUUID: '',
            refUnitUUID:'',
            valueSettingName: '',
            rawValue: '',
            valueUsage: '',
            measureFlag:'',
            qualityInspectFlag:'',
            measureFlagValue:'',
            matDecisionValueSettingNote: ''
        },
        eleQualityInspectFlag: '#x_qualityInspectFlag',
        eleMeasureFlag: '#x_measureFlag',
        eleRefUnit: '#x_refUnitUUID',
        eleRefValueSettingUUID:'#x_refValueSettingUUID',
        searchStandardUnitURL:'../standardMaterialUnit/searchModuleService.html',
        loadValueSettingListURL: '../matConfigExtPropertySetting/loadLeanModuleListService.html',
        loadValueSettingURL: '../matConfigExtPropertySetting/loadModule.html',
        loadModuleEditURL: '../registeredProductExtendProperty/loadModuleEditService.html',
        saveModuleURL: '../registeredProductExtendProperty/saveModuleService.html',
        exitModuleURL: '../registeredProductExtendProperty/exitEditor.html',
        newModuleServiceURL: '../registeredProductExtendProperty/newModuleService.html',
        getMeasureFlagMapURL: '../matConfigExtPropertySetting/getMeasureFlagMap.html',
        getQualityInspectFlagURL: '../matConfigExtPropertySetting/getQualityInspectFlag.html'
    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('logistics', 'RegisteredProduct');
            this.setI18nProperties();
            this.loadModuleEdit();
            this.initSelectConfig();
        });
    },

    methods: {
        initSelectConfig: function(){
            var vm = this;
            $(vm.eleRefValueSettingUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refValueSettingUUID', $(vm.eleRefValueSettingUUID).val());
                var url = vm.loadValueSettingURL + "?uuid=" + $(vm.eleRefValueSettingUUID).val();
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.content, 'id', content.id);
                    vm.$set(vm.content, 'name', content.name);
                    vm.$set(vm.content, 'refValueSettingUUID', content.uuid);
                    vm.$set(vm.content, 'refUnitUUID', content.refUnitUUID);
                    vm.$set(vm.content, 'measureFlag', content.measureFlag);
                    vm.$set(vm.content, 'qualityInspectFlag', content.qualityInspectFlag);
                    vm.$set(vm.content, 'valueUsage', content.valueUsage);
                    if(content.refUnitUUID){
                        $(vm.eleRefUnit).val(content.refUnitUUID);
                        $(vm.eleRefUnit).trigger("change");
                    }
                    if(content.measureFlag){
                        $(vm.eleMeasureFlag).val(content.measureFlag);
                        $(vm.eleMeasureFlag).trigger("change");
                    }
                    if(content.qualityInspectFlag){
                        $(vm.eleQualityInspectFlag).val(content.qualityInspectFlag);
                        $(vm.eleQualityInspectFlag).trigger("change");
                    }

                }.bind(this));
            });
            $(vm.eleQualityInspectFlag).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'qualityInspectFlag', $(vm.eleQualityInspectFlag).val());
            });
            $(vm.eleMeasureFlag).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'measureFlag', $(vm.eleMeasureFlag).val());
            });
            $(vm.eleRefUnit).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refUnitUUID', $(vm.eleRefUnit).val());
            });
        },

        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.quickEdit = $.i18n.prop('quickEdit');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.deleteWarnTitle = $.i18n.prop('deleteWarnTitle');
            this.label.deleteWarnText = $.i18n.prop('deleteWarnText');
            this.label.cancel = $.i18n.prop('cancel');
            this.label.commit = $.i18n.prop('commit');
            this.label.confirm = $.i18n.prop('confirm');
            BusyLoader.cleanPageBackground();

        },

        setNodeI18nPropertiesCore: function () {
            this.label.id = $.i18n.prop('id');
            this.label.name = $.i18n.prop('name');
            this.label.note = $.i18n.prop('note');
            this.label.valueSettingName = $.i18n.prop('valueSettingName');
            this.label.rawValue = $.i18n.prop('rawValue');
            this.label.valueUsage = $.i18n.prop('valueUsage');
            this.label.parentPageTitle = $.i18n.prop('parentPageTitle');
            this.label.refUnitUUID = $.i18n.prop('refUnitUUID');
            this.label.refUnitValue = $.i18n.prop('refUnitValue');
            this.label.pageTitle  = $.i18n.prop('pageTitle');
            this.label.measureFlag  = $.i18n.prop('measureFlag');
            this.label.qualityInspectFlag  = $.i18n.prop('qualityInspectFlag');
            this.label.matDecisionValueSettingNote = $.i18n.prop('matDecisionValueSettingNote');
            this.label.addRegisteredProductExtendProperty = $.i18n.prop('addRegisteredProductExtendProperty');
            this.label.addMatDecisionValueSetting = $.i18n.prop('addMatDecisionValueSetting');
            this.label.registeredProductExtendPropertySection = $.i18n.prop('registeredProductExtendPropertySection');
            this.label.matDecisionValueSettingSection = $.i18n.prop('matDecisionValueSettingSection');

        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'RegisteredProductExtendProperty', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                callback: this.setNodeI18nPropertiesCore
            });

        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if (processMode == PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                var url = this.newModuleServiceURL;
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                this.$http.post(url, requestData).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }
            if (processMode == PROCESSMODE_EDIT) {
// In case [Edit mode]
                var url = this.loadModuleEditURL + "?uuid=" + baseUUID;
                this.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }


        },

        setPageHeaderLink: function () {
            var vm = this;
            var baseUUID = vm.content.parentNodeUUID;
            var baseDocURL = genCommonEditURL("RegisteredProductEditor.html", baseUUID);
            var ser = new XMLSerializer();
            var xmlDoc = document.implementation.createDocument("", "", null);
            $("#x_linkToDoc").empty();
            var docText = vm.label.parentPageTitle + ':' + vm.content.refSerialId;
            var linkToRootDocElement = DocumentOrderMatPopInfo.createPageHeaderLinkToRootDoc(xmlDoc, docText, baseDocURL);
            var htmlContent = ser.serializeToString(linkToRootDocElement);
            $("#x_linkToDoc").prepend(htmlContent);

        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            this.$http.post(vm.saveModuleURL, vm.content).then(function (response) {
                $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                this.setModuleToUI(JSON.parse(response.data).content);
                var processMode = getUrlVar(LABEL_PROCESSMODE);
                if (processMode && processMode == PROCESSMODE_NEW) {
                    var baseUUID = vm.content.uuid;
                    if (baseUUID) {
                        window.location.href = genCommonEditURL("RegisteredProductExtendPropertyEditor.html", baseUUID);
                    }
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.parentNodeUUID;
            window.location.href = genCommonEditURL("RegisteredProductEditor.html", baseUUID);

        },

        refreshEditView: function () {
            var baseUUID = this.content.uuid;
            window.location.href = genCommonEditURL("RegisteredProductExtendPropertyEditor.html", baseUUID);

        },

        getQualityInspectFlag: function (content) {
            var vm = this;
            this.$http.get(this.getQualityInspectFlagURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleQualityInspectFlag).select2({
                        data: JSON.parse(response.body),
                        templateResult: SystemStandrdMetadataProxy.formatDefaultSwitchCode,
                        templateSelection: SystemStandrdMetadataProxy.formatDefaultSwitchCode
                    });
                    if (content) {
                        // manually set initial value
                        $(vm.eleQualityInspectFlag).val(content.qualityInspectFlag);
                        $(vm.eleQualityInspectFlag).trigger("change");
                    }
                }, 0);
            });
        },

        getMeasureFlagMap: function (content) {
            var vm = this;
            this.$http.get(this.getMeasureFlagMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleMeasureFlag).select2({
                        data: JSON.parse(response.body),
                        templateResult: SystemStandrdMetadataProxy.formatDefaultSwitchCode,
                        templateSelection: SystemStandrdMetadataProxy.formatDefaultSwitchCode
                    });
                    if (content) {
                        // manually set initial value
                        $(vm.eleMeasureFlag).val(content.measureFlag);
                        $(vm.eleMeasureFlag).trigger("change");
                    }
                }, 0);
            });
        },

        loadValueSettingList: function (content) {
            var vm = this;
            this.$http.get(this.loadValueSettingListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleRefValueSettingUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefValueSettingUUID).val(content.refValueSettingUUID);
                    $(vm.eleRefValueSettingUUID).trigger("change");
                }, 0);
            });

        },

        loadRefUnitSelectList: function (content) {
            "use strict";
            var vm = this;
            var requestData = {};
            this.$http.post(this.searchStandardUnitURL, requestData).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleRefUnit).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefUnit).val(content.refUnitUUID);
                    $(vm.eleRefUnit).trigger("change");
                }, 0);
            });
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm, 'content', content);
            this.setPageHeaderLink();
            this.getMeasureFlagMap(vm.content);
            this.getQualityInspectFlag(vm.content);
            this.loadValueSettingList(vm.content);
            this.loadRefUnitSelectList(vm.content);
        }

    }
});
