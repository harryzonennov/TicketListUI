var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        author:{
            resourceId: ServiceModuleConstants.SystemConfigureResource,
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        searchModuleURL: '../systemConfigureCategory/searchModuleService.html'
    },

    created: function () {
        "use strict";
        var vm = this;
        vm.initAuthorResourceCheck();
    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        searchModule: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.searchModuleURL, requestData).then(function (response) {
                listVar.refreshTableItems(JSON.parse(response.data).content);
            });
        },
        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = content.systemConfigureCategoryUIModel.uuid;
            var resultURL = "SystemConfigureCategoryEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },
        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            id: "",
            uuid: "",
            scenarioMode: "",
            subScenarioMode: "",
            name: "",
            standardSystemCategory: "",
            elementType: "",
            refUUID: ""
        },

        label: {
            id: '',
            standardSystemCategory: '',
            name: '',
            scenarioMode: '',
            subScenarioMode: '',
            elementType: '',
            clearSearch:'',
            clearSearchComment:'',
            advancedSearchCondition: ''
        },

        eleStandardSystemCategory:'#x_standardSystemCategory',
        eleScenarioMode:'#x_scenarioMode',
        eleSubScenarioMode:'#x_subScenarioMode',
        getScenarioModeMapURL: '../systemConfigureCategory/getScenarioModeMap.html',
        getSubScenarioModeMapURL: '../systemConfigureCategory/getSubScenarioModeMap.html',
        getSystemStandardCategoryMapURL: '../systemConfigureCategory/getSystemStandardCategoryMap.html'
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            vm.loadStandardSystemCategoryList();
            vm.loadScenarioModeList();
            vm.loadSubScenarioModeList();
        });
    },

    methods: {

        clearSearch: function(){
            clearSearchModel(this.content);
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleStandardSystemCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'standardSystemCategory', $(vm.eleStandardSystemCategory).val());
            });
            $(vm.eleScenarioMode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'scenarioMode', $(vm.eleScenarioMode).val());
            });
            $(vm.eleSubScenarioMode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'subScenarioMode', $(vm.eleSubScenarioMode).val());
            });
        },

        loadScenarioModeList: function () {
            var vm = this;
            this.$http.get(this.getScenarioModeMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                resultList.splice(0, 0, {'id':'0', 'text':' '});
                setTimeout(function () {
                    $(vm.eleScenarioMode).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleScenarioMode).val(vm.content.standardSystemCategory);
                    $(vm.eleScenarioMode).trigger("change");
                }, 0);
            });
        },

        loadSubScenarioModeList: function () {
            var vm = this;
            this.$http.get(this.getSubScenarioModeMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                resultList.splice(0, 0, {'id':'0', 'text':' '});
                setTimeout(function () {
                    $(vm.eleSubScenarioMode).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleSubScenarioMode).val(vm.content.subScenarioMode);
                    $(vm.eleSubScenarioMode).trigger("change");
                }, 0);
            });
        },

        loadStandardSystemCategoryList: function () {
            var vm = this;
            this.$http.get(this.getSystemStandardCategoryMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                resultList.splice(0, 0, {'id':'0', 'text':' '});
                setTimeout(function () {
                    $(vm.eleStandardSystemCategory).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleStandardSystemCategory).val(vm.content.standardSystemCategory);
                    $(vm.eleStandardSystemCategory).trigger("change");
                }, 0);
            });
        }
    }

});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: {
            id: '',
            client: '',
            note: '',
            standardSystemCategory: '',
            scenarioMode: '',
            subScenarioMode:'',
            uuid: '',
            name: '',

            msgSystemFailure: '',
            msgUnknowSystemFailure: '',
            index: '',
            lockFailureMessage: '',
            buttonEdit: '',
            buttonView: ''
        },
        tableId: '#x_table_systemConfigureCategory',
        datatable: '',
        items: [],
        loadModuleListURL: '../systemConfigureCategory/loadModuleListService.html',
        preLockURL: '../systemConfigureCategory/preLockService.html'
    },


    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'SystemConfigureResource');
            this.datatable = new ServiceDataTable(this.tableId);
            this.setI18nProperties();
            this.loadModuleList();
        });
    },
    methods: {
        setI18nCommonProperties: function () {
            this.label.msgSystemFailure = $.i18n.prop('msgSystemFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.buttonEdit = $.i18n.prop('edit');
            this.label.buttonView = $.i18n.prop('view');
            processModel.label.search = $.i18n.prop('search');
            processModel.label.add = $.i18n.prop('add');
            searchModel.label.advancedSearchCondition = $.i18n.prop('advancedSearchCondition');
            searchModel.label.clearSearch = $.i18n.prop('clearSearch');
            searchModel.label.clearSearchComment = $.i18n.prop('clearSearchComment');
            BusyLoader.cleanPageBackground();
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },
        setNodeI18nPropertiesCore: function () {
            this.label.id = $.i18n.prop('id');
            this.label.client = $.i18n.prop('client');
            this.label.note = $.i18n.prop('note');
            this.label.standardSystemCategory = $.i18n.prop('standardSystemCategory');
            this.label.scenarioMode = $.i18n.prop('scenarioMode');
            this.label.uuid = $.i18n.prop('uuid');
            this.label.name = $.i18n.prop('name');
            searchModel.label.id = $.i18n.prop('id');
            searchModel.label.standardSystemCategory = $.i18n.prop('standardSystemCategory');
            searchModel.label.scenarioMode = $.i18n.prop('scenarioMode');
            searchModel.label.scenarioMode = $.i18n.prop('scenarioMode');
            searchModel.label.name = $.i18n.prop('name');
            searchModel.label.standardSystemCategory = $.i18n.prop('standardSystemCategory');
            searchModel.label.elementType = $.i18n.prop('elementType');
            searchModel.label.scenarioMode = $.i18n.prop('scenarioMode');
            searchModel.label.refUUID = $.i18n.prop('refUUID');
        },
        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'SystemConfigureCategory', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
        },
        getI18nPath: function () {
            return 'coreFunction/';
        },
        loadModuleList: function () {
            var vm = this;
            this.$http.get(vm.loadModuleListURL).then(function (response) {
                if (!JSON.parse(response.data).content) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    return;
                }
                vm.$set(vm, 'items', JSON.parse(response.data).content);
                setTimeout(function () {
                    vm.datatable.build();
                }, 0);
            });
        },
        refreshTableItems: function (items) {
            this.datatable = new ServiceDataTable(this.tableId);
            this.$set('items', items);
            setTimeout(function () {
                this.datatable.build();
            }.bind(this), 0);

        },
        editModule: function (uuid) {
            var vm = this;
            //var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            // window.location.href = genCommonEditURL("SystemConfigureCategoryEditor.html", uuid);
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                $http:vm.$http,
                author:processModel.author,
                editorPage:"SystemConfigureCategoryEditor.html",
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        preLock: function () {
        }
    }
});
