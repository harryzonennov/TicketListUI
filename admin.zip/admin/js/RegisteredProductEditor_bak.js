
var rightBar = new Vue({
    el: "#rightBarHoc",
    mixins: [ServiceRightBarPanelHelper.defTimelineMinxin, RegisteredProductManager.labelTemplate],
    data: function () {
        return {
            label: RegisteredProductManager.label.registeredProduct,
            selectMeta: {
                iconClassMap: {
                    "materialCategory": MaterialManager.getMaterialCategoryIconArray()
                },
                data: {
                    "status": ""
                }
            }
        };
    },


    methods: {
        setI18nProperties: function () {

        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        initHelpDocumentList: function (uuid) {
            "use strict";
            var vm = this;
            ServiceRightBarPanelHelper.initHelpDocumentWithAction({
                uuid: uuid,
                vm: vm,
                getDocActionNodeListURL:'../registeredProduct/getDocActionNodeList.html',
                errorHandle: dataVar.errorHandle,
                helpDocumentName: ['MaterialHelpDocument']
            });
        }
    }
});

var dataVar = new Vue({
    el: "#x_data",
    mixins: [RegisteredProductManager.labelTemplate],
    data: {
        extendpropertyTableId: '#x_table_extendproperty',
        extendpropertyTable: {},
        label: RegisteredProductManager.label.registeredProduct,
        content: {
            registeredProductUIModel: RegisteredProductManager.content.registeredProductUIModel,
            salesBy: ServiceUtilityHelper.cloneObj(ServiceInvolvePartyHelper.defContentObj),
            salesTo: ServiceUtilityHelper.cloneObj(ServiceInvolvePartyHelper.defContentObj),
            purchaseBy: ServiceUtilityHelper.cloneObj(ServiceInvolvePartyHelper.defContentObj),
            productBy: ServiceUtilityHelper.cloneObj(ServiceInvolvePartyHelper.defContentObj),
            supportBy: ServiceUtilityHelper.cloneObj(ServiceInvolvePartyHelper.defContentObj),
            registeredProductExtendPropertyUIModelList: [],
            registeredProductAttachmentUIModelList:[]
        },
        cache: {
            registeredProductExtendProperty: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refValueSettingUUID: '',
                id: '',
                doubleValue:'',
                name: '',
                valueSettingName: '',
                rawValue: '',
                valueUsage: '',
                note: '',
                measureFlag: '',
                qualityInspectFlag: '',
                refUnitValue: '',
                refUnitUUID: ''
            },
            refDocFlowMap:[],
            refDocFlowList:[]
        },
        attachmentMeta:{
            loadAttachmentURL: '../registeredProduct/loadAttachment.html',
            deleteAttachmentURL: '../registeredProduct/deleteAttachment.html',
            uploadAttachmentURL: '../registeredProduct/uploadAttachment.html',
            uploadAttachmentTextURL: '../registeredProduct/uploadAttachmentText.html'
        },
        attachmentLabel:{
            attachmentSection:''
        },
        author:{
            resourceId:'RegisteredProduct',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        processButtonMeta: [],
        materialStockKeepUnitManager: undefined,
        eleRefPurchaseOrgUUID: '#x_refPurchaseOrgUUID',
        eleRefCustomerUUID: '#x_refCustomerUUID',
        eleRefSalesOrgUUID: '#x_refSalesOrgUUID',
        eleRefSupplierUUID: '#x_refSupplierUUID',
        eleRefProductOrgUUID: '#x_refProductOrgUUID',
        eleRefSupportOrgUUID: '#x_refSupportOrgUUID',
        eleRefLengthUnit: '#x_refLengthUnit',
        eleRefVolumeUnit: '#x_refVolumeUnit',
        eleRefWeightUnit: '#x_refWeightUnit',
        eleSupplyType: '#x_supplyType',
        eleCargoType: '#x_cargoType',
        eleTraceStatus: '#x_traceStatus',
        eleQualityInspectFlag: '#x_qualityInspectFlag',
        eleMatQualityInspectFlag: '#x_matQualityInspectFlag',
        eleMeasureFlag: '#x_measureFlag',
        eleRefUnit: '#x_refUnitUUID',
        eleRefValueSettingUUID:'#x_refValueSettingUUID',
        loadModuleEditURL: '../registeredProduct/loadModuleEditService.html',
        loadModuleViewURL: '../registeredProduct/loadModuleViewService.html',
        getDocFlowListURL: '../registeredProduct/getDocFlowList.html',
        saveModuleURL: '../registeredProduct/saveModuleService.html',
        exitModuleURL: '../registeredProduct/exitEditor.html',
        newModuleServiceURL: '../registeredProduct/newModuleService.html',
        newRegisteredProductExtendPropertyServiceURL: '../registeredProductExtendProperty/newModuleService.html',
        eleExtendPropertyModal: '#x_eleEditExtendPropertyModal',
        loadOrganizationSelectListURL: '../organization/loadModuleListService.html',
        loadSalesOrganizationSelectListURL: '../organization/loadModuleListService.html',
        loadCorporateCustomerSelectListURL: '../corporateCustomer/loadModuleListService.html',
        loadCorporateSupplierSelectListURL: '../corporateSupplier/loadModuleListService.html',
        loadSalesOrganizationURL: '../organization/loadModule.html',
        loadOrganizationURL: '../organization/loadModule.html',
        loadCorporateCustomerURL: '../corporateCustomer/loadModule.html',
        getQualityInspectFlagMapURL: '../materialStockKeepUnit/getQualityInspectFlagMap.html',
        exitURL: 'RegisteredProductList.html',
        searchStandardUnitURL:'../standardMaterialUnit/searchModuleService.html',
        loadValueSettingListURL: '../matConfigExtPropertySetting/loadLeanModuleListService.html',
        loadValueSettingURL: '../matConfigExtPropertySetting/loadModule.html',
        getMeasureFlagMapURL: '../matConfigExtPropertySetting/getMeasureFlagMap.html'
    },

    created: function(){
        "use strict";
        var vm = this;
        vm.initSubComponents();
        vm.initAuthorResourceCheck();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('logistics', 'RegisteredProduct');
            this.setI18nProperties(vm.initProcessButtonMeta());
            this.loadModuleEdit();
            this.extendpropertyTable = new ServiceDataTable(this.extendpropertyTableId);
            this.initSelectConfigure();
            this.initPopOverConfigure();
            this.initManager();
        });
    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function() {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("customer-contact-union", CustomerContactUnion);
            Vue.component("attachment-union", AttachmentUnion);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        /**
         * @Overwrite: Get document type for each edit controller
         */
        getDocumentType: function () {
            return DocumentConstants.DummyDocumentType.RegisteredProduct;
        },

        getServiceManager: function () {
            return RegisteredProductManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "RegisteredProductEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.registeredProductUIModel.uuid;
        },

        /**
         * @Overwrite: get document status from content
         */
        getStatus: function () {
            return this.content.registeredProductUIModel.status;
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        errorHandle: function(oData){
            this.$refs.refBusyLoader.hideBusyLoading();
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        expandProductOrgDetail: function(event){
            ServiceUtilityHelper.toggleDetailCore($("#x_productOrg_moreDetail"), event);
        },

        expandSupportOrgDetail: function(event){
            ServiceUtilityHelper.toggleDetailCore($("#x_supportOrg_moreDetail"), event);
        },

        expandPurchaseOrgDetail: function(event){
            ServiceUtilityHelper.toggleDetailCore($("#x_purchaseOrg_moreDetail"), event);
        },

        expandCorporateCustomerDetail: function(event){
            ServiceUtilityHelper.toggleDetailCore($("#x_corporateCustomer_moreDetail"), event);
        },

        expandCorporateSupplierDetail: function(event){
            ServiceUtilityHelper.toggleDetailCore($("#x_corporateSupplier_moreDetail"), event);
        },

        expandSalesOrgDetail: function(event){
            ServiceUtilityHelper.toggleDetailCore($("#x_salesOrg_moreDetail"), event);
        },

        toggleDetailCore: function($targetElement, event){
            if( $targetElement ){
                if($targetElement.hasClass("hide-display")){
                    $targetElement.toggleClass("hide-display", false);
                    if(event && event.currentTarget){
                        var iconElement = $(event.currentTarget).children("i");
                        iconElement.toggleClass("ion-chevron-down", false);
                        iconElement.toggleClass("ion-chevron-up", true);
                    }
                }else{
                    $targetElement.toggleClass("hide-display", true);
                    if(event && event.currentTarget){
                        var iconElement = $(event.currentTarget).children("i");
                        iconElement.toggleClass("ion-chevron-down", true);
                        iconElement.toggleClass("ion-chevron-up", false);
                    }
                }
            }
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        initManager: function(){
            this.materialStockKeepUnitManager = new MaterialStockKeepUnitManager();
        },

        formatSwitchClass: function(itemSwitch){
            var switchIconArray = SystemStandrdMetadataProxy.getDefaultSwitchIconArray();
            var $element = ServiceCollectionsHelper.filterArray(itemSwitch, 'id', switchIconArray);
            if($element){
                return $element.iconClass;
            }
        },

        formatDisplayProductTab:function(supplyType){
            var displayFlag;
            if (supplyType * 1 === DocumentConstants.Material.supplyType.SELF_PROD){
                displayFlag = true;
            }
            if (supplyType * 1 === DocumentConstants.Material.supplyType.MIXED){
                displayFlag = true;
            }
            return "tab " + DocumentManagerFactory.formatDisplayClass (displayFlag);
        },

        formatDisplayPurchaseTab:function(supplyType){
            var displayFlag;
            if (supplyType * 1 === DocumentConstants.Material.supplyType.PURCHASE){
                displayFlag = true;
            }
            if (supplyType * 1 === DocumentConstants.Material.supplyType.MIXED){
                displayFlag = true;
            }
            return "tab " + DocumentManagerFactory.formatDisplayClass (displayFlag);
        },

        /**
         * Deprecate
         */
        initPopOverConfigure: function () {
            var vm = this;
            // Auto Close Pop over when click outside.
            $('html').click(function (e) {
                $('.popover').popover('hide');
            });

            $("#x_refMaterialSKU_popover").popover({
                html: true,
                trigger: 'manual',
                container: 'body',
                content: function () {
                    return $('#x_refMaterialSKU_popDoc').html();
                }
            }).click(function (e) {
                var $popover = $(this);
                var targetUUID = vm.content.registeredProductUIModel.refMaterialSKUUUID;
                vm.materialStockKeepUnitManager.getDocumentPopoverContent({
                    uuid: targetUUID,
                    $http: vm.$http,
                    $popCoreElement: $("#x_refMaterialSKU_popCore"),
                    fnCallBack: function () {
                        $popover.popover('toggle');
                    }
                });
                e.stopPropagation();
            });
        },



        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nCommonReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nExtendPropertyProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.registeredProductExtendProperty, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,vm: vm,
                fnCallback: fnCallback, modelId: 'RegisteredProduct', coreModelId: 'RegisteredProduct',
                configList: [{
                    name: 'RegisteredProduct',
                    callback: vm.setNodeI18nPropertiesCore
                }, {
                    name: 'RegisteredProductExtendProperty',
                    callback: vm.setI18nExtendPropertyProperties
                }]
            });
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleRefProductOrgUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'refProductOrgUUID', $(vm.eleRefProductOrgUUID).val());
                var url = vm.loadOrganizationURL + "?uuid=" + $(vm.eleRefProductOrgUUID).val();
                ServiceUtilityHelper.httpRequest({
                    url:vm.loadOrganizationURL,
                    $http:vm.$http,
                    uuid:$(vm.eleRefProductOrgUUID).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                        vm.$set(vm.content.registeredProductUIModel, 'productOrganizationId', content.id);
                        vm.$set(vm.content.registeredProductUIModel, 'productOrganizationName', content.name);
                        vm.$set(vm.content.registeredProductUIModel, 'productOrganizationTelephone', content.telephone);
                        vm.$set(vm.content.registeredProductUIModel, 'productOrganizationAddress', content.address);
                        vm.$set(vm.content.registeredProductUIModel, 'productOrganizationTaxNumber', content.taxNumber);
                        vm.$set(vm.content.registeredProductUIModel, 'productOrganizationEmail', content.email);
                        vm.$set(vm.content.registeredProductUIModel, 'productOrganizationBankAccount', content.bankAccount);
                        vm.$set(vm.content.registeredProductUIModel, 'productOrganizationFax', content.fax);
                    }.bind(this)
                });
            });
            $(vm.eleRefSupportOrgUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'refSupportOrgUUID', $(vm.eleRefSupportOrgUUID).val());
                var url = vm.loadOrganizationURL + "?uuid=" + $(vm.eleRefSupportOrgUUID).val();
                ServiceUtilityHelper.httpRequest({
                    url:vm.loadOrganizationURL,
                    $http:vm.$http,
                    uuid:$(vm.eleRefSupportOrgUUID).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationId', content.id);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationName', content.name);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationTelephone', content.telephone);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationAddress', content.address);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationTaxNumber', content.taxNumber);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationEmail', content.email);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationBankAccount', content.bankAccount);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationFax', content.fax);
                    }.bind(this)
                });
            });
            $(vm.eleRefPurchaseOrgUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'refPurchaseOrgUUID', $(vm.eleRefPurchaseOrgUUID).val());
                var url = vm.loadOrganizationURL + "?uuid=" + $(vm.eleRefPurchaseOrgUUID).val();

                ServiceUtilityHelper.httpRequest({
                    url:vm.loadOrganizationURL,
                    $http:vm.$http,
                    uuid:$(vm.eleRefPurchaseOrgUUID).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationId', content.id);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationName', content.name);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationTelephone', content.telephone);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationAddress', content.address);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationTaxNumber', content.taxNumber);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationEmail', content.email);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationBankAccount', content.bankAccount);
                        vm.$set(vm.content.registeredProductUIModel, 'supportOrganizationFax', content.fax);
                    }.bind(this)
                });
            });
            $(vm.eleRefCustomerUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'refCustomerUUID', $(vm.eleRefCustomerUUID).val());
                var url = vm.loadCorporateCustomerURL + "?uuid=" + $(vm.eleRefCustomerUUID).val();
                ServiceUtilityHelper.httpRequest({
                    url:vm.loadCorporateCustomerURL,
                    $http:vm.$http,
                    uuid:$(vm.eleRefCustomerUUID).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                        vm.$set(vm.content.registeredProductUIModel, 'corporateCustomerId', content.id);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateCustomerName', content.name);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateCustomerTelephone', content.telephone);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateCustomerAddress', content.address);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateCustomerTaxNumber', content.taxNumber);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateCustomerEmail', content.email);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateCustomerBankAccount', content.bankAccount);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateCustomerFax', content.fax);
                    }.bind(this)
                });
            });
            $(vm.eleRefSalesOrgUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'refSalesOrgUUID', $(vm.eleRefSalesOrgUUID).val());
                var url = vm.loadOrganizationURL + "?uuid=" + $(vm.eleRefSalesOrgUUID).val();

                ServiceUtilityHelper.httpRequest({
                    url:vm.loadOrganizationURL,
                    $http:vm.$http,
                    uuid:$(vm.eleRefSalesOrgUUID).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                        vm.$set(vm.content.registeredProductUIModel, 'salesOrganizationId', content.id);
                        vm.$set(vm.content.registeredProductUIModel, 'salesOrganizationName', content.name);
                        vm.$set(vm.content.registeredProductUIModel, 'salesOrganizationTelephone', content.telephone);
                        vm.$set(vm.content.registeredProductUIModel, 'salesOrganizationAddress', content.address);
                        vm.$set(vm.content.registeredProductUIModel, 'salesOrganizationTaxNumber', content.taxNumber);
                        vm.$set(vm.content.registeredProductUIModel, 'salesOrganizationEmail', content.email);
                        vm.$set(vm.content.registeredProductUIModel, 'salesOrganizationBankAccount', content.bankAccount);
                        vm.$set(vm.content.registeredProductUIModel, 'salesOrganizationFax', content.fax);
                    }.bind(this)
                });
            });
            $(vm.eleRefSupplierUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'refSupplierUUID', $(vm.eleRefSupplierUUID).val());
                var url = vm.loadCorporateCustomerURL + "?uuid=" + $(vm.eleRefSupplierUUID).val();
                ServiceUtilityHelper.httpRequest({
                    url:vm.loadCorporateCustomerURL,
                    $http:vm.$http,
                    uuid:$(vm.eleRefSupplierUUID).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                        vm.$set(vm.content.registeredProductUIModel, 'corporateSupplierId', content.id);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateSupplierName', content.name);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateSupplierTelephone', content.telephone);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateSupplierAddress', content.address);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateSupplierTaxNumber', content.taxNumber);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateSupplierEmail', content.email);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateSupplierBankAccount', content.bankAccount);
                        vm.$set(vm.content.registeredProductUIModel, 'corporateSupplierFax', content.fax);
                    }.bind(this)
                });
            });

            $(vm.eleCargoType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'cargoType', $(vm.eleCargoType).val());
            });

            $(vm.eleSupplyType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'supplyType', $(vm.eleSupplyType).val());
            });

            $(vm.eleTraceStatus).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'traceStatus', $(vm.eleTraceStatus).val());
            });

            $(vm.eleRefLengthUnit).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'refLengthUnit', $(vm.eleRefLengthUnit).val());
            });

            $(vm.eleRefVolumeUnit).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'refVolumeUnit', $(vm.eleRefVolumeUnit).val());
            });

            $(vm.eleRefWeightUnit).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'refWeightUnit', $(vm.eleRefWeightUnit).val());
            });

            $(vm.eleMatQualityInspectFlag).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.registeredProductUIModel, 'qualityInspectFlag', $(vm.eleMatQualityInspectFlag).val());
            });
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            vm.$refs.refBusyLoader.showBusyLoading();
            if (processMode * 1 === PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                // var url = this.newModuleServiceURL;
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);

                ServiceUtilityHelper.httpRequest({
                    url:this.newModuleServiceURL,
                    $http:vm.$http,
                    method:'post',
                    requestData: requestData,
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        vm.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if (processMode * 1 === PROCESSMODE_EDIT) {
                 // In case [Edit mode]
                vm.getDocFlowList(baseUUID);
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    initAuthor: function(author){vm.$set(vm, 'author', author);},
                    $http:vm.$http,
                    errorHandle:vm.errorHandle,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }
        },

        /**
         * Deprecate
         */
        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }

        },

        /**
         * Deprecate
         */
        copyRegisteredProductExtendProperty: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refValueSettingUUID = origin.refValueSettingUUID;
            target.doubleValue = origin.doubleValue;
            target.rawValue = origin.rawValue;
            target.valueUsage = origin.valueUsage;
            target.note = origin.note;
            target.measureFlag = origin.measureFlag;
            target.qualityInspectFlag = origin.qualityInspectFlag;
            target.refUnitValue = origin.refUnitValue;
            target.refUnitUUID = origin.refUnitUUID;
            return target;

        },

        saveModule: function () {
            var vm = this;
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            ServiceUtilityHelper.httpRequest({
                url:vm.saveModuleURL,
                $http:vm.$http,
                method:'post',
                requestData: vm.content,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                    vm.setModuleToUI(oData.content);
                    var processMode = getUrlVar(LABEL_PROCESSMODE);
                    if (processMode && processMode * 1 === PROCESSMODE_NEW) {
                        var baseUUID = vm.content.registeredProductUIModel.uuid;
                        if (baseUUID) {
                            window.location.href = genCommonEditURL("RegisteredProductEditor.html", baseUUID);
                        }
                    }
                }.bind(this)
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.registeredProductUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);

        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.registeredProductUIModel.uuid;
            if(baseUUID){
                window.location.href = genCommonEditURL("RegisteredProductEditor.html", baseUUID, tabKey);
            }
        },


        getDocFlowList: function(uuid){
            var vm = this;
            var url = this.getDocFlowListURL + "?uuid=" + uuid;
            this.$http.get(url).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var refDocFlowList = JSON.parse(response.body).content;
                DocumentManagerFactory.renderDocFlow(refDocFlowList, "#x_docFlowContainer");
            });
        },


        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'registeredProductUIModel', content.registeredProductUIModel);
            vm.$set(vm.content, 'registeredProductExtendPropertyUIModelList', content.registeredProductExtendPropertyUIModelList);
            vm.$set(vm.content, 'registeredProductAttachmentUIModelList', content.registeredProductAttachmentUIModelList);

            vm.$set(vm.content, 'salesBy', content.salesBy);
            vm.$set(vm.content, 'salesTo', content.salesTo);
            vm.$set(vm.content, 'purchaseBy', content.purchaseBy);
            vm.$set(vm.content, 'productBy', content.productBy);
            vm.$set(vm.content, 'supportBy', content.supportBy);
            if (rightBar) {
                rightBar.initHelpDocumentList(content.registeredProductUIModel.uuid);
            }
            ServiceUtilityHelper.switchToTab();
            var promiseList = MaterialManager.loadDefaultMetaBatch({
                'vm': vm,
                'uiModel':vm.content.registeredProductUIModel
            });
            var promiseListSKU = MaterialStockKeepUnitManager.loadDefaultMetaBatch({
                'vm': vm,
                'uiModel':vm.content.registeredProductUIModel
            });
            RegisteredProductManager.loadDefaultMetaBatch({
                'vm': vm,
                'uiModel':vm.content.registeredProductUIModel
            });
            vm.$refs.refBusyLoader.hideBusyLoading();
            promiseList.concat(promiseListSKU);
            Promise.all([promiseList]).then(function (value) {
                rightBar.initHelpDocumentList();
            }).catch(function (error) {
                vm.errorHandle(error);
            });

        },


        getMeasureFlagMap: function (cache) {
            var vm = this;
            this.$http.get(this.getMeasureFlagMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleMeasureFlag).select2({
                        data: JSON.parse(response.body),
                        templateResult: SystemStandrdMetadataProxy.formatDefaultSwitchCode,
                        templateSelection: SystemStandrdMetadataProxy.formatDefaultSwitchCode
                    });
                    if (cache && cache.registeredProductExtendProperty) {
                        // manually set initial value
                        $(vm.eleMeasureFlag).val(cache.registeredProductExtendProperty.measureFlag);
                        $(vm.eleMeasureFlag).trigger("change");
                    }
                }, 0);
            });
        },




        /**
         * Deprecate
         */
        editRegisteredProductExtendPropertyModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.registeredProductExtendPropertyUIModelList);
            if (!item) {
                return;
            }
            this.cache.registeredProductExtendProperty = this.copyRegisteredProductExtendProperty(item);

            $(this.eleExtendPropertyModal).modal('toggle');
        },
        /**
         * Deprecate
         */
        setToRegisteredProductExtendProperty: function () {
            var item = this._filterItemByUUID(this.cache.registeredProductExtendProperty.uuid, this.content.registeredProductExtendPropertyUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copyRegisteredProductExtendProperty(this.cache.registeredProductExtendProperty);
                this.content.registeredProductExtendPropertyUIModelList.push(newItem);
            } else {
                this.copyRegisteredProductExtendProperty(this.cache.registeredProductExtendProperty, item);
            }
            $(this.eleExtendPropertyModal).modal('hide');
        },


        editRegisteredProductExtendProperty: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            window.location.href = genCommonEditURL("RegisteredProductExtendPropertyEditor.html", uuid);

        }

    }
});
