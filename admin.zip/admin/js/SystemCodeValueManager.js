var SystemCodeValueManager = function () {

};

SystemCodeValueManager.label = {
    systemCodeValueCollection:{
        collectionCategory: '',
        keyType: '',
        collectionType: '',
        id: '',
        name: '',
        note: '',
        tab1Title:'',
        tab2Title:'',
        modelTitle:'',
        systemCodeValueCollectionSection: '',
        systemCodeValueUnionSection: '',
        addSystemCodeValueUnion: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        exit: '',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        cancel: '',
        commit: '',
        confirm: '',
        buttonEdit: '',
        buttonView: ''
    },
    systemCodeValueUnion: {
        id: '',
        keyType: '',
        colorStyle:'',
        iconClass:'',
        lanKey:'',
        tab1Title:'',
        tab2Title:'',
        iconClassComments:'',
        colorStyleComments:'',
        hideFlag:'',
        unionType:'',
        hideFlagComments:'',
        name: '',
        note: ''
    }
};


SystemCodeValueManager.labelTemplate = {
    data: function() {
        return {
            label: {
                "systemCodeValueUnion": SystemCodeValueManager.label.systemCodeValueUnion
            }
        };
    }
};

SystemCodeValueManager.getCollectionTypeIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.SystemCodeValueCollection.CollectionType.SYSTEM, iconClass: 'fa fa-gear content-darkblue'},
        {id: DocumentConstants.SystemCodeValueCollection.CollectionType.CUSTOM, iconClass: 'md md-portrait content-darkblue'}
    ];
};

SystemCodeValueManager.formatCollectionTypeIconClass = function (collectionType) {
    "use strict";
    var iconArray = SystemCodeValueManager.getCollectionTypeIconArray();
    var $element = ServiceCollectionsHelper.filterArray(collectionType, 'id', iconArray);
    if($element){
        return $element.iconClass;
    }
};

SystemCodeValueManager.formatCollectionType = function (collectionType) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(collectionType, SystemCodeValueManager.getCollectionTypeIconArray(), true);
    return $element;
};

SystemCodeValueManager.prototype.getI18nWrap = function (fnCallback) {
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "coreFunction/",
        fnCallback: fnCallback,
        commonCallback: SystemCodeValueManager.setI18nCommonProperties,
        configList: [{
            name: 'SystemCodeValueCollection',
            callback: SystemCodeValueManager.setNodeI18nPropertiesCore
        }, {
            name: 'SystemCodeValueUnion',
            callback: SystemCodeValueManager.setI18nValueUnionProperties
        }]
    });
};


SystemCodeValueManager.setI18nCommonProperties = function () {
    ServiceUtilityHelper.setI18nReflective(SystemCodeValueManager.label.systemCodeValueCollection, $.i18n.prop);
    ServiceUtilityHelper.setI18nReflective(SystemCodeValueManager.label.systemCodeValueUnion, $.i18n.prop);
};

SystemCodeValueManager.setNodeI18nPropertiesCore = function () {
    ServiceUtilityHelper.setI18nReflective(SystemCodeValueManager.label.systemCodeValueCollection, $.i18n.prop, true);
};

SystemCodeValueManager.setI18nValueUnionProperties = function () {
    ServiceUtilityHelper.setI18nReflective(SystemCodeValueManager.label.systemCodeValueUnion, $.i18n.prop, true);
};


SystemCodeValueManager.prototype.getModelTitle = function(){
    return SystemCodeValueManager.label.systemCodeValueCollection.modelTitle;
};

SystemCodeValueManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: "SystemCodeValueCollectionEditor.html",
        url: "../systemCodeValueCollection/loadModuleViewService.html",
        subPath: 'systemCodeValueCollectionUIModel',
        label:SystemCodeValueManager.label,
        getI18nWrap:vm.getI18nWrap.bind(vm)
    });

    var fieldMetaList = [{
        fieldName:'systemCodeValueCollection.id',
    },{
        fieldName:'systemCodeValueCollection.name',
    },{
        fieldName:'collectionTypeValue',
        fieldKey:'collectionType',
        labelKey:'systemCodeValueCollection.collectionType',
        iconArray: SystemCodeValueManager.getCollectionTypeIconArray(),
    },{
        fieldName: 'keyTypeValue',
        fieldKey:'keyType',
        labelKey:'systemCodeValueCollection.keyType'
    },{
        listSubPath:'systemCodeValueUnionUIModelList',
        fieldName:'name',
        labelKey:'systemCodeValueUnion.name',
        listValueStragety:DocumentOrderMatPopInfo.ListItemStragegy.FIRST_MULTI_ITEM,
        listFirstNum:3
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};