var dataVar = new Vue({
    el: "#x_data",
    mixins: [MaterialManager.labelTemplate, SerDocumentControlHelper.defControlMinxin],
    data: {
        label: MaterialManager.label.material,
        content: {
            materialUIModel: MaterialManager.content.materialUIModel,
            materialUnitUIModelList: [],
            materialAttachmentUIModelList: []
        },
        exitModuleURL: '../material/exitEditor.html',
        executeDocActionURL: '../material/executeDocAction.html',
        newModuleServiceURL: '../material/newModuleService.html',
        newModuleFromTypeURL: '../material/newModuleFromType.html',
        newMaterialUnitServiceURL: '../materialUnit/newModuleService.html',
        getDocActionConfigureListURL: '../material/getDocActionConfigureList.html',
        loadStandardUnitSelectListURL: '../material/getStandardUnit.html',
        getActionCodeMapURL: '../material/getActionCodeMap.html',
        exitURL: 'MaterialList.html'
    },

    mounted: function () {
        NavigationPanelIns.initNavigation('logistics', 'Material');
    },

    methods: {

        initSubComponents: function () {
            "use strict";
            var vm = this;
            vm.initSubComponentService();
            vm.initSubComponentDoc();
            Vue.component("material-unit-panel", MaterialUnitPanel);
            Vue.component("material-type-select", MaterialTypeSelect);
        },

        /**
         * @Overwrite: Get document type for each edit controller
         */
        getDocumentType: function () {
            return DocumentConstants.DummyDocumentType.Material;
        },

        getServiceManager: function () {
            return MaterialManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "MaterialEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.materialUIModel.uuid;
        },

        /**
         * @Overwrite: get document status from content
         */
        getStatus: function () {
            return this.content.materialUIModel.status;
        },

        /**
         * @Overwrite provide doc action code matrix
         * @return {*}
         */
        getActionCodeMatrix: function () {
            return {
                submit: {actionCode: MaterialManager.DOC_ACTION_CODE.SUBMIT},
                revokeSubmit: {actionCode: MaterialManager.DOC_ACTION_CODE.REVOKE_SUBMIT},
                approve: {actionCode: MaterialManager.DOC_ACTION_CODE.APPROVE},
                reInit: {actionCode: MaterialManager.DOC_ACTION_CODE.REINIT},
                rejectApprove: {actionCode: MaterialManager.DOC_ACTION_CODE.REJECT_APPROVE},
                countApprove: {actionCode: MaterialManager.DOC_ACTION_CODE.COUNTAPPROVE},
                active: {actionCode: MaterialManager.DOC_ACTION_CODE.ACTIVE},
                archive: {actionCode: MaterialManager.DOC_ACTION_CODE.ARCHIVE}
            };
        },

        getActionCodeIconMap: function () {
            return MaterialManager.getActionCodeIconMap();
        },

        loadMainMaterialUnitSelectList: function () {
            var vm = this;
            return ServiceUtilityHelper.loadTypeAheadRequest({
                url: vm.loadStandardUnitSelectListURL,
                $http: vm.$http,
                errorHandle: vm.errorHandle,
                element: vm.eleMainMaterialUnitName
            });
        },

        loadMaterialSKUList: function (baseUUID) {
            var vm = this;
            var postUrl = '../materialStockKeepUnit/searchModuleService.html';
            var requestData = {refMaterialUUID: baseUUID};
            ServiceUtilityHelper.httpRequest({
                url: postUrl,
                method: 'post',
                requestData: requestData,
                $http: vm.$http,
                errorHandle: ServiceUtilityHelper.handleErrorUIDefault,
                postHandle: function (oData) {
                    vm.$set(vm.cache, 'materialStockKeepList', oData.content);
                }.bind(this)
            });
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'materialUIModel', content.materialUIModel);
            vm.$set(vm.content, 'materialUnitUIModelList', content.materialUnitUIModelList);
            vm.$set(vm.content, 'materialAttachmentUIModelList', content.materialAttachmentUIModelList);
            vm.loadMainMaterialUnitSelectList(content);
            vm.loadMaterialSKUList(content.materialUIModel.uuid);
            vm.postUpdateUIModel();
        },

        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'MaterialEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: MaterialManager,
                coreModelId: 'Material',
                i18nPath: 'coreFunction/',
                getDocActionNodeListURL: '../material/getDocActionNodeList.html',
                helpDocumentName: ['MaterialHelpDocument', 'MaterialUnitHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: 'displayForEdit',
                        callback: 'saveModule'
                    },
                    placeholder: {
                        category: ProcessButtonConstants.placeholderCategory.DOC_ACTION_BTN
                    },
                    exit: {
                        callback: 'exitModule'
                    }
                },
                tabMetaList: [{
                    tabId: 'materialSection',
                    tabTitleKey: 'materialSection',
                    titleLabelKey: 'materialSection',
                    titleHelpKey: 'material.materialSection',
                    titleIcon: 'md md-texture content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'materialSection',
                        updatedByUidPath: 'updatedByUUID',
                        updatedByNamePath: 'updatedByName',
                        updatedDatePath: 'updatedDate',
                        messageResponsePath: 'meta.messageResponse',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'materialUIModel',
                        tabTitleKey: 'materialSection',
                        titleLabelKey: 'materialSection',
                        titleHelpKey: 'material.materialSection',
                        titleIcon: 'md md-texture content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'id',
                            required: true,
                            newRow: true
                        }, {
                            required: true,
                            fieldName: 'name',
                        }, {
                            fieldName: 'status',
                            disabled: true,
                            helpKey: 'material.status',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getStatusURL,
                                formatMeta: 'formatStatus'
                            },
                            iconArray: 'getStatusIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'cargoType',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getCargoTypeURL,
                                formatMeta: 'formatCargoType'
                            },
                            iconArray: 'getCargoTypeIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'materialTypeName',
                            newRow: true,
                            settings: {
                                getMetaDataUrl: '../materialType/searchModuleService.html',
                                method: 'post',
                                selectorType: ServiceModelSelector.SELECTOR_TYPE.MaterialTypeSelect,
                                idField: 'uuid',
                                textField: 'name',
                                requestData: {},
                                uuidField: 'uuid',
                                fieldList: [{
                                    targetField: 'materialTypeId',
                                    sourceField: 'id'
                                }, {
                                    targetField: 'materialTypeName', sourceField: 'name'
                                }]
                            },
                            popupConfigure: {
                                popupLabelClass: "popup-material-sku",
                                documentFunction: "getDocumentPopoverContent",
                                documentType: "MaterialType",
                                targetUidPath: 'refMaterialType',
                                popupTitle: vm.label.materialTypeName,
                                headerTitle: vm.label.materialTypeName
                            },
                            fieldType: AbsInput.FIELDTYPE.ModalSelect2
                        }, {
                            fieldName: 'materialTypeId',
                            disabled: true
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        }]
                    }, {
                        sectionId: 'materialSizeSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'materialUIModel',
                        tabTitleKey: 'materialSection',
                        titleLabelKey: 'materialSection',
                        titleHelpKey: 'material.materialSection',
                        titleIcon: 'md md-straighten content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'mainMaterialUnitName',
                            labelKey: 'mainMaterialUnit',
                            required: true,
                            newRow: true,
                            settings: {
                                getMetaDataUrl: vm.loadStandardUnitSelectListURL,
                                idField: 'uuid',
                                textField: 'name',
                                formatMeta: SystemStandrdMetadataProxy.formatCargoType
                            },
                            fieldType: AbsInput.FIELDTYPE.TypeAhead
                        }, {
                            fieldName: 'packageMaterialType',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.loadPackageMaterialTypeURL,
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'length',
                            newRow: true,
                            postFieldMeta: [{
                                fieldName: 'refLengthUnit',
                                settings: {
                                    getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                    requestData: {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.LENGTH},
                                    method: 'post',
                                    idField: 'uuid',
                                    textField: 'name'
                                },
                                fieldType: AbsInput.FIELDTYPE.Select2
                            }]
                        }, {
                            fieldName: 'width',
                        }, {
                            fieldName: 'height',
                        }, {
                            fieldName: 'volume',
                            newRow: true,
                            postFieldMeta: [{
                                fieldName: 'refVolumeUnit',
                                settings: {
                                    getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                    requestData: {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.VOLUME},
                                    method: 'post',
                                    idField: 'uuid',
                                    textField: 'name'
                                },
                                fieldType: AbsInput.FIELDTYPE.Select2
                            }]
                        }, {
                            fieldName: 'netWeight',
                            postFieldMeta: [{
                                fieldName: 'refWeightUnit',
                                settings: {
                                    getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                    requestData: {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.WEIGHT},
                                    method: 'post',
                                    idField: 'uuid',
                                    textField: 'name'
                                },
                                fieldType: AbsInput.FIELDTYPE.Select2
                            }]
                        }, {
                            fieldName: 'grossWeight'
                        }, {
                            fieldName: 'minStoreNumber'
                        }]
                    }, {
                        sectionId: 'materialAttachment',
                        sectionCategory: AsyncSection.sectionCategory.ATTACHMENT,
                        parentContentPath: 'materialAttachmentUIModelList',
                        errorHandle: 'errorHandle',
                        settings: {
                            configMetaPath: 'attachmentMeta'
                        }
                    }]
                }, {
                    tabId: 'materialProductionSection',
                    tabTitleKey: 'materialProductionSection',
                    titleLabelKey: 'materialProductionSection',
                    titleHelpKey: 'material.materialProductionSection',
                    titleIcon: 'md md-alarm-on  content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'materialCategory',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'materialUIModel',
                        tabTitleKey: 'materialProductionSection',
                        titleLabelKey: 'materialProductionSection',
                        titleHelpKey: 'material.materialProductionSection',
                        titleIcon: 'md md-alarm-on  content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'materialCategory',
                            newRow: true,
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.loadMaterialCategoryURL,
                                formatMeta: 'formatMaterialCategory'
                            },
                            helpKey: 'material.materialCategory',
                            iconArray: 'getMaterialCategoryIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'supplyType',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getSupplyTypeURL,
                                formatMeta: 'formatSupplyType'
                            },
                            helpKey: 'material.supplyType',
                            iconArray: 'getSupplyTypeIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'qualityInspectFlag',
                            helpKey: 'material.qualityInspectFlag',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getQualityInspectFlagMapURL,
                                formatMeta: SystemStandrdMetadataProxy.formatDefaultSwitchCode,
                            },
                            iconArray: SystemStandrdMetadataProxy.getDefaultSwitchIconArray(),
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            refControl: {
                                id: RefControl.Ids.Separator
                            }
                        }, {
                            fieldName: 'fixLeadTime',
                            newRow: true,
                            helpKey: 'material.fixLeadTime',
                            helpBlockKey: 'fixLeadTimeTitle'
                        }, {
                            fieldName: 'variableLeadTime',
                            helpKey: 'material.variableLeadTime',
                            helpBlockKey: 'variableLeadTimeTitle'
                        }, {
                            fieldName: 'amountForVarLeadTime',
                            helpKey: 'material.amountForVarLeadTime',
                            helpBlockKey: 'amountForVarLeadTimeTitle'
                        }, {
                            fieldName: 'operationMode',
                            helpKey: 'material.operationMode',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getOperationModeURL,
                                formatMeta: 'formatOperationMode',
                            },
                            iconArray: 'getOperationModeIconMap',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }]
                    }, {
                        sectionId: 'materialPriceSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'materialUIModel',
                        tabTitleKey: 'materialPriceSection',
                        titleLabelKey: 'materialPriceSection',
                        titleHelpKey: 'material.materialPriceSection',
                        titleIcon: 'md md-attach-money content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'purchasePrice',
                            newRow: true,
                            helpKey: 'material.purchasePrice'
                        }, {
                            fieldName: 'purchasePriceDisplay',
                            helpKey: 'material.purchasePriceDisplay'
                        }, {
                            fieldName: 'retailPrice',
                            newRow: true,
                            helpKey: 'material.retailPrice'
                        }, {
                            fieldName: 'retailPriceDisplay',
                            helpKey: 'material.retailPriceDisplay'
                        }, {
                            fieldName: 'unitCost',
                            newRow: true,
                            helpKey: 'material.unitCost'
                        }, {
                            fieldName: 'unitCostDisplay',
                            helpKey: 'material.unitCostDisplay'
                        }]
                    }]
                }, {
                    tabId: 'materialUnitSection',
                    tabTitleKey: 'materialUnitSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'materialUnitSection',
                        parentContentPath: 'materialUnitUIModelList',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        refItemName: 'materialUnitPanel',
                        detailedPageUrl:'MaterialUnitEditor.html',
                        editModuleFlag: true,
                        editModuleModalFlag: true,
                        requiredSubmit: true,
                        tabTitleKey: 'materialUnitSection',
                        titleLabelKey: 'materialUnitSection',
                        titleHelpKey: 'material.materialUnitSection',
                        titleIcon: 'md md-my-library-books content-portlet-title',
                        scrollX: true,
                        embedProcessButtonMeta: {
                            addDisableFlag: 'disableNotInInit',
                            addTitle: 'addMaterialUnitTitle',
                            newModuleFlag:true,
                            // addCallback: 'addMaterialUnit',
                            addLabel: 'addMaterialUnit'
                        },
                        fieldMetaList: [{
                            fieldName: 'materialUnitUIModel.uuid'
                        }, {
                            fieldName: 'materialUnitUIModel.unitName',
                            labelKey: 'materialUnit.unitName',
                            minWidth: '180px'
                        }, {
                            fieldName: 'materialUnitUIModel.ratioToStandard',
                            labelKey: 'materialUnit.ratioToStandard',
                            minWidth: '180px'
                        }, {
                            fieldName: 'materialUnitUIModel.retailPrice',
                            labelKey: 'materialUnit.retailPrice',
                        }, {
                            fieldName: 'materialUnitUIModel.netWeight',
                            labelKey: 'materialUnit.netWeight',
                        }, {
                            fieldName: 'materialUnitUIModel.note',
                            labelKey: 'materialUnit.note',
                            minWidth: '180px'
                        }]
                    }]
                }, {
                    tabId: 'materialSKUSection',
                    tabTitleKey: 'materialSKUSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'materialSKUSection',
                        parentContentPath: 'materialStockKeepUnitUIModelList',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        editModule: 'editMaterialSKU',
                        dataListPath: 'cache.materialStockKeepList',
                        requiredSubmit: true,
                        tabTitleKey: 'materialSKUSection',
                        titleLabelKey: 'materialSKUSection',
                        titleHelpKey: 'material.materialSKUSection',
                        titleIcon: 'md md-texture content-portlet-title',
                        scrollX: true,
                        embedProcessButtonMeta: {
                            addDisableFlag: 'disableNotInInit',
                            addTitle: 'addMaterialSKUTitle',
                            addCallback: 'addMaterialSKU',
                            addLabel: 'addMaterialSKU'
                        },
                        fieldMetaList: [{
                            fieldName: 'materialStockKeepUnit.uuid'
                        }, {
                            fieldName: 'materialStockKeepUnit.id',
                            labelKey: 'materialStockKeepUnit.id',
                            minWidth: '180px',
                            docPopConfig: {
                                documentType: DocumentConstants.DummyDocumentType.MaterialStockKeepUnit,
                                uuidFieldName: 'materialStockKeepUnit.uuid'
                            }
                        }, {
                            fieldName: 'materialStockKeepUnit.name',
                            labelKey: 'materialStockKeepUnit.name',
                            minWidth: '180px'
                        }, {
                            fieldName: 'materialStockKeepUnit.packageStandard',
                            labelKey: 'materialStockKeepUnit.packageStandard'
                        }, {
                            fieldName: 'materialStockKeepUnit.materialCategoryValue',
                            labelKey: 'materialStockKeepUnit.materialCategory',
                            fieldKey: 'materialStockKeepUnit.materialCategory',
                            iconArray: 'getMaterialCategoryIconArray',
                            minWidth: '180px'
                        }, {
                            fieldName: 'materialStockKeepUnit.materialTypeName'
                        }]
                    }]
                }]
            };
        },

        

        addMaterialSKU: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.materialUIModel.uuid;
            var resultURL = "MaterialStockKeepUnitEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        editMaterialSKU: function (uuid) {
            var vm = this;
            var preLockSKUURL = '../materialStockKeepUnit/preLockService.html';
            ServiceUtilityHelper.navigateToEditModule({
                uuid: uuid,
                $http: vm.$http,
                author: vm.author,
                editorPage: "MaterialStockKeepUnitEditor.html",
                preLockURL: preLockSKUURL,
                forceNewWindow: true,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function (oData) {
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },


    }
});
