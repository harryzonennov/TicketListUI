var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        author:{
            resourceId:'Warehouse',
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        processButtonMeta:[],
        searchModuleURL: '../warehouse/searchModuleService.html'
    },

    created: function(){
        this.initAuthorResourceCheck();
        this.initSubComponents();
    },

    methods: {

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        searchModule: function () {
            listVar.searchModuleList();
        },


        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "WarehouseEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});

var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            name: "",
            id: "",
            switchFlag: "",
            contactTelephone: "",
            addressInfo: "",
            operationMode: "",
            uuid: "",
            refMaterialCategory:"",
            contactEmployeeID:''

        },

        label: WarehouseManager.label.warehouse,

        getRefMaterialCategoryURL:'../warehouse/getRefMaterialCategoryMap.html',
        eleRefMaterialCategory: '#x_refMaterialCategory'
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            vm.getRefMaterialCategory(vm.content);

        });
    },

    methods: {
        clearSearch: function(){
            clearSearchModel(this.content);
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleRefMaterialCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refMaterialCategory',$(vm.eleRefMaterialCategory).val());
            });
        },

        getRefMaterialCategory: function (content) {
            var vm = this;
            this.$http.get(this.getRefMaterialCategoryURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                resultList.splice(0, 0, {'id': '0', 'text': ' '});
                setTimeout(function () {
                    $(vm.eleRefMaterialCategory).select2({
                        data: resultList,
                        templateResult: WarehouseManager.formatMatCategoryIcon,
                        templateSelection: WarehouseManager.formatMatCategoryIcon
                    });
                    // manually set initial value
                    $(vm.eleRefMaterialCategory).val(content.refMaterialCategory);
                    $(vm.eleRefMaterialCategory).trigger("change");
                }, 0);
            });
        }

    }
});

var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: WarehouseManager.label.warehouse,
        tableId: '#x_table_warehouse',
        datatable: '',
        items: [],
        loadModuleListURL: '../warehouse/loadModuleListService.html',
        preLockURL: '../warehouse/preLockService.html',
        deleteModuleURL: '../warehouse/deleteModule.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
        this.setI18nProperties(processModel.initProcessButtonMeta);
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'Warehouse');
            //this.datatable = new ServiceDataTable(this.tableId);
            this.loadModuleList();
        });
    },

    methods: {

        initSubComponents: function(){
            "use strict";
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: vm.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'Warehouse',
                    callback: vm.setNodeI18nPropertiesCore
                }]
            });
        },

        getI18nPath: function () {
            return 'coreFunction/';
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        searchModuleList: function () {
            this.$refs.dataTableFrame.searchModuleList();
        },

        buildSearchData: function (data) {
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../warehouse/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'id',
                labelKey: 'id',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.Warehouse,
                    uuidFieldName: 'uuid'
                }
            }, {
                fieldName: 'name',
                labelKey: 'name',
                minWidth: '180px'
            },{
                fieldName: 'refMaterialCategoryValue',
                fieldKey: 'refMaterialCategory',
                labelKey: 'refMaterialCategory',
                iconArray: WarehouseManager.getMatCategoryIconArray(),
                minWidth: '180px'
            },{
                fieldName: 'contactTelephone',
                labelKey: 'contactTelephone',
                minWidth: '180px'
            },{
                fieldName: 'contactEmployeeID',
                labelKey: 'contactEmployeeID',
                minWidth: '180px'
            },{
                fieldName: 'area',
                labelKey: 'area',
                minWidth: '180px'
            },{
                fieldName: 'addressInfo',
                labelKey: 'addressInfo',
                minWidth: '180px'
            }];
            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        },

        loadModuleList2: function () {
            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:vm.loadModuleListURL,
                $http:vm.$http,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    vm.$set(vm, 'items', oData.content);
                    setTimeout(function () {
                        vm.datatable.build();
                    }, 0);
                }.bind(this)
            });
        },

        refreshTableItems: function (items) {
            this.datatable = new ServiceDataTable(this.tableId);
            this.$set(this, 'items', items);
            setTimeout(function () {
                this.datatable.build();
            }.bind(this), 0);

        },

        editModule: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                author:processModel.author,
                $http:vm.$http,
                editorPage:"WarehouseEditor.html",
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        formatMaterialCategory: function(refMaterialCategory){
            return WarehouseManager.formatMatCategoryIconClass(refMaterialCategory);
        },


        preLock: function () {
        }
    }
});
