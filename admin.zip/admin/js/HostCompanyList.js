var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        processButtonMeta:[],
        searchModuleURL: '../hostCompany/searchModuleService.html'
    },

    created: function(){
        this.initSubComponents();
    },

    methods: {

        initSubComponents: function () {
            "use strict";
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        searchModule: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.searchModuleURL, requestData).then(function (response) {
                listVar.refreshTableItems(JSON.parse(response.data).content);
            });
        },

        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = content.uuid;
            var resultURL = "HostCompanyEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            webPage: "",
            latitude: "",
            streetName: "",
            fullName: "",
            refCityUUID: "",
            regularType: "",
            organType: "",
            mobile: "",
            houseNumber: "",
            refFinOrgUUID: "",
            mainContactUUID: "",
            address: "",
            comReportTitle: "",
            comLogo: "",
            addressInfo: "",
            fax: "",
            name: "",
            townZone: "",
            organizationFunction: "",
            uuid: "",
            addressOnMap: "",
            id: "",
            postcode: "",
            email: "",
            contactTelephone: "",
            cityName: "",
            contactMobileNumber: "",
            accountType: "",
            refOrganizationFunction: "",
            parentOrganizationUUID: "",
            subArea: "",
            refCashierUUID: "",
            telephone: "",
            longitude: "",
            refAccountantUUID: "",
            organLevel: ""

        },

        label: HostCompanyManager.label.hostCompany
    }

});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: HostCompanyManager.label.hostCompany,
        tableId: '#x_table_hostCompany',
        datatable: '',
        items: [],
        loadModuleListURL: '../hostCompany/loadModuleListService.html',
        preLockURL: '../hostCompany/preLockService.html'
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'HostCompany');
            this.datatable = new ServiceDataTable(this.tableId);
            this.setI18nProperties(processModel.initProcessButtonMeta);
            this.loadModuleList();
        });
    },
    methods: {
        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'HostCompany',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        loadModuleList: function () {
            var vm = this;
            this.$http.get(vm.loadModuleListURL).then(function (response) {
                if (!JSON.parse(response.data).content) {
                    $.Notification.notify('error', 'top center', this.label.msgConnectFailure, this.label.msgUnknowSystemFailure);
                    return;
                }
                vm.$set(vm, 'items', JSON.parse(response.data).content);
                setTimeout(function () {
                    vm.datatable.build();
                }, 0);
            });
        },
        refreshTableItems: function (items) {
            this.datatable = new ServiceDataTable(this.tableId);
            this.$set(this,'items', items);
            setTimeout(function () {
                this.datatable.build();
            }.bind(this), 0);

        },
        editModule: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            window.location.href = genCommonEditURL("HostCompanyEditor.html", uuid);

        },
        preLock: function () {
        }
    }
});
