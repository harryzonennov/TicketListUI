var WarehouseManager = function () {

};

WarehouseManager.label = {
    warehouse: ServiceUtilityHelper.getComLabelObject({
        streetName: '',
        cityName: '',
        refWarehouseType: '',
        length: '',
        longitude: '',
        addressOnMap: '',
        warehouseType: '',
        forbiddenGoodsFlag: '',
        latitude: '',
        operationType: '',
        width: '',
        warehouseCategory: '',
        switchFlag: '',
        restrictedSuppilerFlag: '',
        volume: '',
        modelTitle:'',
        upOrganizationId:'',
        upOrganizationName:'',
        contactTelephone: '',
        addressInfo: '',
        operationMode: '',
        townZone: '',
        height: '',
        postcode: '',
        subArea: '',
        hasFootStep: '',
        houseNumber: '',
        restrictedGoodsFlag: '',
        area: '',
        availTempBookingNote: '',
        systemDefault:'',
        refMaterialCategory:'',
        warehouseStoreSettingMaxSafeStoreAmount: '',
        warehouseSection: '',
        refTechSection:'',
        warehouseStoreSettingSection: '',
        warehouseAreaSection: '',
        WarehouseTreeSection: '',
        addWarehouseArea:'',
        addWarehouseStoreSetting:'',
        contactEmployeeID:'',
        contactEmployeeName: '',
        clearSearch:'',
        clearSearchComment:'',
        storeType: '',
        advancedSearchCondition: ''
    }),
    warehouseArea: ServiceUtilityHelper.getComLabelObject({
        storeType: '',
        warehouseAreaSection: '',
        warehouseAreaStoreItemSection: '',
        refTechSection:'',
        length:'',
        area:'',
        width:'',
        volume:'',
        warehouseId: '',
        warehousePageTitle:'',
        itemPageTitle:''
    }),
    warehouseStoreSetting: ServiceUtilityHelper.getComLabelObject({
        safeStoreCalculateCategory: '',
        maxStoreRatio: '',
        dataSourceType: '',
        maxSafeStoreAmount: '',
        refMaterialSKUName:'',
        refMaterialSKUId:'',
        minStoreRatio: '',
        errorType: '',
        minSafeStoreAmount: '',
        targetAverageStoreAmount: ''
    })
};

WarehouseManager.content = {
    warehouseUIModel: ServiceUtilityHelper.extendObject({
        refCityUUID: '',
        mainContactUUID: '',
        streetName: '',
        cityName: '',
        refWarehouseType: '',
        length: '',
        longitude: '',
        addressOnMap: '',
        warehouseType: '',
        forbiddenGoodsFlag: '',
        latitude: '',
        operationType: '',
        width: '',
        warehouseCategory: '',
        switchFlag: '',
        restrictedSuppilerFlag: '',
        volume: '',
        contactTelephone: '',
        addressInfo: '',
        operationMode: '',
        townZone: '',
        height: '',
        postcode: '',
        subArea: '',
        hasFootStep: '',
        houseNumber: '',
        restrictedGoodsFlag: '',
        area: '',
        availTempBookingNote: '',
        refParentOrgRefUUID:'',
        refMaterialCategory:'',
        warehouseStoreSettingRefMaterialSKUUUID: '',
        warehouseStoreSettingRefNodeName: '',
        warehouseStoreSettingRefUUID: '',
        warehouseStoreSettingMaxSafeStoreAmount: '',
        warehouseRefParentOrgRefUUID: '',
        warehouseRefParentOrgRefNodeName: ''
    }, ServiceUtilityHelper.getDefContent()),
    warehouseAreaUIModel: ServiceUtilityHelper.extendObject({
        storeType: '',
        warehouseId:'',
        length:'',
        area:'',
        width:'',
        volume:''
    }, ServiceUtilityHelper.getDefContent())
};

WarehouseManager.labelTemplate = {
    data: function() {
        return {
            label: {
                "warehouseArea":WarehouseManager.label.warehouseArea,
                "warehouseStoreSetting": WarehouseManager.label.warehouseStoreSetting
            }
        };
    }
};

WarehouseManager.constants = {
    loadWarehouseListURL: '../warehouse/loadLeanModuleListService.html',
    searchWarehouseListURL: '../warehouse/searchLeanModuleService.html',
    loadWasteWarehouseListURL: '../warehouse/loadLeanWasteListService.html',
    loadWarehouseAreaListURL: '../warehouseArea/loadLeanModuleListService.html',
    loadWarehouseURL: '../warehouse/loadModule.html',
    loadWarehouseAreaURL: '../warehouseArea/loadModule.html'
};

WarehouseManager.formatTypeIconByRefMatCategory = function(refMaterialCategory){
    if(refMaterialCategory * 1 === DocumentConstants.Warehouse.refMaterialCategory.WASTE){
        return 'md md-store content-red';
    }
    return DocumentManagerFactory.formatDocTypeIconClass(DocumentConstants.DummyDocumentType.Warehouse);
};

WarehouseManager.getMatCategoryIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.Warehouse.refMaterialCategory.NORMAL, iconClass: 'nmd nmd-playlist-add-check content-green'},
        {id: DocumentConstants.Warehouse.refMaterialCategory.WASTE, iconClass: 'md md-block content-red'}
    ];
};


/**
 * [API] Get root node inst id
 */
WarehouseManager.getRootNodeInstId = function(){
    return "warehouse";
};

/**
 * [API]Get item node inst id
 */
WarehouseManager.getItemNodeInstId = function(){
    return "warehouseArea";
};


/**
 * [API] Get resource id for checking authorization
 */
WarehouseManager.getResourceId = function(){
    return ServiceModuleConstants.Warehouse;
};

/**
 * [API] Get document type
 */
WarehouseManager.getDocumentType = function(){
    return DocumentConstants.DummyDocumentType.Warehouse;
};

/**
 * [API]Get root 18n config
 */
WarehouseManager.getI18nRootConfig = function () {
    return {
        i18nPath: 'coreFunction/',
        mainName: 'Warehouse',
        modelId: 'Warehouse', coreModelId: 'Warehouse',
        configList: [{
            name: 'WarehouseArea',
            subLabelPath: 'warehouseArea'
        }, {
            name: 'WarehouseStoreSetting',
            subLabelPath: 'warehouseStoreSetting'
        }]
    };
};

/**
 * [API]Get item 18n config
 */
WarehouseManager.getI18nItemConfig = function () {
    "use strict";
    return {
        i18nPath: 'coreFunction/',
        labelObject: WarehouseManager.label.corporateContactPerson,
        mainName: 'WarehouseArea',
        modelId: 'Warehouse', coreModelId: 'WarehouseArea',
        configList: [{
            name: 'WarehouseArea'
        }]
    };
};


WarehouseManager.setI18nCommonProperties = function () {
    ServiceUtilityHelper.setI18nCommonReflective(WarehouseManager.label.warehouse, $.i18n.prop);
};

WarehouseManager.setNodeI18nPropertiesCore = function () {
    ServiceUtilityHelper.setI18nReflective(WarehouseManager.label.warehouse, $.i18n.prop, true);
};

WarehouseManager.setNodeI18nPropertiesArea = function () {
    ServiceUtilityHelper.setI18nReflective(WarehouseManager.label.warehouseArea, $.i18n.prop, true);
};

WarehouseManager.setNodeI18nPropertiesSettings = function () {
    ServiceUtilityHelper.setI18nReflective(WarehouseManager.label.warehouseStoreSetting, $.i18n.prop, true);
};

WarehouseManager.prototype.getI18nWrap = function (fnCallback) {
    var vm = this;
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "coreFunction/",
        commonCallback: WarehouseManager.setI18nCommonProperties,
        fnCallback: fnCallback,
        configList: [{
            name: 'Warehouse',
            callback: WarehouseManager.setNodeI18nPropertiesCore
        },{
            name: 'WarehouseArea',
            callback: WarehouseManager.setNodeI18nPropertiesArea
        },{
            name: 'WarehouseStoreSetting',
            callback: WarehouseManager.setNodeI18nPropertiesSettings
        }]
    });
};
/**
 * @override Set Basic path for i18n function.
 * @returns {string}
 */
WarehouseManager.getI18nPath = function () {
    return "coreFunction/";
};


WarehouseManager.formatMatCategoryIconClass = function (refMatCategory) {
    "use strict";
    var refMatCategoryIconArray = WarehouseManager.getMatCategoryIconArray();
    var $element = ServiceCollectionsHelper.filterArray(refMatCategory, 'id', refMatCategoryIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

WarehouseManager.formatMatCategoryIcon = function (refMatCategory) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(refMatCategory, WarehouseManager.getMatCategoryIconArray(), true);
    return $element;
};

WarehouseManager.calculateLoadWarehouseListUrl = function(oSettings){
    "use strict";
    if(!oSettings || !oSettings.refMaterialCategory){
        return WarehouseManager.constants.loadWarehouseListURL;
    }
    if(oSettings.refMaterialCategory * 1 === DocumentConstants.Warehouse.refMaterialCategory.WASTE){
        return WarehouseManager.constants.loadWasteWarehouseListURL;
    }
    return WarehouseManager.constants.loadWarehouseListURL;
};

WarehouseManager.calculateSearchRequest = function(oSettings){
    "use strict";
    var requestData = {};
    if(oSettings.refMaterialCategory){
        requestData.refMaterialCategory = oSettings.refMaterialCategory;
    }
    return requestData;
};



/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
WarehouseManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../warehouse/loadModuleViewService.html';
};

/**
 * Utility method of loading warehouse select as well as warehouse area
 * @param oSettings *
 *        ---{string} refWarehouseUUID: initial value: warehouse UUID
 *        ---{DOM} eleRefWarehouseUUID: Select DOM element for Warehouse
 *        ---{string} selectField: [Option] select field for Warehouse, if none, default value is 'id'
 *        ---{string} refWarehouseAreaUUID: initial value: warehouse Area UUID
 *        ---{DOM} eleRefWarehouseAreaUUID: Select DOM element for Warehouse Area
 *        ---{boolean} addEmptyValue: whether need to add empty value for select
 *        ---{boolean} addEmptyAreaValue: whether need to add empty value for select warehouseArea,
 *                    in case need to set specific empty value for warehouse area .
 *        ---{function} fnSetInitWarehouseUUID: call-back after warehouse value is set to select DOM
 *        ---{function} fnSetInitWarehouseAreaUUID: call-back after warehouse area value is set to select DOM
 */
WarehouseManager.loadWarehouseSelectList = function ( oSettings ) {
    "use strict";
    var initValue = oSettings.refWarehouseUUID;
    $.ajax({
        // url: WarehouseManager.calculateLoadWarehouseListUrl(oSettings),
        url: WarehouseManager.constants.searchWarehouseListURL,
        dataType: "json",
        type: "post",
        data:  JSON.stringify(WarehouseManager.calculateSearchRequest(oSettings)),
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success:function(oData){
            var resultList = oData;
            var selectField = oSettings.selectField ? oSettings.selectField : 'id';
            resultList = formatSelectResult(oData.content, 'uuid', selectField);
            if( resultList && oSettings.addEmptyValue && (oSettings.addEmptyValue === true || oSettings.addEmptyValue === 'true')){
                resultList.splice(0, 0, {'id': '0', 'text': ' '});
            }
            setTimeout(function () {
                $(oSettings.eleRefWarehouseUUID).empty();
                $(oSettings.eleRefWarehouseUUID).select2({
                    data: resultList
                });
                var refWarehouseUUID = initValue ? initValue : undefined;
                if (!refWarehouseUUID) {
                    if (oSettings.fnSetInitWarehouseUUID && typeof  oSettings.fnSetInitWarehouseUUID === 'function') {
                        if (resultList && resultList.length && resultList.length > 0) {
                            refWarehouseUUID = resultList[0].id;
                        }
                    }
                }
                if (oSettings.fnSetInitWarehouseUUID && typeof  oSettings.fnSetInitWarehouseUUID === 'function') {
                    oSettings.fnSetInitWarehouseUUID(refWarehouseUUID);
                }
                oSettings.refWarehouseUUID = refWarehouseUUID;
                $(oSettings.eleRefWarehouseUUID).val(refWarehouseUUID);
                $(oSettings.eleRefWarehouseUUID).trigger("change");
                if(oSettings.eleRefWarehouseAreaUUID){
                    WarehouseManager.loadWarehouseAreaSelectList(oSettings);
                }
            }, 0);
        },
        error:function(){
            // do nothing currently
        }
    });
};

/**
 * Utility method of loading warehouse area
 * @param oSettings:
 *        ---{string} refWarehouseUUID: warehouse UUID
 *        ---{string} refWarehouseAreaUUID: initial value: warehouse Area UUID
 *        ---{DOM} eleRefWarehouseAreaUUID: Select DOM element for Warehouse Area
 *        ---{boolean} addEmptyAreaValue: whether need to add empty value for select
 *        ---{function} fnSetInitWarehouseAreaUUID: call-back after warehouse area value is set to select DOM
 */
WarehouseManager.loadWarehouseAreaSelectList = function ( oSettings ) {
    var requestData = {"parentNodeUUID": oSettings.refWarehouseUUID};
    $.ajax({
        url: WarehouseManager.constants.loadWarehouseAreaListURL,
        dataType: "json",
        type: "post",
        data:  JSON.stringify(requestData),
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (oData) {
            var resultList = oData;
            resultList = formatSelectResult(oData.content, 'uuid', 'id');
            if( resultList && oSettings.addEmptyAreaValue && oSettings.addEmptyAreaValue === true){
                resultList.splice(0, 0, {'id': '0', 'text': ' '});
            }
            setTimeout(function () {
                $(oSettings.eleRefWarehouseAreaUUID).empty();
                $(oSettings.eleRefWarehouseAreaUUID).select2({
                    data: resultList
                });
                var refWarehouseAreaUUID = oSettings.refWarehouseAreaUUID ? oSettings.refWarehouseAreaUUID : undefined;
                if (!refWarehouseAreaUUID) {
                    if (oSettings.fnSetInitWarehouseAreaUUID && typeof  oSettings.fnSetInitWarehouseAreaUUID === 'function') {
                        if (resultList && resultList.length && resultList.length > 0) {
                            refWarehouseAreaUUID = resultList[0].id;
                        }
                    }
                }
                if (oSettings.fnSetInitWarehouseAreaUUID && typeof  oSettings.fnSetInitWarehouseAreaUUID === 'function') {
                    oSettings.fnSetInitWarehouseAreaUUID(refWarehouseAreaUUID);
                }
                $(oSettings.eleRefWarehouseAreaUUID).val(refWarehouseAreaUUID);
                $(oSettings.eleRefWarehouseAreaUUID).trigger("change");
            }, 0);
        },
        error: function () {
            // do nothing currently
        }
    });

};

/**
 * Generate handler to handle when warehouse UUID select
 * @param oSettings
 * @return {(function(*): void)|*}
 */
WarehouseManager.genHandlerSelectWarehouseUUID = function(oSettings){
    return function(e){
        // Set value to vue from select2 manually by select2's bug
        var refWarehouseUUID = $(oSettings.eleRefWarehouseUUID).val();
        if(oSettings.fnSetWarehouseUUID && typeof  oSettings.fnSetWarehouseUUID === 'function'){
            oSettings.fnSetWarehouseUUID(refWarehouseUUID);
        }
        // In case also need to init warehouse Area
        if(oSettings.eleRefWarehouseAreaUUID){
            // WarehouseManager.initWarehouseAreaSelect(oSettings);
            // Also need to Update the warehouse area meta data
            WarehouseManager.loadWarehouseAreaSelectList({
                eleRefWarehouseAreaUUID:oSettings.eleRefWarehouseAreaUUID,
                addEmptyAreaValue:oSettings.addEmptyAreaValue,
                refWarehouseUUID:refWarehouseUUID,
                fnSetInitWarehouseAreaUUID:oSettings.fnSetInitWarehouseAreaUUID
            });
        }
        // In case need to use set Warehouse Entity call back
        if (oSettings.fnSetWarehouse && typeof  oSettings.fnSetWarehouse === 'function' && refWarehouseUUID) {
            var url = WarehouseManager.constants.loadWarehouseURL + "?uuid=" + refWarehouseUUID;
            $.ajax({
                url: url,
                dataType: "json",
                type: "get",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                success: function (oData) {
                    var resultList = oData;
                    var warehouse = oData.content;
                    if (oSettings.fnSetWarehouse && typeof  oSettings.fnSetWarehouse === 'function') {
                        oSettings.fnSetWarehouse(warehouse);
                    }
                },
                error: function () {
                    // do nothing currently
                }
            });
        }
    };

};

    /**
 * Utility method to init Warehouse & Warehouse Area Select DOM
 *        ---{DOM} eleRefWarehouseUUID: Select DOM element for Warehouse
 *        ---{DOM} eleRefWarehouseAreaUUID: Select DOM element for Warehouse Area
 *        ---{boolean} addEmptyAreaValue: need to add empty value for Area
 *        ---{function} fnSetWarehouseUUID: call-back after warehouse uuid is get
 *        ---{function} fnSetWarehouse: call-back after warehouse model is get
 *        ---{function} fnSetWarehouseAreaUUID: call-back after warehouse area uuid is get
 *        ---{function} fnSetWarehouseArea: call-back after warehouse area model is get
 */
WarehouseManager.initWarehouseSelect = function ( oSettings ) {
    // $(oSettings.eleRefWarehouseUUID).on("select2:close", WarehouseManager.genHandlerSelectWarehouseUUID(oSettings));
    // $(oSettings.eleRefWarehouseUUID).on("select2:select", WarehouseManager.genHandlerSelectWarehouseUUID(oSettings));
    ServiceUtilityHelper.initSelectConfig({
        element: oSettings.eleRefWarehouseUUID,
        handler: WarehouseManager.genHandlerSelectWarehouseUUID(oSettings)
    });
    if(oSettings.eleRefWarehouseAreaUUID) {
        WarehouseManager.initWarehouseAreaSelect(oSettings);
    }
};


WarehouseManager.genHandlerSelectWarehouseAreaUUID = function (oSettings){
    return function (e) {
        // Set value to vue from select2 manually by select2's bug
        var refWarehouseAreaUUID = $(oSettings.eleRefWarehouseAreaUUID).val();
        if(oSettings.fnSetWarehouseAreaUUID && typeof  oSettings.fnSetWarehouseAreaUUID === 'function'){
            oSettings.fnSetWarehouseAreaUUID(refWarehouseAreaUUID);
        }
        if (oSettings.fnSetWarehouseArea && typeof  oSettings.fnSetWarehouseArea === 'function' && refWarehouseAreaUUID) {
            var url = WarehouseManager.constants.loadWarehouseAreaURL + "?uuid=" + refWarehouseAreaUUID;
            $.ajax({
                url: url,
                dataType: "json",
                type: "get",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                success: function (oData) {
                    var warehouseArea = oData.content;
                    oSettings.fnSetWarehouseArea(warehouseArea);
                },
                error: function () {
                    // do nothing currently
                }
            });
        }
    };
};

/**
 * Utility method to init Warehouse Area Select DOM
 *        ---{DOM} eleRefWarehouseAreaUUID: Select DOM element for Warehouse Area
 *        ---{function} fnSetWarehouseAreaUUID: call-back after warehouse area uuid is get
 *        ---{function} fnSetWarehouseArea: call-back after warehouse area model is get
 */
WarehouseManager.initWarehouseAreaSelect = function ( oSettings ) {
    ServiceUtilityHelper.initSelectConfig({
        element: oSettings.eleRefWarehouseAreaUUID,
        handler: WarehouseManager.genHandlerSelectWarehouseAreaUUID(oSettings)
    });
};

WarehouseManager.prototype.getModelTitle = function(){
    return WarehouseManager.label.warehouse.modelTitle;
};

WarehouseManager.prototype.getDefaultDocumentEditorPage = function () {
    "use strict";
    return "WarehouseEditor.html";
};


WarehouseManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: vm.getDefaultDocumentEditorPage(),
        url: "../warehouse/loadModuleViewService.html",
        subPath: 'warehouseUIModel',
        label: WarehouseManager.label.warehouse,
        docType : DocumentConstants.DummyDocumentType.Warehouse,
        getI18nWrap:vm.getI18nWrap.bind(vm)
    });
    var fieldMetaList = [{
        fieldName:'id',
    },{
        fieldName:'name',
    },{
        fieldName:'contactTelephone',
    },{
        fieldName:'refMaterialCategoryValue',
        fieldKey:'refMaterialCategory',
        labelKey:'refMaterialCategory',
        iconArray: WarehouseManager.getMatCategoryIconArray(),
    },{
        fieldName: 'upOrganizationId'
    },{
        fieldName: 'upOrganizationName'
    },{
        fieldName: 'addressInfo'
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};


