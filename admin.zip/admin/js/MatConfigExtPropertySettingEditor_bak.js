var rightBar = new Vue({
    el: "#rightBarHoc",
    mixins: [ServiceRightBarPanelHelper.defTimelineMinxin],
    data: function () {
        return {
            coreModelId: "MatConfigExtPropertySetting",
            i18nPath:"coreFunction/",
            label: MaterialConfigureTemplateManager.label.matDecisionValueSetting
        };
    },

    methods: {
        initHelpDocumentList: function (uuid) {
            "use strict";
            var vm = this;
            ServiceRightBarPanelHelper.initHelpDocumentWithAction({
                uuid: uuid,
                vm: vm,
                documentType: DocumentConstants.DummyDocumentType.MaterialConfigureTemplate,
                errorHandle: dataVar.errorHandle,
                helpDocumentName: 'MatConfigExtPropertySettingHelpDocument'
            });
        }
    }
});

var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: MaterialConfigureTemplateManager.label.matConfigExtPropertySetting,
        content: {
            matConfigExtPropertySettingUIModel:{
                client: '',
                uuid: '',
                id: '',
                fieldType: '',
                name: '',
                note: '',
                qualityInspectFlag: '',
                valueUsage: '',
                measureFlag: '',
                refUnitUUID: '',
                templateId: '',
                templateName: ''
            }
        },
        processButtonMeta: [],
        getPageHeaderModelListURL: '../matConfigExtPropertySetting/getPageHeaderModelList.html',
        searchStandardUnitURL:'../standardMaterialUnit/searchModuleService.html',
        getQualityInspectFlagURL: '../matConfigExtPropertySetting/getQualityInspectFlag.html',
        eleFieldType: '#x_fieldType',
        loadModuleEditURL: '../matConfigExtPropertySetting/loadModuleEditService.html',
        loadModuleViewURL: '../matConfigExtPropertySetting/loadModuleViewService.html',
        saveModuleURL: '../matConfigExtPropertySetting/saveModuleService.html',
        exitModuleURL: '../matConfigExtPropertySetting/exitEditor.html',
        newModuleServiceURL: '../matConfigExtPropertySetting/newModuleService.html'

    },

    created: function () {
        var vm = this;
        this.initSubComponents();
        this.setI18nProperties(vm.initProcessButtonMeta);
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'MaterialConfigureTemplate');
            this.loadModuleEdit();
        });
    },

    methods: {
        /**
         * Initial register sub component
         */
        initSubComponents: function () {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("page-header-union", PageHeaderUnion);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
            Vue.component("mat-config-ext-property-setting-control", MatConfigExtPropertySettingControl);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'MatConfigExtPropertySetting',
                    callback: vm.setNodeI18nPropertiesCore
                }]
            });
        },

        openRightSideBar: function(key){
            NavigationPanelIns.openRightSideBar(RightBarTemplate.TABS.tab2, key);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },


        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            vm.$refs.refBusyLoader.showBusyLoading();
            vm.$refs.control.loadModule({
                baseUUID: baseUUID,
                processMode: processMode,
                errorHandle: vm.errorHandle,
                pageCategory: DocumentConstants.StandardPropety.PageCategory.PAGE,
                postLoadData: function(content){
                    vm.$refs.refBusyLoader.hideBusyLoading();
                    vm.setModuleToUI(content);
                }
            });
        },

        displayForEdit: function () {
            if(this.$refs.control){
                return this.$refs.control.displayForEdit();
            }
        },

        getPageHeaderModelList: function (uuid, baseUUID) {
            var vm = this;
            vm.$refs.pageHeader.initPageHeader({
                uuid: uuid,
                baseUUID: baseUUID,
                pageHeaderListUrl: vm.getPageHeaderModelListURL,
                fnPageHeaderModel: vm.fnPageHeaderModel
            });
        },

        fnPageHeaderModel: function (pageHeaderModel) {
            if (pageHeaderModel.nodeInstId === 'materialConfigureTemplate') {
                var targetTab = MaterialConfigureTemplateManager.documentTab.matConfigExtPropertySettingSection;
                baseDocURL = genCommonEditURL("MaterialConfigureTemplateEditor.html", pageHeaderModel.uuid, targetTab);
                pageHeaderModel.pageLink = baseDocURL;
                pageHeaderModel.pageTitle = this.label.parentPageTitle + ":" + this.content.matConfigExtPropertySettingUIModel.templateId;
                return pageHeaderModel;
            }
        },

        saveModule: function () {
            var vm = this;
            vm.$refs.control.saveModule();
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.matConfigExtPropertySettingUIModel.parentNodeUUID;
            window.location.href = genCommonEditURL("MaterialConfigureTemplateEditor.html", baseUUID,
                MaterialConfigureTemplateManager.documentTab.matConfigExtPropertySettingSection);
        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.matConfigExtPropertySettingUIModel.uuid;
            window.location.href = genCommonEditURL("MatConfigExtPropertySettingEditor.html", baseUUID, tabKey);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'matConfigExtPropertySettingUIModel', content.matConfigExtPropertySettingUIModel);
            vm.getPageHeaderModelList(vm.content.matConfigExtPropertySettingUIModel.uuid, vm.content.matConfigExtPropertySettingUIModel.parentNodeUUID);
            rightBar.initHelpDocumentList(vm.content.matConfigExtPropertySettingUIModel.uuid);
        }

    }
});
