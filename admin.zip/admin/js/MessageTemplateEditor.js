var rightBar = new Vue({
    el: "#rightBarHoc",
    mixins: [ServiceRightBarPanelHelper.defTimelineMinxin, MessageTemplateManager.labelTemplate],
    data: function () {
        return {
            label: MessageTemplateManager.label,
            coreModelId: "MessageTemplate",
            i18nPath:"coreFunction/"
        };
    },

    methods: {

        initHelpDocumentList: function (uuid) {
            "use strict";
            var vm = this;
            ServiceRightBarPanelHelper.initHelpDocumentWithAction({
                uuid: uuid,
                vm: vm,
                errorHandle: dataVar.errorHandle,
                helpDocumentName: ['MessageTemplateHelpDocument']
            });
        }
    }
});

var dataVar = new Vue({
    el: "#x_data",
    mixins:[MessageTemplateManager.labelTemplate],
    data: {
        label: MessageTemplateManager.label.messageTemplate,
        content: {
            messageTemplateUIModel: {
                uuid: '',
                client: '',
                id: '',
                name: '',
                messageTitle:'',
                messageContent:'',
                messageLevelCode:'',
                messageLevelCodeValue:'',
                navigationSourceId:'',
                searchModelName:'',
                searchModelLabel:'',
                searchDataUrl: '',
                processIndex: '',
                handlerClass: '',
                searchProxyName:'',
                searchProxyLabel:'',
                searchModelClass: '',
                note: ''
            },
            messageTempSearchConditionUIModelList: [],
            messageTempPrioritySettingUIModelList: []
        },
        cache: {
            messageTempSearchCondition: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                fieldName: '',
                logicOperator: '',
                searchOperator: '',
                fieldValue: '',
                note: ''
            },
            messageTempPrioritySetting: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refPrioritySettingUUID: '',
                iconStyle: '',
                endValue: '',
                colorStyle: '',
                startValue: '',
                priorityCode: ''
            },
            searchConfigureList: []
        },
        author: {
            resourceId: ServiceModuleConstants.MessageTemplate,
            actionCode: {
                Edit: false,
                View: false,
                PriceInfo: false,
                Delete: false,
                Excel: false
            }
        },
        processButtonMeta: [],
        embedProcessButtonMeta:[],
        eleRefPrioritySettingUUID: '#x_refPrioritySettingUUID',
        eleSearchModelName: '#x_searchModelName',
        eleNavigationSourceId: '#x_navigationSourceId',
        eleHandlerClass: '#x_handlerClass',
        loadModuleEditURL: '../messageTemplate/loadModuleEditService.html',
        saveModuleURL: '../messageTemplate/saveModuleService.html',
        newModuleServiceURL: '../messageTemplate/newModuleService.html',
        newMessageTempSearchConditionServiceURL: '../messageTempSearchCondition/newModuleService.html',
        eleEditMessageTempSearchConditionModal: '#x_eleEditMessageTempSearchConditionModal',
        newMessageTempPrioritySettingServiceURL: '../messageTempPrioritySetting/newModuleService.html',
        getSearchModelNameMapURL: '../messageTemplate/getSearchModelNameMap.html',
        searchActiveModuleServiceURL: '../navigationItemSetting/searchActiveModuleService.html',
        getAllHandlerListURL: '../messageTemplate/getAllHandlerList.html',
        eleEditMessageTempPrioritySettingModal: '#x_eleEditMessageTempPrioritySettingModal',
        loadSystemCodeValueCollectionSelectListURL: '../SystemCodeValueCollection/loadModuleListService',
        exitURL: 'MessageTemplateList.html',
        exitModuleURL: '../messageTemplate/exitEditor.html'
    },

    created: function(){
        var vm = this;
        vm.initAuthorResourceCheck();
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'MessageTemplate');
            vm.setI18nProperties(vm.initProcessButtonMeta);
            vm.loadModuleEdit();
            vm.initSelectConfigure();
        });
    },

    methods: {

        initSubComponents: function(){
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
            Vue.component("message-temp-priority-panel", MessageTempPrioritySettingPanel);
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
            Vue.component("pop-panel-compensate-section", PopPanelCompensateSection);
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleSearchModelName).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                var modelId = $(vm.eleSearchModelName).val();
                var searchModelProxyUnion = ServiceCollectionsHelper.filterArray( modelId, 'modelId', vm.cache.searchConfigureList);
                vm.$set(vm.content.messageTemplateUIModel, 'searchModelName', modelId);
                if(searchModelProxyUnion){
                    vm.$set(vm.content.messageTemplateUIModel, 'searchProxyName', searchModelProxyUnion.proxyId);
                    vm.$set(vm.content.messageTemplateUIModel, 'searchModelLabel', searchModelProxyUnion.modelName);
                    vm.$set(vm.content.messageTemplateUIModel, 'searchProxyLabel', searchModelProxyUnion.proxyName);
                }
            });

            $(vm.eleNavigationSourceId).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                var navigationSourceId = $(vm.eleNavigationSourceId).val();
                vm.$set(vm.content.messageTemplateUIModel, 'navigationSourceId', navigationSourceId);
            });

            $(vm.eleHandlerClass).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                var handlerClass = $(vm.eleHandlerClass).val();
                vm.$set(vm.content.messageTemplateUIModel, 'handlerClass', handlerClass);
            });

        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();

        },

        setI18nPrioritySettingProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.messageTempPrioritySetting, $.i18n.prop, true);
        },

        setI18nSearchConditionProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.messageTempSearchCondition, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'MessageTemplate',
                    callback: this.setNodeI18nPropertiesCore
                }, {
                    name: 'MessageTempPrioritySetting',
                    callback: this.setI18nPrioritySettingProperties
                }, {
                    name: 'MessageTempSearchCondition',
                    callback: this.setI18nSearchConditionProperties
                },{
                    actionNode: vm.label.actionNode
                }]
            });
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },


        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        formatMessageLevelClass: function (messageLevelCode) {
            return MessageTempPriorityManager.formatMessageLevelCodeIconClass(messageLevelCode);
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            if (processMode === PROCESSMODE_NEW) {
                ServiceUtilityHelper.newModuleDefault({
                    newModuleServiceURL: vm.newModuleServiceURL,
                    vm:vm,
                    errorHandle:vm.errorHandle,
                    postSet:vm.setModuleToUI
                });
            }
            if (processMode === PROCESSMODE_EDIT) {
// In case [Edit mode]
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    errorHandle:vm.errorHandle,
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }
        },

        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }

        },

        copyMessageTempSearchCondition: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.fieldName = origin.fieldName;
            target.logicOperator = origin.logicOperator;
            target.searchOperator = origin.searchOperator;
            target.fieldValue = origin.fieldValue;
            target.note = origin.note;
            return target;

        },

        copyMessageTempPrioritySetting: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refPrioritySettingUUID = origin.refPrioritySettingUUID;
            target.iconStyle = origin.iconStyle;
            target.endValue = origin.endValue;
            target.colorStyle = origin.colorStyle;
            target.startValue = origin.startValue;
            target.priorityCode = origin.priorityCode;
            return target;

        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }

            ServiceUtilityHelper.httpRequest({
                url:this.saveModuleURL,
                $http:vm.$http,
                method:'post',
                requestData: vm.content,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    $.Notification.notify('success', 'top center', vm.label.msgSaveOK, vm.label.msgSaveOKComment);
                    vm.setModuleToUI(oData.content);
                    var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
                    if (processMode && processMode === PROCESSMODE_NEW) {
                        var baseUUID = vm.content.messageTemplateUIModel.uuid;
                        if (baseUUID) {
                            window.location.href = genCommonEditURL("MessageTemplateEditor.html", baseUUID);
                        }
                    }
                }.bind(this)
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.messageTemplateUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);

        },

        refreshEditView: function () {
            var baseUUID = this.content.messageTemplateUIModel.uuid;
            window.location.href = genCommonEditURL("MessageTemplateEditor.html", baseUUID);

        },

        getSearchModelNameMap: function (content) {
            var vm = this;
            ServiceUtilityHelper.loadModelMetaRequest({
                url: vm.getSearchModelNameMapURL,
                method: 'post',
                $http: vm.$http,
                idField: 'modelId',
                textField: 'modelId-modelName',
                initValue: vm.content.messageTemplateUIModel.searchModelName,
                element: vm.eleSearchModelName,
                errorHandle: vm.errorHandle
            });
        },

        getNavigationSourceList: function () {
            var vm = this;
            ServiceUtilityHelper.loadModelMetaRequest({
                url: vm.searchActiveModuleServiceURL,
                method: 'post',
                $http: vm.$http,
                idField: 'id',
                textField: 'id-name',
                requestData: {},
                initValue: vm.content.messageTemplateUIModel.navigationSourceId,
                element: vm.eleNavigationSourceId,
                errorHandle: vm.errorHandle
            });
        },


        getHandlerClassList: function () {
            var vm = this;
            ServiceUtilityHelper.loadModelMetaRequest({
                url: vm.getAllHandlerListURL,
                addEmptyFlag: true,
                $http: vm.$http,
                idField: 'id',
                textField: 'id',
                requestData: {},
                initValue: vm.content.messageTemplateUIModel.handlerClass,
                element: vm.eleHandlerClass,
                errorHandle: vm.errorHandle
            });

        },


        formatLogicOperatorClass: function(logicOperator){
            return SystemStandrdMetadataProxy.formatLogicOperatorIconClass(logicOperator);
        },

        initTableSearchCondition: function(){
            var vm = this;
            var oSettings = {
                editModule: vm.editMessageTempSearchCondition,
                editModuleModal: vm.editMessageTempSearchCondition,
                deleteModule: vm.deleteMessageTempSearchCondition,
                scrollX: true,
                label: vm.label.messageTempSearchCondition,
                errorHandle: vm.errorHandle
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            },   {
                fieldName: 'logicOperatorValue',
                labelKey: 'logicOperator',
                fieldKey: 'logicOperator',
                iconArray: SystemStandrdMetadataProxy.getLogicOperatorIconArray(),
                minWidth: '180px'
            }, {
                fieldName: 'fieldName',
                minWidth: '180px'
            },{
                fieldName: 'fieldValue',
                minWidth: '180px'
            }];

            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableSearchCondition.loadModuleList(oSettings);
        },


        initTablePriority: function(){
            var vm = this;
            var oSettings = {
                editModule: vm.editMessageTempPrioritySetting,
                editModuleModal: vm.editMessageTempPriorityPanel,
                deleteModule: vm.deleteRoleMessageCategory,
                scrollX: true,
                label: vm.label.messageTempPrioritySetting,
                errorHandle: vm.errorHandle
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            },   {
                fieldName: 'messageLevelCodeValue',
                labelKey: 'messageLevelCode',
                fieldKey: 'messageLevelCode',
                iconArray: MessageTempPriorityManager.getMessageLevelCodeIconArray(),
                minWidth: '180px'
            }, {
                fieldName: 'messageTitle',
                minWidth: '180px'
            },{
                fieldName: 'fieldName',
                minWidth: '180px'
            },{
                fieldName: 'fieldValue',
                minWidth: '180px'
            },{
                fieldName: 'dataSourceProviderId',
                minWidth: '180px'
            }, {
                fieldName: 'colorStyle',
                minWidth: '180px'
            }];

            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTablePriority.loadModuleList(oSettings);
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'messageTemplateUIModel', content.messageTemplateUIModel);
            vm.$set(vm.content, 'messageTempSearchConditionUIModelList', content.messageTempSearchConditionUIModelList);
            vm.$set(vm.content, 'messageTempPrioritySettingUIModelList', content.messageTempPrioritySettingUIModelList);
            vm.initTableSearchCondition();
            vm.initTablePriority();
            vm.getSearchModelNameMap(vm.content);
            vm.getNavigationSourceList();
            vm.getHandlerClassList();
            if (rightBar) {
                rightBar.initHelpDocumentList(content.messageTemplateUIModel.uuid);
            }
        },

        editMessageTempSearchConditionModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.messageTempSearchConditionUIModelList);
            if (!item) {
                return;
            }
            this.cache.messageTempSearchCondition = this.copyMessageTempSearchCondition(item);
            $(this.eleEditMessageTempSearchConditionModal).modal('toggle');

        },

        setToMessageTempSearchCondition: function () {
            var item = this._filterItemByUUID(this.cache.messageTempSearchCondition.uuid, this.content.messageTempSearchConditionUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copyMessageTempSearchCondition(this.cache.messageTempSearchCondition);
                this.content.messageTempSearchConditionUIModelList.push(newItem);
            } else {
                this.copyMessageTempSearchCondition(this.cache.messageTempSearchCondition, item);
            }
            $(this.eleEditMessageTempSearchConditionModal).modal('hide');
        },

        newMessageTempSearchConditionModal: function () {
            var baseUUID = this.content.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            this.$http.post(this.newMessageTempSearchConditionServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
// In case success.
                this.cache.messageTempSearchCondition = this.copyMessageTempSearchCondition(JSON.parse(response.data).content, this.cache.messageTempSearchCondition);
                $(this.eleEditMessageTempSearchConditionModal).modal('toggle');
            });

        },


        deleteMessageTempSearchCondition: function (uuid) {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.messageTempSearchConditionUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, vm.content.messageTempSearchConditionUIModelList);
                    }
                });
        },

        addMessageTempSearchCondition: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.messageTemplateUIModel.uuid;
            var resultURL = "MessageTempSearchConditionEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },

        editMessageTempSearchCondition: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            window.location.href = genCommonEditURL("MessageTempSearchConditionEditor.html", uuid);

        },

        editMessageTempPriorityPanel: function(uuid, $event){
            var vm = this;
            vm.$refs.messagePriorityPanel.loadPanel(uuid, PROCESSMODE_EDIT);
            if ($event && $event.clientY && $event.clientY > 0) {
                console.log("top:" + $event.clientY);
                // 60 px is the approx height of topbar
                // anothor 60px is the proper space to topbar
                $('html').scrollTop($event.clientY - 120);
            }
        },

        editMessageTempPrioritySettingModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.messageTempPrioritySettingUIModelList);
            if (!item) {
                return;
            }
            this.cache.messageTempPrioritySetting = this.copyMessageTempPrioritySetting(item);
            $(this.eleEditMessageTempPrioritySettingModal).modal('toggle');

        },

        setToMessageTempPrioritySetting: function () {
            var item = this._filterItemByUUID(this.cache.messageTempPrioritySetting.uuid, this.content.messageTempPrioritySettingUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copyMessageTempPrioritySetting(this.cache.messageTempPrioritySetting);
                this.content.messageTempPrioritySettingUIModelList.push(newItem);
            } else {
                this.copyMessageTempPrioritySetting(this.cache.messageTempPrioritySetting, item);
            }
            $(this.eleEditMessageTempPrioritySettingModal).modal('hide');
        },

        newMessageTempPrioritySettingModal: function () {
            var baseUUID = this.content.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            this.$http.post(this.newMessageTempPrioritySettingServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
// In case success.
                this.cache.messageTempPrioritySetting = this.copyMessageTempPrioritySetting(JSON.parse(response.data).content, this.cache.messageTempPrioritySetting);
                $(this.eleEditMessageTempPrioritySettingModal).modal('toggle');
            });

        },

        deleteMessageTempPrioritySetting: function () {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.messageTempPrioritySettingUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, content.messageTempPrioritySettingUIModelList);
                    }
                });
        },

        addMessageTempPrioritySetting: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.messageTemplateUIModel.uuid;
            var resultURL = "MessageTempPrioritySettingEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        openRightSideBar: function (key) {
            NavigationPanelIns.openRightSideBar(RightBarTemplate.TABS.tab2, key);
        },

        editMessageTempPrioritySetting: function (uuid) {
            window.location.href = genCommonEditURL("MessageTempPrioritySettingEditor.html", uuid);

        }

    }
});
