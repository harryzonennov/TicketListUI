var serialNumberSetting = new Vue({
    el: "#x_data",
    data: {
        label: SerialNumberSettingManager.label.serialNumberSetting,
        content: {
            client: '',
            uuid: '',
            category: '',
            qrcodeType: '',
            coreNumberLength: '',
            ean13PostCodeGenType: '',
            seperator2: '',
            seperator2Json: '',
            prefixTimeCode: '',
            id: '',
            ean13CompanyCodeGenType: '',
            prefixCode1: '',
            seperator1: '',
            seperator1Json: '',
            timeCodeFormat: '',
            systemStandardCategory: '',
            barcodeType: '',
            switchFlag: '',
            name: '',
            barcodeStartValue: '',
            barcodeAsendSize: '',
            coreStartNumber: '',
            postfixTimeCode: '',
            coreStepSize: '',
            note: ''
        },
        author: {
            resourceId: ServiceModuleConstants.SerialNumberSetting,
            actionCode: {
                Edit: false,
                View: false,
                PriceInfo: false,
                Delete: false,
                Excel: false
            }
        },
        processButtonMeta: [],
        embedProcessButtonMeta:[],
        eleCategory: '#x_category',
        eleQrcodeType: '#x_qrcodeType',
        eleCoreNumberLength: '#x_coreNumberLength',
        eleEan13PostCodeGenType: '#x_ean13PostCodeGenType',
        eleSeperator2: '#x_seperator2',
        elePrefixTimeCode: '#x_prefixTimeCode',
        eleEan13CompanyCodeGenType: '#x_ean13CompanyCodeGenType',
        elePrefixCode1: '#x_prefixCode1',
        eleSeperator1: '#x_seperator1',
        eleDateCodeFormat: '#x_dateCodeFormat',
        eleSystemStandardCategory: '#x_systemStandardCategory',
        eleBarcodeType: '#x_barcodeType',
        eleSwitchFlag: '#x_switchFlag',
        getCoreNumberFormatMapUrl:'../serialNumberSetting/getCoreNumberFormatMap.html',
        loadModuleEditURL: '../serialNumberSetting/loadModuleEditService.html',
        loadModuleViewURL: '../serialNumberSetting/loadModuleViewService.html',
        saveModuleURL: '../serialNumberSetting/saveModuleService.html',
        exitModuleURL: '../serialNumberSetting/exitEditor.html',
        newModuleServiceURL: '../serialNumberSetting/newModuleService.html',
        getCategoryURL: '../serialNumberSetting/getCategoryMap.html',
        getQrcodeTypeURL: '../serialNumberSetting/getQrcodeTypeMap.html',
        getEan13PostCodeGenTypeURL: '../serialNumberSetting/getEan13PostCodeGenTypeMap.html',
        getSeperatorURL: '../serialNumberSetting/getSeperatorMap.html',
        getEan13CompanyCodeGenTypeURL: '../serialNumberSetting/getEan13CompanyCodeGenTypeMap.html',
        getSeperator1URL: '../serialNumberSetting/getSepeartorMap.html',
        getDateFormatURL: '../serialNumberSetting/getDateFormatMap.html',
        getSystemStandardCategoryURL: '../serialNumberSetting/getSystemStandardCategory.html',
        getBarcodeTypeURL: '../serialNumberSetting/getBarcodeTypeMap.html',
        getSwitchFlagURL: '../serialNumberSetting/getSwitchFlagMap.html',
        postExitURL: 'SerialNumberSettingList.html'
    },

    created: function(){
        var vm = this;
        vm.initAuthorResourceCheck();
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'SerialNumberSetting');
            this.setI18nProperties(vm.initProcessButtonMeta);
            this.loadModuleEdit();
            this.initSelectConfigure();
        });
    },

    computed:{
        "serialNumberExample":function(){
            var prefixCode = this.content.prefixCode1;
            var seperator1 = this.content.seperator1;
            var prefixTimeCode = this.content.prefixTimeCode;
            var timeCodeFormat = this.content.timeCodeFormat;
            var postfixTimeCode = this.content.postfixTimeCode;
            var seperator2 = this.content.seperator2;
            var coreNumberLength = this.content.coreNumberLength;
            return SerialNumberSettingManager.setExampleContent(
                {
                    prefixCode: prefixCode,
                    seperator1: seperator1,
                    prefixTimeCode: prefixTimeCode,
                    timeCodeFormat: timeCodeFormat,
                    postfixTimeCode: postfixTimeCode,
                    seperator2: seperator2,
                    coreNumberLength: coreNumberLength
                });
        }

    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "foundation/systemResource/",
                commonCallback: vm.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'SerialNumberSetting',
                    callback: vm.setNodeI18nPropertiesCore
                }]
            });
        },


        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'category', $(vm.eleCategory).val());
            });
            $(vm.eleQrcodeType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'qrcodeType', $(vm.eleQrcodeType).val());
            });
            $(vm.eleCoreNumberLength).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'coreNumberLength', $(vm.eleCoreNumberLength).val());
            });
            $(vm.eleEan13PostCodeGenType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'ean13PostCodeGenType', $(vm.eleEan13PostCodeGenType).val());
            });
            $(vm.eleSeperator1).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'seperator1', $(vm.eleSeperator1).val());
            });

            $(vm.eleSeperator2).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'seperator2', $(vm.eleSeperator2).val());
            });

            $(vm.elePrefixTimeCode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'prefixTimeCode', $(vm.elePrefixTimeCode).val());
            });
            $(vm.eleEan13CompanyCodeGenType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'ean13CompanyCodeGenType', $(vm.eleEan13CompanyCodeGenType).val());
            });
            $(vm.elePrefixCode1).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'prefixCode1', $(vm.elePrefixCode1).val());
            });
            $(vm.eleDateCodeFormat).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'timeCodeFormat', $(vm.eleDateCodeFormat).val());
            });
            $(vm.eleSystemStandardCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'systemStandardCategory', $(vm.eleSystemStandardCategory).val());
            });
            $(vm.eleBarcodeType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'barcodeType', $(vm.eleBarcodeType).val());
            });

            $(vm.eleSwitchFlag).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'switchFlag', $(vm.eleSwitchFlag).val());
            });

            $(vm.elePrefixCode1).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'status', $(vm.elePrefixCode1).val());
            });
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            if (processMode === PROCESSMODE_NEW) {
                ServiceUtilityHelper.newModuleDefault({
                    newModuleServiceURL: vm.newModuleServiceURL,
                    vm:vm,
                    errorHandle:vm.errorHandle,
                    postSet:vm.setModuleToUI
                });
            }
            if (processMode === PROCESSMODE_EDIT) {
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    errorHandle:vm.errorHandle,
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },


        saveModule: function () {
            var vm = this;
            ServiceUtilityHelper.defSaveModuleWrapper({
                vm: vm,
                editorPage: "SerialNumberSettingEditor.html",
                fnGetBaseUUID: function (){
                    return vm.content.uuid;
                }
            });
        },


        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.postExitURL, UIFLAG_STANDARD);
        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.uuid;
            window.location.href = genCommonEditURL("SerialNumberSettingEditor.html", baseUUID, tabKey);
        },



        getCategoryMap: function (content) {
            var vm = this;
            this.$http.get(this.getCategoryURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleCategory).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleCategory).val(content.category);
                    $(vm.eleCategory).trigger("change");
                }, 0);
            });

        },

        getQrcodeTypeMap: function (content) {
            var vm = this;
            this.$http.get(this.getQrcodeTypeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleQrcodeType).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleQrcodeType).val(content.qrcodeType);
                    $(vm.eleQrcodeType).trigger("change");
                }, 0);
            });

        },

        getCoreNumberFormat: function (content) {
            var vm = this;
            this.$http.get(this.getCoreNumberFormatMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleCoreNumberLength).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleCoreNumberLength).val(content.coreNumberLength);
                    $(vm.eleCoreNumberLength).trigger("change");
                }, 0);
            });

        },

        getEan13PostCodeGenTypeMap: function (content) {
            var vm = this;
            this.$http.get(this.getEan13PostCodeGenTypeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleEan13PostCodeGenType).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleEan13PostCodeGenType).val(content.ean13PostCodeGenType);
                    $(vm.eleEan13PostCodeGenType).trigger("change");
                }, 0);
            });

        },

        getSeperator2: function (content) {
            var vm = this;
            this.$http.get(this.getSeperatorURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleSeperator2).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleSeperator2).val(content.seperator2);
                    $(vm.eleSeperator2).trigger("change");
                }, 0);
            });

        },

        getEan13CompanyCodeGenType: function (content) {
            var vm = this;
            this.$http.get(this.getEan13CompanyCodeGenTypeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleEan13CompanyCodeGenType).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleEan13CompanyCodeGenType).val(content.ean13CompanyCodeGenType);
                    $(vm.eleEan13CompanyCodeGenType).trigger("change");
                }, 0);
            });

        },

        getPrefixCode: function (content) {
            var vm = this;
            this.$http.get(this.getSeperatorURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.elePrefixCode1).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.elePrefixCode1).val(content.prefixCode1);
                    $(vm.elePrefixCode1).trigger("change");
                }, 0);
            });
        },

        getSeperator1: function (content) {
            var vm = this;
            this.$http.get(this.getSeperatorURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleSeperator1).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleSeperator1).val(content.seperator1);
                    $(vm.eleSeperator1).trigger("change");
                }, 0);
            });

        },

        getDateFormatMap: function (content) {
            var vm = this;
            this.$http.get(this.getDateFormatURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleDateCodeFormat).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleDateCodeFormat).val(content.timeCodeFormat);
                    $(vm.eleDateCodeFormat).trigger("change");
                }, 0);
            });

        },

        getSystemStandardCategory: function (content) {
            var vm = this;
            this.$http.get(this.getSystemStandardCategoryURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleSystemStandardCategory).select2({
                        data: JSON.parse(response.body),
                        templateResult: SystemStandrdMetadataProxy.formatDefaultSystemCategory,
                        templateSelection: SystemStandrdMetadataProxy.formatDefaultSystemCategory
                    });
                    // manually set initial value
                    $(vm.eleSystemStandardCategory).val(content.systemStandardCategory);
                    $(vm.eleSystemStandardCategory).trigger("change");
                }, 0);
            });

        },

        getBarcodeType: function (content) {
            var vm = this;
            this.$http.get(this.getBarcodeTypeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleBarcodeType).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleBarcodeType).val(content.barcodeType);
                    $(vm.eleBarcodeType).trigger("change");
                }, 0);
            });

        },

        loadSwitchFlagList: function (content) {
            var vm = this;
            this.$http.get(this.getSwitchFlagURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleSwitchFlag).select2({
                        data: resultList,
                        templateResult: SystemStandrdMetadataProxy.formatDefaultSwitchCode,
                        templateSelection: SystemStandrdMetadataProxy.formatDefaultSwitchCode
                    });
                    // manually set initial value
                    $(vm.eleSwitchFlag).val(content.switchFlag);
                    $(vm.eleSwitchFlag).trigger("change");
                }, 0);
            });
        },


        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm, 'content', content);
            vm.getCategoryMap(content);
            vm.getCoreNumberFormat(content);
            vm.getEan13PostCodeGenTypeMap(content);
            vm.getSeperator2(content);
            vm.getEan13CompanyCodeGenType(content);
            vm.getPrefixCode(content);
            vm.getSeperator1(content);
            vm.getDateFormatMap(content);
            vm.getSystemStandardCategory(content);
            vm.getBarcodeType(content);
            vm.loadSwitchFlagList(content);

        }

    }
});
