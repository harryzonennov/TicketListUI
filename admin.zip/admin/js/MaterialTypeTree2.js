
var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        searchModuleURL: '../materialType/searchTreeListService.html'
    },
    methods: {
        searchModule: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.searchModuleURL, requestData).then(function (response) {
                listVar.$set(vm, 'items', JSON.parse(response.data).content);
            });
        },
        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "MaterialTypeEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },
        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            parentTypeUUID: "",
            name: "",
            id: "",
            rootTypeName: "",
            rootTypeId: "",
            parentTypeName: "",
            parentTypeId: "",
            rootTypeUUID: ""

        },

        label: {
            parentTypeUUID: '',
            name: '',
            id: '',
            rootTypeName: '',
            rootTypeId: '',
            parentTypeName: '',
            parentTypeId: '',
            advancedSearchCondition: ''
        }
    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;

        });
    }
});
var listVar = new Vue({
    el: "#x_data",
    data: {
        label: {
            name: '',
            note: '',
            id: '',
            rootTypeName: '',
            rootTypeNote: '',
            rootTypeId: '',
            parentTypeName: '',
            parentTypeNote: '',
            parentTypeId: '',

            msgSystemFailure: '',
            msgUnknowSystemFailure: '',
            index: '',
            lockFailureMessage: '',
            buttonEdit: '',
            buttonView: '',
            msgSaveOK: '',
            msgSaveOKComment: '',
            commit: '',
            close: ''
        },
        cache: {
            uuid: '',
            parentNodeUUID: '',
            rootNodeUUID: '',
            client: '',
            name: '',
            note: '',
            id: '',
            rootTypeUUID: '',
            rootTypeName: '',
            rootTypeNote: '',
            rootTypeId: '',
            parentTypeUUID: '',
            parentTypeName: '',
            parentTypeNote: '',
            parentTypeId: ''
        },
        loadModuleListURL: '../materialType/loadModuleListService.html',
        eleEditMaterialTypeModal: '#x_eleEditMaterialTypeModal',
        eleParentTypeUUID:'#x_parentTypeUUID',
        eleParentTypeUUIDCache:'#x_parentTypeUUIDCache',
        eleRootTypeUUID:'#x_rootTypeUUID',
        tableId: '#x_table_materialType',
        datatable: '',
        items: [],
        loadModuleTreeURL: '../materialType/loadTreeListService.html',
        preLockURL: '../materialType/preLockService.html',
        saveModuleURL:'../materialType/saveModuleService.html',
        newModuleServiceURL: '../materialType/newModuleFromParentService.html',
        searchModuleTreeURL: '../materialType/searchTreeListService.html',
        loadModuleEditURL: '../materialType/loadModuleEditService.html'

    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'MaterialType');
            this.datatable = new ServiceDataTable(this.tableId);
            this.setI18nProperties();
            this.loadModuleList();
            this.initSelectConfigure();
            this.loadParentTypeList(searchModel.content);
            this.loadRootTypeList(searchModel.content);
        });
    },


    methods: {
        refreshTreeView: function () {
            var vm = this;
            var ser = new XMLSerializer();
            var treeElement = generateBootstrapTreeContent(vm.generateMaterialTypeTreeView(vm.items));
            var htmlContent = ser.serializeToString(treeElement);
            $("#x_tree_materialType").empty();
            $("#x_tree_materialType").prepend(htmlContent);

            $(".iconEditMaterialTypeModel").on("click", function (e) {
                var uuid = $(this).children("input").attr("value");
                vm.editModuleModal(uuid);
                e.stopPropagation();
            });
            $(".iconNewMaterialTypeModel").on("click", function (e) {
                var baseUUID = $(this).children("input").attr("value");
                vm.newModuleModal(baseUUID);
                e.stopPropagation();
            });
            vm.initTreeAction();

        },

        initTreeAction: function () {
            $('.tree li.parent_li > span').off('click');
            $('.tree li.parent_li > span').on('click', function (e) {
                var children = $(this).parent('li.parent_li').find(' > ul > li');
                if (children.is(":visible")) {
                    children.hide('fast');
                } else {
                    children.show('fast');
                }
                e.stopPropagation();
            });
        },

        _filterMaterialTypeListByParent:function(contentList, parentTypeUUID){
            if(!contentList){
                return;
            }
            if(!contentList.length || contentList.length === 0){
                return;
            }
            var i, len = contentList.length, result = [];
            for( i = 0; i < len; i++){
                if(!parentTypeUUID || parentTypeUUID == ''){
                    // In case root material type
                    if(!contentList[i].parentTypeUUID || contentList[i].parentTypeUUID == ''){
                        result.push(contentList[i]);
                    }
                }
                if(contentList[i].parentTypeUUID === parentTypeUUID){
                    result.push(contentList[i]);
                }
            }
            return result;
        },


        generateMaterialTypeTreeView: function (contentList) {
            var vm = this;
            var headerModel = {};
            headerModel.uuid = '1';
            headerModel.layer = 1;
            headerModel.iconClass = 'icon-th-list';
            headerModel.spanClass = 'badge-warning';
            headerModel.spanContent = '系统物料类别';
            headerModel.subModelList = [];
            var rootTypeList = vm._filterMaterialTypeListByParent(contentList);
            if (rootTypeList && rootTypeList.length > 0){
                var i, lenth = rootTypeList.length;
                for (i = 0; i < lenth; i++) {
                    headerModel.subModelList.push(vm.generateMaterialTypeTreeUnion(rootTypeList[i], contentList, 2));
                }
            }
            return headerModel;
        },


        generateMaterialTypeTreeUnion: function(rawMaterial, contentList, layer){
            var vm = this;
            var materialTypeUnion = {};
            materialTypeUnion.uuid = rawMaterial.uuid;
            materialTypeUnion.layer = layer;
            materialTypeUnion.rootTypeUUID = rawMaterial.rootTypeUUID;
            materialTypeUnion.parentTypeUUID = rawMaterial.parentTypeUUID;
            materialTypeUnion.iconArray = [];
            materialTypeUnion.spanContent = rawMaterial.id + "-" + rawMaterial.name;
            var editIcon = {};
            editIcon.innerUUID = materialTypeUnion.uuid;
            editIcon.class = 'glyphicon glyphicon-pencil content-green iconEditMaterialTypeModel';
            materialTypeUnion.iconArray.push(editIcon);
            var newIcon = {};
            newIcon.innerUUID = materialTypeUnion.uuid;
            newIcon.class = 'fa fa-plus iconNewMaterialTypeModel';
            materialTypeUnion.iconArray.push(newIcon);
            materialTypeUnion.subModelList = [];
            var subTypeList = vm._filterMaterialTypeListByParent(contentList, rawMaterial.uuid);
            if (subTypeList && subTypeList.length > 0){
                var i, lenth = subTypeList.length;
                for (i = 0; i < lenth; i++) {
                    materialTypeUnion.subModelList.push(vm.generateMaterialTypeTreeUnion(subTypeList[i], contentList, layer + 1));
                }
            }
            return materialTypeUnion;
        },


        setI18nCommonProperties: function () {
            this.label.msgSystemFailure = $.i18n.prop('msgSystemFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.buttonEdit = $.i18n.prop('edit');
            this.label.buttonView = $.i18n.prop('view');
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.commit = $.i18n.prop('commit');
            this.label.close = $.i18n.prop('close');
            processModel.label.search = $.i18n.prop('search');
            processModel.label.add = $.i18n.prop('add');
            searchModel.label.advancedSearchCondition = $.i18n.prop('advancedSearchCondition');
        },
        setNodeI18nPropertiesCore: function () {
            this.label.name = $.i18n.prop('name');
            this.label.note = $.i18n.prop('note');
            this.label.id = $.i18n.prop('id');
            this.label.rootTypeName = $.i18n.prop('rootTypeName');
            this.label.rootTypeNote = $.i18n.prop('rootTypeNote');
            this.label.rootTypeId = $.i18n.prop('rootTypeId');
            this.label.parentTypeName = $.i18n.prop('parentTypeName');
            this.label.parentTypeNote = $.i18n.prop('parentTypeNote');
            this.label.parentTypeId = $.i18n.prop('parentTypeId');
            searchModel.label.name = $.i18n.prop('name');
            searchModel.label.id = $.i18n.prop('id');
            searchModel.label.rootTypeName = $.i18n.prop('rootTypeName');
            searchModel.label.rootTypeId = $.i18n.prop('rootTypeId');
            searchModel.label.parentTypeName = $.i18n.prop('parentTypeName');
            searchModel.label.parentTypeId = $.i18n.prop('parentTypeId');
            BusyLoader.cleanPageBackground();
        },
        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'MaterialType', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
        },
        getI18nPath: function () {
            return 'coreFunction/';
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleParentTypeUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(searchModel.content, 'parentTypeUUID', $(vm.eleParentTypeUUID).val());
                var url = vm.loadModuleEditURL + "?uuid=" + $(vm.eleParentTypeUUID).val();
                vm.$http.get(url).then(function (response) {
                    if (!JSON.parse(response.data).content) {
                        swal({
                            title: this.label.msgSystemFailure,
                            text: this.label.msgUnknowSystemFailure,
                            type: "error",
                            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                            confirmButtonText: this.label.confirm
                        });
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(searchModel.content, 'parentTypeName', content.name);
                    vm.$set(searchModel.content, 'rootTypeId', content.rootTypeId);
                    vm.$set(searchModel.content, 'rootTypeName', content.rootTypeName);
                });
            });

            $(vm.eleParentTypeUUIDCache).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache, 'parentTypeUUID', $(vm.eleParentTypeUUIDCache).val());
                var url = vm.loadModuleEditURL + "?uuid=" + $(vm.eleParentTypeUUIDCache).val();
                vm.$http.get(url).then(function (response) {
                    if (!JSON.parse(response.data).content) {
                        swal({
                            title: this.label.msgSystemFailure,
                            text: this.label.msgUnknowSystemFailure,
                            type: "error",
                            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                            confirmButtonText: this.label.confirm
                        });
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.cache, 'parentTypeName', content.name);
                    vm.$set(vm.cache, 'rootTypeId', content.rootTypeId);
                    vm.$set(vm.cache, 'rootTypeName', content.rootTypeName);
                });
            });

            $(vm.eleRootTypeUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(searchModel.content, 'rootTypeUUID', $(vm.eleRootTypeUUID).val());
                var url = vm.loadModuleEditURL + "?uuid=" + $(vm.eleRootTypeUUID).val();
                vm.$http.get(url).then(function (response) {
                    if (!JSON.parse(response.data).content) {
                        swal({
                            title: this.label.msgSystemFailure,
                            text: this.label.msgUnknowSystemFailure,
                            type: "error",
                            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                            confirmButtonText: this.label.confirm
                        });
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    // Clear the parent type search information
                    vm.$set(searchModel.content, 'parentTypeUUID', '');
                    vm.$set(searchModel.content, 'parentTypeName', '');
                    vm.$set(searchModel.content, 'rootTypeId', content.rootTypeId);
                    vm.$set(searchModel.content, 'rootTypeName', content.rootTypeName);
                });
            });
        },

        loadParentTypeList:function(searchContent) {
            var vm = this;
            this.$http.get(this.loadModuleTreeURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'id');
                setTimeout(function () {
                    $(vm.eleParentTypeUUID).select2({
                        data: resultList
                    });
                    $(vm.eleParentTypeUUIDCache).select2({
                        data: resultList
                    });

                    // manually set initial value
                    $(vm.eleParentTypeUUID).val(searchContent.parentTypeUUID);
                    $(vm.eleParentTypeUUID).trigger("change");
                }, 0);
            });
        },

        loadRootTypeList:function(searchContent) {
            var vm = this;
            //TODO change into root type list later
            this.$http.get(this.loadModuleListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'id');
                setTimeout(function () {
                    $(vm.eleRootTypeUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRootTypeUUID).val(searchContent.rootTypeUUID);
                    $(vm.eleRootTypeUUID).trigger("change");
                }, 0);
            });
        },

        loadModuleList: function () {
            var vm = this;
            this.$http.get(vm.loadModuleListURL).then(function (response) {
                if (!JSON.parse(response.data).content) {
                    $.Notification.notify('error', 'top center', this.label.msgSystemFailure, this.label.msgUnknowSystemFailure);
                    return;
                }
                vm.$set(vm, 'items', JSON.parse(response.data).content);
                setTimeout(function () {
                    vm.refreshTreeView();
                }, 0);
            });
        },

        editModule: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            this.$http.post(vm.preLockURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.RC) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                if (oData.RC == HttpStatus.SC_OK) {
                    window.location.href = genCommonEditURL("MaterialTypeEditor.html", uuid);
                } else {
                    $.Notification.notify('error', 'top center',this.label.lockFailureMessage, JSON.parse(response.data).MSG);
                }
            });
        },

        editModuleModal: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            this.$http.post(vm.preLockURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.RC) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                if (oData.RC == HttpStatus.SC_OK) {
                    var url = this.loadModuleEditURL + "?uuid=" + uuid;
                    this.$http.get(url).then(function (response) {
                        oData = JSON.parse(response.data);
                        if (!oData.content) {
                            ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                            return;
                        }
                        // In case success.
                        this.cache = this.copyModule(oData.content, this.cache);
                        this.loadParentTypeList(this.cache);
                        this.loadRootTypeList(this.cache);
                        // manually set initial value
                        $(vm.eleParentTypeUUIDCache).val(this.cache.parentTypeUUID);
                        $(vm.eleParentTypeUUIDCache).trigger("change");
                        $(this.eleEditMaterialTypeModal).modal('toggle');

                    });
                } else {
                    swal(this.label.lockFailureMessage, JSON.parse(response.data).MSG);
                }
            });
        },

        copyModule: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.parentTypeUUID = origin.parentTypeUUID;
            target.note = origin.note;
            target.parentTypeId = origin.parentTypeId;
            target.parentTypeName = origin.parentTypeName;
            target.rootTypeId = origin.rootTypeId;
            target.rootTypeName = origin.rootTypeName;
            return target;

        },

        saveToModule: function () {
            var vm = this;
            this.$http.post(this.saveModuleURL, vm.cache).then(function (response) {
                $(this.eleEditMaterialTypeModal).modal('hide');// Also update to current items
                var item = vm._filterItemByUUID(this.cache.uuid);
                if (!item) {
                    if (!this.cache.uuid) {
                        return;
                    }
                    var newItem = this.copyModule(this.cache);
                    // In case new item added.
                    this.items.push(newItem);
                } else {
                    this.copyModule(this.cache, item);
                }
                this.refreshTreeView();
                $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
            }.bind(this));
        },

        newModuleModal: function (baseUUID) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            this.$http.post(this.newModuleServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!JSON.parse(response.data).content) {
                    swal({
                        title: this.label.msgSystemFailure,
                        text: this.label.msgUnknowSystemFailure,
                        type: "error",
                        confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                        cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                        confirmButtonText: this.label.confirm
                    });
                    return;
                }
                // In case success.
                this.cache = this.copyModule(oData.content, this.cache);
                this.loadParentTypeList(this.cache);
                this.loadRootTypeList(this.cache);
                // manually set initial value
                $(vm.eleParentTypeUUIDCache).val(this.cache.parentTypeUUID);
                $(vm.eleParentTypeUUIDCache).trigger("change");
                $(this.eleEditMaterialTypeModal).modal('toggle');
            });
        },

        _filterItemByUUID: function (uuid) {
            if (!this.items) {
                return;
            }
            for (var i = 0; i < this.items.length; i++) {
                if (uuid === this.items[i].uuid) {
                    return this.items[i];
                }
            }

        },
        preLock: function () {
        }
    }
});
