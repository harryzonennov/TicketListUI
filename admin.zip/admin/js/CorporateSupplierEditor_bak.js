var dataVar = new Vue({
    el: "#x_data",
    mixins: [CorporateSupplierManager.labelTemplate],
    data: {
        contactpersonTableId: '#x_table_corporateContactPerson',
        contactpersonTable: {},
        label: CorporateSupplierManager.label.corporateSupplier,
        content: {
            corporateSupplierUIModel: {
                baseCityUUID: '',
                uuid: '',
                refSalesAreaUUID: '',
                dealerTypeUUID: '',
                refRouteUUID: '',
                id: '',
                tags: '',
                taxNumber: '',
                countryName: '',
                stateName: '',
                cityName:'',
                fax:'',
                supplierLevel:'',
                address:'',
                depositBank:'',
                telephone:'',
                bankAccount: '',
                name: '',
                weiXinID: '',
                status: '',
                weiboID: '',
                customerType: '',
                launchReason: '',
                retireReason: '',
                launchDate: '',
                faceBookID: '',
                note: ''
            },
            corporateContactPersonUIModelList: [],
            corporateCustomerAttachmentUIModelList: []
        },
        cache: {
            corporateContactPerson: {
                id:'',
                name:'',
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refNodeName: '',
                refUUID: '',
                mobile: '',
                telephone: '',
                email:'',
                weixinId:'',
                contactRole: '',
                contactPositionNote: '',
                address: '',
                contactRoleNote: '',
                note: ''
            }
        },
        author:{
            resourceId:'CorporateCustomer',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        attachmentMeta:{
            loadAttachmentURL: '../corporateCustomer/loadAttachment.html',
            deleteAttachmentURL: '../corporateCustomer/deleteAttachment.html',
            uploadAttachmentURL: '../corporateCustomer/uploadAttachment.html',
            uploadAttachmentTextURL: '../corporateCustomer/uploadAttachmentText.html'
        },
        attachmentLabel:{
            attachmentSection:''
        },
        processButtonMeta: [],
        embedProcessButtonMeta:[],
        addressInfoInit: false, // Indicator whethear 'AddressInfo' has initial value.
        eleSupplierLevel: '#x_supplierLevel',
        loadModuleEditURL: '../corporateSupplier/loadModuleEditService.html',
        loadModuleViewURL: '../corporateSupplier/loadModuleViewService.html',
        saveModuleURL: '../corporateSupplier/saveModuleService.html',
        checkDuplicateURL: '../corporateSupplier/checkDuplicate.html',
        newModuleServiceURL: '../corporateSupplier/newModuleService.html',
        getSupplierLevelMapURL:'../corporateSupplier/loadSupplierLevelMap.html',
        loadCitySelectListURL: '../city/loadLeanModuleListService.html',
        newCorporateContactPersonServiceURL: '../individualCustomer/newContactCustomerService.html',
        eleEditCorporateContactPersonModal: '#x_eleEditCorporateContactPersonModal',
        eleCityName:'#x_cityName',
        exitURL: 'CorporateSupplierList.html',
        exitModuleURL: '../corporateSupplier/exitEditor.html'
    },

    created: function(){
        "use strict";
        var vm = this;
        vm.initSubComponents();
        vm.initAuthorResourceCheck();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('logistics', 'CorporateSupplier');
            this.setI18nProperties(vm.initProcessButtonMeta());
            this.loadModuleEdit();
            this.initTagsInput();
            this.initSelectConfig();
            this.initParsleyConfigure();
            this.contactpersonTable = new ServiceDataTable(this.contactpersonTableId);
        }.bind(this));
    },

    watch: {
        'content.corporateSupplierUIModel.stateName': function (stateName) {
            this.updateAddressInfo({
                stateName: stateName,
                cityName:  this.content.corporateSupplierUIModel.cityName,
                townZone: this.content.corporateSupplierUIModel.townZone,
                streetName: this.content.corporateSupplierUIModel.streetName,
                telephone:this.content.corporateSupplierUIModel.contactTelephone
            });
        },
        'content.corporateSupplierUIModel.cityName': function (cityName) {
            this.updateAddressInfo({
                stateName: this.content.corporateSupplierUIModel.stateName,
                cityName: cityName,
                townZone: this.content.corporateSupplierUIModel.townZone,
                streetName: this.content.corporateSupplierUIModel.streetName,
                telephone:this.content.corporateSupplierUIModel.telephone
            });
        },
        'content.corporateSupplierUIModel.townZone': function (townZone) {
            this.updateAddressInfo({
                stateName: this.content.corporateSupplierUIModel.stateName,
                cityName: this.content.corporateSupplierUIModel.cityName,
                townZone: townZone,
                streetName: this.content.corporateSupplierUIModel.streetName,
                telephone:this.content.corporateSupplierUIModel.telephone
            });
        },
        'content.corporateSupplierUIModel.streetName': function (streetName) {
            this.updateAddressInfo({
                stateName: this.content.corporateSupplierUIModel.stateName,
                cityName: this.content.corporateSupplierUIModel.cityName,
                townZone: this.content.corporateSupplierUIModel.townZone,
                streetName: streetName,
                telephone:this.content.corporateSupplierUIModel.telephone
            });
        },
        'content.corporateSupplierUIModel.telephone': function (telephone) {
            this.updateAddressInfo({
                stateName: this.content.corporateSupplierUIModel.stateName,
                cityName: this.content.corporateSupplierUIModel.cityName,
                townZone: this.content.corporateSupplierUIModel.townZone,
                streetName: this.content.corporateSupplierUIModel.streetName,
                telephone:telephone
            });
        }
    },

    methods: {

        initSubComponents: function() {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("popup-label", PopupLabel);
            Vue.component("attachment-union", AttachmentUnion);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initParsleyConfigure: function() {
            var vm = this;
            ServiceParselyMessageHelper.initParsleyConfigureWrapper({
                labelObj: vm.label
            });
        },

        /**
         * @Overwrite: Get document type for each edit controller
         */
        getDocumentType: function () {
            return DocumentConstants.DummyDocumentType.CorporateSupplier;
        },

        getServiceManager: function () {
            return CorporateSupplierManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "CorporateSupplierEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.corporateSupplierUIModel.uuid;
        },

        /**
         * @Overwrite: get document status from content
         */
        getStatus: function () {
            return this.content.corporateSupplierUIModel.status;
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        updateAddressInfo: function (oSettings) {
            var vm = this;
            var address = ServiceUtilityHelper.buildAddressInfo(oSettings);
            if(!vm.addressInfoInit){
                vm.$set(vm.content.corporateSupplierUIModel, 'address', address);
            }
        },

        initTagsInput: function(){
            "use strict";
            $('#x_tags').tagsinput({
                width:'120px'
            });
        },

        initSelectConfig: function(){
            var vm = this;
            $(vm.eleSupplierLevel).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.corporateSupplierUIModel, 'supplierLevel', $(vm.eleSupplierLevel).val());
            });
        },

        loadCitySelectList: function () {
            var vm = this;
            return ServiceUtilityHelper.loadTypeAheadRequest({
                url: vm.loadCitySelectListURL,
                $http: vm.$http,
                errorHandle: vm.errorHandle,
                element: vm.eleCityName
            });
        },
        /**
         * Deprecate
         */
        editCorporateContactPersonModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.corporateContactPersonUIModelList);
            if (!item) {
                return;
            }
            this.cache.corporateContactPerson = this.copyCorporateContactPerson(item);
            $(this.eleEditCorporateContactPersonModal).modal('toggle');
        },
        /**
         * Deprecate
         */
        setToCorporateContactPerson: function () {
            var item = this._filterItemByUUID(this.cache.corporateContactPerson.uuid, this.content.corporateContactPersonUIModelList);
            if (!item) {
                var newItem = this.copyCorporateContactPerson(this.cache.corporateContactPerson);
                this.content.corporateContactPersonUIModelList.push(newItem);
            } else {
                this.copyCorporateContactPerson(this.cache.corporateContactPerson, item);
            }
            $(this.eleEditCorporateContactPersonModal).modal('hide');
        },

        /**
         * Deprecate
         */
        newCorporateContactPersonModal: function () {
            var baseUUID = this.content.corporateSupplierUIModel.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:this.newCorporateContactPersonServiceURL,
                $http:vm.$http,
                method:'post',
                requestData: requestData,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    vm.cache.corporateContactPerson = vm.copyCorporateContactPerson(oData.content, vm.cache.corporateContactPerson);
                    $(vm.eleEditCorporateContactPersonModal).modal('toggle');
                }.bind(this)
            });

        },

        addCorporateContactPerson: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "CorporateContactPersonEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },

        editCorporateContactPerson: function () {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            window.location.href = genCommonEditURL("CorporateContactPersonEditor.html", uuid);
        },


        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nCommonReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nContactPersonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.corporateContactPerson, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'CorporateSupplier',
                    callback: this.setNodeI18nPropertiesCore
                },{
                    name: 'CorporateContactPerson',
                    callback: this.setI18nContactPersonProperties
                }]
            });
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            if (processMode === PROCESSMODE_NEW) {
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                var url = this.newModuleServiceURL;
                baseUUID = getUrlVar("uuid");
                var requestData = generateServiceSimpleContentUnion(baseUUID);
                ServiceUtilityHelper.httpRequest({
                    url:this.newModuleServiceURL,
                    $http:vm.$http,
                    method:'post',
                    requestData: requestData,
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        vm.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if (processMode === PROCESSMODE_EDIT) {
                // In case [Edit mode]
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    initAuthor: function(author){vm.$set(vm, 'author', author);},
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }

        },
        /**
         * Deprecate
         */
        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }
        },

        deleteCoporateContact: function (uuid) {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.corporateContactPersonUIModelList);
                        if (!item) {
                            return;
                        }
                        vm.content.corporateContactPersonUIModelList.$remove(item);
                    } else {
                        // do nothing, just return
                    }
                });
        },

        /**
         * Deprecate
         */
        copyCorporateContactPerson: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refUUID = origin.refUUID;
            target.mobile = origin.mobile;
            target.weixinId = origin.weixinId;
            target.email = origin.email;
            target.contactRole = origin.contactRole;
            target.contactPosition = origin.contactPosition;
            target.contactPositionNote = origin.contactPositionNote;
            target.contactRoleNote = origin.contactRoleNote;
            target.note = origin.note;
            target.address = origin.address;
            return target;

        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            vm.content.corporateSupplierUIModel.tags = $('#x_tags').val();
            this.saveModuleCore();
        },

        saveModuleCore: function(){
            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:this.saveModuleURL,
                $http:vm.$http,
                method:'post',
                requestData: vm.content,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                    this.setModuleToUI(oData.content);
                    var processMode = getUrlVar(LABEL_PROCESSMODE);
                    if (processMode && processMode * 1 === PROCESSMODE_NEW) {
                        var baseUUID = vm.content.corporateSupplierUIModel.uuid;
                        if (baseUUID) {
                            window.location.href = genCommonEditURL("CorporateSupplierEditor.html", baseUUID);
                        }
                    }
                }.bind(this)
            });
        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.corporateSupplierUIModel.uuid;
            window.location.href = genCommonEditURL("CorporateSupplierEditor.html", baseUUID, tabKey);
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.corporateSupplierUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);
        },

        getSupplierLevel: function () {
            var vm = this;
            ServiceUtilityHelper.loadMetaWithCustomReq({
                url: vm.getSupplierLevelMapURL,
                $http: vm.$http,
                initValue: vm.content.corporateSupplierUIModel.supplierLevel,
                idField:'id',
                textField:'name',
                element: vm.eleSupplierLevel,
                errorHandle: vm.errorHandle
            });
        },


        setModuleToUI: function (content) {
            var vm = this;
            if(content.corporateSupplierUIModel.address){
                vm.$set(vm, 'addressInfoInit', true);
            }
            vm.$set(vm.content, 'corporateSupplierUIModel', content.corporateSupplierUIModel);
            vm.$set(vm.content, 'corporateContactPersonUIModelList', content.corporateContactPersonUIModelList);
            vm.$set(vm.content, 'corporateCustomerAttachmentUIModelList', content.corporateCustomerAttachmentUIModelList);
            setTimeout(function () {
                vm.contactpersonTable.build();
            }, 0);
            vm.getSupplierLevel(content);
            ServiceUtilityHelper.switchToTab();
            this.loadCitySelectList(content);
            bindingTagsInput($('#x_tags'), content.corporateSupplierUIModel.tags);
        }

    }
});
