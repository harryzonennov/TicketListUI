var rightBar = new Vue({
    el: "#rightBarHoc",
    mixins: [ServiceRightBarPanelHelper.defTimelineMinxin, SystemCodeValueManager.labelTemplate],
    data: function () {
        return {
            label: SystemCodeValueManager.label,
            coreModelId: "SystemCodeValueCollection",
            i18nPath:"coreFunction/"
        };
    },

    methods: {

        initHelpDocumentList: function (uuid) {
            "use strict";
            var vm = this;
            ServiceRightBarPanelHelper.initHelpDocumentWithAction({
                uuid: uuid,
                vm: vm,
                errorHandle: dataVar.errorHandle,
                helpDocumentName: ['SystemCodeValueCollectionHelpDocument', 'SystemCodeValueUnionHelpDocument']
            });
        }
    }
});

var dataVar = new Vue({
    el: "#x_data",
    mixins: [SystemCodeValueManager.labelTemplate],
    data: {
        label: SystemCodeValueManager.label.systemCodeValueCollection,
        content: {
            systemCodeValueCollectionUIModel: {
                uuid: '',
                client: '',
                collectionCategory: '',
                keyType: '',
                collectionType: '',
                unionType:'',
                id: '',
                name: '',
                note: ''
            },
            systemCodeValueUnionUIModelList: []
        },
        cache: {
            systemCodeValueUnion: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                unionType:'',
                id: '',
                colorStyle:'',
                hideFlag:'',
                iconClass:'',
                name: '',
                note: ''
            }
        },
        author: {
            resourceId: ServiceModuleConstants.SystemCodeValueCollection,
            actionCode: {
                Edit: false,
                PriceInfo: false,
                AuditDoc: false,
                View: false,
                Delete: false,
                Excel: false
            }
        },
        processButtonMeta:[],
        eleCollectionCategory: '#x_collectionCategory',
        eleCollectionType: '#x_collectionType',
        eleKeyType: '#x_keyType',
        eleHideFlag: '#x_hideFlag',
        eleUnionType: '#x_unionType',
        loadModuleEditURL: '../systemCodeValueCollection/loadModuleEditService.html',
        loadModuleViewURL: '../systemCodeValueCollection/loadModuleViewService.html',
        saveModuleURL: '../systemCodeValueCollection/saveModuleService.html',
        newModuleServiceURL: '../systemCodeValueCollection/newModuleService.html',
        newSystemCodeValueUnionServiceURL: '../systemCodeValueUnion/newModuleService.html',
        eleEditSystemCodeValueUnionModal: '#x_eleEditSystemCodeValueUnionModal',
        getCollectionTypeURL: '../systemCodeValueCollection/getCollectionTypeMap.html',
        getCollectionCategoryURL: '../systemCodeValueCollection/getCollectionCategory.html',
        getHideFlagMapURL: '../systemCodeValueUnion/getHideFlagMap.html',
        getKeyTypeURL: '../systemCodeValueUnion/getKeyType.html',
        exitURL: 'SystemCodeValueCollectionList.html',
        exitModuleURL: '../systemCodeValueCollection/exitEditor.html'

    },

    created: function () {
        "use strict";
        var vm = this;
        vm.initAuthorResourceCheck();
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'SystemCodeValueCollection');
            this.setI18nProperties(vm.initProcessButtonMeta);
            this.loadModuleEdit();
            this.initSelectConfigure();
        });
    },

    methods: {

        initAuthorResourceCheck: function () {
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm: vm,
                errorHandle: ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function () {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
            Vue.component("system-code-value-union-pop-editor", SystemCodeValueUnionPopEditor);
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nValueUnionProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.systemCodeValueUnion, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                label: vm.label, vm: vm, errorHandle: vm.errorHandle,
                configList: [{
                    name: 'SystemCodeValueCollection',
                    callback: this.setNodeI18nPropertiesCore
                }, {
                    name: 'SystemCodeValueUnion',
                    callback: this.setI18nValueUnionProperties
                }]
            });
        },


        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleCollectionCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.systemCodeValueCollectionUIModel, 'collectionCategory', $(vm.eleCollectionCategory).val());
            });
            $(vm.eleCollectionType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.systemCodeValueCollectionUIModel, 'collectionType', $(vm.eleCollectionType).val());
            });
            $(vm.eleKeyType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.systemCodeValueCollectionUIModel, 'keyType', $(vm.eleKeyType).val());
            });
            $(vm.eleHideFlag).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.systemCodeValueUnion, 'hideFlag', $(vm.eleHideFlag).val());
            });
            $(vm.eleUnionType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.systemCodeValueUnion, 'unionType', $(vm.eleUnionType).val());
            });

        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            vm.$refs.refBusyLoader.showBusyLoading();
            if (processMode === PROCESSMODE_NEW) {
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                ServiceUtilityHelper.httpRequest({
                    url: vm.newModuleServiceURL,
                    $http: vm.$http,
                    method: 'post',
                    requestData: requestData,
                    errorHandle: vm.errorHandle,
                    postHandle: function (oData) {
                        vm.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if (processMode === PROCESSMODE_EDIT) {
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl: this.loadModuleEditURL,
                    viewUrl: this.loadModuleViewURL,
                    messageContainer: $('.main.message-container'),
                    uuid: baseUUID,
                    author: vm.author,
                    $http: vm.$http,
                    errorHandle: vm.errorHandle,
                    postSet: vm.setModuleToUI
                });
            }
        },

        saveModule: function () {
            var vm = this;
            ServiceUtilityHelper.defSaveModuleWrapper({
                vm: vm,
                editorPage: "SystemCodeValueCollectionEditor.html",
                fnGetBaseUUID: function (){
                    return vm.content.systemCodeValueCollectionUIModel.uuid;
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.systemCodeValueCollectionUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);
        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.systemCodeValueCollectionUIModel.uuid;
            window.location.href = genCommonEditURL("SystemCodeValueCollectionEditor.html", baseUUID,tabKey);

        },

        getCollectionCategory: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getCollectionCategoryURL,
                $http: vm.$http,
                initValue: vm.content.systemCodeValueCollectionUIModel.collectionCategory,
                element: vm.eleCollectionCategory,
                errorHandle: vm.errorHandle
            });
        },


        getCollectionType: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getCollectionCategoryURL,
                $http: vm.$http,
                formatMeta:SystemCodeValueManager.formatCollectionType,
                initValue: vm.content.systemCodeValueCollectionUIModel.formatCollectionType,
                element: vm.eleCollectionType,
                errorHandle: vm.errorHandle
            });
        },

        getKeyType: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getKeyTypeURL,
                $http: vm.$http,
                initValue: vm.content.systemCodeValueCollectionUIModel.keyType,
                element: vm.eleKeyType,
                errorHandle: vm.errorHandle
            });
        },


        getHideFlagMap: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getHideFlagMapURL,
                $http: vm.$http,
                formatMeta:SystemStandrdMetadataProxy.formatHideFlag,
                initValue: vm.content.systemCodeValueCollectionUIModel.hideFlag,
                element: vm.eleHideFlag,
                errorHandle: vm.errorHandle
            });
        },


        getUnionTypeMap: function (cache) {
            var vm = this;
            this.$http.get(vm.getCollectionTypeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleUnionType).select2({
                        data: JSON.parse(response.body),
                        templateResult:SystemCodeValueManager.formatCollectionType,
                        templateSelection:SystemCodeValueManager.formatCollectionType
                    });
                    // manually set initial value
                    if(cache.systemCodeValueUnion && cache.systemCodeValueUnion.unionType){
                        $(vm.eleUnionType).val(cache.systemCodeValueUnion.unionType);
                        $(vm.eleUnionType).trigger("change");
                    }
                }, 0);
            });
        },

        formatUnionTypeClass: function(unionType){
            return SystemCodeValueManager.formatCollectionTypeIconClass(unionType);
        },

        formatHideFlagClass: function(hideFlag){
            return SystemStandrdMetadataProxy.formatHideFlagIconClass(hideFlag);
        },


        initTableValueUnion: function(){
            var vm = this;
            var oSettings = {
                editModule: vm.editSystemCodeValueUnion,
                editModuleModal: vm.editSystemCodeValueUnionModal,
                deleteModule: vm.deleteSystemCodeValueUnion,
                scrollX: true,
                label: vm.label.systemCodeValueUnion,
                errorHandle: vm.errorHandle
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'id',
                minWidth: '180px'
            },{
                fieldName: 'name',
                minWidth: '180px'
            },{
                fieldName: 'lanKey',
                minWidth: '180px'
            },{
                fieldName: 'iconClass',
                iconClassCallback: function(request){
                    return {iconClass: request.uiModel.iconClass};
                },
                minWidth: '180px'
            }, {
                fieldName: 'unionTypeValue',
                fieldKey: 'unionType',
                labelKey: 'unionType',
                iconArray: SystemCodeValueManager.getCollectionTypeIconArray(),
                minWidth: '180px'
            },{
                fieldName: 'hideFlagValue',
                fieldKey: 'hideFlag',
                labelKey: 'hideFlag',
                iconArray: SystemStandrdMetadataProxy.getHideFlagIconArray(),
                minWidth: '180px'
            }];

            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableValueUnion.loadModuleList(oSettings);
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'systemCodeValueCollectionUIModel', content.systemCodeValueCollectionUIModel);
            var systemCodeValueUnionUIModelList = content.systemCodeValueUnionUIModelList;
            systemCodeValueUnionUIModelList.sort(function (valueA, valueB) {
                if (valueA.id < valueB.id) {
                    return -1;
                } else if (valueA.id > valueB.id) {
                    return 1;
                } else {
                    return 0;
                }
            });
            vm.$refs.refBusyLoader.hideBusyLoading();
            vm.$set(vm.content, 'systemCodeValueUnionUIModelList', systemCodeValueUnionUIModelList);
            if (rightBar) {
                rightBar.initHelpDocumentList(content.systemCodeValueCollectionUIModel.uuid);
            }
            vm.getCollectionCategory(content);
            vm.getCollectionType(content);
            vm.getKeyType(content);
            vm.initTableValueUnion();
        },

        openRightSideBar: function (key) {
            NavigationPanelIns.openRightSideBar(RightBarTemplate.TABS.tab2, key);
        },


        editSystemCodeValueUnionModal: function (uuid) {
            var vm = this;
            vm.$refs.codeValueUnionEditor.editDataModal(uuid);
        },

        newSystemCodeValueUnionModal: function (){
            var vm = this;
            vm.$refs.codeValueUnionEditor.newDataModal({
                baseUUID: vm.content.systemCodeValueCollectionUIModel.uuid,
                newDataUrl: vm.newSystemCodeValueUnionServiceURL
            });
        },

        deleteSystemCodeValueUnion: function () {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.systemCodeValueUnionUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, vm.content.systemCodeValueUnionUIModelList);
                    } else {
                        // do nothing, just return
                    }
                }.bind(this)
            );
        },

        hideBySystemType: function(unionType){
            "use strict";
            var displayFlag = true;
            if( unionType * 1 === DocumentConstants.SystemCodeValueCollection.CollectionType.SYSTEM ){
                displayFlag = undefined;
            }
            return DocumentManagerFactory.formatDisplayClass(displayFlag);
        },

        addSystemCodeValueUnion: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.systemCodeValueCollectionUIModel.uuid;
            var resultURL = "SystemCodeValueUnionEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        editSystemCodeValueUnion: function (uuid) {
            window.location.href = genCommonEditURL("SystemCodeValueUnionEditor.html", uuid);
        }

    }
});
