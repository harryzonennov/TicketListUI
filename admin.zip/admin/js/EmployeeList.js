var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        processButtonMeta:[],
        author:{
            resourceId:'Employee',
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        serviceUIMeta: {},
        downloadExcelURL: '../employee/downloadExcel.html',
        searchModuleURL: '../employee/searchModuleService.html'
    },

    created: function(){
        this.initAuthorResourceCheck();
        this.initSubComponents();
    },

    methods: {
        searchModule: function () {
            listVar.searchModuleList();
        },

        initAuthorResourceCheck: function () {
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm: vm,
                errorHandle: ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    callback: vm.newModule
                },
                downloadExcel: {
                    formatClass: vm.displayForExcel,
                    callback: vm.downloadExcel
                },
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        initSubComponents: function () {
            "use strict";
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        downloadExcel: function () {
            var vm = this;
            var excelType = ServiceUIMetaProxy.filterKeyValue(vm.serviceUIMeta, 'excelType');
            ServiceExcelHelper.downloadExcel({
                url: vm.downloadExcelURL,
                $http: vm.$http,
                excelType: excelType,
                busyLoader: vm.$refs.refBusyLoader,
                requestData: searchModel.content,
                reportTitle: listVar.label.modelTitle,
                errorHandle: listVar.errorHandle
            });
        },

        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "EmployeeEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },
        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            name: "",
            id: "",
            operateType: "",
            workRole: "",
            ageLow: "",
            ageHigh: "",
            mobile: "",
            uuid: "",
            gender: "",
            identification: '',
            telephone: ""
        },

        label: EmployeeManager.label.employee,
        eleGender:'#x_gender',
        eleStatus:'#x_status',
        eleOperateType:'#x_operateType',
        eleWorkRole:'#x_workRole',
        eleJobLevel:'#x_jobLevel',
        getStatusURL:'../employee/getStatus.html',
        getOperateTypeURL: '../employee/getOperateType.html',
        getJobLevelURL: '../employee/getJobLevel.html',
        getGenderURL: '../employee/getGender.html',
        getWorkRoleURL:'../employee/getWorkRole.html'

},
mounted:function () {
    this.$nextTick(function () {
        var vm = this;
        vm.initSelectConfigure();
        vm.getGender();
        vm.getOperateType();
        vm.getWorkRole();
        vm.getJobLevel();
        vm.getStatus();
    });
},
methods: {
    clearSearch: function () {
        clearSearchModel(this.content);
    },

    initSelectConfigure:function () {
        var vm = this;
        $(vm.eleGender).on("select2:close", function (e) {
            // Set value to vue from select2 manually by select2's bug
            vm.$set(vm.content, 'gender', $(vm.eleGender).val());
        });
        $(vm.eleOperateType).on("select2:close", function (e) {
            // Set value to vue from select2 manually by select2's bug
            vm.$set(vm.content, 'operateType', $(vm.eleOperateType).val());
        });
        $(vm.eleWorkRole).on("select2:close", function (e) {
            // Set value to vue from select2 manually by select2's bug
            vm.$set(vm.content, 'workRole', $(vm.eleWorkRole).val());
        });
        $(vm.eleJobLevel).on("select2:close", function (e) {
            // Set value to vue from select2 manually by select2's bug
            vm.$set(vm.content, 'jobLevel', $(vm.eleJobLevel).val());
        });
        $(vm.eleStatus).on("select2:close", function (e) {
            // Set value to vue from select2 manually by select2's bug
            vm.$set(vm.content, 'status', $(vm.eleStatus).val());
        });
    },

    getGender:function () {
        var vm = this;
        this.$http.get(this.getGenderURL).then(function (response) {
            if (!JSON.parse(response.body)) {
                // pop up error message
            }
            var resultList = JSON.parse(response.body);
            resultList.splice(0, 0, {'id': '0', 'text': ' '});
            setTimeout(function () {
                $(vm.eleGender).select2({
                    data: resultList,
                    templateResult:EmployeeManager.formatGender,
                    templateSelection:EmployeeManager.formatGender
                });
                // manually set initial value
                $(vm.eleGender).val(vm.content.gender);
                $(vm.eleGender).trigger("change");
            }, 0);
        });
    },

    getStatus: function () {
        var vm = this;
        this.$http.get(this.getStatusURL).then(function (response) {
            if (!JSON.parse(response.body)) {
                // pop up error message
            }
            var resultList = JSON.parse(response.body);
            resultList.splice(0, 0, {'id': '0', 'text': ' '});
            setTimeout(function () {
                $(vm.eleStatus).select2({
                    data: resultList,
                    templateResult:EmployeeManager.formatStatus,
                    templateSelection:EmployeeManager.formatStatus
                });
                // manually set initial value
                if(vm.content.status){
                    $(vm.eleStatus).val(vm.content.status);
                    $(vm.eleStatus).trigger("change");
                }
            }, 0);
        });
    },

    expandEmployeeSearchDetail: function(event){
        ServiceUtilityHelper.toggleDetailCore($("#x_employeeSearch_moreDetail"), event);
    },

    getOperateType:function () {
        var vm = this;
        this.$http.get(this.getOperateTypeURL).then(function (response) {
            if (!JSON.parse(response.body)) {
                // pop up error message
            }
            var resultList = JSON.parse(response.body);
            resultList.splice(0, 0, {'id': '0', 'text': ' '});
            setTimeout(function () {
                $(vm.eleOperateType).select2({
                    data: resultList
                });
                // manually set initial value
                if(vm.content.operateType){
                    $(vm.eleOperateType).val(vm.content.operateType);
                    $(vm.eleOperateType).trigger("change");
                }
            }, 0);
        });
    },

    getWorkRole: function () {
        var vm = this;
        this.$http.get(this.getWorkRoleURL).then(function (response) {
            if (!JSON.parse(response.body)) {
                // pop up error message
            }
            var workRoleArray = JSON.parse(response.body).content;
            var _formatWorkRoleLevel= ServiceUtilityHelper.genTemplateFormatFunction(workRoleArray);
            listVar.$set(vm, 'workRoleArray', workRoleArray);
            var resultList = formatSelectResult(workRoleArray, 'id', 'name');
            resultList.splice(0, 0, {'id': '0', 'text': ' '});
            setTimeout(function () {
                $(vm.eleWorkRole).select2({
                    data: resultList,
                    templateResult:_formatWorkRoleLevel,
                    templateSelection:_formatWorkRoleLevel
                });
                // manually set initial value
                if(vm.content.workRole){
                    $(vm.eleWorkRole).val(vm.content.workRole);
                    $(vm.eleWorkRole).trigger("change");
                }
            }, 0);
        });
    },

    getJobLevel: function () {
        var vm = this;
        this.$http.get(this.getJobLevelURL).then(function (response) {
            if (!JSON.parse(response.body)) {
                // pop up error message
            }
            var jobLevelArray = JSON.parse(response.body).content;
            var _formatJobLevel= ServiceUtilityHelper.genTemplateFormatFunction(jobLevelArray);
            var resultList = formatSelectResult(jobLevelArray, 'id', 'name');
            resultList.splice(0, 0, {'id': '0', 'text': ' '});
            setTimeout(function () {
                $(vm.eleJobLevel).select2({
                    data: resultList,
                    templateResult:_formatJobLevel,
                    templateSelection:_formatJobLevel
                });
                // manually set initial value
                if(vm.content.jobLevel){
                    $(vm.eleJobLevel).val(vm.content.jobLevel);
                    $(vm.eleJobLevel).trigger("change");
                }
            }, 0);
        });
    }
}
});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: EmployeeManager.label.employee,
        items: [],
        workRoleArray:[],
        loadModuleListURL: '../employee/loadModuleListService.html',
        preLockURL: '../employee/preLockService.html'
    },

    created: function(){
        this.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'Employee');
            this.setI18nProperties(processModel.initProcessButtonMeta());
            this.loadModuleList();
        });
    },

    methods: {

        initSubComponents: function(){
            "use strict";
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        setI18nCommonProperties: function () {

            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop);
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});

            $(".expand-wrapper .ion-chevron-down").tooltip({title:'展开更多'});
            $(".expand-wrapper .ion-chevron-up").tooltip({title:'收起'});
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,serviceUIMeta: processModel.serviceUIMeta,
                fnCallback: fnCallback, modelId: 'Employee', coreModelId: 'Employee',
                label: [vm.label, searchModel.label, processModel.label], vm:processModel, errorHandle: vm.errorHandle,
                configList: [{
                    name: 'Employee',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        searchModuleList: function(){
            this.$refs.dataTableFrame.searchModuleList();
        },

        buildSearchData: function(data){
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../employee/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'id',
                labelKey: 'id',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.Employee,
                    uuidFieldName: 'uuid'
                }
            }, {
                fieldName: 'name',
                labelKey: 'name',
                minWidth: '180px'
            },{
                fieldName: 'statusValue',
                fieldKey: 'status',
                labelKey: 'status',
                iconArray: EmployeeManager.getStatusIconArray()
            }, {
                fieldName: 'mobile',
                labelKey: 'mobile',
                minWidth: '150px'
            },{
                fieldName: 'genderValue',
                labelKey: 'gender',
                fieldKey: 'gender',
                minWidth: '100px',
                iconArray: EmployeeManager.getGenderIconArray()
            },{
                fieldName: 'workRoleValue',
                fieldKey: 'workRole',
                labelKey: 'workRole',
                minWidth: '100px',
                iconArrayRequest: {
                    url:'../employee/getWorkRole.html'
                }
            },{
                fieldName: 'logonUserId',
                minWidth: '150px',
            },{
                fieldName: 'organizationName',
                minWidth: '150px',
            }];

            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        },

        formatStatusIconClass: function(status){
            return EmployeeManager.formatStatusIconClass(status);
        },

        formatGenderIconClass: function(gender){
            return EmployeeManager.formatGenderIconClass(gender);
        },

        formatWorkRoleIconClass: function(workRole){
            var workRoleIconArray = ServiceUtilityHelper.convCodeValueIconMap(this.workRoleArray);
            var $element = ServiceCollectionsHelper.filterArray(workRole, 'id', workRoleIconArray);
            if($element && $element.iconClass){
                return $element.iconClass;
            }
        },

        editModule: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            this.$http.post(vm.preLockURL, requestData).then(function (response) {
                if (JSON.parse(response.data).RC == HttpStatus.SC_OK) {
                    window.location.href = genCommonEditURL("EmployeeEditor.html", uuid);
                } else {
                    swal(this.label.lockFailureMessage, JSON.parse(response.data).MSG);
                }
            });
        },

        preLock: function () {
        }
    }
});
