/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var MaterialStockKeepUnitManager = function () {

};

MaterialStockKeepUnitManager.label = {
    materialStockKeepUnit: ServiceUtilityHelper.getComLabelObject({
        materialCategory: '',
        allDefinedSize: '',
        memberSalePrice: '',
        buttonEdit: '',
        quickEdit: '',
        length: '',
        seasonType: '',
        validPeriodUnit: '',
        retailPrice: '',
        retailPriceDisplay: '',
        mainProductionPlace: '',
        materialSKUUnitSection: '',
        materialSKUUnitSizeSection: '',
        width: '',
        refMaterialId:'',
        refMaterialName:'',
        minStoreNumber: '',
        volume: '',
        qualityInspectFlag: '',
        outboundDeliveryPrice: '',
        cargoType: '',
        wholeSalePrice: '',
        switchFlag: '',
        netWeight: '',
        allDefinedColor: '',
        packageStandard: '',
        supplyType: '',
        mainMaterialUnit: '',
        packageMaterialType: '',
        allDefinedPackageStandard: '',
        barcode: '',
        grossWeight: '',
        operationMode: '',
        materialCategoryComment: '',
        materialTypeId: '',
        materialTypeComment: '',
        fixLeadTime: '',
        fixLeadTimeTitle: '',
        variableLeadTime: '',
        variableLeadTimeTitle: '',
        amountForVarLeadTime: '',
        amountForVarLeadTimeTitle: '',
        unitCostComment: '',
        materialProductionSection: '',
        inboundDeliveryPrice: '',
        purchasePrice: '',
        purchasePriceDisplay: '',
        validPeriodValue: '',
        height: '',
        status: '',
        modelTitle: '',
        addMaterialUnit: '',
        refMaterialTypeName: '',
        materialTypeName: '',
        materialTypeNote: '',
        supplierName: '',
        productionPlace: '',
        selectUnitNameComment: '',
        inputUnitNameComment: '',
        supplyTypeComment: '',
        materialSection: '',
        materialPriceSection: '',
        materialUnitSection: '',
        materialSizeSection: '',
        unitCost: '',
        unitCostDisplay: '',
        refLengthUnit: '',
        refVolumeUnit: '',
        refWeightUnit: '',
        msgUnknowSystemFailure: '',
        traceMode: '',
        traceLevel: '',
        traceStatus: '',
        batchInputSerialIdComment: '',
        clearSearch: '',
        clearSearchComment: '',
        advancedSearchCondition: ''
    }),
    material: ServiceUtilityHelper.getComLabelObject({
        supplyType: '',
        materialCategory: '',
        materialTypeId: '',
        materialTypeName: ''
    }),
    materialSKUUnit: ServiceUtilityHelper.getComLabelObject({
        note: '',
        materialName: '',
        length: '',
        width: '',
        height: '',
        mainUnitName: '',
        volume: '',
        purchasePrice: '',
        attachmentSection: '',
        materialSKUUnitSection: '',
        materialSKUUnitSizeSection: '',
        standardMaterialUnitId: '',
        standardMaterialUnitName: '',
        ratioToStandard: '',
        barcode: '',
        retailPrice: '',
        retailPriceDisplay: '',
        memberPrice: '',
        unitCost: '',
        unitCostDisplay: '',
        refLengthUnit: '',
        refVolumeUnit: '',
        refWeightUnit: '',
        unitName: '',
        netWeight: '',
        standardMaterialUnitNote: '',
        packageMaterialType: '',
        materialId: '',
        materialUnitSizeSection: '',
        materialUnitSection: '',
        materialSKUUnitPriceSection: '',
        one: '',
        memberSalePrice: '',
        grossWeight: '',
        ratioToStandardMidComment: '',
        ratioToStandardComment: '',
        ratioToStandardPlaceholder: '',
        selectUnitNameComment: '',
        inputUnitNameComment: ''
    })

};

MaterialStockKeepUnitManager.content = {
    materialStockKeepUnitUIModel: ServiceUtilityHelper.extendObject({
        refSupplierUUID: '',
        fixLeadTime: '',
        traceMode: '',
        traceLevel: '',
        traceStatus: '',
        materialCategoryValue: '',
        allDefinedSize: '',
        amountForVarLeadTime: '',
        memberSalePrice: '',
        qualityInspectFlag: '',
        qualityInspectFlagComment: '',
        length: '',
        validPeriodUnit: '',
        retailPrice: '',
        retailPriceDisplay: '',
        width: '',
        minStoreNumber: '',
        volume: '',
        outboundDeliveryPrice: '',
        supplierName: '',
        productionPlace: '',
        unitCost: '',
        refLengthUnit: '',
        refVolumeUnit: '',
        refWeightUnit: '',
        cargoTypeValue: '',
        wholeSalePrice: '',
        switchFlag: '',
        netWeight: '',
        status: '',
        packageStandard: '',
        supplyType: '',
        mainMaterialUnit: '',
        packageMaterialType: '',
        allDefinedPackageStandard: '',
        barcode: '',
        grossWeight: '',
        inboundDeliveryPrice: '',
        purchasePrice: '',
        purchasePriceDisplay: '',
        variableLeadTime: '',
        validPeriodValue: '',
        height: '',
        materialTypeParentTypeUUID: '',
        refMaterialType: '',
        refMaterialUUID: '',
        materialTypeName: '',
        materialTypeNote: ''
    }, ServiceUtilityHelper.getDefDocContent()),

    materialSKUUnitUIModel: ServiceUtilityHelper.extendObject({
        refNodeName: '',
        refUUID: '',
        nitName: '',
        ratioToStandard: '',
        barcode: '',
        retailPrice: '',
        purchasePrice: '',
        wholeSalePrice: '',
        memberSalePrice: '',
        mainUnitName: '',
        unitCost: '',
        refLengthUnit: '',
        refVolumeUnit: '',
        refWeightUnit: '',
        materialId: '',
        materialName: '',
        netWeight: '',
        length: '',
        width: '',
        volume: '',
        height: '',
        outboundDeliveryPrice: '',
        ratioToStandardMidComment: ''
    })
};

MaterialStockKeepUnitManager.labelTemplate = {
    data: function () {
        return {
            label: {
                "material": MaterialStockKeepUnitManager.label.material,
                "actionNode": ServiceActionCodeNodeHelper.defLabelObj,
                "materialSKUUnit": MaterialStockKeepUnitManager.label.materialSKUUnit
            }
        };
    }
};


/**
 * Definition of Tab on UI
 * @type {{}}
 */
MaterialStockKeepUnitManager.documentTab = {
    materialSection: 'tabMaterialSection',
    materialUnitSection: 'tabMaterialUnitSection'
};

MaterialStockKeepUnitManager.DOC_ACTION_CODE = {
    APPROVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_APPROVE,
    REJECT_APPROVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REJECT_APPROVE,
    SUBMIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_SUBMIT,
    REVOKE_SUBMIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REVOKE_SUBMIT,
    REINIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REINIT,
    ACTIVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_ACTIVE,
    ARCHIVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_ARCHIVE
};

MaterialStockKeepUnitManager.constants = {
    loadMaterialSKUURL: '../materialStockKeepUnit/loadModule.html',
    loadMaterialSKUListURL: '../materialStockKeepUnit/loadLeanModuleListService.html',
    loadMaterialSKUUnitListURL: '../materialStockKeepUnit/getAllMaterialSKUUnitList.html',
    loadMaterialUnitURL: '/materialSKUUnit/loadModule.html',
    loadTraceModeListURL: '../materialStockKeepUnit/getTraceMode.html',
    getTraceStatusURL: '../materialStockKeepUnit/getTraceStatus.html',
    getTraceModeURL: '../materialStockKeepUnit/getTraceMode.html',
    getTraceLevelURL: '../materialStockKeepUnit/getTraceLevel.html',
    calculatePriceURL: '../materialStockKeepUnit/calculatePriceService.html'
};

/**
 * [API] Get root node inst id
 */
MaterialStockKeepUnitManager.getRootNodeInstId = function () {
    return "materialStockKeepUnit";
};

/**
 * [API]Get item node inst id
 */
MaterialStockKeepUnitManager.getItemNodeInstId = function () {
    return "materialSKUUnit";
};


/**
 * [API] Get resource id for checking authorization
 */
MaterialStockKeepUnitManager.getResourceId = function () {
    return ServiceModuleConstants.MaterialStockKeepUnit;
};

/**
 * [API] Get document type
 */
MaterialStockKeepUnitManager.getDocumentType = function () {
    return DocumentConstants.DummyDocumentType.MaterialStockKeepUnit;
};

/**
 * [API]Get root 18n config
 */
MaterialStockKeepUnitManager.getI18nRootConfig = function () {
    return {
        i18nPath: 'coreFunction/',
        mainName: 'MaterialStockKeepUnit',
        modelId: 'MaterialStockKeepUnit', coreModelId: 'MaterialStockKeepUnit',
        configList: [{
            name: 'MaterialSKUUnit',
            subLabelPath: 'materialSKUUnit'
        }, {
            name: 'Material',
            subLabelPath: 'material'
        }, {
            actionNodePath: 'actionNode'
        }]
    };
};

/**
 * [API]Get item 18n config
 */
MaterialStockKeepUnitManager.getI18nItemConfig = function () {
    "use strict";
    return {
        i18nPath: 'coreFunction/',
        labelObject: MaterialStockKeepUnitManager.label.materialUnit,
        mainName: 'MaterialSKUUnit',
        modelId: 'MaterialStockKeepUnit', coreModelId: 'MaterialSKUUnit',
        configList: [{
            name: 'MaterialSKUUnit'
        }]
    };
};


MaterialStockKeepUnitManager.getCustomActionCodeIconMap = function () {
    return [
        {
            id: MaterialStockKeepUnitManager.DOC_ACTION_CODE.REINIT,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_REINIT
        }
    ];
};


MaterialStockKeepUnitManager.formatOperationMode = function(operationMode){
    return MaterialManager.formatOperationMode(operationMode);
};

MaterialStockKeepUnitManager.getActionCodeIconMap = function () {
    var actionCodeIconMap = ServiceUtilityHelper.getMergedActionCodeIconMap(MaterialStockKeepUnitManager.getCustomActionCodeIconMap());
    return actionCodeIconMap;
};

MaterialStockKeepUnitManager.getTraceMode = function (oSettings) {
    return ServiceUtilityHelper.loadMetaRequest(ServiceUtilityHelper.extendObject(oSettings, {
        url: MaterialStockKeepUnitManager.constants.getTraceModeURL,
        formatMeta: MaterialStockKeepUnitManager.formatTraceModeClass
    }));
};

MaterialStockKeepUnitManager.getTraceLevel = function (oSettings) {
    return ServiceUtilityHelper.loadMetaRequest(ServiceUtilityHelper.extendObject(oSettings, {
        url: MaterialStockKeepUnitManager.constants.getTraceLevelURL,
        formatMeta: MaterialStockKeepUnitManager.formatTraceLevel
    }));
};

MaterialStockKeepUnitManager.getTraceStatus = function (oSettings) {
    return ServiceUtilityHelper.loadMetaRequest(ServiceUtilityHelper.extendObject(oSettings, {
        url: MaterialStockKeepUnitManager.constants.getTraceStatusURL,
        formatMeta: MaterialStockKeepUnitManager.formatTraceStatus
    }));
};


MaterialStockKeepUnitManager.initDefSelectConfigure = function (oSettings) {
    var vm = oSettings.vm;
    var uiModel = oSettings.uiModel;


    $(vm.eleTraceMode).on("select2:close", function (e) {
        // Set value to vue from select2 manually by select2's bug
        vm.$set(uiModel, 'traceMode', $(vm.eleTraceMode).val());
    });

    $(vm.eleTraceLevel).on("select2:close", function (e) {
        // Set value to vue from select2 manually by select2's bug
        vm.$set(uiModel, 'traceLevel', $(vm.eleTraceLevel).val());
    });

    $(vm.eleTraceStatus).on("select2:close", function (e) {
        // Set value to vue from select2 manually by select2's bug
        vm.$set(uiModel, 'traceStatus', $(vm.eleTraceStatus).val());
    });
};

/**
 * Provide default template to call batch of loading neccessary meta for material
 * @param oSettings
 *    --{Vue}: vm
 *    --{object}: uiModel
 *    --{function}: callback
 */
MaterialStockKeepUnitManager.loadDefaultMetaBatch = function (oSettings) {
    var vm = oSettings.vm;
    var uiModel = oSettings.uiModel;
    var initSettings = {
        '$http': vm.$http,
        'errorHandle': vm.errorHandle,
        'addEmptyFlag': oSettings.addEmptyFlag
    };
    var innerSettings = ServiceUtilityHelper.cloneObj(initSettings);
    var promiseList = [];
    if (vm['eleTraceStatus']) {
        innerSettings.initValue = uiModel['traceStatus'];
        innerSettings.element = vm['eleTraceStatus'];
        promiseList.push(MaterialStockKeepUnitManager.getTraceStatus(innerSettings));
        innerSettings = ServiceUtilityHelper.resetObject(innerSettings, initSettings);
    }
    if (vm['eleTraceLevel']) {
        innerSettings.initValue = uiModel['traceLevel'];
        innerSettings.element = vm['eleTraceLevel'];
        promiseList.push(MaterialStockKeepUnitManager.getTraceLevel(innerSettings));
        innerSettings = ServiceUtilityHelper.resetObject(innerSettings, initSettings);
    }
    if (vm['eleTraceMode']) {
        innerSettings.initValue = uiModel['traceMode'];
        innerSettings.element = vm['eleTraceMode'];
        promiseList.push(MaterialStockKeepUnitManager.getTraceMode(innerSettings));
    }
    if (promiseList && promiseList.length > 0 && oSettings.callback) {
        Promise.all(promiseList).then(function (value) {
            oSettings.callback({'value': value});
        });
    }
    return promiseList;
};

MaterialStockKeepUnitManager.formatTraceStatus = function (traceStatus) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(traceStatus, MaterialUtility.getTraceStatusArray(), true);
    return $element;
};


MaterialStockKeepUnitManager.formatTraceModeIconClass = function (traceMode) {
    "use strict";
    var traceModeArray = MaterialStockKeepUnitManager.getTraceModeArray();
    var $element = ServiceCollectionsHelper.filterArray(traceMode, 'id', traceModeArray);
    if ($element) {
        return $element.iconClass;
    }
};

/**
 * Constants method: Generate the array for mapping 'traceLevel' and 'iconClass'
 * @returns {*[]}
 */
MaterialStockKeepUnitManager.getTraceLevelArray = function (traceLevel) {
    "use strict";
    return [{
        id: DocumentConstants.MaterialStockKeepUnit.traceLevel.TEMPLATE, iconClass: 'md md-filter-none content-grey'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceLevel.INSTANCE,
        iconClass: 'md md-filter-center-focus content-lightblue'
    }];
};


MaterialStockKeepUnitManager.formatTraceLevel = function (traceLevel) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(traceLevel, MaterialUtility.getTraceLevelArray(), true);
    return $element;
};

MaterialStockKeepUnitManager.formatStatus = function (status) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(status, MaterialManager.getStatusIconArray(), true);
    return $element;
};

/**
 * Constants method: Generate the array for mapping 'TraceMode' and 'iconClass'
 * @returns {*[]}
 */
MaterialStockKeepUnitManager.getTraceModeArray = function () {
    "use strict";
    return [{
        id: DocumentConstants.MaterialStockKeepUnit.traceMode.NONE, iconClass: 'md md-location-disabled content-grey'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceMode.SINGE, iconClass: 'md md-gps-fixed content-lightblue'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceMode.BATCH, iconClass: 'md md-gps-not-fixed content-lightblue'
    }];
};

MaterialStockKeepUnitManager.formatTraceModeClass = function (traceMode) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(traceMode, MaterialStockKeepUnitManager.getTraceModeArray(), true);
    return $element;
};


/**
 * Provide the template to generate default Multi-Select Option for Material SKU Lead UI Model
 * @param oSettings
 *    -- {Object}
 *       implementedNodes: Array to contain self implemented DOM Nodes
 *            {Function<DOM Element>} serialIdCallback
 *            {Function<DOM Element>} refMaterialSKUIdCallback
 *            {Function<DOM Element>} packageStandardCallback
 *            {Function<DOM Element>} statusCallback
 *            {Function<DOM Element>} amountCallback
 *    -- {UIModel} uiModel
 *          -- refMaterialSKUId
 *          -- refMaterialSKUName
 *          -- serialId
 *          --
 *    -- {DOM Element} parentElement
 *    -- {Array<String>} hideOptions
 *    -- {Array<Object>} customElements
 */
MaterialStockKeepUnitManager.genMatSKULeadSelectOptionTemplate = function (oSettings) {
    "use strict";
    var i = 0, uiModel = oSettings.uiModel, parentElement = oSettings.parentElement,
        constantValue, customElement = {}, customElements = oSettings.customElements;


    var optionContent = ServiceDOMUtilityHelper.createDefElement({
        parentElement: parentElement,
        element: 'div',
        class: 'option-content'
    });
    var optionline1 = ServiceDOMUtilityHelper.createDefElement({
        parentElement: optionContent,
        element: 'div',
        class: 'option-line'
    });
    var serialIdNode;
    var refMaterialSKUIdNode;
    var packageStandardNode;
    var statusNode;
    var amountNode;
    // [Constant field]: serial Id / Ref Material SKU Id
    if (constantValue = MaterialStockKeepUnitManager._showConstField(oSettings, 'serialId')) {

        if (oSettings.implementedNodes && oSettings.implementedNodes.serialIdCallback) {
            // Self implementation
            serialIdNode = oSettings.implementedNodes.serialIdCallback({parentElement: optionline1});
        } else {
            serialIdNode = ServiceDOMUtilityHelper.createDefElement({
                parentElement: optionline1,
                element: 'span',
                class: 'popover-info',
                iconClass: 'fa fa-barcode content-linkblue',
                textContent: constantValue
            });
        }

        if (constantValue = MaterialStockKeepUnitManager._showConstField(oSettings, 'refMaterialSKUId')) {

            if (oSettings.implementedNodes && oSettings.implementedNodes.refMaterialSKUIdCallback) {
                // Self implementation
                refMaterialSKUIdNode = oSettings.implementedNodes.refMaterialSKUIdCallback({parentElement: optionline1});
            } else {
                ServiceDOMUtilityHelper.createDefElement({
                    parentElement: optionline1,
                    element: 'span',
                    class: 'popover-info',
                    iconClass: 'fa fa-barcode content-linkblue',
                    textContent: constantValue
                });
            }
        }

    } else {
        if (constantValue = MaterialStockKeepUnitManager._showConstField(oSettings, 'refMaterialSKUId')) {
            if (oSettings.implementedNodes && oSettings.implementedNodes.refMaterialSKUIdCallback) {
                // Self implementation
                refMaterialSKUIdNode = oSettings.implementedNodes.refMaterialSKUIdCallback({parentElement: optionline1});
            } else {
                ServiceDOMUtilityHelper.createDefElement({
                    parentElement: optionline1,
                    element: 'span',
                    class: 'primaryText popover-info',
                    iconClass: 'md md-texture content-linkblue',
                    textContent: constantValue
                });
            }
        }
    }
    // [Constant field]: Ref Material SKU Name
    if (constantValue = MaterialStockKeepUnitManager._showConstField(oSettings, 'refMaterialSKUName')) {
        ServiceDOMUtilityHelper.createDefElement({
            parentElement: optionline1,
            element: 'span',
            class: 'm-l-5',
            textContent: constantValue
        });
    }
    // [Constant field]: packageStandard
    if (!uiModel.serialId && uiModel.packageStandard) {
        if (oSettings.implementedNodes && oSettings.implementedNodes.packageStandardCallback) {
            // Self implementation
            packageStandardNode = oSettings.implementedNodes.packageStandardCallback({parentElement: optionline1});
        } else {
            if (constantValue = MaterialStockKeepUnitManager._showConstField(oSettings, 'packageStandard')) {
                ServiceDOMUtilityHelper.createDefElement({
                    parentElement: optionline1,
                    element: 'span',
                    class: 'm-l-5 primaryText',
                    textContent: constantValue
                });
            }
        }
    }

    var timeAddedFlag = false;

    // Process Custom elements in first line
    if (customElements && customElements.fristLineElments) {
        MaterialStockKeepUnitManager._genMatCustomSelectOptionCore(customElements.fristLineElments, optionline1);
    } else {
        if (!uiModel.serialId && !uiModel.packageStandard) {
            if (uiModel.referenceDate) {
                timeAddedFlag = true;
                ServiceDOMUtilityHelper.createDefElement({
                    parentElement: optionline1,
                    element: 'span',
                    class: 'embededTreeSpan badge-grey pull-right',
                    iconClass: 'md md-history content-darkblue',
                    textContent: uiModel.referenceDate
                });
            }
        }
    }

    var hrSeperator = ServiceDOMUtilityHelper.createDefElement({
        parentElement: optionContent,
        element: 'hr',
        class: 'p-t-3'
    });

    var optionline2 = ServiceDOMUtilityHelper.createDefElement({
        parentElement: optionContent,
        element: 'div',
        class: 'option-line'
    });

    if (oSettings.implementedNodes && oSettings.implementedNodes.statusCallback) {
        // Self implementation
        statusNode = oSettings.implementedNodes.statusCallback({parentElement: optionline2});
    } else {
        // [Constant field]: status
        var iconClass = (uiModel.status && uiModel.status.iconClass) ? uiModel.status.iconClass : null;
        var statusValue = (uiModel.status && uiModel.status.value) ? uiModel.status.value : uiModel.status;
        statusNode = ServiceDOMUtilityHelper.createDefElement({
            parentElement: optionline2,
            element: 'span',
            class: '',
            iconClass: iconClass,
            textContent: statusValue
        });
    }

    // [Constant field]: status
    if (oSettings.implementedNodes && oSettings.implementedNodes.amountCallback) {
        // Self implementation
        amountNode = oSettings.implementedNodes.amountCallback({parentElement: optionline2});
    } else {
        // [Constant field]: status
        amountNode = ServiceDOMUtilityHelper.createDefElement({
            parentElement: optionline2,
            element: 'span',
            class: 'm-l-5 embededTreeSpan badge-info',
            textContent: uiModel.amountLabel
        });
    }

    // Process Custom elements in first line
    if (customElements && customElements.secondLineElments) {
        timeAddedFlag = true;
        MaterialStockKeepUnitManager._genMatCustomSelectOptionCore(customElements.secondLineElments, optionline2);
    }

    // Only show next Doc if both doc id & doc type is input
    if (uiModel.nextDocId && uiModel.nextDocType) {
        ServiceDOMUtilityHelper.createDefElement({
            parentElement: optionline2,
            element: 'span',
            class: 'm-l-5 ',
            iconClass: uiModel.nextDocType.iconClass,
            textContent: uiModel.nextDocType.value
        });
        ServiceDOMUtilityHelper.createDefElement({
            parentElement: optionline2,
            element: 'span',
            class: 'm-l-5 ',
            textContent: uiModel.nextDocId
        });
    } else {
        // In case no next Doc Id
        // [Constant field]: reference Date
        if (timeAddedFlag === false) {
            if (uiModel.referenceDate) {
                ServiceDOMUtilityHelper.createDefElement({
                    parentElement: optionline2,
                    element: 'span',
                    class: 'embededTreeSpan badge-grey pull-right',
                    iconClass: 'md md-history content-darkblue',
                    textContent: uiModel.referenceDate
                });
            }
        }

    }


    return optionContent;
};

/**
 * @private Generate the custom elements
 */
MaterialStockKeepUnitManager._genMatCustomSelectOptionCore = function (lineElements, parentElement) {
    "use strict";
    var customElement = {}, i = 0, length = 0;
    if (lineElements && lineElements.length > 0) {
        length = lineElements.length;
        for (i = 0; i < length; i++) {
            customElement = lineElements[i];
            ServiceDOMUtilityHelper.createDefElement({
                parentElement: parentElement,
                element: customElement.element ? customElement.element : 'span',
                type: customElement.type,
                class: customElement.class,
                iconClass: customElement.iconClass,
                value: customElement.value,
                textContent: customElement.textContent
            });
        }
    }
};

/**
 * @private Check if this field should be hide
 */
MaterialStockKeepUnitManager._showConstField = function (oSettings, fieldName) {
    "use strict";
    var uiModel = oSettings.uiModel, element = uiModel[fieldName];
    if (!element) {
        return;
    }
    var hideFlag = MaterialStockKeepUnitManager._checkHideConstField(oSettings, fieldName);
    if (hideFlag) {
        return;
    } else {
        return element;
    }
};

/**
 * @private Check if this field should be hide
 */
MaterialStockKeepUnitManager._checkHideConstField = function (oSettings, fieldName) {
    "use strict";
    if (!oSettings.hideOptions || oSettings.hideOptions.length === 0) {
        return false;
    }
    var filterResult = oSettings.hideOptions.filter(function (option) {
        return (fieldName === option);
    });
    return (filterResult && filterResult.length > 0);
};


/**
 * @override Get Basic URL for load document material item instance.
 * @returns {string}
 */
MaterialStockKeepUnitManager.prototype.getLoadDocItemBaseURL = function () {
    "use strict";
    return '../inboundItem/loadModuleEditService.html';
};

/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
MaterialStockKeepUnitManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../materialStockKeepUnit/loadModuleViewService.html';
};

/**
 * @override Get Basic URL for load document list.
 * @returns {string}
 */
MaterialStockKeepUnitManager.prototype.getLoadSelectListURL = function () {
    "use strict";
    return '../materialStockKeepUnit/loadModuleListService.html';
};

/**
 * Constants method: Get URL for load status metadata
 * @returns {*[]}
 */
MaterialStockKeepUnitManager.prototype.getStatusURL = function (status) {
    "use strict";
    return '../materialStockKeepUnit/getStatusMap.html';
};

/**
 * Calculate Price for different Material
 * @param oSettings
 *     --{double} amount
 *     --{string} refMaterialSKUUUID
 *     --{string} refUnitUUID
 *     --{double} unitPrice
 */
MaterialStockKeepUnitManager.calculatePrice = function (oSettings) {
    var requestData = {
        refMaterialSKUUUID: oSettings.refMaterialSKUUUID,
        refUnitUUID: oSettings.refUnitUUID,
        amount: oSettings.amount,
        unitPrice: oSettings.unitPrice
    };
    requestData = JSON.stringify(requestData);
    $.ajax({
        url: MaterialStockKeepUnitManager.constants.calculatePriceURL,
        dataType: "json",
        type: "post",
        data: requestData,
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (oData) {
            if (!oData.content) {
                return;
            }
            if (oSettings.fnCallback) {
                oSettings.fnCallback(oData.content);
            }
        },
        error: function () {
            // do nothing currently
        }
    });

};

/**
 * Utility method of loading Material SKU select as well as RefUnit
 * @param oSettings *
 *        ---{string} refMaterialSKUUUID: [Almost Mandatory] initial value: Material SKU UUID
 *        ---{DOM} eleRefMaterialSKUUUID: [Mandatory] Select DOM element for Material SKU UUID *
 *        ---{string} selectField: [Option] select field for Material SKU, if none, default value is 'id'
 *        ---{function} formatSelectResult: [Option] format select call back to process the raw data
 *        ---{DOM} eleRefMaterialUnitUUID:
 *                   [Almost Mandatory] Select DOM element for Material SKU Unit, in case also need to load Unit Selection
 *        ---{string} refMaterialUnitUUID:
 *                   [Almost Mandatory] initial value: Material Unit UUID
 *        ---{boolean} addEmptyValue: if need to add empty value for select
 *        ---{function} fnSetInitMaterialSKUUUID:
 *                  [Almost Mandatory] call-back after material SKU UUID value is set to select DOM
 *        ---{function} fnSetInitMaterialUnitUUID:
 *                 [Almost Mandatory] call-back after unit value is initially set to select DOM, will trigger auto & initial Unit UUID set back
 *        ---{function} [Option]fnMaterialSKUResultList: call-back method to reuse material SKU result list meta data
 *        ---{function} [Option]fnUnitResultList: call-back method to reuse unit result list meta data
 */
MaterialStockKeepUnitManager.loadMaterialSKUSelectList = function (oSettings) {
    var vm = this;
    var type = oSettings.methodType ? oSettings.methodType : 'get';
    var searchInitData = oSettings.searchInitData;
    var loadMaterialSKUListURL = oSettings.loadMaterialSKUListURL ? oSettings.loadMaterialSKUListURL : MaterialStockKeepUnitManager.constants.loadMaterialSKUListURL;
    if (searchInitData && typeof searchInitData === 'object') {
        searchInitData = JSON.stringify(searchInitData);
    }
    $.ajax({
        url: loadMaterialSKUListURL,
        dataType: "json",
        type: type,
        data: searchInitData,
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (oData) {
            var resultList = oData;
            var selectField = oSettings.selectField ? oSettings.selectField : 'id-name';
            if (oSettings.formatSelectResult && typeof oSettings.formatSelectResult === 'function') {
                resultList = oSettings.formatSelectResult(oData.content);
            } else {
                resultList = formatSelectResult(oData.content, 'uuid', selectField);
            }
            if (resultList && oSettings.addEmptyValue && oSettings.addEmptyValue === true) {
                resultList.splice(0, 0, {'id': '0', 'text': ' '});
            }
            $(oSettings.eleRefMaterialSKUUUID).empty();
            $(oSettings.eleRefMaterialSKUUUID).select2({
                data: resultList
            });
            var refMaterialSKUUUID = oSettings.refMaterialSKUUUID ? oSettings.refMaterialSKUUUID : undefined;
            if (!refMaterialSKUUUID) {
                if (oSettings.fnSetInitMaterialSKUUUID && typeof oSettings.fnSetInitMaterialSKUUUID === 'function') {
                    if (resultList && resultList.length && resultList.length > 0) {
                        refMaterialSKUUUID = resultList[0].id;
                    }
                }
            }
            if (oSettings.fnSetInitMaterialSKUUUID && typeof oSettings.fnSetInitMaterialSKUUUID === 'function') {
                oSettings.fnSetInitMaterialSKUUUID(refMaterialSKUUUID);
            }
            $(oSettings.eleRefMaterialSKUUUID).val(refMaterialSKUUUID);
            $(oSettings.eleRefMaterialSKUUUID).trigger("change");
            oSettings.refMaterialSKUUUID = refMaterialSKUUUID;
            MaterialStockKeepUnitManager.setMaterialSKUUUIDValue(oSettings, {
                refMaterialSKUUUID: refMaterialSKUUUID,
                changeElementFlag: true
            });
            if (oSettings.fnMaterialSKUResultList && typeof oSettings.fnMaterialSKUResultList === 'function') {
                oSettings.fnMaterialSKUResultList(resultList);
            }

        },
        error: function (oData) {
            if (oSettings.errorHandle) {
                oSettings.errorHandle(oData);
            }
        }
    });
};

/**
 * Utility method of loading Material Unit for Selection
 * @param oSettings *
 *        ---{string} refMaterialSKUUUID: [Mandatory] base value of ref Material SKU UUID
 *        ---{DOM} eleRefMaterialUnitUUID: [Mandatory] Select DOM element for Material SKU Unit
 *        ---{string} refMaterialUnitUUID: [Almost Mandatory] initial value: Material Unit UUID
 *        ---{function} fnSetInitMaterialUnitUUID:
 *                      [Almost Mandatory] call-back after unit value is initially set to select DOM, will trigger auto & initial Unit UUID set back
 *        ---{function} fnUnitResultList: [Optional] call-back method to reuse unit result list meta data
 *
 */
MaterialStockKeepUnitManager.loadRefUnitSelectList = function (oSettings) {
    var vm = this;
    var requestData = {"baseUUID": oSettings.refMaterialSKUUUID};
    if (oSettings.refMaterialSKUUUID) {
        $.ajax({
            url: MaterialStockKeepUnitManager.constants.loadMaterialSKUUnitListURL,
            dataType: "json",
            type: "post",
            data: JSON.stringify(requestData),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            success: function (oData) {
                var resultList = oData;
                $(oSettings.eleRefMaterialUnitUUID).empty();
                $(oSettings.eleRefMaterialUnitUUID).select2({
                    data: resultList
                });
                var refUnitUUID = oSettings.refMaterialUnitUUID ? oSettings.refMaterialUnitUUID : undefined;
                if (!refUnitUUID) {
                    if (oSettings.fnSetInitMaterialUnitUUID && typeof oSettings.fnSetInitMaterialUnitUUID === 'function') {
                        if (resultList && resultList.length && resultList.length > 0) {
                            refUnitUUID = resultList[0].id;
                        }
                    }
                }
                if (oSettings.fnSetInitMaterialUnitUUID && typeof oSettings.fnSetInitMaterialUnitUUID === 'function') {
                    oSettings.fnSetInitMaterialUnitUUID(refUnitUUID);
                }
                if (oSettings.fnUnitResultList && typeof oSettings.fnUnitResultList === 'function') {
                    oSettings.fnUnitResultList(resultList);
                }
                $(oSettings.eleRefMaterialUnitUUID).val(refUnitUUID);
                $(oSettings.eleRefMaterialUnitUUID).trigger("change");
            },
            error: function (oData) {
                if (oSettings.errorHandle) {
                    oSettings.errorHandle(oData);
                }
            }
        });
    }

};

/**
 * API Method to update refMaterialSKUUUID Value
 * @param oSettings
 * @param changeSettings
 *   --{boolean} postLoadModuleFlag if need to load Material SKU detailed content after set
 *   --{boolean} changeElementFlag if need to update dom element manually
 *   --{String} refMaterialSKUUUID Value of Material SKU UUID
 */
MaterialStockKeepUnitManager.setMaterialSKUUUIDValue = function (oSettings, changeSettings) {
    var refMaterialSKUUUID = changeSettings.refMaterialSKUUUID;
    if (oSettings.fnSetMaterialSKUUUID && typeof oSettings.fnSetMaterialSKUUUID === 'function') {
        oSettings.fnSetMaterialSKUUUID(refMaterialSKUUUID);
    }
    var changeElementFlag = changeSettings.changeElementFlag;
    if (changeElementFlag && changeElementFlag === true) {
        // in case trigger dom element update
        $(oSettings.eleRefMaterialSKUUUID).val(refMaterialSKUUUID);
        $(oSettings.eleRefMaterialSKUUUID).trigger("change");
    }
    // In case also need to init Unit
    if (oSettings.eleRefMaterialUnitUUID) {
        // MaterialStockKeepUnitManager.initMaterialUnitSelect(oSettings);
        // Also need to Update the ref Unit meta data
        MaterialStockKeepUnitManager.loadRefUnitSelectList({
            eleRefMaterialUnitUUID: oSettings.eleRefMaterialUnitUUID,
            refMaterialSKUUUID: refMaterialSKUUUID,
            fnSetInitMaterialUnitUUID: oSettings.fnSetInitMaterialUnitUUID
        });
    }

    // In case need to init Unit2
    if (oSettings.eleRefMaterialUnitUUID2) {
        MaterialStockKeepUnitManager.loadRefUnitSelectList({
            eleRefMaterialUnitUUID: oSettings.eleRefMaterialUnitUUID2,
            refMaterialSKUUUID: refMaterialSKUUUID,
            fnSetInitMaterialUnitUUID: oSettings.fnSetInitMaterialUnitUUID2
        });
    }
    // In case need to init Unit3
    if (oSettings.eleRefMaterialUnitUUID3) {
        MaterialStockKeepUnitManager.loadRefUnitSelectList({
            eleRefMaterialUnitUUID: oSettings.eleRefMaterialUnitUUID3,
            refMaterialSKUUUID: refMaterialSKUUUID,
            fnSetInitMaterialUnitUUID: oSettings.fnSetInitMaterialUnitUUID3
        });
    }
    // In case need to init Unit3
    if (oSettings.eleRefMaterialUnitUUID4) {
        MaterialStockKeepUnitManager.loadRefUnitSelectList({
            eleRefMaterialUnitUUID: oSettings.eleRefMaterialUnitUUID4,
            refMaterialSKUUUID: refMaterialSKUUUID,
            fnSetInitMaterialUnitUUID: oSettings.fnSetInitMaterialUnitUUID4
        });
    }
    // In case need to post load MaterialSKU Content
    var postLoadModuleFlag = changeSettings.postLoadModuleFlag;
    if (postLoadModuleFlag && postLoadModuleFlag === true) {
        if (oSettings.fnSetMaterialSKU && typeof oSettings.fnSetMaterialSKU === 'function') {
            var url = MaterialStockKeepUnitManager.constants.loadMaterialSKUURL + "?uuid=" + refMaterialSKUUUID;
            $.ajax({
                url: url,
                dataType: "json",
                type: "get",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                success: function (oData) {
                    var refMaterialSKU = oData.content;
                    if (oSettings.fnSetMaterialSKU && typeof oSettings.fnSetMaterialSKU === 'function') {
                        oSettings.fnSetMaterialSKU(refMaterialSKU);
                    }
                },
                error: function (oData) {
                    if (oSettings.errorHandle) {
                        oSettings.errorHandle(oData);
                    }
                }
            });
        }
    }

};

/**
 * Utility method to init Material SKU & Material Unit Select DOM
 * @param oSettings *
 *        ---{DOM} eleRefMaterialSKUUUID: Select DOM element for Material SKU UUID *
 *        ---{DOM} eleRefMaterialUnitUUID: Select DOM element for Material SKU Unit, in case also need to load Unit Selection
 *        ---{function} fnSetMaterialSKU: call-back after material SKU UUID value is set to select DOM
 *        ---{function} fnSetMaterialSKUUUID: call-back after ref Unit uuid is get
 *        ---{function} fnSetMaterialUnit: call-back after material SKU UUID value is set to select DOM
 *        ---{function} fnSetMaterialUnitUUID: call-back after ref Unit uuid is get
 */
MaterialStockKeepUnitManager.initMaterialSKUSelect = function (oSettings) {
    'use strict';
    $(oSettings.eleRefMaterialSKUUUID).on("select2:close", function (e) {
        // Set value to vue from select2 manually by select2's bug
        var refMaterialSKUUUID = $(oSettings.eleRefMaterialSKUUUID).val();
        MaterialStockKeepUnitManager.setMaterialSKUUUIDValue(oSettings, {
            refMaterialSKUUUID: refMaterialSKUUUID,
            postLoadModuleFlag: true
        });
    });

    if (oSettings.eleRefMaterialUnitUUID) {
        MaterialStockKeepUnitManager.initMaterialUnitSelect(oSettings);
    }
    if (oSettings.eleRefMaterialUnitUUID2) {
        MaterialStockKeepUnitManager.initMaterialUnitSelect(oSettings);
    }
    if (oSettings.eleRefMaterialUnitUUID3) {
        MaterialStockKeepUnitManager.initMaterialUnitSelect(oSettings);
    }
    if (oSettings.eleRefMaterialUnitUUID4) {
        MaterialStockKeepUnitManager.initMaterialUnitSelect(oSettings);
    }
};

MaterialStockKeepUnitManager.getMaterialSKU = function (oSettings) {
    ServiceUtilityHelper.httpRequest({
        url: MaterialStockKeepUnitManager.constants.loadMaterialSKUURL,
        $http: oSettings.$http,
        uuid: oSettings.uuid,
        errorHandle: oSettings.errorHandle,
        postHandle: oSettings.postHandle
    });
};

MaterialStockKeepUnitManager.getTempateMaterialSKUUUID = function (oSettings) {
    MaterialStockKeepUnitManager.getMaterialSKU({
        $http: oSettings.$http,
        uuid: oSettings.uuid,
        url: oSettings.url,
        errorHandle: oSettings.errorHandle,
        postHandle: function (oData) {
            var materialSKU = oData.content;
            if (ServiceModuleConstants.RegisteredProduct === materialSKU.serviceEntityName) {
                // in case registered product
                oSettings.postHandle(materialSKU.refMaterialSKUUUID, materialSKU);
            } else {
                oSettings.postHandle(materialSKU.uuid, materialSKU);
            }
        }
    });
};

/**
 * Utility method to init Material Unit Select DOM

 *        ---{DOM} eleRefMaterialUnitUUID: Select DOM element for Material SKU Unit, in case also need to load Unit Selection
 *        ---{function} fnSetMaterialUnit: call-back after material SKU UUID value is set to select DOM
 *        ---{function} fnSetMaterialUnitUUID: call-back after ref Unit uuid is get
 */
MaterialStockKeepUnitManager.initMaterialUnitSelect = function (oSettings) {
    if (oSettings.eleRefMaterialUnitUUID) {
        $(oSettings.eleRefMaterialUnitUUID).on("select2:close", MaterialStockKeepUnitManager._getDefUnitSelectHandler({
            eleRefMaterialUnitUUID: oSettings.eleRefMaterialUnitUUID,
            fnSetMaterialUnitUUID: oSettings.fnSetMaterialUnitUUID,
            fnSetMaterialUnit: oSettings.fnSetMaterialUnit
        }));
    }
    if (oSettings.eleRefMaterialUnitUUID2) {
        $(oSettings.eleRefMaterialUnitUUID2).on("select2:close", MaterialStockKeepUnitManager._getDefUnitSelectHandler({
            eleRefMaterialUnitUUID: oSettings.eleRefMaterialUnitUUID2,
            fnSetMaterialUnitUUID: oSettings.fnSetMaterialUnitUUID2,
            fnSetMaterialUnit: oSettings.fnSetMaterialUnit2
        }));
    }
    if (oSettings.eleRefMaterialUnitUUID3) {
        $(oSettings.eleRefMaterialUnitUUID3).on("select2:close", MaterialStockKeepUnitManager._getDefUnitSelectHandler({
            eleRefMaterialUnitUUID: oSettings.eleRefMaterialUnitUUID3,
            fnSetMaterialUnitUUID: oSettings.fnSetMaterialUnitUUID3,
            fnSetMaterialUnit: oSettings.fnSetMaterialUnit3
        }));
    }
    if (oSettings.eleRefMaterialUnitUUID4) {
        $(oSettings.eleRefMaterialUnitUUID4).on("select2:close", MaterialStockKeepUnitManager._getDefUnitSelectHandler({
            eleRefMaterialUnitUUID: oSettings.eleRefMaterialUnitUUID4,
            fnSetMaterialUnitUUID: oSettings.fnSetMaterialUnitUUID4,
            fnSetMaterialUnit: oSettings.fnSetMaterialUnit4
        }));
    }

};

/**
 * Internal reusable default handler method when ref Material UUID is selected
 * @param {Object} oLocalSettings
 *   -- {Dom} eleRefMaterialUnitUUID
 *   -- {function} fnSetMaterialUnitUUID: custom call back method when unit uuid is selected
 *   -- {function} fnSetMaterialUnit: custom call back method when unit module is updated
 * @return {(function(*): void)|*}
 * @private
 */
MaterialStockKeepUnitManager._getDefUnitSelectHandler = function (oLocalSettings) {
    return function (e) {
        // Set value to vue from select2 manually by select2's bug
        var refUnitUUID = $(oLocalSettings.eleRefMaterialUnitUUID).val();
        if (oLocalSettings.fnSetMaterialUnitUUID && typeof oLocalSettings.fnSetMaterialUnitUUID === 'function') {
            oLocalSettings.fnSetMaterialUnitUUID(refUnitUUID);
        }
        if (oLocalSettings.fnSetMaterialUnit && typeof oLocalSettings.fnSetMaterialUnit === 'function') {
            var url = MaterialStockKeepUnitManager.constants.loadMaterialUnitURL + "?uuid=" + refUnitUUID;
            $.ajax({
                url: url,
                dataType: "json",
                type: "get",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                success: function (oData) {
                    var refUnitUUID = oData.content;
                    oLocalSettings.fnSetMaterialUnit(refUnitUUID);
                },
                error: function (oData) {
                    if (oLocalSettings.errorHandle) {
                        oLocalSettings.errorHandle(oData);
                    }
                }
            });
        }
    };
};


MaterialStockKeepUnitManager.loadTraceModeSelectList = function (oSelectElement, initValue, fnCallback) {
    var vm = this;
    $.ajax({
        url: MaterialStockKeepUnitManager.constants.loadTraceModeListURL,
        dataType: "json",
        type: "get",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (oData) {
            var resultList = oData;
            setTimeout(function () {
                $(oSelectElement).empty();
                $(oSelectElement).select2({
                    data: resultList,
                    templateResult: MaterialStockKeepUnitManager.formatTraceMode,
                    templateSelection: MaterialStockKeepUnitManager.formatTraceMode
                });
                var traceMode = initValue ? initValue : undefined;
                if (!traceMode) {
                    if (resultList && resultList.length && resultList.length > 0) {
                        traceMode = resultList[0].id;
                    }
                }
                $(oSelectElement).val(traceMode);
                $(oSelectElement).trigger("change");
                if (fnCallback && typeof fnCallback === 'function') {
                    fnCallback(traceMode);
                }
            }, 0);
        },
        error: function () {
            // do nothing currently
        }
    });

};

MaterialStockKeepUnitManager.formatTraceMode = function (traceMode) {
    var iconElement;
    var $element = ServiceUtilityHelper.formatSelectWithIcon(traceMode, MaterialUtility.getTraceModeArray(), true);
    return $element;
};

MaterialStockKeepUnitManager.loadMaterialSKUUnitSelectCore = function (refMaterialSKUUUID, oSelectElement, initValue, fnCallback) {
    var vm = this;
    var requestData = {"baseUUID": refMaterialSKUUUID};
    $.ajax({
        url: MaterialStockKeepUnitManager.constants.loadMaterialSKUUnitListURL,
        dataType: "json",
        type: "post",
        data: JSON.stringify(requestData),
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (oData) {
            var resultList = oData;
            setTimeout(function () {
                $(oSelectElement).empty();
                $(oSelectElement).select2({
                    data: resultList
                });
                var refUnitUUID = initValue ? initValue : undefined;
                if (!refUnitUUID) {
                    if (resultList && resultList.length && resultList.length > 0) {
                        refUnitUUID = resultList[0].id;
                    }
                }
                $(oSelectElement).val(refUnitUUID);
                $(oSelectElement).trigger("change");
                if (fnCallback && typeof fnCallback === 'function') {
                    fnCallback(refUnitUUID, resultList);
                }
            }, 0);
        },
        error: function () {
            // do nothing currently
        }
    });
};


/**
 * Constants method: Generate the array for mapping 'status' and its icon
 * @returns {*[]}
 */
MaterialStockKeepUnitManager.getTraceStatusIconArray = function () {
    "use strict";
    return [{
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.INIT,
        iconClass: 'md md-remove-circle-outline content-grey'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.ACTIVE, iconClass: 'md md-spellcheck content-peach-red'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.INUSE,
        iconClass: 'nmd nmd-play-circle-outline content-green'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.ARCHIVE, iconClass: 'nmd nmd-not-interested content-red'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.WASTE, iconClass: 'nmd nmd-delete-sweep content-grey'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.DELETE, iconClass: 'nmd nmd-delete-forever content-red'
    }];
};

MaterialStockKeepUnitManager.formatTraceStatus = function (traceStatus) {
    "use strict";
    var $element = ServiceUtilityHelper.formatSelectWithIcon(traceStatus, MaterialStockKeepUnitManager.getTraceStatusIconArray(), true);
    return $element;
};

MaterialStockKeepUnitManager.formatTraceStatusIconClass = function (traceStatus) {
    var traceStatusIconArray = MaterialStockKeepUnitManager.getTraceStatusIconArray();
    var $element = ServiceCollectionsHelper.filterArray(traceStatus, 'id', traceStatusIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

/**
 * @override Set Basic path for i18n function.
 * @returns {string}
 */
MaterialStockKeepUnitManager.getI18nPath = function () {
    return "coreFunction/";
};

MaterialStockKeepUnitManager.prototype.getI18nCommonMap = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(MaterialManager.label.material, $.i18n.prop);
};

MaterialStockKeepUnitManager.prototype.getI18nDocMap = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(MaterialManager.label.material, $.i18n.prop, true);
};

MaterialStockKeepUnitManager.prototype.setI18nCommonProperties = function () {
    ServiceUtilityHelper.setI18nCommonReflective(MaterialStockKeepUnitManager.label.materialStockKeepUnit, $.i18n.prop);
    BusyLoader.cleanPageBackground();
};

MaterialStockKeepUnitManager.prototype.setNodeI18nPropertiesCore = function () {
    ServiceUtilityHelper.setI18nReflective(MaterialStockKeepUnitManager.label.materialStockKeepUnit, $.i18n.prop, true);
};

MaterialStockKeepUnitManager.prototype.getModelTitle = function () {
    return MaterialStockKeepUnitManager.label.materialStockKeepUnit.modelTitle;
};


/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
MaterialStockKeepUnitManager.prototype.getI18nWrap = function (fnCallback) {
    var vm = this;
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "coreFunction/",
        commonCallback: vm.setI18nCommonProperties,
        fnCallback: fnCallback,
        configList: [{
            name: 'MaterialStockKeepUnit',
            callback: vm.setNodeI18nPropertiesCore
        }]
    });
};

MaterialStockKeepUnitManager.prototype.initSerializer = function () {
    "use strict";
    if (!this.serializer) {
        this.serializer = new XMLSerializer();
    }
};

MaterialStockKeepUnitManager.prototype.getDefaultDocumentEditorPage = function () {
    "use strict";
    return "MaterialStockKeepUnitEditor.html";
};

MaterialStockKeepUnitManager.prototype.getDefaultDocumentItemEditorPage = function () {
    "use strict";
    return "MaterialStockKeepUnitEditor.html";
};


MaterialStockKeepUnitManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: this.getDefaultDocumentEditorPage(),
        url: this.getLoadDocumentBaseURL(),
        docType: DocumentConstants.DummyDocumentType.MaterialStockKeepUnit,
        label: MaterialStockKeepUnitManager.label.materialStockKeepUnit,
        subPath: 'materialStockKeepUnitUIModel',
        getI18nWrap: vm.getI18nWrap.bind(vm)
    });

    var fieldMetaList = [{
        fieldName: 'id',
    }, {
        fieldName: 'name',
    }, {
        fieldName: 'packageStandard',
    }, {
        fieldName: 'supplyTypeValue',
        fieldKey: 'supplyType',
        labelKey: 'supplyType',
        iconArray: MaterialManager.getSupplyTypeIconArray(),
    }, {
        fieldName: 'materialTypeName'
    }, {
        fieldName: 'materialCategoryValue',
        fieldKey: 'materialCategory',
        labelKey: 'materialCategory',
        iconArray: MaterialManager.getMaterialCategoryIconArray(),
    }, {
        fieldName: 'traceModeValue',
        fieldKey: 'traceMode',
        labelKey: 'traceMode',
        iconArray: MaterialStockKeepUnitManager.getTraceModeArray()
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};


MaterialStockKeepUnitManager.prototype.getDocItemPopoverContent = function (oSettings) {
    "use strict";
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: this.getDefaultDocumentEditorPage(),
        url: vm.getLoadDocItemBaseURL(),
        label: MaterialStockKeepUnitManager.label,
        getI18nWrap: this.getI18nWrap.bind(vm),
        docType: DocumentConstants.DummyDocumentType.MaterialStockKeepUnit
    });

    var fieldMetaList = [{
        fieldName: 'materialSKUUnitUIModel.refMaterialId',
        labelKey: 'materialSKUUnit.refMaterialId',
    }, {
        fieldName: 'materialSKUUnitUIModel.refMaterialName',
        labelKey: 'materialSKUUnit.refMaterialName',
    }, {
        fieldName: 'materialSKUUnitUIModel.ratioToStandard',
        labelKey: 'materialSKUUnit.ratioToStandard'
    }, {
        fieldName: 'materialSKUUnitUIModel.unitName',
        labelKey: 'materialSKUUnit.unitName',
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};

