/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var MaterialConfigureTemplateManager = function () {

};

MaterialConfigureTemplateManager.Constants = {
    ValueUsage:{
        VAUSAGE_PURCHASE_SUPPLIER:1,
        VAUSAGE_INBOUND_WAREHOUSE:2,
        VAUSAGE_SERIALNUM_FORMAT:3,
        VAUSAGE_RAWMAT_WAREHOUSE:4,
        VAUSAGE_SUBID_FORMAT:5
    },
    RefNodeInstId:{
        MaterialType:'MaterialType',
        Material:'Material',
        MaterialStockKeepUnit:'MaterialStockKeepUnit'
    },
    FieldName:{
        UUID: 'uuid'
    }
};

MaterialConfigureTemplateManager.label={
    materialConfigureTemplate:{
        id: '',
        name: '',
        note: '',
        addMatDecisionValueSetting: '',
        addMatConfigHeaderCondition: '',
        addMatConfigExtPropertySetting: '',
        addMaterialConfigureTemplate: '',
        materialConfigureTemplateSection: '',
        matDecisionValueSettingSection: '',
        matConfigHeaderConditionSection: '',
        matConfigExtPropertySettingSection: '',
        materialConfigureTemplateTreeSection: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        quickEdit: '',
        buttonDelete: '',
        exit: '',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        cancel: '',
        commit: '',
        confirm: '',
        valueUsage: '',
        rawValue: '',
        fieldName: '',
        refNodeInstId: '',
        fieldValue: '',
        logicOperator: '',
        fieldType: '',
        modelTitle:'',
        tab1Title:'',
        tab2Title:'',
        advancedSearchCondition: ''
    },
    matConfigExtPropertySetting: {
        id: '',
        fieldType: '',
        qualityInspectFlag:'',
        name: '',
        modelTitle:'',
        measureFlag: '',
        refUnitValue: '',
        refUnitUUID: '',
        note: '',
        pageTitle: '',
        parentPageTitle:'',
        addMatConfigExtPropertySetting:'',
        matConfigExtPropertySettingSection: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        quickEdit: '',
        valueUsage: '',
        exit: '',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        tab1Title:'',
        tab2Title:'',
        cancel: '',
        commit: '',
        confirm: '',
        templateId: '',
        templateName: ''
    },
    matConfigHeaderCondition: {
        refNodeInstId: '',
        logicOperator: '',
        id: '',
        name: '',
        fieldName: '',
        fieldValue: '',
        valueId:'',
        valueName:'',
        note: '',
        addMatConfigHeaderCondition: '',
        parentPageTitle:'',
        modelTitle:'',
        matConfigHeaderConditionSection: '',
        templateId: '',
        templateName: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        quickEdit: '',
        buttonDelete: '',
        tab1Title:'',
        tab2Title:'',
        exit: '',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        cancel: '',
        commit: '',
        confirm: ''
    },
    matDecisionValueSetting: {
        id: '',
        valueUsage: '',
        name: '',
        rawValue: '',
        valueId:'',
        valueName:'',
        note: '',
        addMatDecisionValueSetting: '',
        matDecisionValueSettingSection: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        parentPageTitle:'',
        modelTitle:'',
        pageTitle:'',
        save: '',
        quickEdit: '',
        buttonDelete: '',
        exit: '',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        tab1Title:'',
        tab2Title:'',
        cancel: '',
        commit: '',
        confirm: '',
        templateId: '',
        templateName: ''
    }
};

MaterialConfigureTemplateManager.content = {
    materialConfigureTemplateUIModel: ServiceUtilityHelper.extendObject({
    }, ServiceUtilityHelper.getDefDocContent()),
    matDecisionValueSettingUIModel: ServiceUtilityHelper.extendObject({
        valueUsage: '',
        rawValue: '',
        templateId: '',
        templateName: ''
    }, ServiceUtilityHelper.getDefDocContent()),
    matConfigHeaderConditionUIModel: ServiceUtilityHelper.extendObject({
        refNodeInstId: '',
        logicOperator: '',
        valueId:'',
        valueName:'',
        fieldName: '',
        fieldValue: '',
        templateId: '',
        templateName: ''
    }, ServiceUtilityHelper.getDefDocContent()),
    matConfigExtPropertySettingUIModel: ServiceUtilityHelper.extendObject({
        fieldType: '',
        qualityInspectFlag: '',
        valueUsage: '',
        measureFlag: '',
        refUnitUUID: '',
        templateId: '',
        templateName: ''
    }, ServiceUtilityHelper.getDefDocContent())
};

MaterialConfigureTemplateManager.labelTemplate = {
    data: function() {
        return {
            label: {
                "matConfigHeaderCondition": MaterialConfigureTemplateManager.label.matConfigHeaderCondition,
                "matDecisionValueSetting": MaterialConfigureTemplateManager.label.matDecisionValueSetting,
                "matConfigExtPropertySetting":MaterialConfigureTemplateManager.label.matConfigExtPropertySetting,
            }
        };
    }
};
/**
 * Core Logic to check if Value Usage is OK for select control
 */
MaterialConfigureTemplateManager.valueUsageSelectable = function(valueUsage){
    "use strict";
    if (!valueUsage || isNaN(valueUsage)) {
        return false;
    }
    if (valueUsage * 1 === MaterialConfigureTemplateManager.Constants.ValueUsage.VAUSAGE_INBOUND_WAREHOUSE
        || valueUsage * 1 === MaterialConfigureTemplateManager.Constants.ValueUsage.VAUSAGE_PURCHASE_SUPPLIER
        || valueUsage * 1 === MaterialConfigureTemplateManager.Constants.ValueUsage.VAUSAGE_SUBID_FORMAT
        || valueUsage * 1 === MaterialConfigureTemplateManager.Constants.ValueUsage.VAUSAGE_SERIALNUM_FORMAT
        || valueUsage * 1 === MaterialConfigureTemplateManager.Constants.ValueUsage.VAUSAGE_RAWMAT_WAREHOUSE) {
        return true;
    }
    return false;
};

/**
 * Core Logic to check if fieldName is OK for select control for header condition
 */
MaterialConfigureTemplateManager.fieldNameSelectable = function(fieldName){
    "use strict";
    if (fieldName) {
        if (fieldName === MaterialConfigureTemplateManager.Constants.FieldName.UUID) {
            return true;
        }
    }
    return false;
};


MaterialConfigureTemplateManager.getHeaderConditionSelectUrl = function(refNodeInstId){
    "use strict";
    if (!refNodeInstId){
        return;
    }
    if (refNodeInstId === MaterialConfigureTemplateManager.Constants.RefNodeInstId.Material) {
        return '../material/loadModuleListService.html';
    }
    if (refNodeInstId === MaterialConfigureTemplateManager.Constants.RefNodeInstId.MaterialType) {
        return '../materialType/loadModuleListService.html';
    }
    if( refNodeInstId === MaterialConfigureTemplateManager.Constants.RefNodeInstId.MaterialStockKeepUnit) {
        return '../materialStockKeepUnit/loadModuleListService.html';
    }
};

MaterialConfigureTemplateManager.getHeaderConditionLoadModuleUrl = function(refNodeInstId){
    "use strict";
    if (!refNodeInstId){
        return;
    }
    if (refNodeInstId === MaterialConfigureTemplateManager.Constants.RefNodeInstId.Material) {
        return '../material/loadModule.html';
    }
    if (refNodeInstId === MaterialConfigureTemplateManager.Constants.RefNodeInstId.MaterialType) {
        return '../materialType/loadModule.html';
    }
    if( refNodeInstId === MaterialConfigureTemplateManager.Constants.RefNodeInstId.MaterialStockKeepUnit) {
        return '../materialStockKeepUnit/loadModule.html';
    }
};


MaterialConfigureTemplateManager.prototype.getModelTitle = function(){
    return MaterialConfigureTemplateManager.label.materialConfigureTemplate.modelTitle;
};

/**
 * [API] Get root node inst id
 */
MaterialConfigureTemplateManager.getRootNodeInstId = function(){
    return "materialConfigureTemplate";
};

/**
 * [API] Get resource id for checking authorization
 */
MaterialConfigureTemplateManager.getResourceId = function(){
    return ServiceModuleConstants.MaterialConfigureTemplate;
};

/**
 * [API] Get document type
 */
MaterialConfigureTemplateManager.getDocumentType = function(){
    return DocumentConstants.DummyDocumentType.MaterialConfigureTemplate;
};


/**
 * [API]Get root 18n config
 */
MaterialConfigureTemplateManager.getI18nRootConfig = function () {
    return {
        i18nPath: 'coreFunction/',
        mainName: 'MaterialConfigureTemplate',
        modelId: 'MaterialConfigureTemplate', coreModelId: 'MaterialConfigureTemplate',
        configList: [{
            name: 'MatConfigExtPropertySetting',
            subLabelPath: 'matConfigExtPropertySetting'
        }, {
            name: 'MatConfigHeaderCondition',
            subLabelPath: 'matConfigHeaderCondition'
        },  {
            name: 'MatConfigValueSetting',
            subLabelPath: 'matConfigValueSetting'
        }, ]
    };
};

/**
 * [API]Get item 18n config
 */
MaterialConfigureTemplateManager.getI18nItemConfig = function () {
    "use strict";
    return {
        i18nPath: 'coreFunction/',
        mainName: 'MatConfigExtPropertySetting',
        modelId: 'MaterialConfigureTemplate', coreModelId: 'MatConfigExtPropertySetting',
        configList: [{
            name: 'MatConfigExtPropertySetting'
        }]
    };
};


MaterialConfigureTemplateManager.getI18nDecisionValueSetting = function () {
    "use strict";
    return {
        i18nPath: 'coreFunction/',
        mainName: 'MatConfigValueSetting',
        modelId: 'MaterialConfigureTemplate', coreModelId: 'MatConfigValueSetting',
        configList: [{
            name: 'MatConfigValueSetting'
        }]
    };
};

MaterialConfigureTemplateManager.getI18nHeaderCondition = function () {
    "use strict";
    return {
        i18nPath: 'coreFunction/',
        mainName: 'MatConfigHeaderCondition',
        modelId: 'MaterialConfigureTemplate', coreModelId: 'MatConfigHeaderCondition',
        configList: [{
            name: 'MatConfigHeaderCondition'
        }]
    };
};

/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
MaterialConfigureTemplateManager.prototype.getI18nWrap = function (fnCallback) {
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "coreFunction/",
        fnCallback: fnCallback,
        commonCallback: MaterialConfigureTemplateManager.setI18nCommonProperties,
        configList: [{
            name: 'MaterialConfigureTemplate',
            callback: MaterialConfigureTemplateManager.setNodeI18nPropertiesCore
        }, {
            name: 'MatConfigExtPropertySetting',
            callback: MaterialConfigureTemplateManager.setI18nPropertySettingProperties
        }, {
            name: 'MatConfigHeaderCondition',
            callback: MaterialConfigureTemplateManager.setI18nHeaderConditionProperties
        }, {
            name: 'MatConfigValueSetting',
            callback: MaterialConfigureTemplateManager.setI18nValueSettingProperties
        }]
    });
};


MaterialConfigureTemplateManager.setI18nCommonProperties = function () {
    ServiceUtilityHelper.setI18nCommonReflective(MaterialConfigureTemplateManager.label.materialConfigureTemplate, $.i18n.prop);
};

MaterialConfigureTemplateManager.setNodeI18nPropertiesCore = function () {
    ServiceUtilityHelper.setI18nReflective(MaterialConfigureTemplateManager.label.materialConfigureTemplate, $.i18n.prop, true);
};

MaterialConfigureTemplateManager.setI18nPropertySettingProperties = function () {
    ServiceUtilityHelper.setI18nReflective(MaterialConfigureTemplateManager.label.matConfigExtPropertySetting, $.i18n.prop, true);
};

MaterialConfigureTemplateManager.setI18nHeaderConditionProperties = function () {
    ServiceUtilityHelper.setI18nReflective(MaterialConfigureTemplateManager.label.matConfigHeaderCondition, $.i18n.prop);
};

MaterialConfigureTemplateManager.setI18nValueSettingProperties = function () {
    ServiceUtilityHelper.setI18nReflective(MaterialConfigureTemplateManager.label.matDecisionValueSetting, $.i18n.prop, true);
};

/**
 * Definition of Tab on UI
 * @type {{}}
 */
MaterialConfigureTemplateManager.documentTab = {
    materialConfigureTemplateSection:'tabMaterialConfigureTemplateSection',
    matConfigExtPropertySettingSection:'tabMatConfigExtPropertySettingSection',
    matDecisionValueSettingSection:'tabMatDecisionValueSettingSection',
    materialConfigureTemplateTreeSection:'tabMaterialConfigureTemplateTreeSection'
};

MaterialConfigureTemplateManager.getValueUsageIconArray = function () {
    "use strict";
    return [
        {id: MaterialConfigureTemplateManager.Constants.ValueUsage.VAUSAGE_PURCHASE_SUPPLIER, iconClass: 'md md-add-shopping-cart content-orange'},
        {id: MaterialConfigureTemplateManager.Constants.ValueUsage.VAUSAGE_INBOUND_WAREHOUSE, iconClass: 'md md-home content-lightblue'},
        {id: MaterialConfigureTemplateManager.Constants.ValueUsage.VAUSAGE_RAWMAT_WAREHOUSE, iconClass: 'md md-home content-green'},
        {id: MaterialConfigureTemplateManager.Constants.ValueUsage.VAUSAGE_SUBID_FORMAT, iconClass: 'md md-format-color-text content-darkblue2'},
        {id: MaterialConfigureTemplateManager.Constants.ValueUsage.VAUSAGE_SERIALNUM_FORMAT, iconClass: 'md md-looks-3 content-lightblue'}
    ];
};

MaterialConfigureTemplateManager.formatValueUsageIconClass = function (valueUsage) {
    "use strict";
    var valueUsageIconArray = MaterialConfigureTemplateManager.getValueUsageIconArray();
    var $element = ServiceCollectionsHelper.filterArray(valueUsage, 'id', valueUsageIconArray);
    if($element){
        return $element.iconClass;
    }
};

MaterialConfigureTemplateManager.formatValueUsage = function (valueUsage) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(valueUsage, MaterialConfigureTemplateManager.getValueUsageIconArray(), true);
    return $element;
};


/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
MaterialConfigureTemplateManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../materialConfigureTemplate/loadModuleViewService.html';
};

/**
 * @override Get Basic URL for load document list.
 * @returns {string}
 */
MaterialConfigureTemplateManager.prototype.getLoadSelectListURL = function () {
    "use strict";
    return '../materialConfigureTemplate/loadModuleListService.html';
};


MaterialConfigureTemplateManager.prototype.getModelTitle = function(){
    return MaterialConfigureTemplateManager.label.materialConfigureTemplate.modelTitle;
};




MaterialConfigureTemplateManager.getDefaultDocumentEditorPage = function () {
    "use strict";
    return "MaterialConfigureTemplateEditor.html";
};

MaterialConfigureTemplateManager.getDefaultDocumentItemEditorPage = function () {
    "use strict";
    return "MatConfigExtPropertySettingEditor.html";
};

/**
 * @override Get Basic URL for load document material item instance.
 * @returns {string}
 */
MaterialConfigureTemplateManager.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../materialConfigureTemplate/loadModuleViewService.html';
};


/**
 * @override Get Basic URL for load document material item instance.
 * @returns {string}
 */
MaterialConfigureTemplateManager.getLoadDocItemBaseURL = function () {
    "use strict";
    return '../matConfigExtPropertySetting/loadModuleViewService.html';
};

MaterialConfigureTemplateManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;

    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: MaterialConfigureTemplateManager.getDefaultDocumentEditorPage(),
        url: MaterialConfigureTemplateManager.getLoadDocumentBaseURL(),
        label: MaterialConfigureTemplateManager.label,
        i18nConfig: MaterialConfigureTemplateManager.getI18nRootConfig(),
        docType: DocumentConstants.DummyDocumentType.MaterialConfigureTemplate
    });

    var fieldMetaList = [{
        fieldName:'materialConfigureTemplateUIModel.id',
        labelKey:'materialConfigureTemplate.id'
    },{
        fieldName:'materialConfigureTemplateUIModel.name',
        labelKey:'materialConfigureTemplate.name'
    },{
        listValueStragety: DocumentOrderMatPopInfo.ListItemStragegy.FIRST_ITEM,
        listSubPath:'matConfigHeaderConditionUIModelList',
        fieldName:'refNodeInstValue',
        labelKey:'matConfigHeaderCondition.refNodeInstId'
    },{
        listValueStragety: DocumentOrderMatPopInfo.ListItemStragegy.FIRST_ITEM,
        listSubPath:'matConfigHeaderConditionUIModelList',
        fieldName:'fieldName',
        labelKey:'matConfigHeaderCondition.fieldName'
    },{
        listValueStragety: DocumentOrderMatPopInfo.ListItemStragegy.ALL_ITEM,
        listSubPath:'matConfigExtPropertySettingUIModelList',
        fieldName:'name',
        labelKey:'matConfigExtPropertySetting.name'
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};


MaterialConfigureTemplateManager.prototype.getDocItemPopoverContent = function (oSettings) {
    "use strict";
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: MaterialConfigureTemplateManager.getDefaultDocumentItemEditorPage(),
        url: MaterialConfigureTemplateManager.getLoadDocItemBaseURL(),
        label: MaterialConfigureTemplateManager.label,
        i18nConfig: MaterialConfigureTemplateManager.getI18nItemConfig(),
        docType: DocumentConstants.DummyDocumentType.MaterialConfigureTemplate
    });

    var fieldMetaList = [{
        fieldName: 'matConfigExtPropertySettingUIModel.id',
        labelKey: 'matConfigExtPropertySetting.id',
    }, {
        fieldName: 'matConfigExtPropertySettingUIModel.name',
        labelKey: 'matConfigExtPropertySetting.name',
    }, {
        fieldName: 'matConfigExtPropertySettingUIModel.fieldType',
        labelKey: 'matConfigExtPropertySetting.fieldType'
    }, {
        fieldName: 'matConfigExtPropertySettingUIModel.qualityInspectValue',
        labelKey: 'matConfigExtPropertySetting.qualityInspectFlag',
        iconArray:SystemStandrdMetadataProxy.getDefaultSwitchIconArray()
    }, {
        fieldName: 'matConfigExtPropertySettingUIModel.measureFlagValue',
        labelKey: 'matConfigExtPropertySetting.measureFlag',
        iconArray:SystemStandrdMetadataProxy.getDefaultSwitchIconArray()
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};