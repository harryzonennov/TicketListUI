var dataVar = new Vue({
    el: "#x_data",
    data: {
        elementresourceTableId: '#x_table_elementresource',
        elementresourceTable: {},
        label: {
            id: '',
            uuid: '',
            name: '',
            indexInGroup: '',
            displaySwitch: '',
            elementTitle: '',
            linkURL: '',
            instSwitch: '',
            note: '',
            parentElementId: '',
            parentElementName: '',
            parentNavigationElementResourceIndexInGroup: '',
            refAuthorizationObjectId: '',
            refAuthorizationObjectName: '',
            refNavigationGroupId: '',
            refNavigationGroupName: '',
            refAuthorActionCodeId: '',
            refAuthorActionCodeName: '',
            elementIcon:'',
            targetPage:'',
            targetPageLink:'',
            navigationElementResourceSection: '',
            parentNavigationElementResourceSection: '',
            authorizationObjectSection: '',
            navigationGroupResourceSection: '',
            actionCodeSection: '',
            subNavigationElementResourceSection: '',


            msgSaveOK: '',
            msgSaveOKComment: '',
            msgConnectFailure: '',
            msgUnknowSystemFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            save: '',
            exit: '',
            quickEdit: '',
            buttonDelete: '',
            close: '',
            deleteWarnTitle: '',
            deleteWarnText: '',
            cancel: '',
            commit: '',
            confirm: '',
            addNavigationElementResource: '',
            addParentNavigationElementResource: '',
            addAuthorizationObject: '',
            addNavigationGroupResource: '',
            addActionCode: '',
            addSubNavigationElementResource: '',
            subNavigationElementResource: {
                id: '',
                name: '',
                elementTitle: '',
                displaySwitch: '',
                indexInGroup: '',
                linkURL: '',
                instSwitch: '',
                note: ''
            }
        },
        content: {
            navigationElementResourceUIModel: {
                client: '',
                id: '',
                uuid: '',
                name: '',
                indexInGroup: '',
                displaySwitch: '',
                elementTitle: '',
                linkURL: '',
                instSwitch: '',
                note: '',
                tabs: '',
                elementIcon: '',
                targetPage:'',
                targetPageLink:'',
                parentElementUUID: '',
                parentElementName: '',
                parentNavigationElementResourceIndexInGroup: '',
                refSimAuthorObjectUUID: '',
                refAuthorizationObjectName: '',
                refNavigationGroupUUID: '',
                refNavigationGroupName: '',
                refAuthorActionCodeUUID: '',
                refAuthorActionCodeName: ''
            },
            subNavigationElementResourceUIModelList: []
        },
        cache: {
            subNavigationElementResource: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refSimAuthorObjectUUID: '',
                refNavigationGroupUUID: '',
                parentElementUUID: '',
                refAuthorActionCodeUUID: '',
                id: '',
                name: '',
                elementTitle: '',
                displaySwitch: '',
                indexInGroup: '',
                linkURL: '',
                instSwitch: '',
                note: ''
            }
        },
        eleDisplaySwitch: '#x_displaySwitch',
        eleParentElementUUID: '#x_parentElementUUID',
        eleRefSimAuthorObjectUUID: '#x_refSimAuthorObjectUUID',
        eleRefNavigationGroupUUID: '#x_refNavigationGroupUUID',
        eleRefAuthorActionCodeUUID: '#x_refAuthorActionCodeUUID',
        getSwitchMapURL: '../navigationElementResource/getSwitchMap.html',
        loadModuleEditURL: '../navigationElementResource/loadModuleEditService.html',
        saveModuleURL: '../navigationElementResource/saveModuleService.html',
        newModuleServiceURL: '../navigationElementResource/newModuleService.html',
        newSubNavigationElementResourceServiceURL: '../navigationElementResource/newModuleService.html',
        eleEditSubNavigationElementResourceModal: '#x_eleEditSubNavigationElementResourceModal',
        loadSubNavigationElementResourceSelectListURL:'../navigationElementResource/loadModuleListService.html',
        loadParentNavigationElementResourceSelectListURL:'../navigationElementResource/loadModuleListService.html',
        loadAuthorizationObjectSelectListURL:'../authorizationObject/loadModuleListService.html',
        loadNavigationGroupResourceSelectListURL:'../navigationGroupResource/loadModuleListService.html',
        loadActionCodeSelectListURL:'../actionCode/loadModuleListService.html',
        loadNavigationElementResourceURL:'../navigationElementResource/loadModule.html',
        loadAuthorizationObjectURL:'../authorizationObject/loadModule.html',
        loadNavigationGroupResourceURL:'../navigationGroupResource/loadModule.html',
        loadActionCodeURL:'../actionCode/loadModule.html',
        exitURL:'NavigationElementResourceList.html',
        exitModuleURL:'../navigationElementResource/exitEditor.html'

    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'NavigationElementResource');
            this.setI18nProperties();
            this.loadModuleEdit();
            this.elementresourceTable = new ServiceDataTable(this.elementresourceTableId);
            this.initSelectConfigure();
        });
    },

    methods: {
        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.quickEdit = $.i18n.prop('quickEdit');
            this.label.nDelet = $.i18n.prop('nDelet');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.deleteWarnTitle = $.i18n.prop('deleteWarnTitle');
            this.label.deleteWarnText = $.i18n.prop('deleteWarnText');
            this.label.cancel = $.i18n.prop('cancel');
            this.label.commit = $.i18n.prop('commit');
            this.label.confirm = $.i18n.prop('confirm');
            this.label.addNavigationElementResource = $.i18n.prop('addNavigationElementResource');
            this.label.addParentNavigationElementResource = $.i18n.prop('addParentNavigationElementResource');
            this.label.addAuthorizationObject = $.i18n.prop('addAuthorizationObject');
            this.label.addNavigationGroupResource = $.i18n.prop('addNavigationGroupResource');
            this.label.addActionCode = $.i18n.prop('addActionCode');
            this.label.addSubNavigationElementResource = $.i18n.prop('addSubNavigationElementResource');
            BusyLoader.cleanPageBackground();

        },

        setNodeI18nPropertiesCore: function () {
            this.label.id = $.i18n.prop('id');
            this.label.uuid = $.i18n.prop('uuid');
            this.label.name = $.i18n.prop('name');
            this.label.indexInGroup = $.i18n.prop('indexInGroup');
            this.label.displaySwitch = $.i18n.prop('displaySwitch');
            this.label.elementTitle = $.i18n.prop('elementTitle');
            this.label.linkURL = $.i18n.prop('linkURL');
            this.label.instSwitch = $.i18n.prop('instSwitch');
            this.label.note = $.i18n.prop('note');
            this.label.parentElementId = $.i18n.prop('parentElementId');
            this.label.parentElementName = $.i18n.prop('parentElementName');

            this.label.elementIcon = $.i18n.prop('elementIcon');
            this.label.targetPage = $.i18n.prop('targetPage');
            this.label.targetPageLink = $.i18n.prop('targetPageLink');
            this.label.parentNavigationElementResourceIndexInGroup = $.i18n.prop('parentNavigationElementResourceIndexInGroup');
            this.label.refAuthorizationObjectId = $.i18n.prop('refAuthorizationObjectId');
            this.label.refAuthorizationObjectName = $.i18n.prop('refAuthorizationObjectName');
            this.label.refNavigationGroupId = $.i18n.prop('refNavigationGroupId');
            this.label.refNavigationGroupName = $.i18n.prop('refNavigationGroupName');
            this.label.refAuthorActionCodeId = $.i18n.prop('refAuthorActionCodeId');
            this.label.refAuthorActionCodeName = $.i18n.prop('refAuthorActionCodeName');
            this.label.navigationElementResourceSection = $.i18n.prop('navigationElementResourceSection');
            this.label.parentNavigationElementResourceSection = $.i18n.prop('parentNavigationElementResourceSection');
            this.label.authorizationObjectSection = $.i18n.prop('authorizationObjectSection');
            this.label.navigationGroupResourceSection = $.i18n.prop('navigationGroupResourceSection');
            this.label.actionCodeSection = $.i18n.prop('actionCodeSection');
            this.label.subNavigationElementResourceSection = $.i18n.prop('subNavigationElementResourceSection');

        },

        setI18nElementResourceProperties: function () {
            this.label.subNavigationElementResource.id = $.i18n.prop('id');
            this.label.subNavigationElementResource.name = $.i18n.prop('name');
            this.label.subNavigationElementResource.elementTitle = $.i18n.prop('elementTitle');
            this.label.subNavigationElementResource.displaySwitch = $.i18n.prop('displaySwitch');
            this.label.subNavigationElementResource.indexInGroup = $.i18n.prop('indexInGroup');
            this.label.subNavigationElementResource.linkURL = $.i18n.prop('linkURL');
            this.label.subNavigationElementResource.instSwitch = $.i18n.prop('instSwitch');
            this.label.subNavigationElementResource.note = $.i18n.prop('note');

        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'NavigationElementResource', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
            jQuery.i18n.properties({
                name: 'SubNavigationElementResource', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setI18nElementResourceProperties
            });

        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleDisplaySwitch).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.navigationElementResourceUIModel, 'displaySwitch', $(vm.eleDisplaySwitch).val());

            });
            $(vm.eleParentElementUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.navigationElementResourceUIModel, 'parentElementUUID', $(vm.eleParentElementUUID).val());
                var url = vm.loadParentNavigationElementResourceURL + "?uuid=" + $(vm.eleParentElementUUID).val();
                vm.$http.get(url).then(function (response) {
                    if (!JSON.parse(response.data).content) {
                        swal({
                            title: this.label.msgConnectFailure,
                            text: this.label.msgLoadDataFailure,
                            type: "error",
                            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                            confirmButtonText: this.label.confirm
                        });
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.content.navigationElementResourceUIModel, 'parentElementName', content.name);
                });
            });
            $(vm.eleRefSimAuthorObjectUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.navigationElementResourceUIModel, 'refSimAuthorObjectUUID', $(vm.eleRefSimAuthorObjectUUID).val());
                var url = vm.loadAuthorizationObjectURL + "?uuid=" + $(vm.eleRefSimAuthorObjectUUID).val();
                vm.$http.get(url).then(function (response) {
                    if (!JSON.parse(response.data).content) {
                        swal({
                            title: this.label.msgConnectFailure,
                            text: this.label.msgLoadDataFailure,
                            type: "error",
                            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                            confirmButtonText: this.label.confirm
                        });
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.content.navigationElementResourceUIModel, 'refAuthorizationObjectName', content.name);
                });
            });
            $(vm.eleRefNavigationGroupUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.navigationElementResourceUIModel, 'refNavigationGroupUUID', $(vm.eleRefNavigationGroupUUID).val());
                var url = vm.loadNavigationGroupResourceURL + "?uuid=" + $(vm.eleRefNavigationGroupUUID).val();
                vm.$http.get(url).then(function (response) {
                    if (!JSON.parse(response.data).content) {
                        swal({
                            title: this.label.msgConnectFailure,
                            text: this.label.msgLoadDataFailure,
                            type: "error",
                            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                            confirmButtonText: this.label.confirm
                        });
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.content.navigationElementResourceUIModel, 'refNavigationGroupName', content.name);
                });
            });
            $(vm.eleRefAuthorActionCodeUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.navigationElementResourceUIModel, 'refAuthorActionCodeUUID', $(vm.eleRefAuthorActionCodeUUID).val());
                var url = vm.loadActionCodeURL + "?uuid=" + $(vm.eleRefAuthorActionCodeUUID).val();
                vm.$http.get(url).then(function (response) {
                    if (!JSON.parse(response.data).content) {
                        swal({
                            title: this.label.msgConnectFailure,
                            text: this.label.msgLoadDataFailure,
                            type: "error",
                            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                            confirmButtonText: this.label.confirm
                        });
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.content.navigationElementResourceUIModel, 'refAuthorActionCodeName', content.name);
                });
            });

        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if (processMode == PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                var url = this.newModuleServiceURL;
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                this.$http.post(url, requestData).then(function (response) {
                    if (!JSON.parse(response.data).content) {
                        swal({
                            title: this.label.msgConnectFailure,
                            text: this.label.msgLoadDataFailure,
                            type: "error",
                            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                            confirmButtonText: this.label.confirm
                        });
                        return;
                    }
                    this.setModuleToUI(JSON.parse(response.data).content);
                });
            }
            if (processMode == PROCESSMODE_EDIT) {
// In case [Edit mode]
                var url = this.loadModuleEditURL + "?uuid=" + baseUUID;
                this.$http.get(url).then(function (response) {
                    if (!JSON.parse(response.data).content) {
                        swal({
                            title: this.label.msgConnectFailure,
                            text: this.label.msgLoadDataFailure,
                            type: "error",
                            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                            confirmButtonText: this.label.confirm
                        });
                        return;
                    }
                    this.setModuleToUI(JSON.parse(response.data).content);
                });
            }


        },

        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }

        },

        copySubNavigationElementResource: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refSimAuthorObjectUUID = origin.refSimAuthorObjectUUID;
            target.refNavigationGroupUUID = origin.refNavigationGroupUUID;
            target.parentElementUUID = origin.parentElementUUID;
            target.refAuthorActionCodeUUID = origin.refAuthorActionCodeUUID;
            target.elementTitle = origin.elementTitle;
            target.displaySwitch = origin.displaySwitch;
            target.indexInGroup = origin.indexInGroup;
            target.linkURL = origin.linkURL;
            target.instSwitch = origin.instSwitch;
            target.note = origin.note;
            return target;

        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            this.$http.post(vm.saveModuleURL, vm.content).then(function (response) {
                $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                this.setModuleToUI(JSON.parse(response.data).content);
                var processMode = getUrlVar(LABEL_PROCESSMODE);
                if (processMode && processMode == PROCESSMODE_NEW) {
                    var baseUUID = vm.content.navigationElementResourceUIModel.uuid;
                    if (baseUUID) {
                        window.location.href = genCommonEditURL("NavigationElementResourceEditor.html", baseUUID);
                    }
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.navigationElementResourceUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);

        },

        refreshEditView: function () {
            var baseUUID = this.content.navigationElementResourceUIModel.uuid;
            window.location.href = genCommonEditURL("NavigationElementResourceEditor.html", baseUUID);

        },

        loadSubNavigationElementResourceSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadSubNavigationElementResourceSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'id');
                setTimeout(function () {
                    $(vm.eleUuid).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleUuid).val(content.navigationElementResourceUIModel.uuid);
                    $(vm.eleUuid).trigger("change");
                }, 0);
            });

        },

        loadParentNavigationElementResourceSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadParentNavigationElementResourceSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'id');
                setTimeout(function () {
                    $(vm.eleParentElementUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleParentElementUUID).val(content.navigationElementResourceUIModel.parentElementUUID);
                    $(vm.eleParentElementUUID).trigger("change");
                }, 0);
            });

        },

        loadAuthorizationObjectSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadAuthorizationObjectSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'id');
                setTimeout(function () {
                    $(vm.eleRefSimAuthorObjectUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefSimAuthorObjectUUID).val(content.navigationElementResourceUIModel.refSimAuthorObjectUUID);
                    $(vm.eleRefSimAuthorObjectUUID).trigger("change");
                }, 0);
            });

        },

        loadNavigationGroupResourceSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadNavigationGroupResourceSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'id');
                setTimeout(function () {
                    $(vm.eleRefNavigationGroupUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefNavigationGroupUUID).val(content.navigationElementResourceUIModel.refNavigationGroupUUID);
                    $(vm.eleRefNavigationGroupUUID).trigger("change");
                }, 0);
            });

        },

        loadActionCodeSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadActionCodeSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleRefAuthorActionCodeUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefAuthorActionCodeUUID).val(content.navigationElementResourceUIModel.refAuthorActionCodeUUID);
                    $(vm.eleRefAuthorActionCodeUUID).trigger("change");
                }, 0);
            });

        },

        getDisplaySwitchMapList: function(content){
            var vm = this;
            this.$http.get(this.getSwitchMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleDisplaySwitch).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleDisplaySwitch).val(content.navigationElementResourceUIModel.displaySwitch);
                    $(vm.eleDisplaySwitch).trigger("change");
                }, 0);
            });
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'navigationElementResourceUIModel', content.navigationElementResourceUIModel);
            vm.$set(vm.content, 'subNavigationElementResourceUIModelList', content.subNavigationElementResourceUIModelList);
            vm.loadSubNavigationElementResourceSelectList(content);
            vm.loadParentNavigationElementResourceSelectList(content);
            vm.loadAuthorizationObjectSelectList(content);
            vm.loadNavigationGroupResourceSelectList(content);
            vm.loadActionCodeSelectList(content);
            vm.getDisplaySwitchMapList(content);

        },

        editSubNavigationElementResourceModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.subNavigationElementResourceUIModelList);
            if (!item) {
                return;
            }
            this.cache.subNavigationElementResource = this.copySubNavigationElementResource(item);
            $(this.eleEditSubNavigationElementResourceModal).modal('toggle');

        },

        setToSubNavigationElementResource: function () {
            var item = this._filterItemByUUID(this.cache.subNavigationElementResource.uuid, this.content.subNavigationElementResourceUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copySubNavigationElementResource(this.cache.subNavigationElementResource);
                this.content.subNavigationElementResourceUIModelList.push(newItem);
            } else {
                this.copySubNavigationElementResource(this.cache.subNavigationElementResource, item);
            }
            $(this.eleEditSubNavigationElementResourceModal).modal('hide');
        },

        newSubNavigationElementResourceModal: function () {
            var baseUUID = this.content.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            this.$http.post(this.newSubNavigationElementResourceServiceURL, requestData).then(function (response) {
                if (!JSON.parse(response.data).content) {
                    swal({
                        title: this.label.msgConnectFailure,
                        text: this.label.msgLoadDataFailure,
                        type: "error",
                        confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                        cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                        confirmButtonText: this.label.confirm
                    });
                    return;
                }
// In case success.
                this.cache.subNavigationElementResource = this.copySubNavigationElementResource(JSON.parse(response.data).content, this.cache.subNavigationElementResource);
                $(this.eleEditSubNavigationElementResourceModal).modal('toggle');
            });

        },

        deleteSubNavigationElementResource: function () {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.subNavigationElementResourceUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, content.subNavigationElementResourceUIModelList);
                    } else {
// do nothing, just return
                    }
                });
        },

        addSubNavigationElementResource: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.navigationElementResourceUIModel.uuid;
            var resultURL = "SubNavigationElementResourceEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },

        editSubNavigationElementResource: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            this.$http.post(vm.preLockURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.RC) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                if (oData.RC == HttpStatus.SC_OK) {
                    window.location.href = genCommonEditURL("SubNavigationElementResourceEditor.html", uuid);
                } else {
                    swal(this.label.lockFailureMessage, JSON.parse(response.data).MSG);
                }
            });

        }

    }
});
