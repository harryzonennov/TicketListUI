/**
 * Created by Zhang,hang on 12/27/2019.
 * General MultiSelect Vue Component to Batch Gen Inquiry request
 *
 * Dependency
 */

var MaterialInit = Vue.extend({
    name: "material-init",
    data: function () {
        "use strict";
        return {
            label: {
                createMaterialTitle:'',
                eleRefMaterialType:'',
                emptySelectedTypeWarnText:'',
                exit:'',
                confirm:'',
                close:'',
                refMaterialType: '',
                materialTypeName: '',
                materialTypeId: '',
                confirmToCreate:''
            },
            cache:{
                materialTypeName: '',
                materialTypeId: '',
                refMaterialType: ''
            },
            baseUUID: undefined,
            coreUUID: undefined,
            eleRefMaterialType: '#x_refMaterialType',
            targetUrl:'../material/newModuleService.html',
            loadMaterialTypeURL: '../materialType/loadModule.html',
            loadMaterialTypeSelectListURL: '../materialType/loadModuleListService.html',
            eleMaterialGenModal: '#material-gen-modal'
        };
    },

    created: function(){
        this.initCoreUUID();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.setI18nProperties();
            vm.initSelectConfigure();
            vm.loadMaterialTypeSelectList(vm.cache);
        }.bind(this));
    },

    computed: {

        comRefMaterialType: function () {
            "use strict";
            return 'x_refMaterialType' + this.coreUUID;
        }
    },

    methods: {

        initCoreUUID: function(){
            "use strict";
            this.coreUUID = genRamdomPostIndex();
        },

        initSelectConfigure: function(){
            "use strict";
            var vm = this;
            $('#' + vm.comRefMaterialType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache, 'refMaterialType', $('#' + vm.comRefMaterialType).val());
                vm.validateInput();
                var url = vm.loadMaterialTypeURL + "?uuid=" + $('#' + vm.comRefMaterialType).val();
                vm.$http.get(url).then(function (response) {
                    if (!JSON.parse(response.data).content) {
                        swal({
                            title: this.label.msgSystemFailure,
                            text: this.label.msgUnknowSystemFailure,
                            type: "error",
                            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                            confirmButtonText: this.label.confirm
                        });
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.cache, 'materialTypeName', content.name);
                    vm.$set(vm.cache, 'materialTypeId', content.id);
                });
            });
        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'Material', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache: true,
                callback: this.setNodeI18nPropertiesCore
            });
        },


        getI18nPath: function () {
            return "coreFunction/";
        },

        setI18nCommonProperties: function () {
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.confirm = $.i18n.prop('confirm');
        },

        setNodeI18nPropertiesCore: function () {
            "use strict";
            this.label.createMaterialTitle = $.i18n.prop('createMaterialTitle');
            this.label.confirmToCreate = $.i18n.prop('confirmToCreate');
            this.label.emptySelectedTypeWarnText = $.i18n.prop('emptySelectedTypeWarnText');
            this.label.refMaterialType = $.i18n.prop('refMaterialType');
            this.label.materialTypeId = $.i18n.prop('materialTypeId');
            this.label.materialTypeName = $.i18n.prop('materialTypeName');
        },

        loadMaterialTypeSelectList: function (cache) {
            var vm = this;
            this.$http.get(this.loadMaterialTypeSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $('#' + vm.comRefMaterialType).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $('#' + vm.comRefMaterialType).val(cache.refMaterialType);
                    $('#' + vm.comRefMaterialType).trigger("change");
                }, 0);
            });
        },


        /**
         * Main Entrance of inquiry batch gen request
         * @param options:
         *     --{String} targetUrl: target url to get inquiry from
         *     --{String} baseUUID: base UUID
         *     --{function} fnLaunchDone: call back function when Muli-select UI is launched
         *     --{function} fnGenDone: call back function after target Document item is generated
         *     --{String} eleMultiSelectId: optional
         */
        initCreation:function(oSettings) {
            var vm = this;
            $(vm.eleMaterialGenModal).modal('show');
        },

        validateInput: function () {
            var vm = this;
            return ServiceValidatorHelper.defaultValidateCheckArray({
                messageContainer: '#x_material_create_container',
                configList: [{
                    valueContainer: '#' + vm.comRefMaterialType,
                    errorMessage: vm.label.emptySelectedTypeWarnText,
                    validType:{
                        defType:ServiceValidatorHelper.DEF_VALID_TYPE.NON_EMPTY
                    },
                    value: vm.cache.refMaterialType,
                    context:'approveStatus'
                }]
            });

        },

        confirmToCreate:function () {
            var vm = this;
            var checkResult = vm.validateInput();
            if (checkResult === false) {
                return;
            }
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.refMaterialType = vm.cache.refMaterialType;
            var resultURL = "MaterialEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        }
    },



    template:
    ' <div id="material-gen-modal" class="modal fade"  role="dialog"  aria-labelledby="custom-width-modalLabel" aria-hidden="true" style="display: none;">\n' +
    '     <div class="modal-dialog" style="width:55%;">\n' +
    '         <div class="modal-content portlet  p-0 ">'+
    '             <div class=" portlet-heading bg-lightgrey">\n' +
    '                 <h3 class="portlet-title "><i class="md md-texture content-portlet-title"></i><i class="md md-add content-green"></i> {{label.createMaterialTitle}}</h3>\n' +
    '                    <div class="portlet-widgets">\n' +
    '                        <button type="button" data-toggle="remove" data-dismiss="modal" aria-hidden="true">\n' +
    '                              <i class="ion-close-round"></i>\n' +
    '                       </button>\n' +
    '                    </div>\n' +
    '                    <div class="clearfix"></div>\n' +
    '             </div>'+
    '             <div class="modal-body">\n' +
    '                <div id="x_material_create_container" class="message-container"></div>\n' +
    '                    <div class="row">\n' +
    '                          <div class="col-md-12">\n' +
    '                              <form action="#" class="form-horizontal" role="form">\n' +
    '                                   <div class="form-group">\n' +
    '                                         <label class=" col-md-4 control-label"><span class="text-required">*</span> {{label.materialTypeName}}</label>\n' +
    '                                                <div class="col-md-7">\n' +
    '                                                      <select  :id="comRefMaterialType" type="text" class="form-control" ' +
        '                                                      v-model="cache.refMaterialType"></select> ' +
    '                                                </div>\n' +
    '                                    </div>\n' +
    '                               </form>\n' +
    '                        </div>\n' +
    '                    </div>\n' +
    '                    <div class="row">\n' +
    '                          <div class="col-md-12">\n' +
    '                                   <form action="#" class="form-horizontal" role="form">\n' +
    '                                         <div class="form-group">\n' +
    '                                              <label class=" col-md-4 control-label">{{label.materialTypeId}}</label>\n' +
    '                                                 <div class="col-md-7"><input type="text" disabled="true" class="form-control" v-model="cache.materialTypeId"></input>\n' +
    '                                                </div>\n' +
    '                                            </div>\n' +
    '                                      </form>\n' +
    '                               </div>\n' +
    '                        </div>' +
    '                   </div>' +
    '                 <div class="modal-footer">\n' +
    '                      <button type="button" class="btn btn-nonAction btn-rounded-embedded" data-dismiss="modal">\n' +
    '                               <i class="md md-close"></i> {{label.close}}</button>\n' +
    '                      <button type="button" @click="confirmToCreate" class="btn btn-action btn-rounded-embedded">\n' +
    '                               <i class="md md-check"></i> {{label.confirmToCreate}}</button>\n' +
    '             </div>'+
    '           </div>'+
    '         </div>'+
    '      </div>'


});





