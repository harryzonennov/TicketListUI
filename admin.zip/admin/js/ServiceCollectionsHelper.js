var ServiceCollectionsHelper = {
    field:{
        UUID: 'uuid',
        REFUUID: 'refUUID'
    }
};

/**
 * If rawList is null or length is zero, then return true;
 * @param rawList
 * @returns {boolean}
 */
ServiceCollectionsHelper.checkNullList = function(rawList){
    if (rawList && rawList.length > 0) {
        return false;
    } else {
        return true;
    }
};

ServiceCollectionsHelper.filterPrimArray = function (key, rawArray){
    var filterArray = ServiceCollectionsHelper.filterToPrimArray(key, rawArray, true);
    if(filterArray && filterArray.length > 0){
        return filterArray[0];
    }
};

/**
 * Filter Prim(simple, flat) array by key value
 * @param key
 * @param rawArray
 * @param fastSkip
 * @returns {*[]}
 */
ServiceCollectionsHelper.filterToPrimArray = function (key, rawArray, fastSkip){
    if(ServiceCollectionsHelper.checkNullList(rawArray)){
        return undefined;
    }
    if(!key){
        return undefined;
    }
    var i = 0, j = 0, filterArray = [];
    for(i = 0;  i < rawArray.length; i++){
        if(rawArray[i] == key){
            filterArray[j] = rawArray[i];
            j++;
            if(fastSkip && fastSkip === true){
                return filterArray;
            }
        }
    }
    return filterArray;
};

ServiceCollectionsHelper.sortArrayByBase = function(toSortArray, baseArray){
    if(ServiceCollectionsHelper.checkNullList(baseArray)){
        return;
    }
    if(ServiceCollectionsHelper.checkNullList(toSortArray)){
        return;
    }
    var resultList = [];
    var i = 0;
    for(i = 0; i < baseArray.length; i++){
        var filterUnion = ServiceCollectionsHelper.filterPrimArray(baseArray[i], toSortArray);
        if(filterUnion){
            resultList.push(filterUnion);
        }
    }
    return resultList;
};

/**
 * Sort Array by comparing property value (specified by fieldName)
 * @param oSettings
 *   --{String} fieldName
 * @returns {*}
 */
ServiceCollectionsHelper.sortArrayByProperty = function(oSettings){
    var fieldName = oSettings.fieldName;
    var rawList = oSettings.rawList;
    function compare( a, b ) {
        if ( a[fieldName] < b[fieldName] ){
            return -1;
        }
        if ( a[fieldName] > b[fieldName] ){
            return 1;
        }
        return 0;
    }
    return rawList.sort( compare );
};

ServiceCollectionsHelper.cloneArray = function(sourceList, targetList){
    if(ServiceCollectionsHelper.checkNullList(sourceList)){
        return;
    }
    var resultList = [];
    if(!ServiceCollectionsHelper.checkNullList(targetList)){
        resultList = targetList;
    }
    ServiceCollectionsHelper.traverseList(sourceList, function (sourceObj){
        if(ServiceCollectionsHelper.checkArrayFlag(sourceObj)){
            resultList = resultList.concat(ServiceUtilityHelper.cloneArray(sourceObj));
        }else{
            resultList.push(ServiceUtilityHelper.cloneObj(sourceObj));
        }
    });
    return resultList;
};

/**
 * Merge two Array Together, and sort them by index
 * @param {Array} baseList: input data list, index value will be place in first place
 * @param {Array} toAdjustList
 * @param oSettings
 *   --{String} indexFieldName
 * @returns {*}
 */
ServiceCollectionsHelper.mergeAndSortArray = function(baseList, toAdjustList, oSettings){
    if(ServiceCollectionsHelper.checkNullList(baseList)){
        return toAdjustList;
    }
    if(ServiceCollectionsHelper.checkNullList(toAdjustList)){
        return baseList;
    }
    var haveAdjustList = [];
    // Local method: get index field name
    var getIndexFieldName = function(){
        var defIndexFieldName = 'index';
        if(!oSettings){
            return defIndexFieldName;
        }
        return oSettings.indexFieldName ? oSettings.indexFieldName : defIndexFieldName;
    };
    // Local method: get index value
    var retrieveIndex = function(toAdjust){
        var indexFieldName = getIndexFieldName();
        return toAdjust[indexFieldName];
    };
    // Local method: calculate next correct index to avoid duplicate with existed data list
    var calculateIndexValue = function(toIndex, baseList){
        // Check if data with same index from baseList
        var indexFieldName = getIndexFieldName();
        var duplicateData = ServiceCollectionsHelper.filterArray(toIndex, indexFieldName, baseList);
        if(duplicateData){
            return calculateIndexValue( toIndex + 1, baseList);
        }else{
            return toIndex;
        }
    };
    ServiceCollectionsHelper.traverseList(toAdjustList, function(toAdjust){
        // Check if data with same index
        var indexFieldName = getIndexFieldName();
        var index = retrieveIndex(toAdjust);
        var corIndex = calculateIndexValue(index, baseList);
        corIndex = calculateIndexValue(corIndex, haveAdjustList);
        toAdjust[indexFieldName] = corIndex;
        haveAdjustList.push(toAdjust);
    });
    return baseList.concat(toAdjustList);
};

/**
 * Merge Pure array with duplicate c
 * @param baseArray
 * @param toAdjustArray
 * @return {*}
 */
ServiceCollectionsHelper.mergeArray = function(baseArray, toAdjustArray){
    if(ServiceCollectionsHelper.checkNullList(baseArray)){
        return toAdjustArray;
    }
    if(ServiceCollectionsHelper.checkNullList(toAdjustArray)){
        return baseArray;
    }
    ServiceCollectionsHelper.traverseList(toAdjustArray, function(toAdjust){
        var duplicateObj = ServiceCollectionsHelper.filterArray(toAdjust, undefined, baseArray);
        if(!duplicateObj){
            baseArray.push(toAdjust);
        }
    });
    return baseArray;
};

ServiceCollectionsHelper.directMergeArray = function(baseList, toAdjustList){
    if(ServiceCollectionsHelper.checkNullList(baseList)){
        return toAdjustList;
    }
    if(ServiceCollectionsHelper.checkNullList(toAdjustList)){
        return baseList;
    }
    return baseList.concat(toAdjustList);
};


/**
 * filter the element from array
 * @param key
 * @param keyName
 * @param rawList
 * @returns {*}
 */
ServiceCollectionsHelper.filterArray = function(key, keyName, rawList, subPath){
    return ServiceCollectionsHelper.filterArrayByKeyList([{keyValue:key, keyName:keyName}], rawList, subPath);
};


ServiceCollectionsHelper.filterArrayByKeyList = function(keyList, rawList, subPath){
    var resultList = ServiceCollectionsHelper.filterToArrayByKeyList({
        keyList: keyList,
        rawList: rawList,
        subPath: subPath,
        fastSkip: true
    });
    if(ServiceCollectionsHelper.checkNullList(resultList)){
        return;
    }
    return resultList[0];
};

/**
 *
 * @param {Array} keyList
 *     -- {Object} keyValue
 *     -- {String} keyName
 *     -- {int} [Optional] logicOperator
 * @param rawList
 * @param subPath
 * @param fastSkip
 * @param {Boolean} assembleSub: Wethear need to assembly sub object (retrieve by sub path)
 * @returns {null|*[]}
 */
ServiceCollectionsHelper.filterToArrayByKeyList = function(oSettings){
    var keyList = oSettings.keyList;
    var rawList = oSettings.rawList;
    var subPath = oSettings.subPath;
    var fastSkip = oSettings.fastSkip;
    var assembleSub = oSettings.assembleSub;
    if(ServiceCollectionsHelper.checkNullList(rawList)){
        return null;
    }
    if(ServiceCollectionsHelper.checkNullList(keyList)){
        return null;
    }
    var i, resultList = [], tempSubModel, tempModel, tempValue, _len = rawList.length;
    for( i = 0; i < _len; i++){
        tempSubModel = ServiceCollectionsHelper.retrieveTempModel(rawList, i, subPath);
        tempModel = ServiceCollectionsHelper.retrieveTempModel(rawList, i);
        var checkResult = true;
        ServiceCollectionsHelper.traverseListInterrupt(keyList, function (keyUnit){
            if (keyUnit.keyName){
                tempValue = ServiceCollectionsHelper.fetchModelValue(keyUnit.keyName, tempSubModel);
            } else {
                // in case pure array
                tempValue = tempSubModel;
            }
            if(keyUnit.logicOperator && keyUnit.logicOperator === DocumentConstants.StandardPropety.StandardLogicOperator.OR){
                // In case parallel format
                if( tempValue == keyUnit.keyValue ){
                    checkResult = true;
                    // break the loop
                    return false;
                }else{
                    checkResult = false;
                }
            }else{
                // In case default: serial format
                if( tempValue != keyUnit.keyValue ){
                    checkResult = false;
                    // break the loop
                    return false;
                }
            }
        });
        if(checkResult === true){
            if(assembleSub === true){
                resultList.push(tempSubModel);
            }else{
                resultList.push(tempModel);
            }
            if(fastSkip === true){
                return resultList;
            }
        }
    }
    return resultList;
};

ServiceCollectionsHelper.retrieveTempModel = function(rawList, index, subPath){
    if(ServiceCollectionsHelper.checkNullList(rawList)){
        return null;
    }
    var tempModel;
    if(subPath){
        tempModel = rawList[index][subPath];
    }else{
        tempModel = rawList[index];
    }
    return tempModel;
};


ServiceCollectionsHelper.fetchModelValue = function(keyName, model){
    if(!model){
        return;
    }
    return model[keyName];
};

/**
 * filter the subArray from array
 * @param key
 * @param keyName
 * @param rawList
 * @returns {*}
 */
ServiceCollectionsHelper.filterToArray = function(key, keyName, rawList, subPath){
    return ServiceCollectionsHelper.filterToArrayByKeyList({
        keyList: [{keyValue:key, keyName:keyName}],
        rawList: rawList,
        subPath: subPath,
        fastSkip: true
    });
};


ServiceCollectionsHelper.filterToArrayWrapper = function(oSettings){
    return ServiceCollectionsHelper.filterToArrayByKeyList({
        keyList: [{keyValue:oSettings.key, keyName:oSettings.keyName}],
        rawList: oSettings.rawList,
        subPath: oSettings.subPath,
        assembleSub: oSettings.assembleSub
    });
};

/**
 * Filter Array by key value and key name, if hit success, return index from the array
 * @param key
 * @param keyName
 * @param rawList
 * @param subPath
 * @returns {int} index in array
 */
ServiceCollectionsHelper.filterArrayIndex = function(key, keyName, rawList, subPath){
    "use strict";
    if(ServiceCollectionsHelper.checkNullList(rawList)){
        return null;
    }
    if(!key){
        return null;
    }
    var i, tempModel, _len = rawList.length;
    for( i = 0; i < _len; i++){
        if (subPath){
            tempModel = rawList[i][subPath];
        } else {
            tempModel = rawList[i];
        }
        var tempValue = tempModel;
        if (keyName){
            tempValue = tempModel[keyName];
        }
        if(key === tempValue){
            return i;
        }
    }
    return -1;
};


ServiceCollectionsHelper.mergeList = function(baseList, addedList, oSettings){
    if (ServiceCollectionsHelper.checkNullList(baseList)) {
        return addedList;
    }
    if (ServiceCollectionsHelper.checkNullList(addedList)) {
        return baseList;
    }
    var keyName = oSettings.keyName, overwrite = oSettings.overwrite, subPath = oSettings.subPath;
    var i, addModel, _len = addedList.length;
    for ( i = 0; i < _len; i++) {
        if (subPath) {
            addModel = addedList[i][subPath];
        } else {
            addModel = addedList[i];
        }
        var key = addModel[keyName];
        var index = ServiceCollectionsHelper.filterArrayIndex(key, keyName, baseList, subPath);
        if (index === -1) {
            // in case not found duplicate unit
            baseList.push(addedList[i]);
        } else {
            // in case same key value member exist
            if (overwrite && overwrite === true) {
                baseList.splice(index, 1, addedList[i]);
            }
            // in custom mergeFunction
            if (oSettings.mergeFunction) {
                var mergedObj = oSettings.mergeFunction(baseList[index], addedList[i]);
                baseList.splice(index, 1, mergedObj);
            }
        }
    }
    return baseList;
};

/**
 * Filter Array by boolean type fnCallback, if hit success, return index from the array

 * @param rawList
 * @param fnCallback
 * @returns {Object} index with model pair
 */
ServiceCollectionsHelper.filterWithIndex = function(rawList, fnCallback){
    "use strict";
    if(ServiceCollectionsHelper.checkNullList(rawList)){
        return null;
    }
    var i, tempResult, _len = rawList.length;
    for( i = 0; i < _len; i++){
        tempResult = fnCallback(rawList[i]);
        if(tempResult === true){
            return { index: i, model:rawList[i] };
        }
    }
};

/**
 * Filter Array by boolean type fnCallback, if hit success, return index from the array

 * @param rawList
 * @param fnCallback
 * @returns {Object} index with model pair
 */
ServiceCollectionsHelper.filterListWithIndex = function(rawList, fnCallback){
    "use strict";
    if(ServiceCollectionsHelper.checkNullList(rawList)){
        return null;
    }
    var i, tempResult, _len = rawList.length, resultList = [];
    for( i = 0; i < _len; i++){
        tempResult = fnCallback(rawList[i]);
        if(tempResult === true){
            resultList.push({ index: i, model:rawList[i] });
        }
    }
    return resultList;
};

/**
 * Filter Array by boolean type fnCallback, if hit success, return index from the array

 * @param rawList
 * @param fnCallback
 * @returns {Object} index with model pair
 */
ServiceCollectionsHelper.filterList = function(rawList, fnCallback){
    "use strict";
    if(ServiceCollectionsHelper.checkNullList(rawList)){
        return null;
    }
    var i, tempResult, _len = rawList.length, resultList = [];
    for( i = 0; i < _len; i++){
        tempResult = fnCallback(rawList[i]);
        if(tempResult === true){
            resultList.push(rawList[i]);
        }
    }
    return resultList;
};

/**
 *
 * @param uuid
 * @param rawList
 * @param subPath
 */
ServiceCollectionsHelper.removeItemByUUID = function (uuid, rawList, subPath) {
    "use strict";
    if(ServiceCollectionsHelper.checkNullList(rawList)){
        return ;
    }
    var _index = ServiceCollectionsHelper.filterArrayIndex(uuid, ServiceCollectionsHelper.field.UUID, rawList, subPath);
    var _len = rawList.length;
    if(_index >= 0 && _index < _len){
        rawList.splice(_index, 1);
    }

};

ServiceCollectionsHelper.filterOutListSelection = function(rawSelectionList, selectedList, rawKeyName, selectedkeyName){
    var vm = this;
    if(ServiceCollectionsHelper.checkNullList(rawSelectionList)){
        return;
    }
    if(ServiceCollectionsHelper.checkNullList(selectedList)){
        return rawSelectionList;
    }
    var result = [], checkIndex = -1;
    rawSelectionList.forEach(function(union){
        checkIndex = ServiceCollectionsHelper.filterArrayIndex(union[rawKeyName], selectedkeyName, selectedList);
        if(checkIndex === -1){
            result.push(union);
        }
    });
    return result;
};

/**
 * Utility method to check weather current object is array or not.
 * @param instance
 * @returns {boolean}
 */
ServiceCollectionsHelper.checkArrayFlag = function (instance) {
    if (!instance) {
        return false;
    }
    if (typeof  instance === "object") {
        if (instance instanceof Array) {
            return true;
        }
    }
    return false;
};

ServiceCollectionsHelper.filterSubListByKeyReflective = function (rawList, key, keyName) {
    if (!rawList || !ServiceCollectionsHelper.checkArrayFlag(rawList) || rawList.length === 0) {
        return;
    }
    var i = 0, comInstance = {}, resultList = [], _len =  rawList.length;
    for( i = 0; i < _len; i++ ){
        comInstance = rawList[i];
        if(comInstance[keyName] && comInstance[keyName] === key){
            resultList.push(comInstance);
        }
        if(comInstance[keyName] && ServiceCollectionsHelper.checkArrayFlag(comInstance[keyName])){
            var tempList = ServiceCollectionsHelper.filterSubListByKeyReflective(comInstance[keyName], key, keyName);
            if(!ServiceCollectionsHelper.checkNullList(tempList)){
                resultList.push(tempList);
            }
        }
    }
    return resultList;

};

ServiceCollectionsHelper.traverseList = function(rawList, fnCallback){
    if(ServiceCollectionsHelper.checkNullList(rawList)){
        return;
    }
    rawList.forEach(fnCallback);
};

/**
 * Traverse list function, with interrupt function
 * @param rawList
 * @param fnCallback
 */
ServiceCollectionsHelper.traverseListInterrupt = function(rawList, fnCallback){
    if(ServiceCollectionsHelper.checkNullList(rawList)){
        return;
    }
    var i = 0, callbackResult, _len =  rawList.length;
    for( i = 0; i < _len; i++ ){
        callbackResult = fnCallback(rawList[i], i);
        if(callbackResult === false){
            break;
        }
    }
};