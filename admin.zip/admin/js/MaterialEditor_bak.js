var rightBar = new Vue({
    el: "#rightBarHoc",
    mixins: [ServiceRightBarPanelHelper.defTimelineMinxin, MaterialManager.labelTemplate],
    data: function () {
        return {
            label: MaterialManager.label.material,
            coreModelId: "Material",
            i18nPath:"coreFunction/",
            selectMeta: {
                iconClassMap: {
                    "material.materialCategory": MaterialManager.getMaterialCategoryIconArray(),
                    "material.supplyType": MaterialManager.getSupplyTypeIconArray(),
                    "material.operationMode": MaterialManager.getOperationModeIconMap(),
                    "material.status": MaterialManager.getStatusIconArray(),
                    "material.matQualityInspectFlag": SystemStandrdMetadataProxy.getDefaultSwitchIconArray()
                },
                data: {
                    "material.materialCategory": "",
                    "material.supplyType": "",
                    "material.status": "",
                    "material.operationMode": "",
                    "material.matQualityInspectFlag": ""
                }
            }
        };
    },

    methods: {

        getActionMeta: function(){
            return {"actionCodeMap": MaterialManager.getActionCodeIconMap()};
        },

        initHelpDocumentList: function (uuid) {
            "use strict";
            var vm = this;
            ServiceRightBarPanelHelper.initHelpDocumentWithAction({
                uuid: uuid,
                vm: vm,
                getDocActionNodeListURL: '../material/getDocActionNodeList.html',
                errorHandle: dataVar.errorHandle,
                helpDocumentName: ['MaterialHelpDocument', 'MaterialUnitHelpDocument']
            });
        }
    }
});

var dataVar = new Vue({
    el: "#x_data",
    mixins: [MaterialManager.labelTemplate],
    data: {
        materialUnitTableId: '#x_table_materialUnit',
        materialUnitTable: {},
        materialSKUTableId: '#x_table_materialSKU',
        materialSKUTable: {},
        label: MaterialManager.label.material,
        content: {
            materialUIModel: {
                uuid: '',
                id: '',
                name: '',
                fixLeadTime: '',
                yearType: '',
                materialCategory: '',
                allDefinedSize: '',
                amountForVarLeadTime: '',
                memberSalePrice: '',
                client: '',
                subAlcoholType: '',
                qualityInspectFlag:'',
                length: '',
                seasonType: '',
                materialPicture: '',
                validPeriodUnit: '',
                retailPrice: '',
                retailPriceDisplay: '',
                width: '',
                minStoreNumber: '',
                volume: '',
                outboundDeliveryPrice: '',
                refMainSupplierUUID: '',
                mainSupplierName: '',
                mainProductionPlace: '',
                cargoType: '',
                alcoholType: '',
                operationMode:'',
                wholeSalePrice: '',
                switchFlag: '',
                netWeight: '',
                status: '',
                packageStandard: '',
                supplyType: '',
                mainMaterialUnit: '',
                packageMaterialType: '',
                allDefinedPackageStandard: '',
                barcode: '',
                grossWeight: '',
                inboundDeliveryPrice: '',
                purchasePrice: '',
                purchasePriceDisplay: '',
                variableLeadTime: '',
                validPeriodValue: '',
                height: '',
                note: '',
                unitCost: '',
                refLengthUnit: '',
                refVolumeUnit: '',
                refWeightUnit: '',
                materialTypeParentTypeUUID: '',
                refMaterialType: '',
                materialTypeId: '',
                materialTypeName: '',
                materialTypeNote: ''
            },
            materialUnitUIModelList: [],
            materialAttachmentUIModelList:[]
        },

        selectMeta:{
            iconClassMap:{
                supplyType: MaterialManager.getSupplyTypeIconArray(),
                traceMode:MaterialStockKeepUnitManager.getTraceModeArray(),
                qualityInspectFlag:SystemStandrdMetadataProxy.getDefaultSwitchIconArray()
            },
            data:{
                materialCategory:'',
                supplyType:'',
                traceMode:'',
                qualityInspectFlag:''
            }
        },
        author:{
            resourceId:DocumentConstants.DummyDocumentType.Material,
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        authorSKU:{
            resourceId:DocumentConstants.DummyDocumentType.MaterialStockKeepUnit,
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        cache:{
            materialStockKeepList:[]
        },
        attachmentMeta:{
            loadAttachmentURL: '../material/loadAttachment.html',
            deleteAttachmentURL: '../material/deleteAttachment.html',
            uploadAttachmentURL: '../material/uploadAttachment.html',
            uploadAttachmentTextURL: '../material/uploadAttachmentText.html'
        },
        attachmentLabel:{
            attachmentSection:'产品图片'
        },
        docActionConfigureList:[],
        processButtonMeta: [],
        embedProcessButtonMeta:[],
        eleRefMaterialType: '#x_refMaterialType',
        eleRefMainSupplier: '#x_refMainSupplier',
        eleStatus:'#x_status',
        eleRefSupplyType: '#x_refSupplyType',
        eleRefCargoType: '#x_refCargoType',
        eleSwitchFlag: '#x_switchFlag',
        eleRefLengthUnit: '#x_refLengthUnit',
        eleRefVolumeUnit: '#x_refVolumeUnit',
        eleRefWeightUnit: '#x_refWeightUnit',
        eleOperationMode: '#x_operationMode',
        eleRefMainMaterialUnit: "#x_refMainMaterialUnit",
        eleMainMaterialUnitName: '#x_mainMaterialUnitName',
        eleMatQualityInspectFlag: '#x_matQualityInspectFlag',
        eleRefPackageMaterialType: '#x_refPackageMaterialType',
        eleRefMaterialCategory: '#x_refMaterialCategory',
        loadModuleEditURL: '../material/loadModuleEditService.html',
        loadModuleViewURL: '../material/loadModuleViewService.html',
        saveModuleURL: '../material/saveModuleService.html',
        exitModuleURL: '../material/exitEditor.html',
        executeDocActionURL: '../material/executeDocAction.html',
        newModuleServiceURL: '../material/newModuleService.html',
        newModuleFromTypeURL: '../material/newModuleFromType.html',
        newMaterialUnitServiceURL: '../materialUnit/newModuleService.html',
        getDocActionConfigureListURL: '../material/getDocActionConfigureList.html',
        loadStandardUnitSelectListURL: '../material/getStandardUnit.html',
        getActionCodeMapURL: '../material/getActionCodeMap.html',
        exitURL: 'MaterialList.html'
    },

    created: function(){
        "use strict";
        var vm = this;
        vm.initSubComponents();
        vm.initDocActionConfigureList();
        vm.initAuthorResourceCheck();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('logistics', 'Material');
            this.setI18nProperties(vm.initProcessButtonMeta());
            this.loadModuleEdit();
            this.initUnitTable();
            this.materialSKUTable = new ServiceDataTable(this.materialSKUTableId);
            this.initSelectConfigure();
        });
    },

    methods: {

        initSubComponents: function() {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("attachment-union", AttachmentUnion);
            Vue.component("doc-action-modal", DocActionModal);
            Vue.component("material-unit-panel", MaterialUnitPanel);
            Vue.component("pop-panel-compensate-section", PopPanelCompensateSection);
            Vue.component("material-type-selector", MaterialTypeSelector);
            Vue.component("material-type-select", MaterialTypeSelect);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initDocActionConfigureList: function (){
            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:vm.getDocActionConfigureListURL,
                $http:vm.$http,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    vm.$set(vm, 'docActionConfigureList', oData.content);
                }.bind(this)
            });
        },

        selectMaterialTypeModal: function () {
            var vm = this;
            // this.$refs.refMaterialTypeSelect.selectMaterialTypeModal();
            this.$refs.refMaterialTypeSelect.initSelectModal();
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        setToMaterialType: function(materialType){
            var vm = this;
            vm.$set(vm.content.materialUIModel, 'refMaterialType', materialType.uuid);
            vm.$set(vm.content.materialUIModel, 'materialTypeName', materialType.name);
            vm.$set(vm.content.materialUIModel, 'materialTypeId', materialType.id);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nCommonReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nMaterialProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.material, $.i18n.prop, true);
        },

        setI18nUnitProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.materialUnit, $.i18n.prop, true);
        },

        setI18nMaterialSKUProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.materialStockKeepUnit, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'Material',
                    callback: this.setNodeI18nPropertiesCore
                }, {
                    name: 'MaterialUnit',
                    callback: this.setI18nUnitProperties
                }, {
                    name: 'MaterialStockKeepUnit',
                    callback: this.setI18nMaterialSKUProperties
                },{
                    actionNode: vm.label.actionNode
                }]
            });
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var embedProcessButtonMeta = [{
                button: {
                    id: 'batchAddMatList',
                    label: vm.label.batchAddMatList,
                    title: vm.label.batchAddMatList,
                    disableFlag: vm.disableNotInInit,
                    icon: 'md md-more-vert',
                    formatClass: '',
                    callback: '',
                }
            }];
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                active: {
                    label: '激活产品',
                    formatClass: vm.displayForActive,
                    iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_ACTIVE,
                    callback: vm.activeService
                },
                reInit: {
                    label: '重新编辑',
                    formatClass: vm.displayForReInit,
                    iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_REINIT,
                    callback: vm.reInitService
                },
                submit: {
                    formatClass: vm.displayForSubmit,
                    callback: vm.submitService
                },
                revokeSubmit: {
                    formatClass: vm.displayForRevokeSubmit,
                    callback: vm.revokeSubmitService
                },
                approve: {
                    formatClass: vm.displayForApprove,
                    callback: vm.approveOrder
                },
                rejectApprove: {
                    formatClass: vm.displayForApprove,
                    callback: vm.rejectApproveService
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$set(vm, 'embedProcessButtonMeta', embedProcessButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        displayForActionCodeConfig: function(oSettings){
            return ServiceUtilityHelper.displayForActionCodeConfig({
                currentStatus:this.content.materialUIModel.status * 1,
                docActionConfigureList:this.docActionConfigureList,
                targetActionCode:oSettings.targetActionCode,
                accessActionCodeModel:this.author.actionCode,
                renderModel: oSettings.renderModel,
                involveTaskStatus:oSettings.involveTaskStatus,
            });
        },


        displayForApprove: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: MaterialManager.DOC_ACTION_CODE.APPROVE,
                renderModel:{approve:{}},
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForRejectApprove: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: MaterialManager.DOC_ACTION_CODE.REJECT_APPROVE,
                renderModel:{approve:{}},
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForSubmit: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: MaterialManager.DOC_ACTION_CODE.SUBMIT,
                renderModel:{approve:{}},
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForRevokeSubmit: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: MaterialManager.DOC_ACTION_CODE.REVOKE_SUBMIT,
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForActive: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: MaterialManager.DOC_ACTION_CODE.ACTIVE,
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForReInit: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: MaterialManager.DOC_ACTION_CODE.REINIT,
                involveTaskStatus: this.involveTaskStatus
            });
        },

        genActionNodeInitConfigure: function(oSettings){
            var vm = this;
            if(!oSettings.targetUrl){
                oSettings.targetUrl = vm.executeDocActionURL;
            }
            if(!oSettings.serviceUIModel){
                oSettings.serviceUIModel = vm.content;
            }
            if(!oSettings.postHandle){
                oSettings.postHandle = vm.refreshEditView;
            }
            if(!oSettings.getActionCodeURL){
                oSettings.getActionCodeURL = vm.getActionCodeMapURL;
            }
            if(!oSettings.actionIconMap){
                oSettings.actionIconMap = MaterialManager.getActionCodeIconMap();
            }
            return oSettings;
        },


        validateSave: function () {
            var vm = this;
            return ServiceValidatorHelper.defaultValidateCheckArray({
                messageContainer: '.main.message-container',
                configList: [{
                    errorMessagePrefix: vm.label.id,
                    validType: {
                        defType: ServiceValidatorHelper.DEF_VALID_TYPE.NON_EMPTY
                    },
                    context: 'planExecutionDate',
                    value: vm.content.materialUIModel.id
                }]
            });
        },

        validateApprove: function(){

        },


        revokeSubmitService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.revokeSubmitWarnTitle,
                warnText:vm.label.actionNode.revokeSubmitWarnText,
                actionCode:MaterialManager.DOC_ACTION_CODE.REVOKE_SUBMIT
            }));
        },

        submitService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.submitWarnTitle,
                warnText:vm.label.actionNode.submitWarnText,
                preValidate:vm.validateSave,
                actionCode:MaterialManager.DOC_ACTION_CODE.SUBMIT
            }));
        },


        rejectApproveService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.rejectApproveWarnTitle,
                warnText:vm.label.actionNode.rejectApproveWarnText,
                preValidate:vm.validateSave,
                actionCode:MaterialManager.DOC_ACTION_CODE.REJECT_APPROVE
            }));
        },

        approveService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.approveWarnTitle,
                warnText:vm.label.actionNode.approveWarnText,
                preValidate:vm.validateSave,
                actionCode:MaterialManager.DOC_ACTION_CODE.APPROVE
            }));
        },

        activeService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.activeWarnTitle,
                warnText:vm.label.activeWarnMessage,
                preValidate:vm.validateSave,
                actionCode:MaterialManager.DOC_ACTION_CODE.ACTIVE
            }));
        },

        reInitService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.approveWarnTitle,
                warnText:vm.label.actionNode.approveWarnText,
                preValidate:vm.validateSave,
                actionCode:MaterialManager.DOC_ACTION_CODE.REINIT
            }));
        },

        initSelectConfigure: function () {
            var vm = this;
            MaterialManager.initDefSelectConfigure({
                'vm':vm,
                'uiModel': vm.content.materialUIModel
            });

            $(vm.eleRefMainMaterialUnit).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.materialUIModel, 'mainMaterialUnit', $(vm.eleRefMainMaterialUnit).val());
            });

            $(vm.eleMainMaterialUnitName).on('typeahead:selected', function (evt, item) {
                vm.$set(vm.content.materialUIModel, 'mainMaterialUnitName', item.text);
                vm.$set(vm.content.materialUIModel, 'mainMaterialUnit', item.id);
            });
        },

        errorHandle: function(oData){
            this.$refs.refBusyLoader.hideBusyLoading();
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            vm.$refs.refBusyLoader.showBusyLoading();
            if (processMode === PROCESSMODE_NEW) {
                // in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                var refMaterialType = getUrlVar('refMaterialType');
                var requestData = refMaterialType? {baseUUID: refMaterialType}:{};
                var url = refMaterialType? this.newModuleFromTypeURL:this.newModuleServiceURL;
                ServiceUtilityHelper.httpRequest({
                    url: url,
                    $http: vm.$http,
                    requestData: requestData,
                    errorHandle: vm.errorHandle,
                    postHandle: function (oData) {
                        vm.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if (processMode === PROCESSMODE_EDIT) {
                // In case [Edit mode]
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    initAuthor: function(author){vm.$set(vm, 'author', author);},
                    $http:vm.$http,
                    errorHandle:vm.errorHandle,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }
        },

        saveModule: function () {
            var vm = this;
            ServiceUtilityHelper.defSaveModuleWrapper({
                vm: vm,
                editorPage: "MaterialEditor.html",
                fnGetBaseUUID: function (){
                    return vm.content.materialUIModel.uuid;
                }
            });
        },


        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.materialUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);
        },

        formatMaterialCategory: function(materialCategory){
            return MaterialManager.formatMaterialCategoryIconClass(materialCategory);
        },

        loadMainMaterialUnitSelectList: function () {
            var vm = this;
            return ServiceUtilityHelper.loadTypeAheadRequest({
                url: vm.loadStandardUnitSelectListURL,
                $http: vm.$http,
                errorHandle: vm.errorHandle,
                element: vm.eleMainMaterialUnitName
            });
        },

        formatOperationMode: function(operationMode){
            var $element = ServiceUtilityHelper.formatSelectWithIcon(operationMode, MaterialUtility.getOperationMode(), true);
            return $element;
        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.materialUIModel.uuid;
            window.location.href = genCommonEditURL("MaterialEditor.html", baseUUID, tabKey);
        },

        openRightSideBar: function(key){
            NavigationPanelIns.openRightSideBar(RightBarTemplate.TABS.tab2, key);
        },

        loadMaterialSKUList: function(baseUUID){
            var vm = this;
            var postUrl = '../materialStockKeepUnit/searchModuleService.html';
            var requestData = {refMaterialUUID:baseUUID};
            ServiceUtilityHelper.httpRequest({
                url:postUrl,
                method:'post',
                requestData: requestData,
                $http:vm.$http,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault,
                postHandle:function(oData){
                    vm.$set(vm.cache, 'materialStockKeepList', oData.content);
                    setTimeout(function () {
                        vm.materialSKUTable.build();
                    }.bind(this), 0);
                }.bind(this)
            });
        },

        initUnitTable: function () {
            var vm = this;
            this.materialUnitTable = new ServiceDataTable(this.materialUnitTableId);
            ServiceUtilityHelper.initTableSelect({
                parentTable: vm.materialUnitTableId
            });
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'materialUIModel', content.materialUIModel);
            vm.$set(vm.content, 'materialUnitUIModelList', content.materialUnitUIModelList);
            vm.$set(vm.content, 'materialAttachmentUIModelList', content.materialAttachmentUIModelList);
            MaterialManager.loadDefaultMetaBatch({
                'vm': vm,
                'uiModel':vm.content.materialUIModel,
                'rightBar': rightBar,
                'callback':function(){
                    rightBar.initHelpDocumentList(vm.content.materialUIModel.uuid);
                }
            });
            vm.loadMainMaterialUnitSelectList(content);
            vm.$refs.refBusyLoader.hideBusyLoading();
            vm.loadMaterialSKUList(content.materialUIModel.uuid);
        },

        openExcelUploadModal: function () {
            $("#x_uploadExcelModal").modal('toggle');
        },

        editMaterialUnitModal: function (uuid, $event) {
            var vm = this;
            vm.$refs.materialUnitPanel.loadPanel({
                baseUUID: uuid,
                processMode: PROCESSMODE_EDIT,
                errorHandle: vm.errorHandle,
                $event: $event,
                compensateSection: vm.$refs.popPanelCompSection,
                promiseAllCallback: function () {
                    if (rightBar) {
                        rightBar.initHelpDocumentList(vm.content.materialUIModel.uuid);
                    }
                },
                postRefreshContent: vm.refreshContent,
                postRefresh: function () {
                    vm.refreshEditView(MaterialManager.documentTab.materialUnitSection);
                }
            });
        },


        addMaterialUnit: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.parentNodeUUID = this.content.materialUIModel.uuid;
            var resultURL = "MaterialUnitEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },
        /**
         * Deprecated
         * @param baseUUID
         */
        newMaterialUnitModal: function () {
            var vm = this;
            vm.$refs.materialUnitPanel.loadPanel({
                baseUUID: vm.content.materialUIModel.uuid,
                processMode: PROCESSMODE_NEW,
                compensateSection: vm.$refs.popPanelCompSection,
                postRefreshContent: vm.refreshContent,
                postRefresh: function () {
                    vm.refreshEditView(MaterialManager.documentTab.materialSection);
                }
            });
        },

        refreshContent: function () {
            var vm = this;
            var baseUUID = this.content.materialUIModel.uuid;
            ServiceUtilityHelper.loadEditModuleDefault({
                editUrl: this.loadModuleEditURL,
                viewUrl: this.loadModuleViewURL,
                messageContainer: $('.main.message-container'),
                uuid: baseUUID,
                author: vm.author,
                $http: vm.$http,
                errorHandle: vm.errorHandle,
                postSet: vm.setModuleToUI
            });
        },

        addMaterialSKU: function(){
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.materialUIModel.uuid;
            var resultURL = "MaterialStockKeepUnitEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        editMaterialSKU: function(uuid){
            var vm = this;
            var preLockSKUURL = '../materialStockKeepUnit/preLockService.html';
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                $http:vm.$http,
                author:vm.author,
                editorPage:"MaterialStockKeepUnitEditor.html",
                preLockURL: preLockSKUURL,
                forceNewWindow: true,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        editMaterialUnit: function (uuid) {
            window.location.href = genCommonEditURL("MaterialUnitEditor.html", uuid);
        }

    }
});
