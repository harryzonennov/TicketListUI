var dataVar = new Vue({
    el: "#x_data",
    mixins:[PricingSettingManager.labelTemplate],
    data: {
        currencyconfigureTableId: '#x_table_currencyconfigure',
        currencyconfigureTable: {},
        label: PricingSettingManager.label.pricingSetting,
        content: {
            pricingSettingUIModel: {
                uuid: '',
                client: '',
                id: '',
                name: '',
                defaultTaxRate: '',
                multiCurrencyFlag: '',
                defCurrencyCode: '',
                note: ''
            },
            pricingCurrencyConfigureUIModelList: []
        },
        author:{
            resourceId:'PricingSetting',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        cache: {
            pricingCurrencyConfigure: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                id: '',
                name: '',
                currencyCode: '',
                defaultCurrency:'',
                activeFlag:'',
                exchangeRate: '',
                note: ''
            }
        },
        processButtonMeta:[],
        loadModuleEditURL: '../pricingSetting/loadModuleEditService.html',
        saveModuleURL: '../pricingSetting/saveModuleService.html',
        newModuleServiceURL: '../pricingSetting/newModuleService.html',
        newPricingCurrencyConfigureServiceURL: '../pricingCurrencyConfigure/newModuleService.html',
        eleEditPricingCurrencyConfigureModal: '#x_eleEditPricingCurrencyConfigureModal',
        exitURL: 'PricingSettingList.html',
        exitModuleURL: '../pricingSetting/exitEditor.html'
    },

    created: function(){
        var vm = this;
        vm.initAuthorResourceCheck();
        vm.initSubComponents();
    },

    mounted: function () {
        var vm = this;
        NavigationPanelIns.initNavigation('systemAdmin', 'PricingSetting');
        this.setI18nProperties(vm.initProcessButtonMeta);
        this.loadModuleEdit();
        this.currencyconfigureTable = new ServiceDataTable(this.currencyconfigureTableId);
    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        editPricingCurrencyConfigureModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.pricingCurrencyConfigureUIModelList);
            if (!item) {
                return;
            }
            this.cache.pricingCurrencyConfigure = this.copyPricingCurrencyConfigure(item);
            $(this.eleEditPricingCurrencyConfigureModal).modal('toggle');
        },

        setToPricingCurrencyConfigure: function () {
            var item = this._filterItemByUUID(this.cache.pricingCurrencyConfigure.uuid, this.content.pricingCurrencyConfigureUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copyPricingCurrencyConfigure(this.cache.pricingCurrencyConfigure);
                this.content.pricingCurrencyConfigureUIModelList.push(newItem);
            } else {
                this.copyPricingCurrencyConfigure(this.cache.pricingCurrencyConfigure, item);
            }
            $(this.eleEditPricingCurrencyConfigureModal).modal('hide');
        },

        newPricingCurrencyConfigureModal: function () {
            var vm = this;
            var baseUUID = vm.content.pricingSettingUIModel.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            this.$http.post(this.newPricingCurrencyConfigureServiceURL, requestData).then(function (response) {
                if (!JSON.parse(response.data).content) {
                    swal({
                        title: this.label.msgConnectFailure,
                        text: this.label.msgLoadDataFailure,
                        type: "error",
                        confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                        cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                        confirmButtonText: this.label.confirm
                    });
                    return;
                }
// In case success.
                this.cache.pricingCurrencyConfigure = this.copyPricingCurrencyConfigure(JSON.parse(response.data).content, this.cache.pricingCurrencyConfigure);
                $(this.eleEditPricingCurrencyConfigureModal).modal('toggle');
            });

        },

        addPricingCurrencyConfigure: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = content.uuid;
            var resultURL = "PricingCurrencyConfigureEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        editPricingCurrencyConfigure: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            window.location.href = genCommonEditURL("PricingCurrencyConfigureEditor.html", uuid);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nCurrencyConfigureProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.pricingCurrencyConfigure, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'PricingSetting',
                    callback: this.setNodeI18nPropertiesCore
                }, {
                    name: 'PricingCurrencyConfigure',
                    callback: this.setI18nCurrencyConfigureProperties
                }]
            });
        },


        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            if (processMode === PROCESSMODE_NEW) {
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                ServiceUtilityHelper.httpRequest({
                    url:this.newModuleServiceURL,
                    $http:vm.$http,
                    method:'post',
                    requestData: requestData,
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        this.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if (processMode === PROCESSMODE_EDIT) {
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    errorHandle:vm.errorHandle,
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }
        },

        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }
        },

        copyPricingCurrencyConfigure: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.currencyCode = origin.currencyCode;
            target.exchangeRate = origin.exchangeRate;
            target.note = origin.note;
            return target;

        },

        saveModule: function () {
            var vm = this;
            ServiceUtilityHelper.defSaveModuleWrapper({
                vm: vm,
                editorPage: "SerialNumberSettingEditor.html",
                fnGetBaseUUID: function (){
                    return vm.content.uuid;
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.pricingSettingUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);

        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.pricingSettingUIModel.uuid;
            window.location.href = genCommonEditURL("PricingSettingEditor.html", baseUUID, tabKey);
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'pricingSettingUIModel', content.pricingSettingUIModel);
            var formatConfigureList = content.pricingCurrencyConfigureUIModelList;
            vm.$set(vm.content, 'pricingCurrencyConfigureUIModelList', formatConfigureList);

        }

    }
});
