/**
 * Document manager factory
 * Should based on ["PurchaseContractManager", "SalesContractManager"]
 */

var DocumentManagerFactory = {};

var _instance,
    docI18nArray = [],
    _cache = [],
    documentMetaData = {};


DocumentManagerFactory.getDocumentManagerFromCache = function (docType) {
    "use strict";
    if (!_cache || _cache.length === 0) {
        return;
    }
    var i;
    for (i = 0; i < _cache.length; i++) {
        if (_cache[i].docType === docType) {
            return _cache[i].instance;
        }
    }
};

/**
 * Main Entry to init/get Document meta data by multiple document types.
 * @param documentTypes
 * @param fnCallback
 */
DocumentManagerFactory.initDocumentMetaDataArray = function (documentTypes, fnCallback) {
    var promiseList = [];
    for (var i = 0; i < documentTypes.length; i++) {
        var docType = documentTypes[i];
        promiseList.push(DocumentManagerFactory.initDocumentMetaDataUnion(docType));
    }
    Promise.all(promiseList).then(function (resultList) {
        if (resultList && resultList.length > 0) {
            for (var j = 0; j < resultList.length; j++) {
                documentMetaData[resultList[j].docType] = resultList[j];
            }
        }
        if (fnCallback && typeof  fnCallback === 'function') {
            fnCallback(documentMetaData);
        }
    });
};

/**
 * Init/get document metadata by document type
 * @param docType
 * @returns {Promise$2|*}
 */
DocumentManagerFactory.initDocumentMetaDataUnion = function (docType) {
    var promise = new Promise(function (resolve, reject) {
        var documentMananger = DocumentManagerFactory.getDocumentManager(docType);
        if (documentMananger) {
            // Init docMetaData
            var docMetaData = documentMetaData[docType];
            if (docMetaData) {
                docMetaData.documentManager = documentMananger;
            } else {
                docMetaData = {
                    docType: docType,
                    documentManager: documentMananger
                };
            }
            /*
             * Get or initialize 'statusMetaArray' for this docMetaData
             */
            if (docMetaData.statusMetaArray && docMetaData.statusMetaArray.length > 0) {
                resolve(docMetaData);
            } else {
                var promiseStatus = DocumentManagerFactory.initStatusMetaData(docMetaData);
                promiseStatus.then(function (oData) {
                    resolve(oData);
                }).catch(function (error) {
                    resolve({docType: docMetaData});
                });
            }
            // Initilize Status Icon for each status
            DocumentManagerFactory.initStatusIconArray(docMetaData);
        }
    });
    return promise;
};

/**
 * Using ajax request to get each document's [Status] metadata
 * 'getStatusURL' should be defined in each document Manager
 * @param {Object} docMetaData
 *               -- {Object} documentManager: document manager instance
 * @returns {Promise$2|*}
 */
DocumentManagerFactory.initStatusMetaData = function (docMetaData) {
    return new Promise(function (resolve, reject) {
        if (!docMetaData.documentManager.getStatusURL) {
            // In case not 'getStatusURL' for manager, just return
            resolve(docMetaData);
        }
        $.ajax({
            url: docMetaData.documentManager.getStatusURL(),
            dataType: "json",
            type: "get",
            success:function(oData){
                docMetaData.statusMetaArray = oData;
                resolve(docMetaData);
            },
            error:function(){
                reject();
            }
        });
    });
};

/**
 * Common interface to return manager's getStatus icon array
 * 'getStatusIconArray' method should be defined for each document manager
 * @param docMetaData
 */
DocumentManagerFactory.initStatusIconArray = function (docMetaData) {
    docMetaData.statusIconArray = docMetaData.documentManager.getStatusIconArray? docMetaData.documentManager.getStatusIconArray():undefined;
};


DocumentManagerFactory.getDocumentTypeIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.DocumentType.INQUIRY, iconClass: 'md md-subject content-orange'},
        {id: DocumentConstants.DocumentType.PURCHASECONTRACT, iconClass: 'nmd nmd-shopping-cart content-orange'},
        {id: DocumentConstants.DocumentType.SALESCONTRACT, iconClass:'md md-assignment content-green'},
        {id: DocumentConstants.DocumentType.BIDDINGINVITATIONORDER, iconClass: 'nmd nmd-gavel content-darkblue1'},
        {id: DocumentConstants.DocumentType.INVENTORY_CHECKORDER, iconClass: 'md md-assignment-turned-in content-green'},
        {id: DocumentConstants.DocumentType.OUTBOUNDDELIVERY, iconClass: 'md md-file-upload content-orange'},
        {id: DocumentConstants.DocumentType.INVENTORY_TRANSFER, iconClass: 'md md-repeat content-lightblue'},
        {id: DocumentConstants.DocumentType.WAREHOUSESTOREITEM, iconClass: 'md md-now-widgets content-lightblue'},
        {id: DocumentConstants.DocumentType.INBOUNDDELIVERY, iconClass: 'md md-file-download content-green'},
        {id: DocumentConstants.DocumentType.PRODUCTIONORDER, iconClass: 'ion-wrench content-pink'},
        {id: DocumentConstants.DocumentType.PRODUCTORDERITEM, iconClass: 'md md-format-align-left content-orange'},
        {id: DocumentConstants.DocumentType.PRODUCTPLANITEM, iconClass: 'md md-format-align-left content-green'},
        {id: DocumentConstants.DocumentType.PRODUCTIONPLAN, iconClass: 'md md-event-available content-green'},
        {id: DocumentConstants.DocumentType.PRODPICKINGORDER, iconClass:'ion-clipboard content-green'},
        {id: DocumentConstants.DocumentType.PRODRETURNORDER, iconClass:'ion-arrow-return-left content-green'},
        {id: DocumentConstants.DocumentType.PRODORDERREPORT, iconClass:'fa fa-flag-checkered content-green'},
        {id: DocumentConstants.DocumentType.QUALITYINSPECTORDER, iconClass:'md md-straighten content-lightblue'},
        {id: DocumentConstants.DocumentType.SALESRETURNORDER, iconClass:'nmd nmd-rotate-left content-peach-red'},
        {id: DocumentConstants.DocumentType.SALESFORCAST, iconClass:'nmd nmd-av-timer content-lightblue'},
        {id: DocumentConstants.DocumentType.PURCHASEREQUEST, iconClass:'nmd nmd-add-shopping-cart content-green'},
        {id: DocumentConstants.DocumentType.PURCHASERETURNORDER, iconClass:'nmd nmd-remove-shopping-cart content-pink'},
        {id: DocumentConstants.DocumentType.RECEIPT, iconClass: 'md md-receipt content-green'},
        {id: DocumentConstants.DocumentType.VOUCHER, iconClass: 'md md-receipt content-orange'},
        {id: DocumentConstants.DocumentType.BILLOFMATERIALTEMPLATE, iconClass: 'fa fa-gears content-green'},
        {id: DocumentConstants.DocumentType.BILLOFMATERIALORDER, iconClass: 'fa fa-gears content-orange'},
        {id: DocumentConstants.DocumentType.WASTEPROCESSORDER, iconClass: 'nmd nmd-delete-forever content-red'},
        {id: DocumentConstants.DocumentType.REPAIRPRODORDER, iconClass: 'fa fa-stethoscope content-red'},
        {id: DocumentConstants.DocumentType.REPAIRPRODORDERITEM, iconClass: 'fa fa-medkit content-red'},
        {id: DocumentConstants.DummyDocumentType.PRODUCTIONORDER_ITEM, iconClass: 'md md-format-align-left content-orange'},
        {id: DocumentConstants.DummyDocumentType.MaterialStockKeepUnit, iconClass: 'md md-texture content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.Material, iconClass: 'md md-texture content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.MaterialType, iconClass: 'md md-texture content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.MaterialConfigureTemplate, iconClass: 'md md-texture content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.RegisteredProduct, iconClass: 'md md-texture content-linkblue'},
        {id: DocumentConstants.DummyDocumentType.CorporateCustomer, iconClass: 'md md-contacts content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.IndividualCustomer, iconClass: 'md md-nature-people content-green'},
        {id: DocumentConstants.DummyDocumentType.CorporateSupplier, iconClass: 'md md-contacts content-orange'},
        {id: DocumentConstants.DummyDocumentType.Organization, iconClass: 'fa fa-building-o content-green'},
        {id: DocumentConstants.DummyDocumentType.Employee, iconClass: 'fa fa-male content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.ExternalDriver, iconClass:'md md-local-shipping content-green'},
        {id: DocumentConstants.DummyDocumentType.LogonUser, iconClass: 'md md-contacts content-darkblue'},
        {id: DocumentConstants.DummyDocumentType.TransitPartner, iconClass: 'md md-directions-train'},
        {id: DocumentConstants.DummyDocumentType.FinAccount, iconClass: 'md md-attach-money content-orange'},
        {id: DocumentConstants.DummyDocumentType.FinAccountTitle, iconClass: 'md md-texture content-linkblue'},
        {id: DocumentConstants.DummyDocumentType.ProdWorkCenter, iconClass: 'fa fa-industry content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.Warehouse, iconClass: 'md md-store content-green'},
        {id: DocumentConstants.DummyDocumentType.Role, iconClass: 'fa fa-puzzle-piece content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.AuthorizationObject, iconClass: 'fa fa-puzzle-piece content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.AuthorizationGroup, iconClass: 'md md-group-work content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.MessageTemplate, iconClass: 'md md-chat content-green'},
        {id: DocumentConstants.DummyDocumentType.ServiceFlowModel, iconClass: 'nmd nmd-playlist-add-check content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.ServiceDocumentSetting, iconClass: 'nmd nmd-playlist-add-check content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.FlowRouter, iconClass: 'md md-call-split content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.SystemExecutorSetting, iconClass: 'md md-settings-power content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.WorkCalendar, iconClass: 'md md-call-split content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.CalendarTemplate, iconClass: 'md md-call-split content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.SerialNumberSetting, iconClass: 'md md-format-color-text content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.PricingSetting, iconClass: 'fa fa-gear content-lightblue'},
        {id: DocumentConstants.DummyDocumentType.SystemCodeValueCollection, iconClass: 'fa fa-gears content-portlet-title'}
    ];
};

DocumentManagerFactory.formatDocTypeIconClass = function (documentType) {
    "use strict";
    var documentTypeIconArray = DocumentManagerFactory.getDocumentTypeIconArray();
    var $element = ServiceCollectionsHelper.filterArray(documentType, 'id', documentTypeIconArray);
    if($element && $element.iconClass){
        return $element.iconClass;
    }
};

DocumentManagerFactory.formatDocumentType = function (docType) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(docType, DocumentManagerFactory.getDocumentTypeIconArray(), true);
    return $element;
};

DocumentManagerFactory.deefStatusIcon = {

};

DocumentManagerFactory.getDefStatusIconArray = function () {
    "use strict";
    return [
        {id: DocumentContentProp.status.INITIAL, iconClass: 'md md-remove-circle-outline content-grey'},
        {id: DocumentContentProp.status.SUBMITTED, iconClass: 'nmd nmd-format-color-text content-orange'},
        {id: DocumentContentProp.status.REVOKE_SUBMIT, iconClass: 'nmd nmd-do-not-disturb-off content-orange'},
        {id: DocumentContentProp.status.REJECT_APPROVAL, iconClass: 'nmd nmd-gavel content-darkblue1'},
        {id: DocumentContentProp.status.ARCHIVED, iconClass: 'nmd nmd-sd-storage content-grey'},
        {id: DocumentContentProp.status.CANCELED, iconClass: 'nmd nmd-delete-forever content-grey'}
    ];
};

DocumentManagerFactory.formatDefStatusClass = function (status) {
    "use strict";
    var statusIconArray = DocumentManagerFactory.getDefStatusIconArray();
    var $element = ServiceCollectionsHelper.filterArray(status, 'id', statusIconArray);
    if($element && $element.iconClass){
        return $element.iconClass;
    }
};

DocumentManagerFactory.formatDefStatus = function (status) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(status, DocumentManagerFactory.getDefStatusIconArray(), true);
    return $element;
};

/**
 * Return the class to show element or not
 * @param id: key flag for show element or not
 * @returns {*}
 */
DocumentManagerFactory.formatDisplayClass = function (displayFlag) {
    "use strict";
    if(displayFlag){
        return DocumentManagerFactory.DISPLAY_CLASS.DISPLAY;
    }else{
        return DocumentManagerFactory.DISPLAY_CLASS.HIDE;
    }
};

DocumentManagerFactory.DISPLAY_CLASS = {
    DISPLAY: "hold-display",
    HIDE:"hide-display"
};

/**
 * Return the class to show element or not by checking the property equals true
 * @param id: key flag for show element or not
 * @returns {*}
 */
DocumentManagerFactory.formatDisplayTrueProperty = function (property) {
    "use strict";
    if( property && property === true ){
        return DocumentManagerFactory.formatDisplayClass(true);
    }else{
        return DocumentManagerFactory.formatDisplayClass();
    }
};


/**
 * Return the class to show element or not by checking the property equals true
 * @param id: key flag for show element or not
 * @returns {*}
 */
DocumentManagerFactory.formatDisplayNotTrueProperty = function (property) {
    "use strict";
    if( property && property === true ){
        return DocumentManagerFactory.formatDisplayClass();
    }else{
        return DocumentManagerFactory.formatDisplayClass(true);
    }
};


DocumentManagerFactory.getDocumentI18nPromise = function (refSEName, refNodeName) {
    "use strict";
    return new Promise(function (resolve, reject) {
        var i18nConfigure = DocumentManagerFactory.getDocumentI18nConfigure(refSEName, refNodeName);
        if (!i18nConfigure) {
            reject({"error": "no i18n configured"});
        }
        jQuery.i18n.properties({
            name: i18nConfigure.name, //properties file name
            path: i18nConfigure.path,
            mode: 'map', //Using map mode to consume properties files
            language: getLan(),
            cache:true,
            callback: function (oResult) {
                if ($.i18n) {
                    resolve($.i18n);
                } else {
                    reject({"error": "no i18n configured"});
                }
            }.bind(this)
        });
    });

};

DocumentManagerFactory.getDocumentI18nConfigure = function (refSEName, refNodeName) {
    "use strict";
    if (!refSEName || !refNodeName) {
        return undefined;
    }
    if (refSEName === 'BidInvitationOrder' && refNodeName === 'ROOT') {
        return DocumentManagerFactory.handleDefaultI18nUnion('BidInvitationOrder', "coreFunction/");
    }
    if (refSEName === 'BidInvitationOrder' && refNodeName === 'BidMaterialItem') {
        return DocumentManagerFactory.handleDefaultI18nUnion('BidMaterialItem', "coreFunction/");
    }
    if (refSEName === 'InboundDelivery' && refNodeName === 'ROOT') {
        return DocumentManagerFactory.handleDefaultI18nUnion('InboundDelivery', "coreFunction/");
    }
    if (refSEName === 'InboundDelivery' && refNodeName === 'InboundItemReference') {
        return DocumentManagerFactory.handleDefaultI18nUnion('InboundItem', "coreFunction/");
    }
    if (refSEName === 'OutboundDelivery' && refNodeName === 'ROOT') {
        return DocumentManagerFactory.handleDefaultI18nUnion('OutboundDelivery', "coreFunction/");
    }
    if (refSEName === 'OutboundDelivery' && refNodeName === 'OutboundItemReference') {
        return DocumentManagerFactory.handleDefaultI18nUnion('OutboundItem', "coreFunction/");
    }

};

DocumentManagerFactory.handleDefaultI18nUnion = function (key, subPath) {
    "use strict";
    var i18nUnion = ServiceCollectionsHelper.filterArray(key, 'name', docI18nArray);
    if (i18nUnion) {
        return i18nUnion;
    }
    i18nUnion = {
        name: key, //properties file name
        path: getI18nRootPath() + subPath
    };
    docI18nArray.push(i18nUnion);
    return i18nUnion;
};


DocumentManagerFactory.getDocumentManagerDef = function (docType) {
    if (!docType || docType === 0) {
        return;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PURCHASECONTRACT) {
        return PurchaseContractManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PRODUCTIONORDER) {
        return ProductionOrderManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PRODUCTIONPLAN) {
        return ProductionPlanManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.SALESCONTRACT) {
        return SalesContractManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.SALESFORCAST) {
        return SalesForcastManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PURCHASEREQUEST) {
        return PurchaseRequestManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PURCHASERETURNORDER) {
        return PurchaseReturnOrderManager;
    }
    if (docType  * 1 === DocumentConstants.DocumentType.SALESRETURNORDER) {
        return SalesReturnOrderManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.BIDDINGINVITATIONORDER) {
        return BidInvitationOrderManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.INQUIRY) {
        return InquiryManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.INBOUNDDELIVERY) {
        return InboundDeliveryManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.OUTBOUNDDELIVERY) {
        return OutboundDeliveryManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PRODPICKINGORDER) {
        return ProdPickingOrderManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PRODRETURNORDER) {
        return ProdReturnOrderManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PRODORDERREPORT) {
        return ProdOrderReportManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.INVENTORY_TRANSFER) {
        return InventoryTransferOrderManager;
    }
    if (docType  * 1 === DocumentConstants.DocumentType.INVENTORY_CHECKORDER) {
        return InventoryCheckOrderManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.WAREHOUSESTOREITEM) {
        return WarehouseStoreManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PRODUCTORDERITEM) {
        return ProductionOrderItemManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PRODUCTPLANITEM) {
        return ProductionPlanItemManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.QUALITYINSPECTORDER) {
        return QualityInspectOrderManager;
    }
    if (docType * 1 === ServiceModuleConstants.WarehouseStoreItem) {
        return WarehouseStoreManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.BILLOFMATERIALORDER) {
        return BillOfMaterialManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.BILLOFMATERIALTEMPLATE) {
        return BillOfMaterialTemplateManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.WASTEPROCESSORDER) {
        return WasteProcessOrderManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.REPAIRPRODORDER) {
        return RepairProdOrderManager;
    }
    if (docType * 1 === DocumentConstants.DocumentType.REPAIRPRODORDERITEM) {
        return RepairProdOrderItemManager;
    }
    if (docType * 1 === DocumentConstants.DummyDocumentType.FinAccountTitle) {
        return FinAccountTitleManager;
    }
    if ( docType === DocumentConstants.DummyDocumentType.SystemCodeValueCollection){
        return SystemCodeValueManager;
    }
    if ( docType === DocumentConstants.DummyDocumentType.StandardMaterialUnit){
        return StandardMaterialUnitManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.FinAccount) {
        return FinAccountManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.MaterialStockKeepUnit) {
        return MaterialStockKeepUnitManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.MaterialType) {
        return MaterialTypeManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.RegisteredProduct) {
        return RegisteredProductManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.MaterialConfigureTemplate) {
        return MaterialConfigureTemplateManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.CorporateCustomer) {
        return CorporateCustomerManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.IndividualCustomer) {
        return IndividualCustomerManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.CorporateSupplier) {
        return CorporateSupplierManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.Employee) {
        return EmployeeManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.Organization) {
        return OrganizationManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.ProdWorkCenter) {
        return ProdWorkCenterManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.Warehouse) {
        return WarehouseManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.MessageTemplate) {
        return MessageTemplateManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.SerialNumberSetting) {
        return SerialNumberSettingManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.PricingSetting) {
        return PricingSettingManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.Role) {
        return RoleManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.AuthorizationGroup) {
        return AuthorizationGroupManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.AuthorizationObject) {
        return AuthorizationObjectManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.ServiceFlowModel) {
        return ServiceFlowModelManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.ServiceDocumentSetting) {
        return ServiceDocumentSettingManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.FlowRouter) {
        return FlowRouterManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.CalendarTemplate) {
        return CalendarTemplateManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.SystemExecutorSetting) {
        return SystemExecutorSettingManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.ServiceExtensionSetting) {
        return ServiceExtensionSettingManager;
    }
    if (docType === DocumentConstants.DummyDocumentType.SerExtendPageSetting) {
        return SerExtendPageSettingManager;
    }

};

DocumentManagerFactory.getDocumentManager = function (docType) {
    if (!docType || docType === 0) {
        return;
    }
    var _instance = DocumentManagerFactory.getDocumentManagerFromCache(docType);
    if (_instance) {
        return _instance;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PURCHASECONTRACT) {
        _instance = new PurchaseContractManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PRODUCTIONORDER) {
        _instance = new ProductionOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType * 1 === DocumentConstants.DocumentType.PRODUCTIONPLAN) {
        _instance = new ProductionPlanManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType * 1 === DocumentConstants.DocumentType.SALESCONTRACT) {
        _instance = new SalesContractManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType * 1 === DocumentConstants.DocumentType.SALESFORCAST) {
        _instance = new SalesForcastManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType * 1 === DocumentConstants.DocumentType.PURCHASEREQUEST) {
        _instance = new PurchaseRequestManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType * 1 === DocumentConstants.DocumentType.PURCHASERETURNORDER) {
        _instance = new PurchaseReturnOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }


    if (docType  * 1 === DocumentConstants.DocumentType.SALESRETURNORDER) {
        _instance = new SalesReturnOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType * 1 === DocumentConstants.DocumentType.BIDDINGINVITATIONORDER) {
        _instance = new BidInvitationOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType * 1 === DocumentConstants.DocumentType.INQUIRY) {
        _instance = new InquiryManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType * 1 === DocumentConstants.DocumentType.INBOUNDDELIVERY) {
        _instance = new InboundDeliveryManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType * 1 === DocumentConstants.DocumentType.OUTBOUNDDELIVERY) {
        _instance = new OutboundDeliveryManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType * 1 === DocumentConstants.DocumentType.PRODPICKINGORDER) {
        _instance = new ProdPickingOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType * 1 === DocumentConstants.DocumentType.PRODRETURNORDER) {
        _instance = new ProdReturnOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType * 1 === DocumentConstants.DocumentType.PRODORDERREPORT) {
        _instance = new ProdOrderReportManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType * 1 === DocumentConstants.DocumentType.INVENTORY_TRANSFER) {
        _instance = new InventoryTransferOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType  * 1 === DocumentConstants.DocumentType.INVENTORY_CHECKORDER) {
        _instance = new InventoryCheckOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType * 1 === DocumentConstants.DocumentType.WAREHOUSESTOREITEM) {
        _instance = new WarehouseStoreManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType * 1 === DocumentConstants.DocumentType.PRODUCTORDERITEM) {
        _instance = new ProductionOrderItemManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }


    if (docType * 1 === DocumentConstants.DocumentType.PRODUCTPLANITEM) {
        _instance = new ProductionPlanItemManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType * 1 === DocumentConstants.DocumentType.QUALITYINSPECTORDER) {
        _instance = new QualityInspectOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType  === ServiceModuleConstants.WarehouseStoreItem) {
        _instance = new WarehouseStoreManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType  === ServiceModuleConstants.WasteProcessOrder) {
        _instance = new WasteProcessOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DocumentType.BILLOFMATERIALORDER) {
        _instance = new BillOfMaterialManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType === DocumentConstants.DocumentType.BILLOFMATERIALTEMPLATE) {
        _instance = new BillOfMaterialTemplateManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType * 1 === DocumentConstants.DocumentType.WASTEPROCESSORDER) {
        _instance = new WasteProcessOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DocumentType.REPAIRPRODORDER) {
        _instance = new RepairProdOrderManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DocumentType.REPAIRPRODORDERITEM) {
        _instance = new RepairProdOrderItemManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.FinAccountTitle) {
        _instance = new FinAccountTitleManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.FinAccount) {
        _instance = new FinAccountManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.MaterialStockKeepUnit) {
        _instance = new MaterialStockKeepUnitManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType === DocumentConstants.DummyDocumentType.Material) {
        _instance = new MaterialManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.MaterialType) {
        _instance = new MaterialTypeManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType === DocumentConstants.DummyDocumentType.MaterialConfigureTemplate) {
        _instance = new MaterialConfigureTemplateManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.RegisteredProduct) {
        _instance = new RegisteredProductManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.CorporateCustomer) {
        _instance = new CorporateCustomerManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.IndividualCustomer) {
        _instance = new IndividualCustomerManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.CorporateSupplier) {
        _instance = new CorporateSupplierManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.Employee) {
        _instance = new EmployeeManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.LogonUser) {
        _instance = new LogonUserManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.Organization) {
        _instance = new OrganizationManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.ProdWorkCenter) {
        _instance = new ProdWorkCenterManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }


    if ( docType === DocumentConstants.DummyDocumentType.SystemCodeValueCollection){
        _instance = new SystemCodeValueManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if ( docType === DocumentConstants.DummyDocumentType.StandardMaterialUnit){
        _instance = new StandardMaterialUnitManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.Warehouse) {
        _instance = new WarehouseManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.MessageTemplate) {
        _instance = new MessageTemplateManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.SerialNumberSetting) {
        _instance = new SerialNumberSettingManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType === DocumentConstants.DummyDocumentType.PricingSetting) {
        _instance = new PricingSettingManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.Role) {
        _instance = new RoleManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.ServiceFlowModel) {
        _instance = new ServiceFlowModelManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType === DocumentConstants.DummyDocumentType.ServiceDocumentSetting) {
        _instance = new ServiceDocumentSettingManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType === DocumentConstants.DummyDocumentType.FlowRouter) {
        _instance = new FlowRouterManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
    if (docType === DocumentConstants.DummyDocumentType.CalendarTemplate) {
        _instance = new CalendarTemplateManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.AuthorizationGroup) {
        _instance = new AuthorizationGroupManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.AuthorizationObject) {
        _instance = new AuthorizationObjectManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }

    if (docType === DocumentConstants.DummyDocumentType.SystemExecutorSetting) {
        _instance = new SystemExecutorSettingManager();
        _cache.push({docType: docType, instance: _instance});
        return _instance;
    }
};

/**
 *
 * @param oSettings
 *   --{Vue} vm: vue instance from DocumentOrderMatPopInfo
 */
DocumentManagerFactory.getItemModelTitleWrap = function (oSettings){
    var vm = oSettings.vm;
    var managerInstance = oSettings.managerInstance;
    managerInstance.getI18nWrap(function (){
        var modelTitle = managerInstance.getItemModelTitle();
        var callback = oSettings.callback;
        if(callback){
            callback(modelTitle);
        }else{
            vm.$set(vm.label,'modelTitle', modelTitle);
        }
    });
};

DocumentManagerFactory.getStatusIconArray = function (docType){
    var defDocumentManager = DocumentManagerFactory.getDocumentManagerDef(docType);
    if (!defDocumentManager || !defDocumentManager.getStatusIconArray) {
        return;
    }
    return defDocumentManager.getStatusIconArray();
};


DocumentManagerFactory.formatStatusClass = function(status, docType){
    var statusIconArray = DocumentManagerFactory.getStatusIconArray(docType);
    var $element = ServiceCollectionsHelper.filterArray(status, 'id', statusIconArray);
    if($element){
        return $element.iconClass;
    }
};

DocumentManagerFactory.formatStatus = function (docType) {
    var defDocumentManager = DocumentManagerFactory.getDocumentManagerDef(docType);
    if (!defDocumentManager || !defDocumentManager.formatStatus) {
        return;
    }
    return defDocumentManager.formatStatus;
};


DocumentManagerFactory.getActionCodeMap = function(docType) {
    var defDocumentManager = DocumentManagerFactory.getDocumentManagerDef(docType);
    var customActionCodeIconMap = (defDocumentManager && defDocumentManager.getCustomActionCodeIconMap) ?
        defDocumentManager.getCustomActionCodeIconMap():undefined;
    var actionCodeIconMap = ServiceUtilityHelper.getMergedActionCodeIconMap(customActionCodeIconMap);
    return actionCodeIconMap;
};


DocumentManagerFactory.formatActionCodeClass = function (actionCode, docType) {
    var actionCodeMap = DocumentManagerFactory.getActionCodeMap(docType);
    var $element = ServiceCollectionsHelper.filterArray(actionCode, 'id', actionCodeMap);
    if($element){
        return $element.iconClass;
    }
};

DocumentManagerFactory.formatActionCode = function (docType) {
    var actionCodeMap = DocumentManagerFactory.getActionCodeMap(docType);
    var _func = function(actionCode){
        var $element = ServiceUtilityHelper.formatSelectWithIcon(actionCode, actionCodeMap, true);
        return $element;
    };
    return _func;
};


DocumentManagerFactory.renderDocFlow = function(refDocFlowList, $container, homeDocType, fnDone){
    var promiseList = [];
    var _widgetActiveFlag = false;
    if(refDocFlowList && refDocFlowList.length > 0){
        for(var i = 0; i < refDocFlowList.length; i++){
            var docType = refDocFlowList[i].documentType * 1;
            if (docType === homeDocType * 1){
                _widgetActiveFlag = true;
            }else{
                _widgetActiveFlag = false;
            }
            var documentManager = DocumentManagerFactory.getDocumentManager(docType);
            if(documentManager && documentManager.convDocItemWidget ){
                var promise = documentManager.convDocItemWidget({
                    serviceDocumentExtendUIModel: refDocFlowList[i],
                    _widgetActiveFlag: _widgetActiveFlag
                });
                promiseList.push(promise);
            }
        }
        Promise.all(promiseList).then(function (refDocFlowMap) {
            DocumentManagerFactory.renderDocFlowCore(refDocFlowMap, $container, fnDone);
        });
    }
};

DocumentManagerFactory.renderDocFlowCore = function(refDocFlowMap, $container, fnDone){
    var columnWidth = 3, rowLength = 12, colClass;
    colClass = "col-md-" + columnWidth;
    if(refDocFlowMap && refDocFlowMap.length > 0) {
        var _refDocFlowMap = refDocFlowMap.sort(function(a, b){
            return a.processIndex * 1 - b.processIndex * 1;
        });
        $($container).empty();
        var rowElement, ser = new XMLSerializer(), rowList = [];
        for (var i = 0; i < _refDocFlowMap.length; i++) {
            var docFlow = _refDocFlowMap[i];
            var parentElement = ServiceDOMUtilityHelper.createDefElement({
                class: colClass,
                element: 'div'
            });
            if((i * columnWidth) % rowLength === 0 ){
                rowElement = ServiceDOMUtilityHelper.createDefElement({
                    class: "row",
                    element: 'div'
                });
                rowList.push(rowElement);
            }
            parentElement.appendChild(docFlow.widgetElement);
            rowElement.append(parentElement);
            //
            // if(((i + 1) * columnWidth) % rowLength === 0 || (i + 1) === _refDocFlowMap.length){
            //     rowList.push(rowElement);
            // }
        }
        if(rowList.length > 0){
            for (var j = rowList.length - 1; j >= 0; j--) {
                var row = rowList[j];
                var htmlContent = ser.serializeToString(row);
                $($container).prepend(htmlContent);
            }
        }
        if(fnDone){
            fnDone();
        }
    }
};

/**
 * Get Document Status Wrap
 * @param {object} oSettings
 *            --{object} documentManager: document manager instance
 *            --{int} docType: document type
 *            --{$http} $http
 *            --{int} initValue
 *            --{DOM} oSelectElement
 *            --{function} fnCallback
 */
DocumentManagerFactory.getDocumentStatusWrap = function(oSettings){
    var documentManager = oSettings.documentManager;
    if(!documentManager){
        documentManager = DocumentManagerFactory.getDocumentManager(oSettings.docType);
    }
    if(!documentManager || !documentManager.getStatusURL || !oSettings.oSelectElement){
        return;
    }
    var _formatStatus = function(status){
        if(documentManager && documentManager.getStatusIconArray){
            var $element = ServiceUtilityHelper.formatSelectWithIcon(status, documentManager.getStatusIconArray(), true);
            return $element;
        }
    };
    oSettings.$http.get(documentManager.getStatusURL()).then(function (response) {
        if (!JSON.parse(response.body)) {
            // pop up error message
        }
        var resultList = JSON.parse(response.body);
        setTimeout(function () {
            $(oSettings.oSelectElement).select2({
                data: resultList,
                templateResult: _formatStatus,
                templateSelection: _formatStatus

            });
            // manually set initial value
            $(oSettings.oSelectElement).val(oSettings.initValue);
            $(oSettings.oSelectElement).trigger("change");
            if (oSettings.fnCallback && typeof  oSettings.fnCallback === 'function') {
                oSettings.fnCallback(oSettings.initValue, resultList);
            }
        }, 0);
    });
};

