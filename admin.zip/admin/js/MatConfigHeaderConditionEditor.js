var dataVar = new Vue({
    el: "#x_data",
    mixins: [ServiceItemEditorHelper.defControlMinxin],
    data: {
        label: MaterialConfigureTemplateManager.label.matConfigHeaderCondition,
        content: {
            matConfigHeaderConditionUIModel:MaterialConfigureTemplateManager.content.matConfigHeaderConditionUIModel
        },
        getPageHeaderModelListURL: '../matConfigHeaderCondition/getPageHeaderModelList.html',
        getRefNodeInstIdURL: '../matConfigHeaderCondition/getRefNodeInstId.html',
        getLogicOperatorURL: '../matConfigHeaderCondition/getLogicOperator.html',
        getFieldNameURL: '../matConfigHeaderCondition/getFieldName.html'
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'MaterialConfigureTemplate');
            this.setI18nProperties(vm.initProcessButtonMeta);
            this.loadModuleEdit();
        });
    },

    methods: {


        displayBySelect: function(fieldName){
            "use strict";
            var displayFlag = MaterialConfigureTemplateManager.fieldNameSelectable(fieldName);
            return DocumentManagerFactory.formatDisplayClass(displayFlag);
        },

        displayByInput: function(fieldName){
            "use strict";
            var displayFlag = !MaterialConfigureTemplateManager.fieldNameSelectable(fieldName);
            return DocumentManagerFactory.formatDisplayClass(displayFlag);
        },

        getPageHeaderModelList: function (uuid, baseUUID) {
            var vm = this;
            vm.$refs.pageHeader.initPageHeader({
                uuid: uuid,
                baseUUID: baseUUID,
                pageHeaderListUrl: vm.getPageHeaderModelListURL,
                fnPageHeaderModel: vm.fnPageHeaderModel
            });
        },

        fnPageHeaderModel: function (pageHeaderModel) {
            if (pageHeaderModel.nodeInstId === 'materialConfigureTemplate') {
                var targetTab = MaterialConfigureTemplateManager.documentTab.matConfigHeaderConditionSection;
                baseDocURL = genCommonEditURL("MaterialConfigureTemplateEditor.html", pageHeaderModel.uuid, targetTab);
                pageHeaderModel.pageLink = baseDocURL;
                pageHeaderModel.pageTitle = this.label.parentPageTitle + ":" + this.content.matConfigHeaderConditionUIModel.templateId;
                return pageHeaderModel;
            }
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'matConfigHeaderConditionUIModel', content.matConfigHeaderConditionUIModel);
            vm.getPageHeaderModelList(vm.content.matConfigHeaderConditionUIModel.uuid, vm.content.matConfigHeaderConditionUIModel.parentNodeUUID);
            rightBar.initHelpDocumentList(vm.content.matConfigHeaderConditionUIModel.uuid);
        },

        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'MatConfigHeaderConditionEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: MaterialConfigureTemplateManager,
                coreModelId: 'MatConfigHeaderCondition',
                i18nPath: 'coreFunction/',
                helpDocumentName: ['MatConfigHeaderConditionHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: vm.displayForEdit,
                        callback: vm.saveModule
                    },
                    exit: {
                        callback: vm.exitModule
                    }
                },
                pageHeaderConfig: [{
                    nodeInstId: 'materialConfigureTemplate',
                    baseEditUrl:"MaterialConfigureTemplateEditor.html",
                    targetTab: MaterialConfigureTemplateManager.documentTab.matConfigHeaderConditionSection,
                    pageTitlePath: 'parentPageTitle' ,
                    pageTitleVarPath: 'templateId'
                },{
                    active: true,
                    nodeInstId: 'matConfigHeaderCondition',
                    baseEditUrl:"MatConfigHeaderConditionEditor.html",
                    pageTitlePath: 'pageHeaderTitle' ,
                    pageTitleVarPath: 'name'
                }],
                tabMetaList: [{
                    tabId: 'matConfigHeaderConditionSection',
                    tabTitleKey: 'matConfigHeaderConditionSection',
                    titleLabelKey: 'matConfigHeaderConditionSection',
                    titleHelpKey: 'materialStockKeepUnit.matConfigHeaderConditionSection',
                    titleIcon: 'md md-straighten content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'materialUnitSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'matConfigHeaderConditionUIModel',
                        tabTitleKey: 'materialUnitSection',
                        titleLabelKey: 'materialUnitSection',
                        titleHelpKey: 'material.materialUnitSection',
                        titleIcon: 'md md-texture content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'id',
                            newRow: true
                        }, {
                            fieldName: 'refNodeInstId',
                            newRow: true,
                            helpKey: 'matConfigHeaderCondition.refNodeInstId',
                            settings: {
                                getMetaDataUrl: vm.getRefNodeInstIdURL
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'logicOperator',
                            helpKey: 'matConfigHeaderCondition.logicOperator',
                            settings: {
                                getMetaDataUrl: vm.getLogicOperatorURL,
                                formatMeta:SystemStandrdMetadataProxy.formatLogicOperator,
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'fieldName',
                            helpKey: 'matConfigHeaderCondition.fieldName',
                            settings: {
                                getMetaDataUrl: vm.getFieldTypeURL
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'fieldValue',
                            hidden: vm.displayBySelect(vm.content.matConfigHeaderConditionUIModel.fieldName),
                            helpKey: 'matConfigHeaderCondition.fieldValue'
                        }, {
                            fieldName: 'fieldValue',
                            hidden: vm.displayByInput(vm.content.matConfigHeaderConditionUIModel.fieldName),
                            helpKey: 'matConfigHeaderCondition.fieldValue',
                            settings: {
                                getMetaDataUrl: MaterialConfigureTemplateManager.getHeaderConditionSelectUrl(vm.content.refNodeInstId),
                                method: 'post',
                                idField: 'uuid',
                                textField: 'name',
                                requestData: {},
                                uuidField: 'uuid',
                                postLoadUrl: MaterialConfigureTemplateManager.getHeaderConditionLoadModuleUrl(vm.content.matConfigHeaderConditionUIModel.refNodeInstId),
                                fieldList: [{
                                    targetField: 'valueId',
                                    sourceField: 'id'
                                }, {
                                    targetField: 'valueName', sourceField: 'name'
                                }]
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        },{
                            fieldName: 'valueId',
                            disabled: true,
                            helpKey: 'matConfigHeaderCondition.valueId'
                        }, {
                            fieldName: 'valueName',
                            disabled: true,
                            helpKey: 'matConfigHeaderCondition.valueName'
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        } ]
                    }]
                }]
            };
        }

    }
});
