var rightBar = new Vue({
    el: "#rightBarHoc",
    mixins: [ServiceRightBarPanelHelper.defTimelineMinxin],
    data: function () {
        return {
            coreModelId: "MatConfigValueSetting",
            i18nPath:"coreFunction/",
            label: MaterialConfigureTemplateManager.label.matDecisionValueSetting
        };
    },

    methods: {
        initHelpDocumentList: function (uuid) {
            "use strict";
            var vm = this;
            ServiceRightBarPanelHelper.initHelpDocumentWithAction({
                uuid: uuid,
                vm: vm,
                documentType: DocumentConstants.DummyDocumentType.MaterialConfigureTemplate,
                errorHandle: dataVar.errorHandle,
                helpDocumentName: 'MatConfigValueSettingHelpDocument'
            });
        }
    }
});

var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: MaterialConfigureTemplateManager.label.matDecisionValueSetting,
        content: {
            matDecisionValueSettingUIModel:MaterialConfigureTemplateManager.content.matDecisionValueSettingUIModel
        },
        processButtonMeta: [],
        getPageHeaderModelListURL: '../matDecisionValueSetting/getPageHeaderModelList.html',
        exitModuleURL: '../matDecisionValueSetting/exitEditor.html'
    },

    created: function () {
        var vm = this;
        this.setI18nProperties(vm.initProcessButtonMeta);
        this.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'MaterialConfigureTemplate');
            this.loadModuleEdit();
        });
    },

    methods: {
        /**
         * Initial register sub component
         */
        initSubComponents: function () {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("page-header-union", PageHeaderUnion);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
            Vue.component("mat-config-value-setting-control", MatConfigValueSettingControl);
        },

        openRightSideBar: function(key){
            NavigationPanelIns.openRightSideBar(RightBarTemplate.TABS.tab2, key);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'MatConfigValueSetting',
                    callback: vm.setNodeI18nPropertiesCore
                }]
            });
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            // vm.$refs.refBusyLoader.showBusyLoading();
            vm.$refs.control.loadModule({
                baseUUID: baseUUID,
                processMode: processMode,
                errorHandle: vm.errorHandle,
                pageCategory: DocumentConstants.StandardPropety.PageCategory.PAGE,
                postLoadData: function(content){
                    vm.$refs.refBusyLoader.hideBusyLoading();
                    vm.setModuleToUI(content);
                }
            });
        },

        displayForEdit: function () {
            if(this.$refs.control){
                return this.$refs.control.displayForEdit();
            }
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        getPageHeaderModelList: function (uuid, baseUUID) {
            var vm = this;
            vm.$refs.pageHeader.initPageHeader({
                uuid: uuid,
                baseUUID: baseUUID,
                pageHeaderListUrl: vm.getPageHeaderModelListURL,
                fnPageHeaderModel: vm.fnPageHeaderModel
            });
        },

        fnPageHeaderModel: function (pageHeaderModel) {
            if (pageHeaderModel.nodeInstId === 'materialConfigureTemplate') {
                var targetTab = MaterialConfigureTemplateManager.documentTab.matConfigExtPropertySettingSection;
                baseDocURL = genCommonEditURL("MaterialConfigureTemplateEditor.html", pageHeaderModel.uuid, targetTab);
                pageHeaderModel.pageLink = baseDocURL;
                pageHeaderModel.pageTitle = this.label.parentPageTitle + ":" + this.content.matDecisionValueSettingUIModel.templateId;
                return pageHeaderModel;
            }
        },

        saveModule: function () {
            var vm = this;
            vm.$refs.control.saveModule();
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.matDecisionValueSettingUIModel.parentNodeUUID;
            window.location.href = genCommonEditURL("MaterialConfigureTemplateEditor.html", baseUUID,
                MaterialConfigureTemplateManager.documentTab.matDecisionValueSettingSection);
        },

        displayByUsageSelect: function(valueUsage){
            "use strict";
            var displayFlag = MaterialConfigureTemplateManager.valueUsageSelectable(valueUsage);
            return DocumentManagerFactory.formatDisplayClass(displayFlag);
        },

        displayByUsageInput: function(valueUsage){
            "use strict";
            var displayFlag = !MaterialConfigureTemplateManager.valueUsageSelectable(valueUsage);
            return DocumentManagerFactory.formatDisplayClass(displayFlag);
        },

        refreshEditView: function () {
            var baseUUID = this.content.matDecisionValueSettingUIModel.uuid;
            window.location.href = genCommonEditURL("MatConfigureValueSettingEditor.html", baseUUID);
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'matDecisionValueSettingUIModel', content.matDecisionValueSettingUIModel);
            vm.getPageHeaderModelList(vm.content.matDecisionValueSettingUIModel.uuid, vm.content.matDecisionValueSettingUIModel.parentNodeUUID);
            rightBar.initHelpDocumentList(vm.content.matDecisionValueSettingUIModel.uuid);
        }

    }
});
