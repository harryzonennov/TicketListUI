var dataVar = new Vue({
    el: "#x_data",
    mixins: [CorporateCustomerManager.labelTemplate, SerDocumentControlHelper.defControlMinxin],
    data: {
        label: CorporateCustomerManager.label.corporateCustomer,
        content: {
            corporateCustomerUIModel: CorporateCustomerManager.content.corporateCustomerUIModel,
            corporateContactPersonUIModelList: [],
            corporateCustomerAttachmentUIModelList: []
        },
        addressInfoInit: false, // Indicator whethear 'AddressInfo' has initial value.
        getStatusURL: '../corporateCustomer/getStatus.html',
        checkDuplicateURL: '../corporateCustomer/checkDuplicate.html',
        getCustomerLevelMapURL: '../corporateCustomer/loadCustomerLevelMap.html',
        newCorporateContactPersonServiceURL: '../individualCustomer/newContactCustomerService.html',
        exitURL: 'CorporateCustomerList.html',
        exitModuleURL: '../corporateCustomer/exitEditor.html'
    },

    created: function() {
        this.initSubComponentsController();
    },

    mounted: function () {
        NavigationPanelIns.initNavigation('logistics', 'CorporateCustomer');
    },

    methods: {
        /**
         * @Overwrite extended init sub vue components logic
         * @return {*}
         */
        initSubComponentsController: function () {
            Vue.component("corporate-contact-person-panel", CorporateContactPersonPanel);
        },

        /**
         * @Overwrite: Get document type for each edit controller
         */
        getDocumentType: function () {
            return DocumentConstants.DummyDocumentType.CorporateCustomer;
        },

        getServiceManager: function () {
            return CorporateCustomerManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "CorporateCustomerEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.corporateCustomerUIModel.uuid;
        },

        /**
         * @Overwrite: get document status from content
         */
        getStatus: function () {
            return this.content.corporateCustomerUIModel.status;
        },

        /**
         * @Overwrite provide doc action code matrix
         * @return {*}
         */
        getActionCodeMatrix: function () {
            return {
                submit: {actionCode: CorporateCustomerManager.DOC_ACTION_CODE.SUBMIT},
                revokeSubmit: {actionCode: CorporateCustomerManager.DOC_ACTION_CODE.REVOKE_SUBMIT},
                approve: {actionCode: CorporateCustomerManager.DOC_ACTION_CODE.APPROVE},
                reInit: {actionCode: CorporateCustomerManager.DOC_ACTION_CODE.REINIT},
                rejectApprove: {actionCode: CorporateCustomerManager.DOC_ACTION_CODE.REJECT_APPROVE},
                countApprove: {actionCode: CorporateCustomerManager.DOC_ACTION_CODE.COUNTAPPROVE},
                active: {actionCode: CorporateCustomerManager.DOC_ACTION_CODE.ACTIVE},
                archive: {actionCode: CorporateCustomerManager.DOC_ACTION_CODE.ARCHIVE}
            };
        },

        setModuleToUI: function (content) {
            var vm = this;
            if (content.corporateCustomerUIModel.address) {
                vm.$set(vm, 'addressInfoInit', true);
            }
            vm.$set(vm.content, 'corporateCustomerUIModel', content.corporateCustomerUIModel);
            vm.$set(vm.content, 'corporateContactPersonUIModelList', content.corporateContactPersonUIModelList);
            vm.$set(vm.content, 'corporateCustomerAttachmentUIModelList', content.corporateCustomerAttachmentUIModelList);
            vm.postUpdateUIModel();
        },

        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'CorporateCustomerEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: CorporateCustomerManager,
                coreModelId: 'CorporateCustomer',
                i18nPath: 'coreFunction/',
                getDocActionNodeListURL: '../corporateCustomer/getDocActionNodeList.html',
                helpDocumentName: ['CorporateCustomerHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: 'displayForEdit',
                        callback: 'saveModule'
                    },
                    placeholder: {
                        category: ProcessButtonConstants.placeholderCategory.DOC_ACTION_BTN
                    },
                    exit: {
                        callback: 'exitModule'
                    }
                },
                callbackTemplateList: [{
                    templateId:'updateAddressInfo',
                    watchFieldList:['stateName', 'cityName', 'townZone', 'streetName', 'contactTelephone'],
                    callbackTemplate:function(content) {
                        var oSettings =  {
                            stateName: "${stateName}",
                            cityName: "${cityName}",
                            townZone: "${townZone}",
                            streetName: "${streetName}",
                            telephone: "${telephone}",
                        } ;
                        return ServiceUtilityHelper.buildAddressInfo(oSettings);
                    },
                    enableFlag: function() {
                        return true;
                    }
                }],
                tabMetaList: [{
                    tabId: 'corporateCustomerSection',
                    tabTitleKey: 'corporateCustomerSection',
                    titleLabelKey: 'corporateCustomerSection',
                    titleHelpKey: 'corporateCustomer.corporateCustomerSection',
                    titleIcon: 'md md-texture content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'corporateCustomerSection',
                        updatedByUidPath: 'updatedByUUID',
                        updatedByNamePath: 'updatedByName',
                        updatedDatePath: 'updatedDate',
                        messageResponsePath: 'meta.messageResponse',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'corporateCustomerUIModel',
                        tabTitleKey: 'corporateCustomerSection',
                        titleLabelKey: 'corporateCustomerSection',
                        titleHelpKey: 'corporateCustomer.corporateCustomerSection',
                        titleIcon: 'md md-content-paste content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'id',
                            required: true,
                            newRow: true
                        }, {
                            required: true,
                            fieldName: 'name',
                        }, {
                            fieldName: 'status',
                            disabled: true,
                            helpKey: 'corporateCustomer.status',
                            settings: {
                                getMetaDataUrl: vm.getStatusURL,
                                formatMeta: 'formatStatus'
                            },
                            iconArray: 'getStatusIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'depositBank',
                        }, {
                            fieldName: 'bankAccount',
                        }, {
                            fieldName: 'taxNumber',
                        }, {
                            fieldName: 'customerLevel',
                            disabled: true,
                            helpKey: 'corporateCustomer.customerLevel',
                            settings: {
                                getMetaDataUrl: vm.getCustomerLevelMapURL,
                                formatMetaCallback: 'formatCustomerLevel',
                                idField:'id',
                                textField:'name'
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        }]
                    }, {
                        sectionId: 'corporateContactSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'corporateCustomerUIModel',
                        tabTitleKey: 'corporateCustomerSection',
                        titleLabelKey: 'corporateCustomerSection',
                        titleHelpKey: 'corporateCustomer.corporateCustomerSection',
                        titleIcon: 'md md-quick-contacts-dialer content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'telephone',
                            newRow: true,
                        }, {
                            fieldName: 'fax',
                        }, {
                            fieldName: 'weiXinID'
                        }, {
                            fieldName: 'email'
                        }, {
                            refControl: {
                                id: RefControl.Ids.Separator
                            }
                        }, {
                            newRow: true,
                            fieldName: 'stateName'
                        }, {
                            fieldName: 'cityName'
                        }, {
                            fieldName: 'townZone'
                        }, {
                            fieldName: 'streetName'
                        }, {
                            fieldName: 'address',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea,
                            setAutoValue: {
                                callbackTemplateId:"updateAddressInfo"
                            },
                        }]
                    }, ]
                },{
                    tabId: 'corporateContactPersonSection',
                    tabTitleKey: 'corporateContactPersonSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'corporateContactPersonSection',
                        parentContentPath: 'corporateContactPersonUIModelList',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        detailedPageUrl: 'CorporateContactPersonEditor.html',
                        refItemName: 'contactPersonPanel',
                        editModuleFlag: true,
                        editModuleModalFlag: true,
                        tabTitleKey: 'corporateContactPersonSection',
                        titleLabelKey: 'corporateContactPersonSection',
                        titleHelpKey: 'corporateCustomer.corporateContactPersonSection',
                        titleIcon: 'md md-nature-people content-portlet-title',
                        scrollX: true,
                        embedProcessButtonMeta: {
                            addTitle: 'add',
                            addLabel: 'add',
                            newModuleModalFlag: true
                        },
                        fieldMetaList: [{
                            fieldName: 'corporateContactPersonUIModel.uuid'
                        }, {
                            fieldName: 'corporateContactPersonUIModel.name',
                            labelKey: 'corporateContactPerson.name',
                            minWidth: '180px'
                        }, {
                            fieldName: 'corporateContactPersonUIModel.contactRoleNote',
                            labelKey: 'corporateContactPerson.contactRole',
                            minWidth: '180px'
                        }, {
                            fieldName: 'corporateContactPersonUIModel.contactPositionNote',
                            labelKey: 'corporateContactPerson.contactPosition',
                        }, {
                            fieldName: 'corporateContactPersonUIModel.mobile',
                            labelKey: 'corporateContactPerson.mobile',
                        }, {
                            fieldName: 'corporateContactPersonUIModel.email',
                            labelKey: 'corporateContactPerson.email',
                            minWidth: '180px'
                        }]
                    }]
                },{
                    tabId: 'customerAttachmentSection',
                    tabTitleKey: 'customerAttachmentSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'corporateCustomerAttachment',
                        sectionCategory: AsyncSection.sectionCategory.ATTACHMENT,
                        parentContentPath: 'corporateCustomerAttachmentUIModelList',
                        errorHandle: 'errorHandle',
                        settings: {
                            configMetaPath: 'attachmentMeta'
                        }
                    }]
                }]
            };
        },

    }
});
