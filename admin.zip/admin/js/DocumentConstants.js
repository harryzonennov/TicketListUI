/**
 * Constant management for Service Module, should be consistent with backend platform class: IServiceModelConstants
 */
var ServiceModuleConstants = {

    AuthorizationObject: 'AuthorizationObject',

    AuthorizationGroup: 'AuthorizationGroup',

    MaterialStockKeepUnit: 'MaterialStockKeepUnit',

    QualityInspectOrder: 'QualityInspectOrder',

    SalesContract: 'SalesContract',

    SalesReturnOrder: 'SalesReturnOrder',

    MaterialType: 'MaterialType',

    Material: 'Material',

    RegisteredProduct: 'RegisteredProduct',

    StandardMaterialUnit: 'StandardMaterialUnit',

    ProdWorkCenter: 'ProdWorkCenter',

    CorporateCustomer: 'CorporateCustomer',

    PurchaseContract: 'PurchaseContract',

    MaterialConfigureTemplate: 'MaterialConfigureTemplate',

    SalesForcast: 'SalesForcast',

    PurchaseRequest: 'PurchaseRequest',

    PurchaseReturnOrder: 'PurchaseReturnOrder',

    WasteProcessOrder: 'WasteProcessOrder',

    Inquiry: 'Inquiry',

    IndividualCustomer: 'IndividualCustomer',

    InboundDelivery: 'InboundDelivery',

    OutboundDelivery: 'OutboundDelivery',

    InventoryCheckOrder: 'InventoryCheckOrder',

    InventoryTransferOrder: 'InventoryTransferOrder',

    ProductionOrder: 'ProductionOrder',

    RepairProdOrder: 'RepairProdOrder',

    ProdPickingOrder: 'ProdPickingOrder',

    ProductionPlan: 'ProductionPlan',

    TransitPartner: 'TransitPartner',

    CorporateSupplier: 'CorporateSupplier',

    CalendarTemplate: 'CalendarTemplate',

    Employee: 'Employee',

    LogonUser: 'LogonUser',

    ServiceFlowModel: 'ServiceFlowModel',

    FlowRouter: 'FlowRouter',

    Role: 'Role',

    MessageTemplate: 'MessageTemplate',

    SearchProxyConfig: 'SearchProxyConfig',

    Organization: 'Organization',

    ExternalDriver: 'ExternalDriver',

    FinAccountTitle: 'FinAccountTitle',

    FinAccount: 'FinAccount',

    BillOfMaterialOrder: 'BillOfMaterialOrder',

    BillOfMaterialTemplate: 'BillOfMaterialTemplate',

    HostCompany: 'HostCompany',

    SerialNumberSetting: 'SerialNumberSetting',

    SystemCodeValueCollection:'SystemCodeValueCollection',

    SystemConfigureResource: 'SystemConfigureResource',

    SystemExecutorSetting: 'SystemExecutorSetting',

    SystemConfigureCategory: 'SystemConfigureCategory',

    ServiceDocumentSetting: 'ServiceDocumentSetting',

    ServiceExtensionSetting: 'ServiceExtensionSetting',

    SerExtendPageSetting: 'SerExtendPageSetting',

    PricingSetting: 'PricingSetting',

    Warehouse: "Warehouse",

    WarehouseStoreItem: "WarehouseStoreItem",

    WarehouseStore: "WarehouseStore",

    WorkCalendar: 'WorkCalendar'

};

var DocumentContentProp = {

    status: {

        INITIAL: 1,

        APPROVED: 2,

        DELIVERY_DONE: 4,

        PROCESS_DONE: 5,

        SUBMITTED: 299,

        ACTIVE:305,

        INPROCESS: 310,

        REVOKE_SUBMIT: 699,

        REJECT_APPROVAL: 790,

        BLOCKED:910,

        ARCHIVED: 980,

        CANCELED: 990

    },

    statusIcon: {

        INITIAL: 'md md-remove-circle-outline content-grey',

        INPROCESS: 'md md-restore content-orange',

        APPROVED: 'md md-spellcheck content-peach-red',

        DELIVERY_DONE: 'md md md-done-all content-green',

        ACTIVE: '',

        PROCESS_DONE: 'md md md-done-all content-green',

        SUBMITTED: 'nmd nmd-format-color-text content-orange',

        BLOCKED: 'md md-block content-red',

        REVOKE_SUBMIT: 'nmd nmd-gavel content-darkblue1',

        REJECT_APPROVAL: 'nmd nmd-do-not-disturb-alt content-peach-red',

        ARCHIVED: 'nmd nmd-sd-storage content-grey',

        CANCELED: 'nmd nmd-delete-forever content-grey'

    }
};

/**
 * Constant management for Document Content.
 */
var DocumentConstants = {

    /**
     * Service Module constants, should be consistent with backend platform class: IServiceModelConstants
     */

    ServiceModuleConstants: {

        AuthorizationObject: 'AuthorizationObject',

        MaterialStockKeepUnit: 'MaterialStockKeepUnit',

        QualityInspectOrder: 'QualityInspectOrder',

        Material: 'Material',

        RegisteredProduct: 'RegisteredProduct',

        ProdWorkCenter: 'ProdWorkCenter',

        CorporateCustomer: 'CorporateCustomer',

        Inquiry: 'Inquiry',

        IndividualCustomer: 'IndividualCustomer',

        InboundDelivery: 'InboundDelivery',

        OutboundDelivery: 'OutboundDelivery',

        InventoryCheckOrder: 'InventoryCheckOrder',

        InventoryTransferOrder: 'InventoryTransferOrder',

        ProductionOrder: 'ProductionOrder',

        ProdPickingOrder: 'ProdPickingOrder',

        ProductionPlan: 'ProductionPlan',

        TransitPartner: 'TransitPartner',

        CorporateSupplier: 'CorporateSupplier',

        Employee: 'Employee',

        LogonUser: 'LogonUser',

        Organization: 'Organization',

        ExternalDriver: 'ExternalDriver',

        FinAccountTitle: 'FinAccountTitle',

        FinAccount: 'FinAccount',

        BillOfMaterialOrder: 'BillOfMaterialOrder',

        BillOfMaterialTemplate: 'BillOfMaterialTemplate',

        Warehouse: "Warehouse",

        WarehouseStoreItem: "WarehouseStoreItem"
    },


    StandardPropety: {

        SystemCategory: {
            SYSTEM_STANDARD: 1,
            SELF_DEFINED: 2
        },

        PageCategory: {
            PAGE: 1,
            PANEL_DOWN: 2,
            PANEL_RIGHT: 3,
            MODAL: 6
        },

        Switch: {
            ON: 1,
            OFF: 2,
            INITIAL: 3,
            DELETE: 4
        },

        StandardLogicOperator: {
            AND: 1,
            OR: 2
        },

        StandardDocFlowDirection:{
            DIREC_PREV:1,
            DIREC_NEXT:2,
            DIREC_PREV_PROF:3,
            DIREC_NEXT_PROF:4,
            RESERVED:5,
        },

        SimpleSEMessageResponse: {
            MESSAGELEVEL_INFO: 1,
            MESSAGELEVEL_WARN: 2,
            MESSAGELEVEL_ERROR: 3
        },

        SystemHideFlag: {
            HIDE_FLAG: 1,
            UNHIDE_FLAG: 2
        },

        Gender: {
            MALE: 1,
            FEMALE: 2
        },

        ServiceFlowInvolveTask:{
            STATUS_NONE: 1,
            STATUS_BLOCK_OTHER: 2,
            STATUS_HIT: 3
        },

        KeyFlag: {
            KEY: 1,
            NON_KEY: 2
        },

        ValueOperator: {
            OPERATOR_EQUAL: 1,

            OPERATOR_BETWEEN: 2,

            OPERATOR_NOT_BETWEEN: 3,

            OPERATOR_GREATER_EQ: 4,

            OPERATOR_GREATER: 5,

            OPERATOR_LESS_EQ: 6,

            OPERATOR_LESS: 7,

            OPERATOR_NOT_EQ: 8,

            OPERATOR_CONTAINS: 9
        },

        SystemCheckResult: {

            INIT: 1,

            ERROR: 2,

            OK: 3
        },

        ServiceItemUpdateModel: {

            NOCHANGE: 1,

            CREATE: 2,

            DELETE: 3,

            INCREASE: 4,

            DECREASE: 5,

            UPDATE: 6

        },

        MethodType: {
            get: 'get',
            post: 'post',
            put: 'put',
            patch: 'patch'
        },

        EmptyString: '',

        ExecutionResult: {
            RESULT_SUCCESS: 1,
            RESULT_ERROR: 2,
            RESULT_ABORT: 3
        },

        MessageLevelCode: {
            INFO: 1,
            WARN: 2,
            ERROR: 3
        },

        SystemSerialParallel: {
            SERIAL: 1,
            PARALLEL: 2
        },

        SystemMandatoryMode: {
            MODE_MANDATORY: 1,
            MODE_SELECTIVE: 2
        },

        SerExtendPageSetting: {
            pageCategory:{
                EDIT: 1,
                LIST: 2,
                INIT: 3
            }
        },

        SystemAuthActionCode: {
            ACID_EDIT: "Edit",
            ACID_VIEW: "View",
            ACID_LIST: "List",
            ACID_DELETE: "Delete",
            ACID_AUDITDOC: "AuditDoc",
            ACID_EXCEL: "Excel",
            ACID_PRICEINFO: "PriceInfo"
        },

        SystemAuthActionCodeIcon: {
            ACID_EDIT: 'md md-mode-edit content-green',
            ACID_VIEW: "nmd nmd-description content-darkblue1",
            ACID_LIST: "nmd nmd-youtube-searched-for content-green",
            ACID_DELETE: "nmd nmd-delete-forever content-peach-red",
            ACID_AUDITDOC: "md md-spellcheck content-peach-red",
            ACID_EXCEL: "fa fa-file-excel-o content-green",
            ACID_PRICEINFO: "nmd nmd-money-off content-orange"
        },

        SystemDefExtServiceActionCode: {
            ACTION_SEARCH: "search",
            ACTION_NEW: "new",
            ACTION_BATCH_INBOUND: "inbound",
            ACTION_BATCH_OUTBOUND: "outbound",
            ACTION_START_PROCESS: "startProcess",
        },

        DefDocActionCodeHeader: {
            ACTION_UPDATE: "update",
            ACTION_APPROVE: "approve",
            ACTION_COUNTAPPROVE: "countApprove",
            ACTION_REJECT: "reject",
            ACTION_DELIVERY_DONE: "deliveryDone",
            ACTION_PROCESS_DONE: "processDone",
            ACTION_SUBMIT: "submit",
            ACTION_ACTIVE: "active",
            ACTION_INPROCESS: "inprocess",
            ACTION_REINIT: "reinit",
            ACTION_REVOKE_SUBMIT: "revokeSubmit",
            ACTION_REJECT_APPROVE: "rejectApprove",
            ACTION_DRYRUN:"dryRun",
            ACTION_ARCHIVE: "archive",
            ACTION_CANCEL: "cancel"
        },

        DefDocStatusHeader: {
            STATUS_INITIAL: "initial",
            STATUS_REJECT_APPROVAL: "rejectApproval",
            STATUS_APPROVED: "approved",
            STATUS_DELIVERY_DONE: "deliveryDone",
            STATUS_PROCESS_DONE: "processDone",
            STATUS_SUBMITTED: "submitted",
            STATUS_ACTIVE: "active",
            STATUS_INPROCESS: "inProcess",
            STATUS_CANCELED: "canceled"
        },

        SystemDefDocActionCodeProxy: {
            ACTION_UPDATE: 1,
            ACTION_APPROVE: 2,
            ACTION_COUNTAPPROVE: 3,
            ACTION_REJECT: 4,
            ACTION_DELIVERY_DONE: 5,
            ACTION_PROCESS_DONE: 6,
            ACTION_SUBMIT: 299,
            ACTION_ACTIVE: 305,
            ACTION_INPROCESS: 310,
            ACTION_REINIT: 350,
            ACTION_REVOKE_SUBMIT: 690,
            ACTION_REJECT_APPROVE: 790,
            ACTION_DRYRUN:810,
            ACTION_ARCHIVE: 980,
            ACTION_CANCEL: 990
        },

        SystemDefDocActionCodeIcon: {
            ACTION_NEW: 'fa fa-plus-square content-green',
            ACTION_ACTIVE: 'ion-wand content-pink',
            ACTION_EDIT: 'md md-mode-edit content-green',
            ACTION_REINIT: 'md md-mode-edit content-green',
            ACTION_SEARCH: 'nmd nmd-youtube-searched-for content-lightblue',
            ACTION_BATCH_INBOUND: 'md md-file-download content-green',
            ACTION_BATCH_OUTBOUND: 'md md-file-upload content-orange',
            ACTION_SIMULATE: 'fa fa-calculator content-lightblue',
            ACTION_INPROCESS_RED: 'md md-access-alarms content-peach-red',
            ACTION_APPROVE: 'md md-spellcheck content-peach-red',
            ACTION_ARCHIVE: DocumentContentProp.statusIcon.ARCHIVED,
            ACTION_COUNTAPPROVE: 'fa fa-rotate-left content-green',
            ACTION_DELIVERY_DONE: 'md md-done-all content-green',
            ACTION_PROCESS_DONE: 'fa fa-flag-checkered content-green',
            ACTION_SUBMIT: 'nmd nmd-format-color-text content-orange',
            ACTION_REVOKE_SUBMIT: 'ion-arrow-return-left content-green',
            ACTION_REJECT_APPROVE: 'nmd nmd-do-not-disturb-alt content-peach-red'
        }
    },


    /**
     * Document type constants, should be consistent with backend platform class: IDefDocumentResource
     */
    DocumentType: {

        RECEIPT: 1,

        VOUCHER: 2,

        BOOKINGNOTE: 3,

        FINANCE: 4,

        VEHICLERUNORDER: 5,

        VEHICLERUNORDERCONTRACT: 6,

        TRANSITORDER: 7,

        RECEIVERNOTE: 9,

        EXTERNALEXPRESSORDER: 10,

        INBOUNDDELIVERY: 11,

        OUTBOUNDDELIVERY: 12,

        INVENTORY_CHECKORDER: 13,

        INVENTORY_TRANSFER: 14,

        SALESORDER: 15,

        PURCHASE: 16,

        PRODUCTIONORDER: 17,

        SALESRETURNORDER: 18,

        SALESCONTRACT: 19,

        PURCHASECONTRACT: 20,

        SALESSETTLEORDER: 21,

        PURCHASESETTLEORDER: 22,

        BIDDINGINVITATIONORDER: 23,

        INQUIRY: 24,

        PRODUCTIONPLAN: 25,

        PRODPICKINGORDER: 26,

        PRODRETURNORDER: 27,

        QUALITYINSPECTORDER: 28,

        PRODORDERREPORT: 29,

        WAREHOUSESTOREITEM: 30,

        PRODUCTORDERITEM: 31,

        PRODUCTPLANITEM: 32,

        SALESFORCAST: 33,

        PURCHASEREQUEST: 34,

        PURCHASERETURNORDER: 35,

        BILLOFMATERIALTEMPLATE: 36,

        BILLOFMATERIALORDER: 37,

        WASTEPROCESSORDER: 38,

        REPAIRPRODORDER: 39,

        REPAIRPRODORDERITEM: 40
    },

    /* this kind of document type only exist in front end*/
    DummyDocumentType: {

        PRODUCTIONORDER_ITEM: 100,

        MaterialStockKeepUnit: ServiceModuleConstants.MaterialStockKeepUnit,

        Material: ServiceModuleConstants.Material,

        MaterialType: ServiceModuleConstants.MaterialType,

        MaterialConfigureTemplate: ServiceModuleConstants.MaterialConfigureTemplate,

        RegisteredProduct: ServiceModuleConstants.RegisteredProduct,

        StandardMaterialUnit: ServiceModuleConstants.StandardMaterialUnit,

        ProdWorkCenter: ServiceModuleConstants.ProdWorkCenter,

        CorporateCustomer: ServiceModuleConstants.CorporateCustomer,

        Inquiry: ServiceModuleConstants.Inquiry,

        IndividualCustomer: ServiceModuleConstants.IndividualCustomer,

        InboundDelivery: ServiceModuleConstants.InboundDelivery,

        OutboundDelivery: ServiceModuleConstants.OutboundDelivery,

        InventoryCheckOrder: ServiceModuleConstants.InventoryCheckOrder,

        InventoryTransferOrder: ServiceModuleConstants.InventoryTransferOrder,

        ProductionOrder: ServiceModuleConstants.ProductionOrder,

        ProdPickingOrder: ServiceModuleConstants.ProdPickingOrder,

        ProductionPlan: ServiceModuleConstants.ProductionPlan,

        TransitPartner: ServiceModuleConstants.TransitPartner,

        CorporateSupplier: ServiceModuleConstants.CorporateSupplier,

        Employee: ServiceModuleConstants.Employee,

        LogonUser: ServiceModuleConstants.LogonUser,

        Organization: ServiceModuleConstants.Organization,

        ExternalDriver: ServiceModuleConstants.ExternalDriver,

        FinAccountTitle: ServiceModuleConstants.FinAccountTitle,

        FinAccount: ServiceModuleConstants.FinAccount,

        BillOfMaterialOrder: ServiceModuleConstants.BillOfMaterialOrder,

        SystemCodeValueCollection: ServiceModuleConstants.SystemCodeValueCollection,

        ServiceExtensionSetting: ServiceModuleConstants.ServiceExtensionSetting,

        SerExtendPageSetting: ServiceModuleConstants.SerExtendPageSetting,

        Warehouse: ServiceModuleConstants.Warehouse,

        WarehouseStoreItem: ServiceModuleConstants.WarehouseStoreItem,

        HostCompany: ServiceModuleConstants.HostCompany,

        MessageTemplate: ServiceModuleConstants.MessageTemplate,

        Role: ServiceModuleConstants.Role,

        AuthorizationObject: ServiceModuleConstants.AuthorizationObject,

        AuthorizationGroup: ServiceModuleConstants.AuthorizationGroup,

        SerialNumberSetting: ServiceModuleConstants.SerialNumberSetting,

        PricingSetting: ServiceModuleConstants.PricingSetting,

        ServiceFlowModel: ServiceModuleConstants.ServiceFlowModel,

        ServiceDocumentSetting: ServiceModuleConstants.ServiceDocumentSetting,

        FlowRouter: ServiceModuleConstants.FlowRouter,

        CalendarTemplate: ServiceModuleConstants.CalendarTemplate,

        WorkCalendar:ServiceModuleConstants.WorkCalendar,

        SystemExecutorSetting: ServiceModuleConstants.SystemConfigureResource

    },

    /**
     * Constant of General Document attributes, should keep consistent with back-end.
     */
    Document: {
        priorityCode: {

            LOW: 1,

            MIDDLE: 2,

            HIGH: 3,

            VERYHIGH: 4
        },
        status: {
            INITIAL: 1,

            INPROCESS: 2,

            RELEASED: 3,

            FINISHED: 4,

            SUBMITTED: 299,

            REVOKE_SUBMIT: 699,

            REJECT_APPROVAL: 790,

            ARCHIVED: 980,

            CANCELED: 990

        }
    },

    Material: {
        operationMode: {
            SIMPLE: 1,
            COMPOUND: 2
        },
        supplyType: {
            SELF_PROD: 1,
            PURCHASE: 2,
            SUBCONTRACT: 3,
            MIXED: 4
        },
        status: {
            INIT: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            SUBMITTED:DocumentContentProp.status.SUBMITTED,
            ACTIVE:DocumentContentProp.status.ACTIVE,
            ARCHIVED: DocumentContentProp.status.ARCHIVED
        },
        materialCategory: {
            RETAIL: 1,
            PRODUCT: 2,
            RAWMATERIAL: 3,
            SEMIPRODUCT: 4,
            AUXILIARY: 5
        }
    },

    MaterialStockKeepUnit: {
        traceMode: {
            NONE: 1,
            SINGE: 2,
            BATCH: 3
        },
        traceLevel: {
            TEMPLATE: 1,
            INSTANCE: 2
        },
        status: {
            INIT: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            SUBMITTED:DocumentContentProp.status.SUBMITTED,
            ACTIVE:DocumentContentProp.status.ACTIVE,
            ARCHIVED: DocumentContentProp.status.ARCHIVED
        },
        traceStatus: {
            INIT: 1,
            ACTIVE: 2,
            INUSE: 3,
            ARCHIVE: 4,
            WASTE: 5,
            DELETE: 6
        }

    },


    AccountObject: {
        AccountType: {
            IND_CUSTOMER: 1,
            COR_CUSTOMER: 2,
            EMPLOYEE: 3,
            TRANSIT_PARTNER: 4,
            EXTER_DRIVER: 5,
            ORGANIZATION: 6,
            SUPPIER: 7
        }
    },

    CorporateCustomer: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            INUSE:DocumentContentProp.status.ACTIVE,
            ARCHIVED: DocumentContentProp.status.ARCHIVED
        }
    },

    CorporateSupplier: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            INUSE:DocumentContentProp.status.ACTIVE,
            ARCHIVED: DocumentContentProp.status.ARCHIVED
        }

    },

    AuthorizationObject: {
        aoType: {
            SYS: 1,
            RESOURCE: 2,
            ACCTITLE: 3
        }
    },

    Cargo: {
        cargoType: {
            LIGHT: 1,
            HEAVY: 2,
            MIXED: 3
        }
    },

    CalendarTemplateItem: {
        periodType: {
            WEEK: 1,
            MONTH: 2,
            QUARTER: 3,
            YEAR: 4
        }
    },

    WorkCalendarDayItem: {
        dayStatus: {
            VOCATION: 1,
            WORK: 2
        }
    },

    BillOfMaterialOrder: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            INUSE: DocumentContentProp.status.ACTIVE,
            APPROVED: DocumentContentProp.status.APPROVED,
            RETIRED: DocumentContentProp.status.ARCHIVED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        }
    },

    BillOfMaterialTemplate: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            INUSE: DocumentContentProp.status.ACTIVE,
            RETIRED: DocumentContentProp.status.ARCHIVED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        }
    },

    FinAccountTitle: {
        FinAccountType: {
            DEBIT: 1,
            CREDIT: 2
        },
        Category: {
            GENERAL: 1,
            SECONDARY: 2,
            SUBSIDIARY: 3,
            FOURTH: 4,
            FIFTH: 5
        },
        originalType: {
            STANDARD: 1,
            CUST: 2
        }
    },

    FinAccount: {
        auditStatus: {
            UNDONE: 1,
            DONE: 2,
            REJECT: 3
        },

        verifyStatus: {
            UNDONE: 1,
            DONE: 2
        },

        recordStatus: {
            UNDONE: 1,
            DONE: 2
        },

        ADJUST: {
            DISCOUNT: 1,
            INCREASE: 2
        }
    },

    PurchaseContract: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            DELIVERY_DONE: DocumentContentProp.status.DELIVERY_DONE,
            PROCESS_DONE: DocumentContentProp.status.PROCESS_DONE,
            ARCHIVED: DocumentContentProp.status.ARCHIVED,
            CANCELED: DocumentContentProp.status.CANCELED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        }
    },

    PurchaseRequest: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            INPROCESS: DocumentContentProp.status.INPROCESS,
            DELIVERY_DONE: DocumentContentProp.status.DELIVERY_DONE,
            ARCHIVED: DocumentContentProp.status.ARCHIVED,
            CANCELED: DocumentContentProp.status.CANCELED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        }
    },

    PurchaseReturnOrder: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            DELIVERY_DONE: DocumentContentProp.status.DELIVERY_DONE,
            ARCHIVED: DocumentContentProp.status.ARCHIVED,
            CANCELED: DocumentContentProp.status.CANCELED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        }
    },

    Inquiry: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            IN_PROCESS: DocumentContentProp.status.INPROCESS,
            DELIVERY_DONE: DocumentContentProp.status.DELIVERY_DONE,
            PROCESS_DONE: DocumentContentProp.status.PROCESS_DONE,
            ARCHIVED: DocumentContentProp.status.ARCHIVED,
            CANCELED: DocumentContentProp.status.CANCELED,
            REVOKE_SUBMIT: DocumentContentProp.status.REVOKE_SUBMIT,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        }
    },

    StandardMaterialUnit: {

        unitCategory: {
            PACKAGE: 1,
            WEIGHT: 2,
            VOLUME: 3,
            LENGTH: 4
        }

    },

    SystemCodeValueCollection: {
        CollectionType: {
            SYSTEM: 1,
            CUSTOM: 2
        }
    },

    SystemExecutor: {
        status: {
            INIT: 1,
            ACTIVE: 2,
            ARCHIVE: 3
        }
    },

    SalesContract: {
        /**
         * Constant of SalesContract Status, should keep consistent with back-end.
         */
        status: {
            INITIAL:
            DocumentContentProp.status.INITIAL,
            APPROVED:
            DocumentContentProp.status.APPROVED,
            INPLAN:
                3,
            DELIVERY_DONE:
                4,
            PROCESS_DONE:
                5,
            ARCHIVED: DocumentContentProp.status.ARCHIVED,
            CANCELED: DocumentContentProp.status.CANCELED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        }
    },


    SalesReturnOrder: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            DELIVERY_DONE: 4,
            PROCESS_DONE: 5,
            ARCHIVED: DocumentContentProp.status.ARCHIVED,
            CANCELED: DocumentContentProp.status.CANCELED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        }
    },

    SalesForcast: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            IN_PLAN: 3,
            PROCESS_DONE: 4,
            ARCHIVED: DocumentContentProp.status.ARCHIVED,
            CANCELED: DocumentContentProp.status.CANCELED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        }
    },

    WasteProcessOrder: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            PROCESS_DONE: DocumentContentProp.status.PROCESS_DONE,
            DELIVERY_DONE: DocumentContentProp.status.DELIVERY_DONE,
            ARCHIVED: DocumentContentProp.status.ARCHIVED,
            CANCELED: DocumentContentProp.status.CANCELED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        },
        processType: {
            DISCARD: 1,
            SALESAS_WASTE: 2,
            SALESTO_SUPPLIER: 3
        }
    },

    SalesSettleOrder: {
        /**
         * Constant of SalesSettle Order, should keep consistent with back-end.
         */
        status: {
            INIT: 1,
            PARTICALLY_SETTLE:
                2,
            FULLY_SETTLE:
                3
        }
    },


    ProductionOrder: {
        /**
         * Constant of ProductionOrder Status, should keep consistent with back-end.
         */
        status: {
            INITIAL:
            DocumentContentProp.status.INITIAL,
            APPROVED:
            DocumentContentProp.status.APPROVED,
            INPRODUCTION:
            DocumentContentProp.status.INPROCESS,
            FINISHED:
            DocumentContentProp.status.DELIVERY_DONE,
            BLOCKED:
            DocumentContentProp.status.BLOCKED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        },

        category: {
            MANUAL: 1,
            SYSTEM: 2
        },

        doneStatus: {
            INITIAL: 1,
            PARTFINISH:
                2,
            FULLFINISH:
                3
        }
    },

    ProdOrderTargetMatItem: {
        status: {
            INIT: 1,
            INPROCESS:
                2,
            DONE_PRODUCTION:
                3,
            CANCELED:
                4
        }
    },

    RepairProdOrder: {
        /**
         * Constant of RepairProdOrder Status, should keep consistent with back-end.
         */
        status: {
            INITIAL:
            DocumentContentProp.status.INITIAL,
            APPROVED:
            DocumentContentProp.status.APPROVED,
            INPRODUCTION:
            DocumentContentProp.status.INPROCESS,
            FINISHED:
            DocumentContentProp.status.DELIVERY_DONE,
            BLOCKED:
            DocumentContentProp.status.BLOCKED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        },

        genOrderItemMode: {
            NO_NEED: 1,
            ADD_MANUAL: 2
        },

        category: {
            MANUAL: 1,
            SYSTEM: 2
        },

        doneStatus: {
            INITIAL: 1,
            PARTFINISH:
                2,
            FULLFINISH:
                3
        }
    },

    RepairProdTargetMatItem: {
        status: {
            INIT: DocumentContentProp.status.INITIAL,
            INPROCESS:
            DocumentContentProp.status.INPROCESS,
            DONE_PRODUCTION:
            DocumentContentProp.status.DELIVERY_DONE,
            CANCELED:
            DocumentContentProp.status.CANCELED
        }
    },


    ProdOrderReport: {
        /**
         * Constant of ProdOrderReport Report Status, should keep consistent with back-end.
         */
        reportStatus: {
            INIT: 1,
            FINISHED:
                2
        },

        reportCategory: {
            DONE: 1,
            PROBLEM: 2
        }
    },

    ProdPickingOrder: {
        /**
         * Constant of ProdPickingOrder Status, should keep consistent with back-end.
         */
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            INPROCESS:
            DocumentContentProp.status.INPROCESS,
            DELIVERY_DONE:
            DocumentContentProp.status.DELIVERY_DONE,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL
        },

        category: {
            MANUAL: 1,
            PRODORDER: 2,
            PRODORDERBATCH: 3
        },

        processType: {
            INPLAN: 1,
            REPLENISH: 2,
            RETURN: 3
        }
    },

    QualityInspectOrder: {
        /**
         * Constant of QualityInspectOrder, should keep consistent with back-end.
         */
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            INPROCESS:
            DocumentContentProp.status.INPROCESS,
            TESTDONE: 190,
            PROCESSDONE:DocumentContentProp.status.PROCESS_DONE
        },

        category: {
            INBOUND: 1,
            OUTBOUND:
                2,
            PRODUCTION:
                3
        },

        inspectType: {
            FULLINSPECT: 1,
            RAMINSPECT:
                2
        },

        checkStatus: {

            CHECKSTATUS_INITIAL: 1,

            CHECKSTATUS_PARTPASS: 2,

            CHECKSTATUS_FULLPASS: 3,

            CHECKSTATUS_NOTPASS: 4
        }
    },

    ProductionPlan: {
        /**
         * Constant of Production Plan Status, should keep consistent with back-end.
         */
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED,
            APPROVED:DocumentContentProp.status.APPROVED,
            INPRODUCTION:DocumentContentProp.status.INPROCESS,
            FINISHED:DocumentContentProp.status.DELIVERY_DONE,
            BLOCKED:DocumentContentProp.status.BLOCKED
        },

        category: {
            MANUAL: 1,
            SYSTEM: 2
        }
    },

    ProductionOrderItem: {
        /**
         * Constant of Production Plan Item Status, should keep consistent with back-end.
         */
        itemStatus: {
            INITIAL: 1,
            INPROCESS:
                2,
            LACKINPLAN:
                3,
            AVAILABLE:
                4,
            PART_AVAILABLE:
                5,
            ALL_DONE:
                6,
            PART_DONE:
                7
        }
    },


    RepairProdOrderItem: {
        /**
         * Constant of Production Plan Item Status, should keep consistent with back-end.
         */
        itemStatus: {
            INITIAL: 1,
            INPROCESS:
                2,
            LACKINPLAN:
                3,
            AVAILABLE:
                4,
            PART_AVAILABLE:
                5,
            ALL_DONE:
                6,
            PART_DONE:
                7
        }
    },

    Employee: {
        status: {
            INIT: 1,
            ACTIVE: 2,
            ARCHIVE: 3
        }
    },

    LogonUser: {
        status: {
            INIT: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            SUBMITTED: DocumentContentProp.status.SUBMITTED,
            REVOKE_SUBMIT: DocumentContentProp.status.REVOKE_SUBMIT,
            ACTIVE: DocumentContentProp.status.ACTIVE,
            ARCHIVE: DocumentContentProp.status.ARCHIVED
        }
    },

    Delivery: {
        /**
         * Constant of Delivery Order,  should keep consistent with back-end.
         */
        status: {
            INITIAL: 1,
            APPROVED:
                2,
            PROCESSDONE: DocumentContentProp.status.PROCESS_DONE,
            REVOKE_SUBMIT: DocumentContentProp.status.REVOKE_SUBMIT,
            DELIVERY_DONE: DocumentContentProp.status.DELIVERY_DONE,
            SUBMITTED:DocumentContentProp.status.SUBMITTED,
            REJECT: DocumentContentProp.status.REJECT_APPROVAL
        },

        approveStatus: {
            INIT: 1,
            ADOPT: 2,
            REJECT: 3
        },

        approveType: {
            MANUAL: 1,
            AUTO: 2
        },

        settleStatus: {
            INIT: 1,
            PARTIALDONE: 2,
            DONE: 3
        }

    },

    Warehouse: {
        refMaterialCategory: {
            NORMAL: 1,
            WASTE: 2
        }
    },

    WarehouseStoreItem: {

        status: {
            INSTOCK: 1,
            ARCHIVE: 2
        },

        batchMode: {
            MODE_DISPLAY: 1,
            MODE_MERGE: 2
        }
    },

    WarehouseStoreCheck: {
        STATUS_SUFFICIENT: 1,
        STATUS_INSUFFICIENT: 2,
        STATUS_EMPTY: 3
    },

    InventoryCheckOrder: {
        status: {
            INITIAL: DocumentContentProp.status.INITIAL,
            APPROVED: DocumentContentProp.status.APPROVED,
            DELIVERY_DONE: DocumentContentProp.status.DELIVERY_DONE,
            PROCESS_DONE: DocumentContentProp.status.PROCESS_DONE,
            ARCHIVED: DocumentContentProp.status.ARCHIVED,
            CANCELED: DocumentContentProp.status.CANCELED,
            REJECT_APPROVAL: DocumentContentProp.status.REJECT_APPROVAL,
            SUBMITTED: DocumentContentProp.status.SUBMITTED
        },
    },

    InventoryCheckItem: {
        checkResult: {
            BALANCE: 1,
            PROFIT: 2,
            LOSS: 3
        }
    }

};

/**
 * Constants class to store system configure all kinds of resources constants
 * Should be consistent with backend constant interface IServicePlatformSysConfigureConstants and its sub interfaces
 */
var SysConfigureConstants = {

    /**
     * Constants area of Extension Union
     */
    ExtensionUnion: {
        LogDeliveryApproveProcess: "LogDeliveryApproveProcess",
        Delivery_001Process: "Delivery_001Process",
        LogDeliveryCategory: "LogDeliveryCategory"
    },

    /**
     * Constants area of Code Value Union
     */
    CodeValueUnion: {
        Delivery_001Process_Auto: "1",
        Delivery_001Process_Manual: "2",
        LogDeliveryCategory_Standard: "1",
        LogDeliveryCategory_Manual: "2",
        LogDeliveryApproveProcess_Standard: "1",
        LogDeliveryApproveProcess_AutoApprove: "2",
        CurrencyCodeSetting_USD: "USD",
        CurrencyCodeSetting_CNY: "CNY",
        CurrencyCodeSetting_NZD: "NZD"
    },

    /**
     * Constants area of Code Value Collection
     */
    CodeValueCollection: {
        CurrencyCodeSetting: "PlatformCurrencyCodeSetting"
    }

};

