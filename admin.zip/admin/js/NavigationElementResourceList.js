var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        searchModuleURL: '../navigationElementResource/searchModuleService.html'
    },
    methods: {
        searchModule: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.searchModuleURL, requestData).then(function (response) {
                listVar.refreshTableItems(JSON.parse(response.data).content);
            });
        },
        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "NavigationElementResourceEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },
        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            name: "",
            id: "",
            parentElementId: "",
            displaySwitch: "",
            refAuthorizationObjectId: "",
            refNavigationGroupId: ""
        },

        label: {
            name: '',
            id: '',
            refNavigationGroupId: '',
            displaySwitch: '',
            refAuthorizationObjectId: '',
            parentElementId: '',
            clearSearch:'',
            clearSearchComment:'',
            advancedSearchCondition: ''
        },
        eleDisplaySwitch: '#x_displaySwitch',
        eleParentElementUUID: '#x_parentElementUUID',
        eleRefSimAuthorObjectUUID: '#x_refSimAuthorObjectUUID',
        eleRefNavigationGroupUUID: '#x_refNavigationGroupUUID',
        eleRefAuthorActionCodeUUID: '#x_refAuthorActionCodeUUID',
        loadSubNavigationElementResourceSelectListURL: '../subNavigationElementResource/loadModuleListService.html',
        loadParentNavigationElementResourceSelectListURL: '../parentNavigationElementResource/loadModuleListService.html',
        loadAuthorizationObjectSelectListURL: '../authorizationObject/loadModuleListService.html',
        loadNavigationGroupResourceSelectListURL: '../navigationGroupResource/loadModuleListService.html',
        loadActionCodeSelectListURL: '../actionCode/loadModuleListService.html',
        getSwitchMapURL: '../navigationElementResource/getSwitchMap.html'
    },


    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            vm.loadSubNavigationElementResourceSelectList();
            vm.loadParentNavigationElementResourceSelectList();
            vm.getDisplaySwitchMapList();
        });
    },
    methods: {
        clearSearch: function(){
            clearSearchModel(this.content);
        },
        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleDisplaySwitch).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'displaySwitch', $(vm.eleDisplaySwitch).val());

            });
            $(vm.eleParentElementUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.navigationElementResourceUIModel, 'parentElementUUID', $(vm.eleParentElementUUID).val());
            });
            $(vm.eleRefSimAuthorObjectUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.navigationElementResourceUIModel, 'refSimAuthorObjectUUID', $(vm.eleRefSimAuthorObjectUUID).val());
            });
            $(vm.eleRefNavigationGroupUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.navigationElementResourceUIModel, 'refNavigationGroupUUID', $(vm.eleRefNavigationGroupUUID).val());
            });
            $(vm.eleRefAuthorActionCodeUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.navigationElementResourceUIModel, 'refAuthorActionCodeUUID', $(vm.eleRefAuthorActionCodeUUID).val());
            });
        },
        loadSubNavigationElementResourceSelectList: function () {
            var vm = this;
            this.$http.get(this.loadSubNavigationElementResourceSelectListURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body), 'uuid', 'id', true);
                setTimeout(function () {
                    $(vm.eleUuid).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleUuid).val(vm.content.navigationElementResourceUIModel.uuid);
                    $(vm.eleUuid).trigger("change");
                }, 0);
            });
        },

        getDisplaySwitchMapList: function(){
            var vm = this;
            this.$http.get(this.getSwitchMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                resultList.splice(0, 0, {'id': '0', 'text': '-'});
                setTimeout(function () {
                    $(vm.eleDisplaySwitch).select2({
                        data: resultList
                    });
                }, 0);
            });
        },
        loadParentNavigationElementResourceSelectList: function () {
            var vm = this;
            this.$http.get(this.loadParentNavigationElementResourceSelectListURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body), 'uuid', 'id', true);
                setTimeout(function () {
                    $(vm.eleParentElementUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleParentElementUUID).val(vm.content.navigationElementResourceUIModel.parentElementUUID);
                    $(vm.eleParentElementUUID).trigger("change");
                }, 0);
            });
        }
    }
});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: {
            name: '',
            id: '',
            displaySwitch:'',
            refAuthorizationObjectId: "",
            refNavigationGroupId: "",
            parentElementId:'',

            msgConnectFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            buttonEdit: '',
            buttonView: ''
        },
        tableId: '#x_table_navigationElementResource',
        datatable: '',
        items: [],
        loadModuleListURL: '../navigationElementResource/loadModuleListService.html',
        preLockURL: '../navigationElementResource/preLockService.html'
    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'NavigationElementResource');
            this.datatable = new ServiceDataTable(this.tableId);
            this.setI18nProperties();
            this.loadModuleList();
        });
    },
    methods: {
        setI18nCommonProperties: function () {
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.buttonEdit = $.i18n.prop('edit');
            this.label.buttonView = $.i18n.prop('view');
            processModel.label.search = $.i18n.prop('search');
            processModel.label.add = $.i18n.prop('add');
            searchModel.label.advancedSearchCondition = $.i18n.prop('advancedSearchCondition');
            searchModel.label.clearSearch = $.i18n.prop('clearSearch');
            searchModel.label.clearSearchComment = $.i18n.prop('clearSearchComment');
            BusyLoader.cleanPageBackground();
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },
        setNodeI18nPropertiesCore: function () {
            this.label.name = $.i18n.prop('name');
            this.label.id = $.i18n.prop('id');
            this.label.displaySwitch = $.i18n.prop('displaySwitch');
            this.label.refAuthorizationObjectId = $.i18n.prop('refAuthorizationObjectId');
            this.label.refNavigationGroupId = $.i18n.prop('refNavigationGroupId');
            this.label.parentElementId = $.i18n.prop('parentElementId');
            searchModel.label.name = $.i18n.prop('name');
            searchModel.label.id = $.i18n.prop('id');
            searchModel.label.parentElementId = $.i18n.prop('parentElementId');
            searchModel.label.displaySwitch = $.i18n.prop('displaySwitch');
            searchModel.label.refAuthorizationObjectId = $.i18n.prop('refAuthorizationObjectId');
            searchModel.label.refNavigationGroupId = $.i18n.prop('refNavigationGroupId');
        },
        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'NavigationElementResource', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
        },
        getI18nPath: function () {
            return "coreFunction/";
        },
        loadModuleList: function () {
            var vm = this;
            this.$http.get(vm.loadModuleListURL).then(function (response) {
                if (!JSON.parse(response.data).content) {
                    $.Notification.notify('error', 'top center', this.label.msgConnectFailure, this.label.msgLoadDataFailure);
                    return;
                }
                vm.$set(vm, 'items', JSON.parse(response.data).content);
                setTimeout(function () {
                    vm.datatable.build();
                }, 0);
            });
        },
        refreshTableItems: function (items) {
            this.datatable = new ServiceDataTable(this.tableId);
            this.$set(this, 'items', items);
            setTimeout(function () {
                this.datatable.build();
            }, 0);

        },
        editModule: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            this.$http.post(vm.preLockURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.RC) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                if (oData.RC == HttpStatus.SC_OK) {
                    window.location.href = genCommonEditURL("NavigationElementResourceEditor.html", uuid);
                } else {
                    swal(this.label.lockFailureMessage, JSON.parse(response.data).MSG);
                }
            });
        },
        preLock: function () {
        }
    }
});
