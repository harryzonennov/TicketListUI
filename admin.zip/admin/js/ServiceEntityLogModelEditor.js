var dataVar = new Vue({
    el: "#x_data",
    data: {
        logitemTableId: '#x_table_serviceEntityLogItem',
        logitemTable: {},
        label: {
            messageType: '',
            processMode: '',
            refUUID: '',
            createdTime: '',
            id: '',
            name: '',
            refLogonUserId: '',
            refLogonUserName: '',
            note: '',
            lastUpdateTime:'',

            serviceEntityLogModelSection: '',
            logonUserSection: '',
            serviceEntityLogItemSection: '',

            msgSaveOK: '',
            msgSaveOKComment: '',
            msgConnectFailure: '',
            msgUnknowSystemFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            save: '',
            exit: '',
            quickEdit: '',
            buttonDelete: '',
            close: '',
            deleteWarnTitle: '',
            deleteWarnText: '',
            cancel: '',
            commit: '',
            confirm: '',
            addServiceEntityLogModel: '',
            addServiceEntityLogItem: '',
            serviceEntityLogItem: {
                newValue: '',
                fieldType: '',
                oldValue: '',
                name: '',
                id: ''
            }
        },
        content: {
            serviceEntityLogModelUIModel: {
                refNodeName: '',
                refSEName: '',
                messageType: '',
                processMode: '',
                refUUID: '',
                createdTime: '',
                createdBy: '',
                name: '',
                password: '',
                note: ''
            },
            serviceEntityLogItemUIModelList: []
        },
        cache: {
            serviceEntityLogItem: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refNodeName: '',
                refUUID: '',
                newValue: '',
                fieldType: '',
                oldValue: ''
            }

        },
        eleMessageType: '#x_messageType',
        eleProcessMode: '#x_processMode',
        eleRefUUID: '#x_refUUID',
        eleCreatedBy: '#x_createdBy',
        loadModuleEditURL: '../serviceEntityLogModel/loadModuleEditService.html',
        saveModuleURL: '../serviceEntityLogModel/saveModuleService.html',
        newModuleServiceURL: '../serviceEntityLogModel/newModuleService.html',
        eleEditServiceEntityLogItemModal: '#x_eleEditServiceEntityLogItemModal',
        getMessageTypeURL: '../serviceEntityLogModel/getMessageTypeMap.html',
        getProcessModeURL: '../serviceEntityLogModel/getProcessModeMap.html',
        exitURL: 'ServiceEntityLogModelList.html',
        exitModuleURL: '../serviceEntityLogModel/exitEditor.html'

    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            this.setI18nProperties();
            this.loadModuleEdit();
            this.logitemTable = new ServiceDataTable(this.logitemTableId);
            this.initSelectConfigure();
        }.bind(this));
    },

    methods: {
        editServiceEntityLogItemModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.serviceEntityLogItemUIModelList);
            if (!item) {
                return;
            }
            this.cache.serviceEntityLogItem = this.copyServiceEntityLogItem(item);
            $(this.eleEditServiceEntityLogItemModal).modal('toggle');

        },

        setToServiceEntityLogItem: function () {
            var item = this._filterItemByUUID(this.cache.serviceEntityLogItem.uuid, this.content.serviceEntityLogItemUIModelList);
            if (!item) {
                //In case new Item added
                var newItem = this.copyServiceEntityLogItem(this.cache.serviceEntityLogItem);
                this.content.serviceEntityLogItemUIModelList.push(newItem);
            } else {
                this.copyServiceEntityLogItem(this.cache.serviceEntityLogItem, item);
            }
            $(this.eleEditServiceEntityLogItemModal).modal('hide');
        },


        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.quickEdit = $.i18n.prop('quickEdit');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.deleteWarnTitle = $.i18n.prop('deleteWarnTitle');
            this.label.deleteWarnText = $.i18n.prop('deleteWarnText');
            this.label.cancel = $.i18n.prop('cancel');
            this.label.commit = $.i18n.prop('commit');
            this.label.confirm = $.i18n.prop('confirm');
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            this.label.messageType = $.i18n.prop('messageType');
            this.label.processMode = $.i18n.prop('processMode');
            this.label.createdTime = $.i18n.prop('createdTime');
            this.label.id = $.i18n.prop('id');
            this.label.name = $.i18n.prop('name');
            this.label.password = $.i18n.prop('password');
            this.label.note = $.i18n.prop('note');
            this.label.lastUpdateTime = $.i18n.prop('lastUpdateTime');
            this.label.serviceEntityLogModelSection = $.i18n.prop('serviceEntityLogModelSection');
            this.label.logonUserSection = $.i18n.prop('logonUserSection');
            this.label.serviceEntityLogItemSection = $.i18n.prop('serviceEntityLogItemSection');
            this.label.refLogonUserId = $.i18n.prop('refLogonUserId');
            this.label.id = $.i18n.prop('id');
            this.label.refLogonUserName = $.i18n.prop('refLogonUserName');
            this.label.name = $.i18n.prop('name');

        },

        setI18nLogItemProperties: function () {
            this.label.serviceEntityLogItem.newValue = $.i18n.prop('newValue');
            this.label.serviceEntityLogItem.fieldType = $.i18n.prop('fieldType');
            this.label.serviceEntityLogItem.oldValue = $.i18n.prop('oldValue');
            this.label.serviceEntityLogItem.id = $.i18n.prop('id');
            this.label.serviceEntityLogItem.name = $.i18n.prop('name');

        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'ServiceEntityLogModel', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
            jQuery.i18n.properties({
                name: 'ServiceEntityLogItem', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setI18nLogItemProperties
            });

        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        initSelectConfigure: function () {
            var vm = this;


        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var refSEName = getUrlVar("refSEName");
            vm.content.serviceEntityLogModelUIModel.refSEName = refSEName;
            if(refSEName === 'BidInvitationOrder'){
                Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'BidInvitationLogModel');
            }
            if(refSEName === 'InboundDelivery'){
                Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'InboundDeliveryLogModel');
            }
            if(refSEName === 'OutboundDelivery'){
                Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'OutboundDeliveryLogModel');
            }
            var url = this.loadModuleEditURL + "?uuid=" + baseUUID;
            this.$http.get(url).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                this.setModuleToUI(oData.content);
            });

        },


        copyServiceEntityLogItem: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refNodeName = origin.refNodeName;
            target.refUUID = origin.refUUID;
            target.newValue = origin.newValue;
            target.fieldType = origin.fieldType;
            target.oldValue = origin.oldValue;
            return target;
        },


        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.serviceEntityLogModelUIModel.uuid;
            var refSEName = vm.content.serviceEntityLogModelUIModel.refSEName;
            var exitURL = this.exitURL + '?refSEName=' + refSEName;
            defaultExitEditor(baseUUID, this.exitModuleURL, exitURL, UIFLAG_STANDARD);

        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.serviceEntityLogModelUIModel.uuid;
            window.location.href = genCommonEditURL("ServiceEntityLogModelEditor.html", baseUUID, tabKey);
        },

        getMessageType: function (content) {
            var vm = this;
            this.$http.get(this.getMessageTypeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleMessageType).select2({
                        data: JSON.parse(response.body)
                    })
                    // manually set initial value
                    $(vm.eleMessageType).val(content.serviceEntityLogModelUIModel.messageType);
                    $(vm.eleMessageType).trigger("change");
                }, 0);
            });

        },

        getProcessMode: function (content) {
            var vm = this;
            this.$http.get(this.getProcessModeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleProcessMode).select2({
                        data: JSON.parse(response.body)
                    })
                    // manually set initial value
                    $(vm.eleProcessMode).val(content.serviceEntityLogModelUIModel.processMode);
                    $(vm.eleProcessMode).trigger("change");
                }, 0);
            });
        },

        /**
         * Post process the logItem model list with field id & name translate into UI field
         * @param rawList
         */
        postProcessLogItemUIModelList: function(serviceEntityLogModelUIModel, rawLogItemUIModelList){
            "use strict";
            var vm = this;
            if(ServiceCollectionsHelper.checkNullList(rawLogItemUIModelList)){
                return;
            }
            var refSEName = serviceEntityLogModelUIModel.refSEName;
            var refNodeName = serviceEntityLogModelUIModel.refNodeName;
            var fieldI18nPromise = DocumentManagerFactory.getDocumentI18nPromise(refSEName, refNodeName);
            fieldI18nPromise.then(function(i18n){
                for (var i = 0, len = rawLogItemUIModelList.length; i < len; i++){
                    var fieldName = rawLogItemUIModelList[i].id;
                    if(i18n.prop(fieldName)){
                        rawLogItemUIModelList[i].name = i18n.prop(fieldName);
                    }
                }
                vm.$set(vm.content, 'serviceEntityLogItemUIModelList', rawLogItemUIModelList);
                setTimeout(function () {
                    vm.logitemTable.build();
                }, 0);
            });
        },


        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'serviceEntityLogModelUIModel', content.serviceEntityLogModelUIModel);
            vm.postProcessLogItemUIModelList(content.serviceEntityLogModelUIModel, content.serviceEntityLogItemUIModelList);
            vm.getMessageType(content);
            vm.getProcessMode(content);

        }

    }
});
