var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: {
            id: '',
            name: '',
            currencyCode: '',
            exchangeRate: '',
            note: '',
            defaultCurrency: '',
            activeFlag: '',
            pricingCurrencyConfigureSection: '',

            msgSaveOK: '',
            msgSaveOKComment: '',
            msgConnectFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            save: '',
            exit: '',
            close: '',
            commit: ''
        },
        author:{
            resourceId:'PricingCurrencyConfigure',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        content: {
            id: '',
            name: '',
            currencyCode: '',
            exchangeRate: '',
            defaultCurrency: '',
            activeFlag: '',
            note: ''
        },
        eleActiveFlag: '#x_activeFlag',
        eleDefaultCurrency: '#x_defaultCurrency',
        loadModuleEditURL: '../pricingCurrencyConfigure/loadModuleEditService.html',
        saveModuleURL: '../pricingCurrencyConfigure/saveModuleService.html',
        exitModuleURL: '../pricingCurrencyConfigure/exitEditor.html',
        newModuleServiceURL: '../pricingCurrencyConfigure/newModuleService.html'
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'PricingCurrencyConfigure');
            this.setI18nProperties();
            this.initAuthorResourceCheck();
            this.loadModuleEdit();
            this.initSwitchery();
        });
    },


    methods: {

        initAuthorResourceCheck: function(){
            var vm = this;
            var authorPromise = ServiceApplicationFactory.getAuthorizationObject(this.$http, this.author.resourceId, this.author.actionCode);
            authorPromise.then(function(oResult){
                vm.author = oResult;
            }, function (reason) {
                // don't do anything
            });
        },

        initSwitchery: function () {
            initSwitcheryCore(this.eleActiveFlag, '#00b19d', "#cad7e6");
            initSwitcheryCore(this.eleDefaultCurrency, '#00b19d', "#cad7e6");
        },

        initSetSwitch: function (content) {
            initSetSwitchCore(this.eleActiveFlag, content.activeFlag);
            initSetSwitchCore(this.eleDefaultCurrency, content.defaultCurrency);
        },

        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.commit = $.i18n.prop('commit');

        },

        setNodeI18nPropertiesCore: function () {
            this.label.id = $.i18n.prop('id');
            this.label.name = $.i18n.prop('name');
            this.label.currencyCode = $.i18n.prop('currencyCode');
            this.label.exchangeRate = $.i18n.prop('exchangeRate');
            this.label.note = $.i18n.prop('note');
            this.label.defaultCurrency =  $.i18n.prop('defaultCurrency');
            this.label.activeFlag =  $.i18n.prop('activeFlag');
            this.label.pricingCurrencyConfigureSection = $.i18n.prop('pricingCurrencyConfigureSection');

        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'PricingCurrencyConfigure', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });

        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            if (processMode === PROCESSMODE_NEW) {
                ServiceUtilityHelper.newModuleDefault({
                    newModuleServiceURL: vm.newModuleServiceURL,
                    vm:vm,
                    errorHandle:vm.errorHandle,
                    postSet:vm.setModuleToUI
                });
            }
            if (processMode === PROCESSMODE_EDIT) {
// In case [Edit mode]
                var url = this.loadModuleEditURL + "?uuid=" + baseUUID;
                this.$http.get(url).then(function (response) {
                    if (!JSON.parse(response.data).content) {
                        swal({
                            title: this.label.msgConnectFailure,
                            text: this.label.msgLoadDataFailure,
                            type: "error",
                            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                            confirmButtonText: this.label.confirm
                        });
                        return;
                    }
                    this.setModuleToUI(JSON.parse(response.data).content, true);
                });
            }


        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            this.$http.post(vm.saveModuleURL, vm.content).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                        container: $('.main.message-container')
                    });
                    return;
                }
                $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                this.setModuleToUI(oData.content);
                var processMode = getUrlVar(LABEL_PROCESSMODE);
                if (processMode && processMode == PROCESSMODE_NEW) {
                    var baseUUID = vm.content.uuid;
                    if (baseUUID) {
                        window.location.href = genCommonEditURL("PricingCurrencyConfigureEditor.html", baseUUID);
                    }
                }
            }).catch(function(error){
                ServiceHttpRequestHelper.handleErrorWithBarWrap(error, {
                    container: $('.main.message-container')
                });
                return;
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.parentNodeUUID;
            window.location.href = genCommonEditURL("PricingSettingEditor.html", baseUUID);

        },

        refreshEditView: function () {
            var baseUUID = this.content.uuid;
            window.location.href = genCommonEditURL("PricingCurrencyConfigureEditor.html", baseUUID);

        },

        setModuleToUI: function (content, initFlag) {
            var vm = this;
            vm.$set(vm, 'content', content);
            if(initFlag && initFlag === true){
                vm.initSetSwitch(content);
            }
        }

    }
});
