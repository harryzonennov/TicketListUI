
var dataVar = new Vue({
    el: "#x_data",
    mixins: [ServiceItemEditorHelper.defControlMinxin],
    data: {
        label: MaterialConfigureTemplateManager.label.matDecisionValueSetting,
        content: {
            matDecisionValueSettingUIModel:MaterialConfigureTemplateManager.content.matDecisionValueSettingUIModel
        },
        processButtonMeta: [],
        getValueUsageURL: '../matDecisionValueSetting/getValueUsage.html',
        getPageHeaderModelListURL: '../matDecisionValueSetting/getPageHeaderModelList.html',
        exitModuleURL: '../matDecisionValueSetting/exitEditor.html'
    },

    mounted: function () {
        NavigationPanelIns.initNavigation('systemAdmin', 'MaterialConfigureTemplate');
    },

    methods: {

        getServiceManager: function () {
            return MaterialConfigureTemplateManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "MatConfigValueSettingEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.matDecisionValueSettingUIModel.uuid;
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getParentUUID: function () {
            return this.content.matDecisionValueSettingUIModel.parentNodeUUID;
        },

        getI18nConfig: function() {
            return MaterialConfigureTemplateManager.getI18nDecisionValueSetting();
        },

        hideForUsageInput: function(){
            "use strict";
            var vm = this;
            var displayFlag = MaterialConfigureTemplateManager.valueUsageSelectable(vm.content.matDecisionValueSettingUIModel.valueUsage);
            return DocumentManagerFactory.formatDisplayClass(displayFlag);
        },

        hideForUsageSelect: function(){
            "use strict";
            var vm = this;
            var displayFlag = !MaterialConfigureTemplateManager.valueUsageSelectable(vm.content.matDecisionValueSettingUIModel.valueUsage);
            return DocumentManagerFactory.formatDisplayClass(displayFlag);
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'matDecisionValueSettingUIModel', content.matDecisionValueSettingUIModel);
            vm.postUpdateUIModel();
        },

        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'MatConfigValueSettingEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: MaterialConfigureTemplateManager,
                coreModelId: 'MatDecisionValueSetting',
                i18nPath: 'coreFunction/',
                helpDocumentName: ['MatConfigValueSettingHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: vm.displayForEdit,
                        callback: vm.saveModule
                    },
                    exit: {
                        callback: vm.exitModule
                    }
                },
                pageHeaderConfig: [{
                    nodeInstId: 'materialConfigureTemplate',
                    baseEditUrl:"MaterialConfigureTemplateEditor.html",
                    targetTab: MaterialConfigureTemplateManager.documentTab.matDecisionValueSettingSection,
                    pageTitlePath: 'parentPageTitle' ,
                    pageTitleVarPath: 'templateId'
                },{
                    active: true,
                    nodeInstId: 'matDecisionValueSetting',
                    baseEditUrl:"MatDecisionValueSettingEditor.html",
                    pageTitlePath: 'pageHeaderTitle' ,
                    pageTitleVarPath: 'name'
                }],
                tabMetaList: [{
                    tabId: 'matDecisionValueSettingSection',
                    tabTitleKey: 'matDecisionValueSettingSection',
                    titleLabelKey: 'matDecisionValueSettingSection',
                    titleHelpKey: 'materialStockKeepUnit.matDecisionValueSettingSection',
                    titleIcon: 'md md-straighten content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'materialUnitSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'matDecisionValueSettingUIModel',
                        tabTitleKey: 'materialUnitSection',
                        titleLabelKey: 'materialUnitSection',
                        titleHelpKey: 'material.materialUnitSection',
                        titleIcon: 'md md-texture content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'valueUsage',
                            helpKey: 'matDecisionValueSetting.valueUsage',
                            newRow: true,
                            settings: {
                                getMetaDataUrl: vm.getValueUsageURL,
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'id',
                            newRow: true
                        }, {
                            fieldName: 'name'
                        }, {
                            fieldName: 'rawValue',
                            hidden: 'hideForUsageInput',
                        }, {
                            fieldName: 'rawValue',
                            newRow: true,
                            helpKey: 'matDecisionValueSetting.rawValue',
                            hidden: 'hideForUsageSelect',
                            settings: {
                                getMetaDataUrl: vm.getRefNodeInstIdURL
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'valueId',
                            disabled: true,
                            helpKey: 'matDecisionValueSetting.valueId'
                        }, {
                            fieldName: 'valueName',
                            disabled: true,
                            helpKey: 'matDecisionValueSetting.valueName'
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        } ]
                    }]
                }]
            };
        }

    }
});
