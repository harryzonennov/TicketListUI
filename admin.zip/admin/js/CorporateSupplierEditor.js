var dataVar = new Vue({
    el: "#x_data",
    mixins: [CorporateSupplierManager.labelTemplate],
    data: {
        contactpersonTableId: '#x_table_corporateContactPerson',
        contactpersonTable: {},
        label: CorporateSupplierManager.label.corporateSupplier,
        content: {
            corporateSupplierUIModel: CorporateSupplierManager.content.corporateSupplierUIModel,
            corporateContactPersonUIModelList: [],
            corporateCustomerAttachmentUIModelList: []
        },
        addressInfoInit: false, // Indicator whethear 'AddressInfo' has initial value.
        getSupplierLevelMapURL:'../corporateSupplier/loadSupplierLevelMap.html',
        loadCitySelectListURL: '../city/loadLeanModuleListService.html',
        newCorporateContactPersonServiceURL: '../individualCustomer/newContactCustomerService.html',
        eleEditCorporateContactPersonModal: '#x_eleEditCorporateContactPersonModal',
        eleCityName:'#x_cityName',
        exitURL: 'CorporateSupplierList.html',
        exitModuleURL: '../corporateSupplier/exitEditor.html'
    },

    mounted: function () {
        NavigationPanelIns.initNavigation('logistics', 'CorporateSupplier');
    },

    watch: {
        'content.corporateSupplierUIModel.stateName': function (stateName) {
            this.updateAddressInfo({
                stateName: stateName,
                cityName:  this.content.corporateSupplierUIModel.cityName,
                townZone: this.content.corporateSupplierUIModel.townZone,
                streetName: this.content.corporateSupplierUIModel.streetName,
                telephone:this.content.corporateSupplierUIModel.contactTelephone
            });
        },
        'content.corporateSupplierUIModel.cityName': function (cityName) {
            this.updateAddressInfo({
                stateName: this.content.corporateSupplierUIModel.stateName,
                cityName: cityName,
                townZone: this.content.corporateSupplierUIModel.townZone,
                streetName: this.content.corporateSupplierUIModel.streetName,
                telephone:this.content.corporateSupplierUIModel.telephone
            });
        },
        'content.corporateSupplierUIModel.townZone': function (townZone) {
            this.updateAddressInfo({
                stateName: this.content.corporateSupplierUIModel.stateName,
                cityName: this.content.corporateSupplierUIModel.cityName,
                townZone: townZone,
                streetName: this.content.corporateSupplierUIModel.streetName,
                telephone:this.content.corporateSupplierUIModel.telephone
            });
        },
        'content.corporateSupplierUIModel.streetName': function (streetName) {
            this.updateAddressInfo({
                stateName: this.content.corporateSupplierUIModel.stateName,
                cityName: this.content.corporateSupplierUIModel.cityName,
                townZone: this.content.corporateSupplierUIModel.townZone,
                streetName: streetName,
                telephone:this.content.corporateSupplierUIModel.telephone
            });
        },
        'content.corporateSupplierUIModel.telephone': function (telephone) {
            this.updateAddressInfo({
                stateName: this.content.corporateSupplierUIModel.stateName,
                cityName: this.content.corporateSupplierUIModel.cityName,
                townZone: this.content.corporateSupplierUIModel.townZone,
                streetName: this.content.corporateSupplierUIModel.streetName,
                telephone:telephone
            });
        }
    },

    methods: {


        /**
         * @Overwrite: Get document type for each edit controller
         */
        getDocumentType: function () {
            return DocumentConstants.DummyDocumentType.CorporateSupplier;
        },

        getServiceManager: function () {
            return CorporateSupplierManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "CorporateSupplierEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.corporateSupplierUIModel.uuid;
        },

        /**
         * @Overwrite: get document status from content
         */
        getStatus: function () {
            return this.content.corporateSupplierUIModel.status;
        },


        updateAddressInfo: function (oSettings) {
            var vm = this;
            var address = ServiceUtilityHelper.buildAddressInfo(oSettings);
            if(!vm.addressInfoInit){
                vm.$set(vm.content.corporateSupplierUIModel, 'address', address);
            }
        },


        /**
         * Deprecate
         */
        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }
        },

        deleteCoporateContact: function (uuid) {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.corporateContactPersonUIModelList);
                        if (!item) {
                            return;
                        }
                        vm.content.corporateContactPersonUIModelList.$remove(item);
                    } else {
                        // do nothing, just return
                    }
                });
        },

        /**
         * @Overwrite provide doc action code matrix
         * @return {*}
         */
        getActionCodeMatrix: function () {
            return {
                submit: {actionCode: CorporateSupplierManager.DOC_ACTION_CODE.SUBMIT},
                revokeSubmit: {actionCode: CorporateSupplierManager.DOC_ACTION_CODE.REVOKE_SUBMIT},
                approve: {actionCode: CorporateSupplierManager.DOC_ACTION_CODE.APPROVE},
                reInit: {actionCode: CorporateSupplierManager.DOC_ACTION_CODE.REINIT},
                rejectApprove: {actionCode: CorporateSupplierManager.DOC_ACTION_CODE.REJECT_APPROVE},
                countApprove: {actionCode: CorporateSupplierManager.DOC_ACTION_CODE.COUNTAPPROVE},
                active: {actionCode: CorporateSupplierManager.DOC_ACTION_CODE.ACTIVE},
                archive: {actionCode: CorporateSupplierManager.DOC_ACTION_CODE.ARCHIVE}
            };
        },

        setModuleToUI: function (content) {
            var vm = this;
            if(content.corporateSupplierUIModel.address){
                vm.$set(vm, 'addressInfoInit', true);
            }
            vm.$set(vm.content, 'corporateSupplierUIModel', content.corporateSupplierUIModel);
            vm.$set(vm.content, 'corporateContactPersonUIModelList', content.corporateContactPersonUIModelList);
            vm.$set(vm.content, 'corporateCustomerAttachmentUIModelList', content.corporateCustomerAttachmentUIModelList);
            vm.postUpdateUIModel();
        },

        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'CorporateSupplierEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: CorporateSupplierManager,
                coreModelId: 'CorporateSupplier',
                i18nPath: 'coreFunction/',
                getDocActionNodeListURL: '../corporateSupplier/getDocActionNodeList.html',
                helpDocumentName: ['CorporateSupplierHelpDocument', 'CorporateContactPersonHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: 'displayForEdit',
                        callback: 'saveModule'
                    },
                    placeholder: {
                        category: ProcessButtonConstants.placeholderCategory.DOC_ACTION_BTN
                    },
                    exit: {
                        callback: 'exitModule'
                    }
                },
                tabMetaList: [{
                    tabId: 'corporateSupplierSection',
                    tabTitleKey: 'corporateSupplierSection',
                    titleLabelKey: 'corporateSupplierSection',
                    titleHelpKey: 'corporateSupplier.corporateSupplierSection',
                    titleIcon: 'md md-texture content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'corporateSupplierSection',
                        updatedByUidPath: 'updatedByUUID',
                        updatedByNamePath: 'updatedByName',
                        updatedDatePath: 'updatedDate',
                        messageResponsePath: 'meta.messageResponse',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'corporateSupplierUIModel',
                        tabTitleKey: 'corporateSupplierSection',
                        titleLabelKey: 'corporateSupplierSection',
                        titleHelpKey: 'corporateSupplier.corporateSupplierSection',
                        titleIcon: 'md md-texture content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'id',
                            required: true,
                            newRow: true
                        }, {
                            required: true,
                            fieldName: 'name',
                        }, {
                            fieldName: 'status',
                            disabled: true,
                            helpKey: 'corporateSupplier.status',
                            settings: {
                                getMetaDataUrl: vm.getStatusURL,
                                formatMeta: 'formatStatus'
                            },
                            iconArray: 'getStatusIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'depositBank',
                        }, {
                            fieldName: 'bankAccount',
                        }, {
                            fieldName: 'taxNumber',
                        }, {
                            fieldName: 'customerLevel',
                            disabled: true,
                            helpKey: 'corporateSupplier.customerLevel',
                            settings: {
                                getMetaDataUrlFunc: vm.getCustomerLevelMapURL,
                                formatMetaCallback: 'formatCustomerLevel'
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        }]
                    }, {
                        sectionId: 'corporateContactSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'corporateSupplierUIModel',
                        tabTitleKey: 'corporateSupplierSection',
                        titleLabelKey: 'corporateSupplierSection',
                        titleHelpKey: 'corporateSupplier.corporateSupplierSection',
                        titleIcon: 'md md-straighten content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'telephone',
                            newRow: true,
                        }, {
                            fieldName: 'fax',
                        }, {
                            fieldName: 'weiXinID'
                        }, {
                            newRow: true,
                            fieldName: 'stateName'
                        }, {
                            fieldName: 'cityName'
                        }, {
                            fieldName: 'townZone'
                        }, {
                            fieldName: 'streetName'
                        }, {
                            fieldName: 'address',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        }]
                    }, {
                        tabId: 'corporateContactPersonSection',
                        tabTitleKey: 'corporateContactPersonSection',
                        editBlock: true,
                        sectionMetaList: [{
                            sectionId: 'corporateContactPersonSection',
                            parentContentPath: 'corporateContactPersonUIModelList',
                            sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                            detailedPageUrl: 'CorporateContactPersonEditor.html',
                            editModuleFlag: true,
                            requiredSubmit: true,
                            tabTitleKey: 'corporateContactPersonSection',
                            titleLabelKey: 'corporateContactPersonSection',
                            titleHelpKey: 'corporateSupplier.corporateContactPersonSection',
                            titleIcon: 'md md-my-library-books content-portlet-title',
                            scrollX: true,
                            embedProcessButtonMeta: {
                                addDisableFlag: 'disableNotInInit',
                                addTitle: 'addCorporateContactPersonTitle',
                                newModuleFlag: true,
                                // addCallback: 'addCorporateContactPerson',
                                addLabel: 'addCorporateContactPerson'
                            },
                            fieldMetaList: [{
                                fieldName: 'corporateContactPersonUIModel.uuid'
                            }, {
                                fieldName: 'corporateContactPersonUIModel.name',
                                labelKey: 'corporateContactPerson.name',
                                minWidth: '180px'
                            }, {
                                fieldName: 'corporateContactPersonUIModel.contactRoleNote',
                                labelKey: 'corporateContactPerson.contactRole',
                                minWidth: '180px'
                            }, {
                                fieldName: 'corporateContactPersonUIModel.contactPositionNote',
                                labelKey: 'corporateContactPerson.contactPosition',
                            }, {
                                fieldName: 'corporateContactPersonUIModel.mobile',
                                labelKey: 'corporateContactPerson.mobile',
                            }, {
                                fieldName: 'corporateContactPersonUIModel.email',
                                labelKey: 'corporateContactPerson.email',
                                minWidth: '180px'
                            }]
                        }]
                    }]
                }]
            };
        }

    }
});
