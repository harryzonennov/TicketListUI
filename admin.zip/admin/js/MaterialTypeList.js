var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        downloadExcelURL: '../material/downloadExcel.html',
        searchModuleURL: '../materialType/searchModuleService.html'
    },
    author:{
        resourceId:'MaterialType',
        actionCode:{
            Edit:false,
            View:false,
            Excel: false,
            Delete: false
        }
    },

    created: function(){
        this.initSubComponents();
        this.initAuthorResourceCheck();
    },

    methods: {

        searchModule: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.searchModuleURL, requestData).then(function (response) {
                listVar.$set(vm, 'items', JSON.parse(response.data).content);
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    formatClass: vm.displayForEdit,
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "MaterialTypeEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        newModuleModal: function () {
            listVar.newModuleModal();
        },

        uploadExcel: function(){
            listVar.uploadExcel();
        },

        showExcelButton: function(){
            return this.author.actionCode.Excel;
        },

        downloadExcel: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.downloadExcelURL, requestData).then(function (response) {
                ExcelUploadAttach.showFile(response.body, vm.label.reportTitle);
                // vm.showFile(response.body);
            }.bind(this));
        }
    }
});

var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            parentTypeUUID: "",
            rootTypeName: "",
            rootTypeId: "",
            parentTypeName: "",
            parentTypeId: "",
            rootTypeUUID: "",
            name: "",
            id: ""

        },

        label: MaterialTypeManager.label.materialType,
        eleParentTypeUUID:'#x_parentTypeUUID',
        eleRootTypeUUID:'#x_rootTypeUUID',
        loadModuleListURL: '../materialType/loadModuleListService.html',
        loadModuleViewURL: '../materialType/loadModuleViewService.html',
        loadModuleEditURL: '../materialType/loadModuleEditService.html'

    },

    mounted:function(){
        this.initSelectConfigure();
        this.loadParentTypeList(this.content);
        this.loadRootTypeList(this.content);
    },

    methods:{

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleParentTypeUUID).on("select2:close", function (e) {
                var parentTypeUUIDValue = $(vm.eleParentTypeUUID).val();
                if(!parentTypeUUIDValue || parentTypeUUIDValue === ''){
                    vm.$set('content.parentTypeUUID', parentTypeUUIDValue);
                    vm.$set('content.parentTypeName', '');
                    vm.$set('content.rootTypeId', '');
                    vm.$set('content.rootTypeName', '');
                }
                // Set value to vue from select2 manually by select2's bug
                vm.$set('content.parentTypeUUID', parentTypeUUIDValue);
                var url = vm.loadModuleViewURL + "?uuid=" + $(vm.eleParentTypeUUID).val();
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        listVar.errorHandle(oData);
                        return;
                    }
                    var content = oData.content;
                    vm.$set('content.parentTypeName', content.name);
                    vm.$set('content.rootTypeId', content.rootTypeId);
                    vm.$set('content.rootTypeName', content.rootTypeName);
                });
            });

            $(vm.eleRootTypeUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set('content.rootTypeUUID', $(vm.eleRootTypeUUID).val());
                var url = vm.loadModuleViewURL + "?uuid=" + $(vm.eleRootTypeUUID).val();
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        listVar.errorHandle(oData);
                        return;
                    }
                    var content = oData.content;
                    // Clear the parent type search information
                    vm.$set('content.parentTypeUUID', '');
                    vm.$set('content.parentTypeName', '');
                    vm.$set('content.rootTypeId', content.rootTypeId);
                    vm.$set('content.rootTypeName', content.rootTypeName);
                });
            });
        },

        loadParentTypeList:function(searchContent) {
            var vm = this;
            this.$http.get(this.loadModuleListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSearchSelectResult(JSON.parse(response.body).content, 'uuid', 'id');
                setTimeout(function () {
                    $(vm.eleParentTypeUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleParentTypeUUID).val(searchContent.parentTypeUUID);
                    $(vm.eleParentTypeUUID).trigger("change");
                }, 0);
            });
        },

        loadRootTypeList:function(searchContent) {
            var vm = this;
            //TODO change into root type list later
            this.$http.get(this.loadModuleListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSearchSelectResult(JSON.parse(response.body).content, 'uuid', 'id');
                setTimeout(function () {
                    $(vm.eleRootTypeUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRootTypeUUID).val(searchContent.rootTypeUUID);
                    $(vm.eleRootTypeUUID).trigger("change");
                }, 0);
            });
        }

    }
});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: MaterialTypeManager.label.materialType,
        cache: {
            uuid: '',
            parentNodeUUID: '',
            rootNodeUUID: '',
            client: '',
            parentTypeUUID: '',
            name: '',
            note: '',
            id: '',
            rootTypeUUID: '',
            rootTypeName: '',
            rootTypeNote: '',
            rootTypeId: '',
            parentTypeName: '',
            parentTypeNote: '',
            parentTypeId: ''
        },

        configMetaUploadExcel:{
            uploadAttachmentURL: '../materialType/uploadExcel.html',
            successCallback:function(){

            }
        },
        eleEditMaterialTypeModal: '#x_eleEditMaterialTypeModal',

        tableId: '#x_table_materialType',
        datatable: '',
        items: [],
        loadModuleListURL: '../materialType/loadModuleListService.html',
        preLockURL: '../materialType/preLockService.html',
        newModuleServiceURL: '../materialType/newModuleService.html',
        saveModuleURL: '../materialType/saveModuleService.html'
    },

    mounted: function () {
        var vm = this;
        NavigationPanelIns.initNavigation('systemAdmin', 'MaterialType');
        this.datatable = new ServiceDataTable(this.tableId);
        this.setI18nProperties(processModel.initProcessButtonMeta);
        this.loadModuleList();
    },

    methods: {
        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties, serviceUIMeta: processModel.serviceUIMeta,
                fnCallback: fnCallback,
                label: [vm.label, processModel.label, searchModel.label], vm: processModel, errorHandle: vm.errorHandle,
                configList: [{
                    name: 'MaterialType',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        loadModuleList: function () {
            var vm = this;
            this.$http.get(vm.loadModuleListURL).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    vm.errorHandle(oData);
                    return;
                }
                vm.$set(vm, 'items', JSON.parse(response.data).content);
                setTimeout(function () {
                    vm.datatable.build();
                }, 0);
            }).catch(function (error) {
                vm.errorHandle(error);
            });
        },

        uploadExcel: function () {
            // refresh success call back
            this.$set(this.configMetaUploadExcel, 'successCallback', this.searchTableList);
            this.$refs.excelUploadModal.popup(vm.configMetaUploadExcel);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                $http:vm.$http,
                author:processModel.author,
                editorPage:"MaterialTypeEditor.html",
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        editModuleModal: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                author:processModel.author,
                $http:vm.$http,
                postHandle:function(oData){
                    vm.cache = vm.copyModule(oData.content, vm.cache);
                    $(vm.eleEditMaterialTypeModal).modal('toggle');
                },
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });

        },
        copyModule: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.parentTypeUUID = origin.parentTypeUUID;
            target.note = origin.note;
            target.parentTypeUUID = origin.parentTypeUUID;

        },
        saveToModule: function () {
            var vm = this;
            this.$http.post(this.saveModuleURL, vm.cache).then(function (response) {
                $(this.eleEditMaterialTypeModal).modal('hide');// Also update to current items
                var item = vm._filterItemByUUID(this.cache.uuid);
                if (!item) {
                    if (!this.cache.uuid) {
                        return;
                    }
                    var newItem = this.copyModule(this.cache);
// In case new item added.
                    this.items.push(newItem);
                } else {
                    this.copyModule(this.cache, item);
                }
                $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
            });
        },
        newModuleModal: function () {
            var requestData = {};
            this.$http.post(this.newModuleServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    vm.errorHandle(oData);
                    return;
                }
// In case success.
                this.cache = this.copyModule(JSON.parse(response.data).content, this.cache);
                $(this.eleEditMaterialTypeModal).modal('toggle');
            });
        },

        _filterItemByUUID: function (uuid) {
            if (!this.items) {
                return;
            }
            for (var i = 0; i < this.items.length; i++) {
                if (uuid === this.items[i].uuid) {
                    return this.items[i];
                }
            }
        }
    }
});
