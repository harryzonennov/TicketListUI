/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var RegisteredProductManager = function () {

};

RegisteredProductManager.label = {
    registeredProduct:ServiceUtilityHelper.getComLabelObject({
        mainMaterialUnitName: '',
        length: '',
        traceStatus: '',
        productionBatchNumber: '',
        validToDate: '',
        validPeriodUnit: '',
        barcode: '',
        size: '',
        retailPrice: '',
        refVolumeUnit: '',
        unitCost: '',
        traceLevel: '',
        modelTitle:'',
        volume: '',
        mainMaterialUnit: '',
        cargoType: '',
        purchasePrice: '',
        grossWeight: '',
        refWeightUnit: '',
        netWeight: '',
        supplyType: '',
        operationMode: '',
        packageStandard: '',
        traceMode: '',
        referenceDate: '',
        switchFlag: '',
        serialId: '',
        productionDate: '',
        qualityInspectFlag:'',
        width: '',
        productionPlace: '',
        validPeriodValue: '',
        refLengthUnit: '',
        height: '',
        validFromDate: '',
        attachmentSection: '',
        documentFlowSection:'',
        materialSizeSection:'',
        materialPriceSection:'',
        packageMaterialType: '',
        buttonEdit: '',
        buttonView: '',

        refPurchaseOrgUUID: '',
        purchaseOrgContactName: '',
        purchaseOrganizationAddress: '',
        purchaseOrganizationTaxNumber: '',
        purchaseOrgContactId: '',
        purchaseOrgContactMobile: '',
        purchaseOrgContactWeixin: '',
        purchaseOrganizationFax: '',
        purchaseOrganizationId: '',
        partyRole: '',
        purchaseOrganizationTelephone: '',
        purchaseOrganizationBankAccount: '',
        purchaseOrgContactEmail: '',
        purchaseOrganizationEmail: '',
        purchaseOrganizationName: '',

        refCustomerUUID: '',
        corporateCustomerName: '',
        customerContactName: '',
        customerContactId: '',
        customerContactWeixin: '',
        corporateCustomerAddress: '',
        corporateCustomerTaxNumber: '',
        corporateCustomerTelephone: '',
        corporateCustomerId: '',
        customerContactMobile: '',
        corporateCustomerRole: '',
        corporateCustomerBankAccount: '',
        customerContactEmail: '',
        corporateCustomerEmail: '',

        refSalesOrgUUID: '',
        salesOrganizationId: '',
        salesOrgContactId: '',
        salesOrgContactName: '',
        salesOrganizationName: '',
        salesOrgContactMobile: '',
        salesOrganizationTaxNumber: '',
        salesOrganizationFax: '',
        salesOrganizationBankAccount: '',
        salesOrgContactWeixin: '',
        salesOrganizationAddress: '',
        salesOrganizationTelephone: '',
        salesOrganizationEmail: '',
        salesOrgContactEmail: '',

        refSupportOrgUUID: '',
        supportOrganizationId: '',
        supportOrgContactId: '',
        supportOrgContactName: '',
        supportOrganizationName: '',
        supportOrgContactMobile: '',
        supportOrganizationTaxNumber: '',
        supportOrganizationFax: '',
        supportOrganizationBankAccount: '',
        supportOrgContactWeixin: '',
        supportOrganizationAddress: '',
        supportOrganizationTelephone: '',
        supportOrganizationEmail: '',
        supportOrgContactEmail: '',

        refProductOrgUUID: '',
        productOrganizationId: '',
        productOrgContactId: '',
        productOrgContactName: '',
        productOrganizationName: '',
        productOrgContactMobile: '',
        productOrganizationTaxNumber: '',
        productOrganizationFax: '',
        productOrganizationBankAccount: '',
        productOrgContactWeixin: '',
        productOrganizationAddress: '',
        productOrganizationTelephone: '',
        productOrganizationEmail: '',
        productOrgContactEmail: '',

        refSupplierUUID: '',
        supplierContactName: '',
        corporateSupplierName: '',
        corporateSupplierBankAccount: '',
        corporateSupplierAddress: '',
        corporateSupplierTelephone: '',
        supplierContactWeixin: '',
        corporateSupplierId: '',
        supplierContactId: '',
        corporateSupplierTaxNumber: '',
        supplierContactMobile: '',
        corporateSupplierFax: '',
        corporateSupplierEmail: '',
        supplierContactEmail: '',

        refMaterialSKUName: '',
        refMaterialSKUId: '',
        addRegisteredProduct: '',
        addPurchaseOrgParty: '',
        addSalesOrgParty: '',
        addCustomerParty: '',
        addSupplierParty: '',
        addMaterialStockKeepUnit: '',
        addRegisteredProductExtendProperty: '',

        basicPropertySection:'',
        registeredProductSection: '',
        purchaseOrgContactSection: '',
        productOrganizationSection:'',
        salesOrganizationSection: '',
        corporateCustomerSection: '',
        corporateSupplierSection: '',
        materialStockKeepUnitSection: '',
        productExtendPropertySection: '',
        registeredProductExtendSection:'',
        searchPlaceHolder: '',
        materialCategory:'',
        clearSearch:'',
        clearSearchComment:'',
        advancedSearchCondition: ''
    }),
    registeredProductExtendProperty:ServiceUtilityHelper.getComLabelObject({
        rawValue:'',
        qualityInspectFlag:'',
        measureFlag:'',
        refMaterialSKUId:'',
        refMaterialSKUName:'',
        packageStandard:'',
        refSerialId:'',
        valueSettingName: '',
        valueUsage: '',
        refUnitValue: '',
        refUnitUUID: '',
        matDecisionValueSettingNote: '',
        addRegisteredProductExtendProperty: '',
        addMatDecisionValueSetting: '',
        parentPageTitle:'',
        registeredProductExtendPropertySection: '',
        matDecisionValueSettingSection: '',
    })
};

RegisteredProductManager.content = {
    registeredProductUIModel: {
        client: '',
        refTemplateUUID: '',
        uuid: '',
        id: '',
        mainMaterialUnitName: '',
        name: '',
        length: '',
        minStoreNumber: '',
        packageMaterialType: '',
        traceStatus: '',
        productionBatchNumber: '',
        validToDate: '',
        validPeriodUnit: '',
        barcode: '',
        qualityInspectFlag:'',
        size: '',
        refVolumeUnit: '',
        unitCost: '',
        traceLevel: '',
        memberSalePrice: '',
        volume: '',
        mainMaterialUnit: '',
        purchasePrice: '',
        grossWeight: '',
        refWeightUnit: '',
        netWeight: '',
        operationMode: '',
        traceMode: '',
        referenceDate: '',
        switchFlag: '',
        serialId: '',
        productionDate: '',
        width: '',
        productionPlace: '',
        validPeriodValue: '',
        refLengthUnit: '',
        height: '',
        validFromDate: '',
        note: '',
        refNodeName: '',

        refPurchaseOrgUUID: '',
        purchaseOrgContactName: '',
        purchaseOrganizationAddress: '',
        purchaseOrganizationTaxNumber: '',
        purchaseOrgContactId: '',
        purchaseOrgContactMobile: '',
        purchaseOrgContactWeixin: '',
        purchaseOrganizationFax: '',
        purchaseOrganizationId: '',
        purchaseOrganizationTelephone: '',
        purchaseOrganizationBankAccount: '',
        purchaseOrgContactEmail: '',
        purchaseOrganizationEmail: '',
        purchaseOrganizationName: '',

        refCustomerUUID: '',
        corporateCustomerName: '',
        customerContactName: '',
        customerContactId: '',
        customerContactWeixin: '',
        corporateCustomerAddress: '',
        corporateCustomerTaxNumber: '',
        corporateCustomerTelephone: '',
        corporateCustomerId: '',
        customerContactMobile: '',
        corporateCustomerBankAccount: '',
        customerContactEmail: '',
        corporateCustomerEmail: '',

        refSalesOrgUUID: '',
        salesOrganizationId: '',
        salesOrgContactId: '',
        salesOrgContactName: '',
        salesOrganizationName: '',
        salesOrgContactMobile: '',
        salesOrganizationTaxNumber: '',
        salesOrganizationFax: '',
        salesOrganizationBankAccount: '',
        salesOrgContactWeixin: '',
        salesOrganizationAddress: '',
        salesOrganizationTelephone: '',
        salesOrganizationEmail: '',
        salesOrgContactEmail: '',

        refSupplierUUID: '',
        supplierContactName: '',
        corporateSupplierName: '',
        corporateSupplierBankAccount: '',
        corporateSupplierAddress: '',
        corporateSupplierTelephone: '',
        supplierContactWeixin: '',
        corporateSupplierId: '',
        supplierContactId: '',
        corporateSupplierTaxNumber: '',
        supplierContactMobile: '',
        corporateSupplierFax: '',
        corporateSupplierEmail: '',
        supplierContactEmail: '',

        refSupportOrgUUID: '',
        supportOrganizationId: '',
        supportOrgContactId: '',
        supportOrgContactName: '',
        supportOrganizationName: '',
        supportOrgContactMobile: '',
        supportOrganizationTaxNumber: '',
        supportOrganizationFax: '',
        supportOrganizationBankAccount: '',
        supportOrgContactWeixin: '',
        supportOrganizationAddress: '',
        supportOrganizationTelephone: '',
        supportOrganizationEmail: '',
        supportOrgContactEmail: '',

        refProductOrgUUID: '',
        productOrganizationId: '',
        productOrgContactId: '',
        productOrgContactName: '',
        productOrganizationName: '',
        productOrgContactMobile: '',
        productOrganizationTaxNumber: '',
        productOrganizationFax: '',
        productOrganizationBankAccount: '',
        productOrgContactWeixin: '',
        productOrganizationAddress: '',
        productOrganizationTelephone: '',
        productOrganizationEmail: '',
        productOrgContactEmail: '',

        refMaterialSKUUUID: '',
        refMaterialSKUName: '',
        refMaterialSKUId: '',
        supplyType: '',
        packageStandard: '',
        cargoType: ''
    },
    registeredProductExtendPropertyUIModel:{
        id: '',
        name: '',
        note: '',
        parentNodeUUID:'',
        pageTitle:'',
        refValueSettingUUID: '',
        refUnitUUID:'',
        valueSettingName: '',
        rawValue: '',
        valueUsage: '',
        measureFlag:'',
        qualityInspectFlag:'',
        measureFlagValue:'',
        matDecisionValueSettingNote: ''
    }
};


RegisteredProductManager.labelTemplate = {
    data: function() {
        return {
            label: {
                "actionNode":ServiceActionCodeNodeHelper.defLabelObj,
                "registeredProductExtendProperty": RegisteredProductManager.label.registeredProductExtendProperty
            }
        };
    }
};

/**
 * Definition of Tab on UI
 * @type {{}}
 */
RegisteredProductManager.documentTab = {
    registeredProductSection:'tab_registeredProductSection',
    productOrganizationSectio:'tab_productOrganizationSection',
    corporateCustomerSection:'tab_corporateCustomerSection',
    corporateSupplierSectio:'tab_corporateSupplierSection',
    productExtendPropertySection:'tab_productExtendPropertySection'
};

RegisteredProductManager.constants = {
    loadMaterialSKUURL: '../materialStockKeepUnit/loadLeanModuleListService.html',
    loadMaterialSKUUnitListURL: '../materialStockKeepUnit/getAllMaterialSKUUnitList.html',
    loadTraceModeListURL: '../materialStockKeepUnit/getTraceMode.html',
    loadOrganizationSelectListURL: '../organization/loadModuleListService.html',
    loadSalesOrganizationSelectListURL: '../organization/loadModuleListService.html',
    loadCorporateCustomerSelectListURL: '../corporateCustomer/loadModuleListService.html',
    loadCorporateSupplierSelectListURL: '../corporateSupplier/loadModuleListService.html',
    loadSalesOrganizationURL: '../organization/loadModule.html',
    loadOrganizationURL: '../organization/loadModule.html',
};

/**
 * @override Get Basic URL for load document material item instance.
 * @returns {string}
 */
RegisteredProductManager.prototype.getLoadDocItemBaseURL = function () {
    "use strict";
    return '../registeredProductExtendProperty/loadModuleEditService.html';
};

/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
RegisteredProductManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../registeredProduct/loadModuleViewService.html';
};

/**
 * @override Get Basic URL for load document list.
 * @returns {string}
 */
RegisteredProductManager.prototype.getLoadSelectListURL = function () {
    "use strict";
    return '../registeredProduct/loadModuleListService.html';
};

/**
 * Constants method: Get URL for load status metadata
 * @returns {*[]}
 */
RegisteredProductManager.prototype.getStatusURL = function(status) {
    "use strict";
    return '../registeredProduct/getStatusMap.html';
};


RegisteredProductManager.loadMaterialSKUSelectList = function ( oSelectElement, initValue, fnCallback) {
    var vm = this;
    $.ajax({
        url: RegisteredProductManager.constants.loadMaterialSKUURL,
        dataType: "json",
        type: "get",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success:function(oData){
            var resultList = oData;
            resultList = formatSelectResult(oData.content, 'uuid', 'id');
            setTimeout(function () {
                $(oSelectElement).empty();
                $(oSelectElement).select2({
                    data: resultList
                });
                var refMaterialSKUUUID = initValue ? initValue : undefined;
                if (!refMaterialSKUUUID) {
                    if (resultList && resultList.length && resultList.length > 0) {
                        refMaterialSKUUUID = resultList[0].id;
                    }
                }
                $(oSelectElement).val(refMaterialSKUUUID);
                $(oSelectElement).trigger("change");
                if (fnCallback && typeof  fnCallback === 'function') {
                    fnCallback(refMaterialSKUUUID);
                }
            }, 0);
        },
        error:function(){
            // do nothing currently
        }
    });

};

RegisteredProductManager.loadTraceModeSelectList = function ( oSelectElement, initValue, fnCallback) {
    var vm = this;
    $.ajax({
        url: RegisteredProductManager.constants.loadTraceModeListURL,
        dataType: "json",
        type: "get",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success:function(oData){
            var resultList = oData;
            setTimeout(function () {
                $(oSelectElement).empty();
                $(oSelectElement).select2({
                    data: resultList,
                    templateResult: RegisteredProductManager.formatTraceMode,
                    templateSelection: RegisteredProductManager.formatTraceMode
                });
                var traceMode = initValue ? initValue : undefined;
                if (!traceMode) {
                    if (resultList && resultList.length && resultList.length > 0) {
                        traceMode = resultList[0].id;
                    }
                }
                $(oSelectElement).val(traceMode);
                $(oSelectElement).trigger("change");
                if (fnCallback && typeof  fnCallback === 'function') {
                    fnCallback(traceMode);
                }
            }, 0);
        },
        error:function(){
            // do nothing currently
        }
    });

};

RegisteredProductManager.formatTraceMode = function(traceMode){
    var iconElement;
    var $element = ServiceUtilityHelper.formatSelectWithIcon(traceMode, MaterialUtility.getTraceModeArray(), true);
    return $element;
},

RegisteredProductManager.loadMaterialSKUUnitSelectCore = function (refMaterialSKUUUID, oSelectElement, initValue, fnCallback) {
    var vm = this;
    var requestData = {"baseUUID": refMaterialSKUUUID};
    $.ajax({
        url: RegisteredProductManager.constants.loadMaterialSKUUnitListURL,
        dataType: "json",
        type: "post",
        data:  JSON.stringify(requestData),
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success:function(oData){
            var resultList = oData;
            setTimeout(function () {
                $(oSelectElement).empty();
                $(oSelectElement).select2({
                    data: resultList
                });
                var refUnitUUID = initValue ? initValue : undefined;
                if (!refUnitUUID) {
                    if (resultList && resultList.length && resultList.length > 0) {
                        refUnitUUID = resultList[0].id;
                    }
                }
                $(oSelectElement).val(refUnitUUID);
                $(oSelectElement).trigger("change");
                if (fnCallback && typeof  fnCallback === 'function') {
                    fnCallback(refUnitUUID);
                }
            }, 0);
        },
        error:function(){
            // do nothing currently
        }
    });
};

/**
 * Core Logic to check if current serial id is empty, should be consistent with back-end logic
 * @param serialId
 * @returns {boolean}
 */
RegisteredProductManager.checkEmptySerialId = function(serialId){
    if(serialId && serialId !== ''){
        return;
    }
    return true;
};


RegisteredProductManager.getNonEmptySerialAmount = function(serialIdList){
    if(!serialIdList || serialIdList.length === 0){
        return 0;
    }
    var nonEmptyAmount = 0;
    for(var i = 0; i < serialIdList.length; i++){
        if(!RegisteredProductManager.checkEmptySerialId(serialIdList[i])){
            nonEmptyAmount += 1;
        }
    }
    return nonEmptyAmount;
};

/**
 * Constants method: Generate the array for mapping 'status' and its icon
 * @returns {*[]}
 */
RegisteredProductManager.getTraceStatusIconArray = function () {
    "use strict";
    return [{
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.INIT, iconClass: 'md md-remove-circle-outline content-grey'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.ACTIVE, iconClass: 'md md-spellcheck content-peach-red'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.INUSE, iconClass: 'md md-restore content-green'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.ARCHIVE, iconClass: 'md md-archive content-grey'
    }];
};

RegisteredProductManager.formatTraceStatus = function (traceStatus) {
    "use strict";
    var $element = ServiceUtilityHelper.formatSelectWithIcon(traceStatus, MaterialStockKeepUnitManager.getTraceStatusIconArray(), true);
    return $element;
};

RegisteredProductManager.formatTraceStatusClass = function(status){
    var traceStatusIconArray = RegisteredProductManager.getTraceStatusIconArray();
    var $element = ServiceCollectionsHelper.filterArray(status, 'id', traceStatusIconArray);
    if($element){
        return $element.iconClass;
    }
};

RegisteredProductManager.loadOrganizationSelectList = function (oSettings) {
    return ServiceUtilityHelper.loadModelMetaRequest( ServiceUtilityHelper.extendObject(oSettings, {
        url: RegisteredProductManager.constants.loadOrganizationSelectListURL,
        idField: 'uuid',
        textField: 'name'
    }));
};

RegisteredProductManager.loadCorporateCustomerSelectList = function (oSettings) {
    return ServiceUtilityHelper.loadModelMetaRequest( ServiceUtilityHelper.extendObject(oSettings, {
        url: RegisteredProductManager.constants.loadCorporateCustomerSelectListURL,
        idField: 'uuid',
        textField: 'name'
    }));
};

RegisteredProductManager.loadCorporateSupplierSelectList = function (oSettings) {
    return ServiceUtilityHelper.loadModelMetaRequest( ServiceUtilityHelper.extendObject(oSettings, {
        url: RegisteredProductManager.constants.loadCorporateSupplierSelectListURL,
        idField: 'uuid',
        textField: 'name'
    }));
};


RegisteredProductManager.loadDefaultMetaBatch = function(oSettings) {
    var vm = oSettings.vm;
    var uiModel = oSettings.uiModel;
    var initSettings = {
        '$http': vm.$http,
        'errorHandle': vm.errorHandle,
        'addEmptyFlag': oSettings.addEmptyFlag
    };
    var innerSettings = ServiceUtilityHelper.cloneObj(initSettings);
    var promiseList = [];
    if (vm['eleRefSupplierUUID']) {
        innerSettings.initValue = uiModel['refSupplierUUID'];
        innerSettings.element = vm['eleRefSupplierUUID'];
        RegisteredProductManager.loadCorporateSupplierSelectList(innerSettings);
        innerSettings = ServiceUtilityHelper.resetObject(innerSettings, initSettings);
    }
    if (vm['eleRefCustomerUUID']) {
        innerSettings.initValue = uiModel['refCustomerUUID'];
        innerSettings.element = vm['eleRefCustomerUUID'];
        RegisteredProductManager.loadCorporateCustomerSelectList(innerSettings);
        innerSettings = ServiceUtilityHelper.resetObject(innerSettings, initSettings);
    }
    if (vm['eleRefSalesOrgUUID']) {
        innerSettings.initValue = uiModel['refSalesOrgUUID'];
        innerSettings.element = vm['eleRefSalesOrgUUID'];
        RegisteredProductManager.loadOrganizationSelectList(innerSettings);
        innerSettings = ServiceUtilityHelper.resetObject(innerSettings, initSettings);
    }

    if (vm['eleRefSupportOrgUUID']) {
        innerSettings.initValue = uiModel['refSupportOrgUUID'];
        innerSettings.element = vm['eleRefSupportOrgUUID'];
        RegisteredProductManager.loadOrganizationSelectList(innerSettings);
        innerSettings = ServiceUtilityHelper.resetObject(innerSettings, initSettings);
    }

    if (vm['eleRefProductOrgUUID']) {
        innerSettings.initValue = uiModel['refProductOrgUUID'];
        innerSettings.element = vm['eleRefProductOrgUUID'];
        RegisteredProductManager.loadOrganizationSelectList(innerSettings);
        innerSettings = ServiceUtilityHelper.resetObject(innerSettings, initSettings);
    }

    if (vm['eleRefPurchaseOrgUUID']) {
        innerSettings.initValue = uiModel['refPurchaseOrgUUID'];
        innerSettings.element = vm['eleRefPurchaseOrgUUID'];
        RegisteredProductManager.loadOrganizationSelectList(innerSettings);
        innerSettings = ServiceUtilityHelper.resetObject(innerSettings, initSettings);
    }

    if( promiseList && promiseList.length > 0 && oSettings.callback){
        Promise.all(promiseList).then(function(value){
            oSettings.callback({ 'value': value});
        });
    }
    return promiseList;
};

RegisteredProductManager.prototype.getModelTitle = function(){
    return RegisteredProductManager.label.registeredProduct.modelTitle;
};

/**
 * [API] Get root node inst id
 */
RegisteredProductManager.getRootNodeInstId = function(){
    return "registeredProduct";
};

/**
 * [API]Get item node inst id
 */
RegisteredProductManager.getItemNodeInstId = function(){
    return "registeredProductExtendProperty";
};


/**
 * [API] Get resource id for checking authorization
 */
RegisteredProductManager.getResourceId = function(){
    return ServiceModuleConstants.RegisteredProduct;
};

/**
 * [API] Get document type
 */
RegisteredProductManager.getDocumentType = function(){
    return DocumentConstants.DummyDocumentType.RegisteredProduct;
};

/**
 * [API]Get root 18n config
 */
RegisteredProductManager.getI18nRootConfig = function () {
    return {
        i18nPath: 'coreFunction/',
        mainName: 'RegisteredProduct',
        modelId: 'RegisteredProduct', coreModelId: 'RegisteredProduct',
        configList: [{
            name: 'RegisteredProductExtendProperty',
            subLabelPath: 'registeredProductExtendProperty'
        }, {
            name: 'MaterialStockKeepUnit',
            subLabelPath: 'materialStockKeepUnit'
        }, {
            actionNodePath: 'actionNode'
        }]
    };
};

/**
 * [API]Get item 18n config
 */
RegisteredProductManager.getI18nItemConfig = function () {
    "use strict";
    return {
        i18nPath: 'coreFunction/',
        labelObject: RegisteredProductManager.label.registeredProductExtendProperty,
        mainName: 'RegisteredProductExtendProperty',
        modelId: 'RegisteredProduct', coreModelId: 'RegisteredProductExtendProperty',
        configList: [{
            name: 'RegisteredProductExtendProperty'
        }]
    };
};


RegisteredProductManager.getActionCodeIconMap = function () {
    var actionCodeIconMap = ServiceUtilityHelper.getMergedActionCodeIconMap(RegisteredProductManager.getCustomActionCodeIconMap());
    return actionCodeIconMap;
};

/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
RegisteredProductManager.prototype.getI18nWrap = function (fnCallback) {

    var vm = this;
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "coreFunction/",
        commonCallback: vm.setI18nCommonProperties,
        fnCallback: fnCallback,
        configList: [{
            name: 'RegisteredProduct',
            callback: vm.setNodeI18nPropertiesCore
        },{
            name: 'MaterialStockKeepUnit',
            callback: vm.getI18nMaterialSKUMap
        },{
            name: 'RegisteredProductExtendProperty',
            callback: vm.getI18nDocItemMap
        }]
    });
};


/**
 * @override Set Basic path for i18n function.
 * @returns {string}
 */
RegisteredProductManager.getI18nPath = function () {
    return "coreFunction/";
};

RegisteredProductManager.prototype.getI18nCommonMap = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(RegisteredProductManager.label.registeredProduct, $.i18n.prop);
    ServiceUtilityHelper.setI18nReflective(RegisteredProductManager.label.registeredProductExtendProperty, $.i18n.prop);

};

RegisteredProductManager.prototype.setNodeI18nPropertiesCore = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(RegisteredProductManager.label.registeredProduct, $.i18n.prop, true);
};

RegisteredProductManager.prototype.getI18nMaterialSKUMap = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(RegisteredProductManager.label.registeredProduct, $.i18n.prop);
};


RegisteredProductManager.prototype.getI18nDocItemMap = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(RegisteredProductManager.label.registeredProductExtendProperty, $.i18n.prop, true);
};


RegisteredProductManager.prototype.initSerializer = function () {
    "use strict";
    if (!this.serializer) {
        this.serializer = new XMLSerializer();
    }
};

RegisteredProductManager.prototype.getDefaultDocumentEditorPage = function () {
    "use strict";
    return "RegisteredProductEditor.html";
};

RegisteredProductManager.prototype.getDefaultDocumentItemEditorPage = function () {
     "use strict";
     return "RegisteredProductExtendPropertyEditor.html";
};

RegisteredProductManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: this.getDefaultDocumentEditorPage(),
        url: this.getLoadDocumentBaseURL(),
        label:RegisteredProductManager.label.registeredProduct,
        subPath: 'registeredProductUIModel',
        getI18nWrap:vm.getI18nWrap.bind(vm)
    });

    var fieldMetaList = [{
        fieldName:'serialId',
    },{
        fieldName:'id',
    },{
        fieldName:'refMaterialSKUId',
    },{
        fieldName:'refMaterialSKUName',
    },{
        fieldName:'packageStandard',
    },{
        fieldName:'supplyTypeValue',
        fieldKey:'supplyType',
        labelKey:'supplyType',
        iconArray: MaterialManager.getSupplyTypeIconArray(),
    },{
        fieldName: 'materialTypeName'
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};

