/**
 * Created by Zhang,Hang on 8/23/2016.
 */

var searchModel = new Vue({
    el: "#x_data",
    data: {
        content: {
            uuid:'',
            name:'',
            id:'',
            userId:'',
            client:'',
            password:'',
            languageCode:'',
            errorMessage:''
        },
        label: {
            userId: '',
            password:'',
            languageCode:'',
            login:'',
            loginComment:'',
            loginSystemComment:'',
            msgSystemFailure: '',
            msgUnknowSystemFailure: '',
            noneAuthorizedFailure: '',
            noneLogonUser: '',
            reloginSessionTimeout: ''
        },
        eleLanguageSet: '#x_languageSet',
        serviceResourseHelper:{},
        loginURL: '../common/loginService.html'
    },

    mounted: function () {
        this.$nextTick(function () {
            this.initLoginSetting();
            this.initSelectConfigure();
            this.loadLanguageSettings();
            this.initMetaData();
            this.setI18nProperties();
        });
    },

    methods: {

        initMetaData: function(){
            "use strict";
            this.serviceResourseHelper = new ServiceResourseHelper();
            var oSettings = {
                $http: this.$http
            };
            var resourcePromise = this.serviceResourseHelper.loadAllResourcePromise(oSettings);
            resourcePromise.then(function (value) {
                console.log(value);
            });
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleLanguageSet).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'languageCode', $(vm.eleLanguageSet).val());
                vm.setI18nProperties();
            });
        },

        setI18nProperties: function () {
            var lanCode = (this.content.languageCode)?this.content.languageCode:getBrowserLan();
            jQuery.i18n.properties({
                name: 'ComElements', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: lanCode,
                cache: true,
                callback: this.setI18nCommonProperties
            });
        },

        getI18nPath: function () {
            return "foundation/";
        },

        setI18nCommonProperties: function () {
            this.label.userId = $.i18n.prop('userId');
            this.label.password = $.i18n.prop('password');
            this.label.languageCode = $.i18n.prop('languageCode');
            this.label.msgSystemFailure = $.i18n.prop('msgSystemFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.noneAuthorizedFailure = $.i18n.prop('noneAuthorizedFailure');
            this.label.noneLogonUser = $.i18n.prop('noneLogonUser');
            this.label.reloginSessionTimeout = $.i18n.prop('reloginSessionTimeout');
            this.label.login = $.i18n.prop('login');
            this.label.loginComment = $.i18n.prop('loginComment');
            this.label.loginSystemComment = $.i18n.prop('loginSystemComment');
        },


        loadLanguageSettings: function(){
            var vm = this;
            var lanConfigPath = 'js/loginLanguage.json';
            // var initLanguage = getBrowserLan();
            var initLanguage = "zh_CN";
            $.getJSON(lanConfigPath, function (data) {
                var resultList = data.languageList;
                setTimeout(function () {
                    $(vm.eleLanguageSet).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleLanguageSet).val(initLanguage);
                    $(vm.eleLanguageSet).trigger("change");
                    vm.$set(vm.content, 'languageCode', $(vm.eleLanguageSet).val());
                    vm.setI18nProperties();
                }, 0);
            });
        },

        initLoginSetting: function(){
            "use strict";
            var vm = this;
            vm.getI18nWrap(function () {
                vm.getI18nCommonMap();
                var errorCode = getUrlVar("errorCode");
                var subErrorCode = getUrlVar("subErrorCode");
                var pathname = getUrlVar("pathName");
                vm.$set(vm.content, 'subErrorCode', subErrorCode);
                vm.$set(vm.content, 'errorCode', errorCode);
                vm.$set(vm.content, 'pathname', pathname);
                if(errorCode + "" === HttpStatus.SC_UNAUTHORIZED + ""){
                    if(subErrorCode + "" === HttpSubStatus.SC_SUBERROR_LOGONFAILED + ""){
                        vm.$set(vm.content, 'errorMessage', vm.label.reloginSessionTimeout);
                    }
                }
            });
        },

        login: function () {
            var vm = this;
            this.serviceResourseHelper = new ServiceResourseHelper();
            var oSettings = {
                $http: this.$http
            };
            // var requestData = generateServiceSimpleContentUnion("userId", this.content.userId, "password", this.content.password, "client", "001");
            var requestData = {
                userId:this.content.userId,
                password:this.content.password,
                client:'001',
                languageCode:this.content.languageCode
            };
            sessionStorage.setItem('lanCode',this.content.languageCode);
            this.$http.post(vm.loginURL, requestData).then(function (response) {
                if (JSON.parse(response.data).errorCode == HttpStatus.SC_OK) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    var resourcePromise = this.serviceResourseHelper.loadAllResourcePromise(oSettings);
                    resourcePromise.then(function (value) {
                        vm.forwardToTarget(oData.content);
                    }.bind(this));
                } else {
                    ServiceHttpRequestHelper.handleErrorCodeWrap({
                        errorMessage: JSON.parse(response.data).errorMessage,
                        errorTitle: "登陆失败"
                    });
                    //swal("登陆失败", JSON.parse(response.data).errorMessage);
                }
            }, function (response) {
                alert(response.statusText);
            });
        },

        forwardToTarget: function(content) {
            "use strict";
            var vm = this;
            // TODO TEMP switch off
            // content.passwordInitFlag = false;
            if(content.passwordInitFlag && content.passwordInitFlag === true){
                var uuid = content.uuid;
                var baseEditURL = "InitialLogin.html";
                var paras = {uuid: uuid, kennwort:Base64.encode(this.content.password)};
                var resultURL = baseEditURL + "?" + urlEncode(paras);
                window.location.href = resultURL;
                return;
            }
            var resultPara = getUrlVars();
            // call to get logon user's role list
            var promise = ServiceApplicationFactory.getRoleListPromise(this.$http);
            promise.then(function(roleList){
                if(resultPara.pathname){
                    resultPara.errorCode = undefined;
                    resultPara.subErrorCode = undefined;
                    var pathname = resultPara.pathname;
                    resultPara.pathname = undefined;
                    var resultURL = pathname + "?" + urlEncode(resultPara);
                    window.location.href = resultURL;
                }else{
                    vm.setDefPageByRole(roleList);
                }
            }, function(oError){

            });

        },

        setDefPageByRole: function(roleList){
            if(roleList && roleList.length > 0){
                for(var i = 0; i < roleList.length; i++){
                    var role = roleList[i];
                    if(role.roleUIModel.defaultPageUrl){
                        window.location.href = role.roleUIModel.defaultPageUrl;
                        return;
                    }
                }
            }
            window.location.href = "BidInvitationOrderList.html";
        },

        getI18nWrap: function (fnCallback) {
            "use strict";
            var vm = this;
            jQuery.i18n.properties({
                name: 'ComElements', //properties file name
                path: getI18nRootPath() + vm.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: fnCallback
            });
        },

        getI18nCommonMap: function () {
            "use strict";
            this.label.msgSystemFailure = $.i18n.prop('msgSystemFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.noneAuthorizedFailure = $.i18n.prop('noneAuthorizedFailure');
            this.label.noneLogonUser = $.i18n.prop('noneLogonUser');
            this.label.reloginSessionTimeout = $.i18n.prop('reloginSessionTimeout');
        },

        getI18nPath: function () {
            "use strict";
            return "foundation/";
        }
    }
});

