var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        searchModuleURL: '../workCalendar/searchModuleService.html'
    },
    methods: {
        searchModule: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.searchModuleURL, requestData).then(function (response) {
                listVar.refreshTableItems(JSON.parse(response.data).content);
            });
        },
        newModule: function () {
            listVar.newWorkCalendarModal();
        },
        newModuleModal: function () {
            listVar.newWorkCalendarModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            id: "",
            defaultFlag: "",
            templateName: "",
            templateId: "",
            year: ""

        },

        label: {
            id: '',
            defaultFlag: '',
            year: '',
            refTemplateUUID: '',
            templateName: '',
            templateId: '',
            calendarTemplateYear: '',
            vocationType: '',
            refDate: '',
            dayStatus: '',
            advancedSearchCondition: ''
        },
        getDefaultFlagURL: '../workCalendar/getDefaultFlag.html',
        getVocationTypeURL: '../workCalendarDayItem/getVocationType.html',
        getDayStatusURL: '../workCalendarDayItem/getDayStatus.html'

    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            vm.getDefaultFlag();
        });
    },
    methods: {
        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleDefaultFlag).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'defaultFlag', $(vm.eleDefaultFlag).val());
            });
            $(vm.eleRefCalendarTemplate).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refTemplateUUID', $(vm.eleRefCalendarTemplate).val());
            });
        },
        getDefaultFlag: function () {
            var vm = this;
            this.$http.get(this.getDefaultFlagURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                resultList.splice(0, 0, {'id': '0', 'text': ' '});
                setTimeout(function () {
                    $(vm.eleDefaultFlag).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleDefaultFlag).val(vm.content.defaultFlag);
                    $(vm.eleDefaultFlag).trigger("change");
                }, 0);
            });
        }
    }
});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: {
            id: '',
            defaultFlag: '',
            year: '',
            name: '',
            templateName: '',
            templateId: '',
            msgConnectFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            buttonEdit: '',
            buttonView: '',
            calendarTemplate:{
                addWorkCalendarTitle:'',
                id:'',
                name:'',
                year:'',
                note:''
            }
        },
        cache:{
            calendarTemplate:{
                id:'',
                name:'',
                year:'',
                note:'',
                uuid:''
            },
            calendarTemplateList:[]
        },
        tableId: '#x_table_workCalendar',
        datatable: '',
        items: [],
        eleRefCalendarTemplate:'#x_refCalendarTemplate',
        eleCalendarTemplateModal:'#x_calendarTemplateModal',
        loadModuleListURL: '../workCalendar/loadModuleListService.html',
        loadTemplateListURL: '../calendarTemplate/loadLeanModuleListService.html',
        loadTemplateModuleURL: '../calendarTemplate/loadModule.html',
        preLockURL: '../workCalendar/preLockService.html'
    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'WorkCalendar');
            this.datatable = new ServiceDataTable(this.tableId);
            this.setI18nProperties();
            this.loadModuleList();
            this.initSelectConfigure();
            this.loadCalendarTemplateSelectList();
        });
    },
    methods: {

        initSelectConfigure: function () {
            var vm = this;

            $(vm.eleRefCalendarTemplate).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.calendarTemplate, 'uuid', $(vm.eleRefCalendarTemplate).val());
                var url = vm.loadTemplateModuleURL + "?uuid=" + $(vm.eleRefCalendarTemplate).val();
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.cache.calendarTemplate, 'name', content.name);
                    vm.$set(vm.cache.calendarTemplate, 'id', content.id);
                    vm.$set(vm.cache.calendarTemplate, 'year', content.year);
                });
            });
        },

        newWorkCalendarModal: function(){
            this.loadCalendarTemplateSelectList();
            $(this.eleCalendarTemplateModal).modal('toggle');
        },

        confirmToNewWorkCalendar: function(){
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.cache.calendarTemplate.uuid;
            paras.content = this.cache.calendarTemplate.year;
            var resultURL = "WorkCalendarEditor.html" + "?" + urlEncode(paras);
            $(this.eleCalendarTemplateModal).modal('hide');
            window.location.href = resultURL;
        },

        setI18nCommonProperties: function () {
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.buttonEdit = $.i18n.prop('edit');
            this.label.buttonView = $.i18n.prop('view');
            this.label.confirm = $.i18n.prop('confirm');
            this.label.cancel = $.i18n.prop('cancel');
            processModel.label.search = $.i18n.prop('search');
            processModel.label.add = $.i18n.prop('add');
            searchModel.label.advancedSearchCondition = $.i18n.prop('advancedSearchCondition');
            BusyLoader.cleanPageBackground();
        },
        setNodeI18nPropertiesCore: function () {
            this.label.id = $.i18n.prop('id');
            this.label.defaultFlag = $.i18n.prop('defaultFlag');
            this.label.year = $.i18n.prop('year');
            this.label.name = $.i18n.prop('name');
            this.label.templateName = $.i18n.prop('templateName');
            this.label.templateId = $.i18n.prop('templateId');
            this.label.calendarTemplate.addWorkCalendarTitle = $.i18n.prop('addWorkCalendarTitle');
            searchModel.label.defaultFlag = $.i18n.prop('defaultFlag');
            searchModel.label.refTemplateUUID = $.i18n.prop('refTemplateUUID');
            searchModel.label.templateName = $.i18n.prop('templateName');
            searchModel.label.templateId = $.i18n.prop('templateId');
            searchModel.label.name = $.i18n.prop('name');
            searchModel.label.id = $.i18n.prop('id');
            searchModel.label.year = $.i18n.prop('year');
        },
        setNodeI18nPropertiesTemplate: function () {
            this.label.calendarTemplate.id = $.i18n.prop('id');
            this.label.calendarTemplate.year = $.i18n.prop('year');
            this.label.calendarTemplate.name = $.i18n.prop('name');
            this.label.calendarTemplate.note = $.i18n.prop('note');
        },
        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'WorkCalendar', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
            jQuery.i18n.properties({
                name: 'CalendarTemplate', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesTemplate
            });
        },
        getI18nPath: function () {
            return 'foundation/common/';
        },
        loadModuleList: function () {
            var vm = this;
            this.$http.get(vm.loadModuleListURL).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                vm.$set(vm, 'items', JSON.parse(response.data).content);
                setTimeout(function () {
                    vm.datatable.build();
                }, 0);
            });
        },

        loadCalendarTemplateSelectList: function () {
            var vm = this;
            if(vm.cache.calendarTemplateList && vm.cache.calendarTemplateList.length > 0){
                vm._setTemplateSelect(vm.cache.calendarTemplate.uuid, vm.cache.calendarTemplateList);
            }else{
                this.$http.get(this.loadTemplateListURL).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    var resultList = formatSelectResult(oData.content, 'uuid', 'name', true);
                    vm.cache.calendarTemplateList = resultList;
                    vm._setTemplateSelect(vm.cache.calendarTemplate.uuid, resultList);
                });
            }
        },

        _setTemplateSelect: function(refTemplateUUID, resultList){
            var vm = this;
            setTimeout(function () {
                $(vm.eleRefCalendarTemplate).select2({
                    data: resultList
                });
                // manually set initial value
                $(vm.eleRefCalendarTemplate).val(refTemplateUUID);
                $(vm.eleRefCalendarTemplate).trigger("change");
            }, 0);
        },

        refreshTableItems: function (items) {
            this.datatable = new ServiceDataTable(this.tableId);
            this.$set(this, 'items', items);
            setTimeout(function () {
                this.datatable.build();
            }, 0);

        },
        editModule: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            this.$http.post(vm.preLockURL, requestData).then(function (response) {
                if (JSON.parse(response.data).RC == HttpStatus.SC_OK) {
                    window.location.href = genCommonEditURL("WorkCalendarEditor.html", uuid);
                } else {
                    swal(this.label.lockFailureMessage, JSON.parse(response.data).MSG);
                }
            });
        },
        preLock: function () {
        }
    }
});
