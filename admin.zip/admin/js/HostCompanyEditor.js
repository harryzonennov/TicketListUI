var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: HostCompanyManager.label.hostCompany,
        content: {
            refCityUUID: '',
            refFinOrgUUID: '',
            mainContactUUID: '',
            client: '',
            uuid: '',
            parentOrganizationUUID: '',
            refCashierUUID: '',
            refAccountantUUID: '',
            id: '',
            streetName: '',
            fullName: '',
            name: '',
            cityName: '',
            webPage: '',
            latitude: '',
            regularType: '',
            organType: '',
            mobile: '',
            houseNumber: '',
            address: '',
            comReportTitle: '',
            comLogo: '',
            addressInfo: '',
            fax: '',
            townZone: '',
            organizationFunction: '',
            addressOnMap: '',
            postcode: '',
            contactTelephone: '',
            contactMobileNumber: '',
            accountType: '',
            refOrganizationFunction: '',
            subArea: '',
            telephone: '',
            longitude: '',
            organLevel: '',
            note: '',
            email: ''
        },

        author:{
            resourceId:'HostCompany',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        processButtonMeta: [],
        loadModuleEditURL: '../hostCompany/loadModuleEditService.html',
        loadModuleViewURL: '../hostCompany/loadModuleViewService.html',
        saveModuleURL: '../hostCompany/saveModuleService.html',
        newModuleServiceURL: '../hostCompany/newModuleService.html',
        exitURL: 'HostCompanyList.html',
        exitModuleURL: '../hostCompany/exitEditor.html'
    },

    created: function(){
        "use strict";
        var vm = this;
        vm.initSubComponents();
    },


    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'HostCompany');
            this.setI18nProperties(vm.initProcessButtonMeta);
            this.loadModuleEdit();
            vm.initAuthorResourceCheck();
        });
    },

    methods: {
        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        initSubComponents: function() {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'HostCompany',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },


        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if (processMode * 1 === PROCESSMODE_NEW) {
               ServiceUtilityHelper.newModuleDefault({
                   newModuleServiceURL: vm.newModuleServiceURL,
                   vm:vm,
                   errorHandle:vm.errorHandle,
                   postSet:vm.setModuleToUI
                });
            }
            if (processMode * 1 === PROCESSMODE_EDIT) {
                // In case [Edit mode]
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    initAuthor: function(author){vm.$set(vm, 'author', author);},
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }
        },


        saveModule: function () {
            var vm = this;
            ServiceUtilityHelper.defSaveModuleWrapper({
                vm: vm,
                editorPage: "HostCompanyEditor.html",
                fnGetBaseUUID: function (){
                    return vm.content.uuid;
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);

        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.uuid;
            window.location.href = genCommonEditURL("HostCompanyEditor.html", baseUUID, tabKey);

        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm, 'content', content);
        }

    }
});
