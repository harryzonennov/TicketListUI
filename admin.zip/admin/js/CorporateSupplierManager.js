/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var CorporateSupplierManager = function () {

};

CorporateSupplierManager.label = {
    corporateSupplier: ServiceUtilityHelper.getComLabelObject({
        weiXinID: '',
        status: '',
        weiboID: '',
        email:'',
        customerType: '',
        subDistributorType: '',
        faceBookID: '',
        modelTitle:'',
        address: '',
        telephone:'',
        deleteWarnTitle:'',
        deleteWarnText:'',
        contactSection:'',
        supplierLevel:'',
        confirm:'',
        cancel:'',
        buttonEdit: '',
        quickEdit:'',
        tags:'',
        tagsEditComment:'',
        taxNumber: '',
        countryName: '',
        stateName: '',
        cityName:'',
        streetName:'',
        townZone:'',
        fax:'',
        depositBank:'',
        bankAccount: '',
        corporateSupplierSection: '',
        corporateContactPersonSection: '',
        customerAttachmentSection: ''
    }),
    corporateContactPerson:  ServiceUtilityHelper.getComLabelObject({
        address: '',
        mobile: '',
        telephone: '',
        contactRole: '',
        contactPosition: '',
        contactPersonCustomerType: '',
        contactRoleNote: '',
        contactPersonNote: '',
        weixinId:'',
        email:'',
        add: ''
    })
};

CorporateSupplierManager.content = {
    corporateSupplierUIModel: ServiceUtilityHelper.extendObject({
        baseCityUUID: '',
        refSalesAreaUUID: '',
        dealerTypeUUID: '',
        refRouteUUID: '',
        tags: '',
        taxNumber: '',
        countryName: '',
        stateName: '',
        cityName:'',
        fax:'',
        supplierLevel:'',
        address:'',
        depositBank:'',
        telephone:'',
        bankAccount: '',
        weiXinID: '',
        status: '',
        weiboID: '',
        customerType: '',
        launchReason: '',
        retireReason: '',
        launchDate: '',
        faceBookID: ''
    }, ServiceUtilityHelper.getDefContent()),
    corporateContactPersonUIModel:ServiceUtilityHelper.extendObject({
        refNodeName: '',
        refUUID: '',
        contactRole: '',
        contactPosition: '',
        contactPositionNote: '',
        contactRoleNote: '',
        contactPersonId: '',
        contactPersonName: '',
        contactPersonCustomerType: '',
        contactPersonNote: ''
    }, ServiceUtilityHelper.getDefContent())
};

CorporateSupplierManager.labelTemplate = {
    data: function() {
        return {
            label: {
                "corporateContactPerson":CorporateSupplierManager.label.corporateContactPerson
            }
        };
    }
};

/**
 * Definition of Tab on UI
 * @type {{}}
 */
CorporateSupplierManager.documentTab = {
    corporateCustomerSection:"tabCorporateCustomerSection",
    contactSection:"tabCorporateContactPersonSection",
    customerAttachmentSection:"tabCustomerAttachmentSection"
};

CorporateSupplierManager.DOC_ACTION_CODE = {
    APPROVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_APPROVE,
    REJECT_APPROVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REJECT_APPROVE,
    SUBMIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_SUBMIT,
    REVOKE_SUBMIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REVOKE_SUBMIT,
    REINIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REINIT,
    ACTIVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_ACTIVE,
    ARCHIVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_ARCHIVE
};

/**
 * @override Get Basic URL for load document corporateSupplier item instance.
 * @returns {string}
 */
CorporateSupplierManager.prototype.getLoadDocItemBaseURL = function () {
    "use strict";
    return undefined;
};

/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
CorporateSupplierManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../corporateSupplier/loadModuleViewService.html';
};

/**
 * Constants method: Get URL for load status metadata
 * @returns {*[]}
 */
CorporateSupplierManager.prototype.getStatusURL = function(status) {
    "use strict";
    return undefined;
};

/**
 * Constants method: Generate the array for mapping 'status' and its icon
 * @returns {*[]}
 */
CorporateSupplierManager.prototype.getStatusIconArray = function () {
    "use strict";
    return CorporateSupplierManager.getStatusIconArray();
};

/**
 * @override Get Basic URL for load document list.
 * @returns {string}
 */
CorporateSupplierManager.prototype.getLoadSelectListURL = function () {
    "use strict";
    return '../corporateCustomer/loadModuleListService.html';
};

/**
 * [API] Get root node inst id
 */
CorporateSupplierManager.getRootNodeInstId = function(){
    return "corporateSupplier";
};

/**
 * [API]Get item node inst id
 */
CorporateSupplierManager.getItemNodeInstId = function(){
    return "corporateContactPerson";
};


/**
 * [API] Get resource id for checking authorization
 */
CorporateSupplierManager.getResourceId = function(){
    return ServiceModuleConstants.CorporateSupplier;
};

/**
 * [API] Get document type
 */
CorporateSupplierManager.getDocumentType = function(){
    return DocumentConstants.DummyDocumentType.CorporateSupplier;
};

/**
 * [API]Get root 18n config
 */
CorporateSupplierManager.getI18nRootConfig = function () {
    return {
        i18nPath: 'coreFunction/',
        mainName: 'CorporateSupplier',
        modelId: 'CorporateSupplier', coreModelId: 'CorporateSupplier',
        configList: [{
            name: 'CorporateContactPerson',
            subLabelPath: 'corporateContactPerson'
        }, {
            name: 'CorporateSupplierStockKeepUnit',
            subLabelPath: 'corporateSupplierStockKeepUnit'
        }, {
            actionNodePath: 'actionNode'
        }]
    };
};

/**
 * [API]Get item 18n config
 */
CorporateSupplierManager.getI18nItemConfig = function () {
    "use strict";
    return {
        i18nPath: 'coreFunction/',
        labelObject: CorporateSupplierManager.label.corporateContactPerson,
        mainName: 'CorporateContactPerson',
        modelId: 'CorporateSupplier', coreModelId: 'CorporateContactPerson',
        configList: [{
            name: 'CorporateContactPerson'
        }]
    };
};


CorporateSupplierManager.getActionCodeIconMap = function () {
    var actionCodeIconMap = ServiceUtilityHelper.getMergedActionCodeIconMap(CorporateSupplierManager.getCustomActionCodeIconMap());
    return actionCodeIconMap;
};

CorporateSupplierManager.prototype.getDefaultDocumentEditorPage = function(){
    "use strict";
    return "CorporateSupplierEditor.html";
};

CorporateSupplierManager.prototype.getDefaultDocumentItemEditorPage = function(){
    "use strict";
    return undefined;
};


/**
 * Constants method: Generate the array for mapping 'status' and its icon
 * @returns {*[]}
 */
CorporateSupplierManager.getStatusIconArray = function () {
    "use strict";
    return [{
        id: DocumentConstants.CorporateSupplier.status.INITIAL, iconClass: DocumentContentProp.statusIcon.INITIAL
    }, {
        id: DocumentConstants.CorporateSupplier.status.INUSE, iconClass: DocumentContentProp.statusIcon.INPROCESS
    }, {
        id: DocumentConstants.CorporateSupplier.status.ARCHIVED, iconClass: DocumentContentProp.statusIcon.ARCHIVED
    }];
};

CorporateSupplierManager.formatStatusIconClass = function (status) {
    "use strict";
    var statusIconArray = CorporateSupplierManager.getStatusIconArray();
    var $element = ServiceCollectionsHelper.filterArray(status, 'id', statusIconArray);
    if($element){
        return $element.iconClass;
    }
};

CorporateSupplierManager.formatStatus = function (status) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(status, CorporateSupplierManager.getStatusIconArray(), true);
    return $element;
};

CorporateSupplierManager.prototype.getModelTitle = function(){
    return CorporateSupplierManager.label.corporateSupplier.modelTitle;
};

CorporateSupplierManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: vm.getDefaultDocumentEditorPage(),
        url: vm.getLoadDocumentBaseURL(),
        subPath: 'corporateSupplierUIModel',
        docType : DocumentConstants.DummyDocumentType.CorporateSupplier,
        label:CorporateSupplierManager.label.corporateSupplier,
        i18nConfig: CorporateSupplierManager.getI18nRootConfig(),
    });

    var fieldMetaList = [{
        fieldName:'id',
    },{
        fieldName:'name',
    },{
        fieldName:'telephone',
    },{
        fieldName:'mobile',
    },{
        fieldName: 'address'
    },{
        fieldName: 'note'
    }];

    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};



