var dataVar = new Vue({
    el: "#x_data",
    mixins: [ServiceItemEditorHelper.defControlMinxin],
    data: {
        label: RegisteredProductManager.label.registeredProductExtendProperty,
        content: {
            registeredProductExtendPropertyUIModel: RegisteredProductManager.content.registeredProductExtendPropertyUIModel,
            serviceUIMeta: {},
            registeredProductExtendPropertyAttachmentList: []
        },
        eleRefValueSettingUUID:'#x_refValueSettingUUID',
        getPageHeaderModelListURL: '../registeredProductExtendProperty/getPageHeaderModelList.html',
        searchStandardUnitURL:'../standardRegisteredProductExtendProperty/searchModuleService.html',
        loadValueSettingListURL: '../matConfigExtPropertySetting/loadLeanModuleListService.html',
        loadValueSettingURL: '../matConfigExtPropertySetting/loadModule.html',
        getMeasureFlagMapURL: '../matConfigExtPropertySetting/getMeasureFlagMap.html',
        getQualityInspectFlagURL: '../matConfigExtPropertySetting/getQualityInspectFlag.html'
    },

    mounted: function () {
        NavigationPanelIns.initNavigation('logistics', 'RegisteredProduct');
    },

    methods: {

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "RegisteredProductExtendPropertyEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.registeredProductExtendPropertyUIModel.uuid;
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getParentUUID: function () {
            return this.content.registeredProductExtendPropertyUIModel.parentNodeUUID;
        },

        /**
         * @Overwrite get service manager class
         * @return {*}
         */
        getServiceManager: function (){
            return RegisteredProductManager;
        },

        //TODO obsolete
        initSelectConfig: function(){
            var vm = this;
            $(vm.eleRefValueSettingUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refValueSettingUUID', $(vm.eleRefValueSettingUUID).val());
                var url = vm.loadValueSettingURL + "?uuid=" + $(vm.eleRefValueSettingUUID).val();
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.content, 'id', content.id);
                    vm.$set(vm.content, 'name', content.name);
                    vm.$set(vm.content, 'refValueSettingUUID', content.uuid);
                    vm.$set(vm.content, 'refUnitUUID', content.refUnitUUID);
                    vm.$set(vm.content, 'measureFlag', content.measureFlag);
                    vm.$set(vm.content, 'qualityInspectFlag', content.qualityInspectFlag);
                    vm.$set(vm.content, 'valueUsage', content.valueUsage);
                    if(content.refUnitUUID){
                        $(vm.eleRefUnit).val(content.refUnitUUID);
                        $(vm.eleRefUnit).trigger("change");
                    }
                    if(content.measureFlag){
                        $(vm.eleMeasureFlag).val(content.measureFlag);
                        $(vm.eleMeasureFlag).trigger("change");
                    }
                    if(content.qualityInspectFlag){
                        $(vm.eleQualityInspectFlag).val(content.qualityInspectFlag);
                        $(vm.eleQualityInspectFlag).trigger("change");
                    }

                }.bind(this));
            });
        },


        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'registeredProductExtendPropertyUIModel', content.registeredProductExtendPropertyUIModel);
            vm.$set(vm.content, 'registeredProductExtendPropertyAttachmentList', content.registeredProductExtendPropertyAttachmentList);
            vm.postUpdateUIModel();
        },

        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'RegisteredProductExtendPropertyEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: RegisteredProductManager,
                coreModelId: 'RegisteredProductExtendProperty',
                i18nPath: 'coreFunction/',
                helpDocumentName: ['RegisteredProductExtendPropertyHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: vm.displayForEdit,
                        callback: vm.saveModule
                    },
                    exit: {
                        callback: vm.exitModule
                    }
                },
                pageHeaderConfig: [{
                    nodeInstId: 'registeredProduct',
                    baseEditUrl:"RegisteredProductEditor.html",
                    targetTab: RegisteredProductManager.documentTab.registeredProductExtendPropertySection,
                    pageTitlePath: 'parentPageTitle' ,
                    pageTitleVarPath: 'refSerialId'
                },{
                    active: true,
                    nodeInstId: 'registeredProductExtendProperty',
                    baseEditUrl:"RegisteredProductExtendPropertyEditor.html",
                    pageTitlePath: 'pageTitle' ,
                    pageTitleVarPath: 'id'
                }],
                callbackTemplateList: [{
                    templateId:'valueSettingUpdate',
                    watchFieldList:["valueSettingName"],
                    method: 'get',
                    url:vm.loadValueSettingURL,
                    uidPath: 'refValueSettingUUID',
                    callbackTemplate:function(content) {
                        return content;
                    }
                }],
                tabMetaList: [{
                    tabId: 'registeredProductExtendPropertySection',
                    tabTitleKey: 'registeredProductExtendPropertySection',
                    titleLabelKey: 'registeredProductExtendPropertySection',
                    titleHelpKey: 'registeredProduct.registeredProductExtendPropertySection',
                    titleIcon: 'md md-straighten content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'registeredProductExtendPropertySection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'registeredProductExtendPropertyUIModel',
                        tabTitleKey: 'registeredProductExtendPropertySection',
                        titleLabelKey: 'registeredProductExtendPropertySection',
                        titleHelpKey: 'material.registeredProductExtendPropertySection',
                        titleIcon: 'md md-texture content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'valueSettingName',
                            newRow: true,
                            fieldKey: 'refValueSettingUUID',
                            settings: {
                                getMetaDataUrl: vm.loadValueSettingListURL,
                                postLoadUrl: vm.loadValueSettingURL,
                                uuidField:'refValueSettingUUID',
                                idField: 'uuid',
                                textField: 'name',
                                fieldList: ['id', 'name', {sourceField: 'uuid', targetField:'refValueSettingUUID'},
                                     'refUnitUUID', 'measureFlag', 'qualityInspectFlag', 'valueUsage']
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'measureFlag',
                            helpKey: 'registeredProductExtendProperty.measureFlag',
                            settings: {
                                getMetaDataUrl: vm.getMeasureFlagMapURL,
                                formatMeta: SystemStandrdMetadataProxy.formatDefaultSwitchCode,
                            },
                            setAutoValue: {
                                callbackTemplateId:"valueSettingUpdate",
                                returnRetrieveByField:'measureFlag'
                            },
                            iconArray: SystemStandrdMetadataProxy.getDefaultSwitchIconArray(),
                            fieldType: AbsInput.FIELDTYPE.Select2
                        },{
                            fieldName: 'qualityInspectFlag',
                            helpKey: 'registeredProductExtendProperty.qualityInspectFlag',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getQualityInspectFlagMapURL,
                                formatMeta: SystemStandrdMetadataProxy.formatDefaultSwitchCode,
                            },
                            setAutoValue: {
                                callbackTemplateId:"valueSettingUpdate",
                                returnRetrieveByField:'qualityInspectFlag'
                            },
                            iconArray: SystemStandrdMetadataProxy.getDefaultSwitchIconArray(),
                            fieldType: AbsInput.FIELDTYPE.Select2
                        },{
                            fieldName: 'id',
                            newRow: true
                        }, {
                            fieldName: 'name'
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        },{
                            refControl: {
                                id: RefControl.Ids.Separator
                            }
                        }, {
                            fieldName: 'doubleValue',
                            fieldKey:'rawValue',
                            labelKey:'rawValue',
                            newRow: true,
                            required: true,
                            postFieldMeta: [{
                                fieldName: 'refUnitUUID',
                                settings: {
                                    getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                    method:'post',
                                    requestData: {},
                                    idField: 'uuid',
                                    textField: 'name'
                                },
                                setAutoValue: {
                                    callbackTemplateId:"valueSettingUpdate",
                                    returnRetrieveByField:'refUnitUUID'
                                },
                                fieldType: AbsInput.FIELDTYPE.Select2
                            }]
                        }]
                    }]
                }, {
                    tabId: 'registeredProductExtendPropertyAttachment',
                    tabTitleKey: 'attachmentSection',
                    sectionMetaList: [{
                        sectionId: 'registeredProductExtendPropertyAttachment',
                        editBlock: true,
                        sectionCategory: AsyncSection.sectionCategory.ATTACHMENT,
                        parentContentPath: 'registeredProductExtendPropertyAttachmentUIModelList',
                        errorHandle: 'errorHandle',
                        settings: {
                            configMetaPath: 'attachmentMeta'
                        }
                    }]
                }]
            };
        }

    }
});
