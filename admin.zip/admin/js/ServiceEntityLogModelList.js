var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        searchModuleURL: '../serviceEntityLogModel/searchModuleService.html'
    },
    methods: {
        searchModule: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.searchModuleURL, requestData).then(function (response) {
                listVar.refreshTableItems(JSON.parse(response.data).content);
            });
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            messageType: '',
            processMode: '',
            name: '',
            newValue: '',
            fieldType: '',
            oldValue: '',
            id:'',
            refLogonUserId:'',
            refLogonUserName: '',
            lastUpdateTimeStrHigh: '',
            lastUpdateTimeStrLow: '',
            refSEName:'BidInvitationOrder'

        },

        label: {
            messageType: '',
            processMode: '',
            name: '',
            newValue: '',
            fieldType: '',
            oldValue: '',
            id:'',
            refLogonUserId:'',
            clearSearch:'',
            clearSearchComment:'',
            refLogonUserName: '',
            lastUpdateTime: '',
            advancedSearchCondition: ''
        },
        eleLastUpdateTimeHigh: '#x_lastUpdateTimeHigh',
        eleLastUpdateTimeLow: '#x_lastUpdateTimeLow',
        eleMessageType: '#x_messageType',
        eleProcessMode: '#x_processMode',
        eleRefUUID: '#x_refUUID',
        eleCreatedBy: '#x_createdBy',
        searchModuleURL: '../serviceEntityLogModel/searchModuleService.html',
        getMessageTypeURL: '../serviceEntityLogModel/getMessageTypeMap.html',
        getProcessModeURL: '../serviceEntityLogModel/getProcessModeMap.html'
    },


    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            vm.getMessageType();
            vm.getProcessMode();
            vm.initDatePickerConfigure();
        });
    },
    methods: {

        clearSearch: function(){
            clearSearchModel(this.content);
        },

        initDatePickerConfigure: function () {
            $(this.eleLastUpdateTimeHigh).datepicker({
                language: "zh-CN",
                autoclose: true,
                clearBtn: true,
                todayBtn: true,
                format: "yyyy-mm-dd"
            });
            $(this.eleLastUpdateTimeHigh).datepicker().on(
                'changeDate', function (oEvent) {
                    this.content.lastUpdateTimeStrHigh = $(this.eleLastUpdateTimeHigh).val();
                }.bind(this));
            $(this.eleLastUpdateTimeLow).datepicker({
                language: "zh-CN",
                autoclose: true,
                clearBtn: true,
                todayBtn: true,
                format: "yyyy-mm-dd"
            });
            $(this.eleLastUpdateTimeLow).datepicker().on(
                'changeDate', function (oEvent) {
                    this.content.lastUpdateTimeStrLow = $(this.eleLastUpdateTimeLow).val();
                }.bind(this));
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleMessageType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'messageType', $(vm.eleMessageType).val());
            });
            $(vm.eleProcessMode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'processMode', $(vm.eleProcessMode).val());
            });

        },
        getMessageType: function () {
            var vm = this;
            this.$http.get(this.getMessageTypeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                resultList.splice(0, 0, {'id': '0', 'text': ' '});
                setTimeout(function () {
                    $(vm.eleMessageType).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleMessageType).val(vm.content.messageType);
                    $(vm.eleMessageType).trigger("change");
                }, 0);
            });
        },
        getProcessMode: function () {
            var vm = this;
            this.$http.get(this.getProcessModeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                resultList.splice(0, 0, {'id': '0', 'text': ' '});
                setTimeout(function () {
                    $(vm.eleProcessMode).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleProcessMode).val(vm.content.processMode);
                    $(vm.eleProcessMode).trigger("change");
                }, 0);
            });
        }

    }
});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: {
            messageType: '',
            processMode: '',
            name: '',
            newValue: '',
            fieldType: '',
            oldValue: '',
            id:'',
            refLogonUserId:'',
            refLogonUserName: '',
            lastUpdateTime: ''
        },
        tableId: '#x_table_serviceEntityLogModel',
        datatable: '',
        items: [],
        loadModuleListURL: '../serviceEntityLogModel/loadModuleListService.html',
        preLockURL: '../serviceEntityLogModel/preLockService.html'
    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            this.initRefSEName();
            this.datatable = new ServiceDataTable(this.tableId);
            this.setI18nProperties();
            this.loadModuleList();
        });
    },
    methods: {

        initRefSEName: function(){
            var refSEName = getUrlVar("refSEName");
            searchModel.content.refSEName = refSEName;
            if(refSEName === 'BidInvitationOrder'){
                Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'BidInvitationLogModel');
            }
            if(refSEName === 'InboundDelivery'){
                Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'InboundDeliveryLogModel');
            }
            if(refSEName === 'OutboundDelivery'){
                Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'OutboundDeliveryLogModel');
            }
        },

        setI18nCommonProperties: function () {
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.buttonEdit = $.i18n.prop('edit');
            this.label.buttonView = $.i18n.prop('view');
            processModel.label.search = $.i18n.prop('search');
            searchModel.label.advancedSearchCondition = $.i18n.prop('advancedSearchCondition');
            searchModel.label.clearSearch = $.i18n.prop('clearSearch');
            searchModel.label.clearSearchComment = $.i18n.prop('clearSearchComment');
            BusyLoader.cleanPageBackground();
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },
        setNodeI18nPropertiesCore: function () {
            this.label.messageType = $.i18n.prop('messageType');
            this.label.processMode = $.i18n.prop('processMode');
            this.label.name = $.i18n.prop('name');
            this.label.id = $.i18n.prop('id');
            this.label.refLogonUserId = $.i18n.prop('refLogonUserId');
            this.label.refLogonUserName = $.i18n.prop('refLogonUserName');
            this.label.lastUpdateTime = $.i18n.prop('lastUpdateTime');

            searchModel.label.messageType = $.i18n.prop('messageType');
            searchModel.label.processMode = $.i18n.prop('processMode');
            searchModel.label.name = $.i18n.prop('name');
            searchModel.label.id = $.i18n.prop('id');
            searchModel.label.refLogonUserId = $.i18n.prop('refLogonUserId');
            searchModel.label.refLogonUserName = $.i18n.prop('refLogonUserName');
            searchModel.label.lastUpdateTime = $.i18n.prop('lastUpdateTime');
            searchModel.label.newValue = $.i18n.prop('newValue');
            searchModel.label.fieldType = $.i18n.prop('fieldType');
            searchModel.label.oldValue = $.i18n.prop('oldValue');
            searchModel.label.password = $.i18n.prop('password');
            searchModel.label.id = $.i18n.prop('id');
            searchModel.label.name = $.i18n.prop('name');
        },
        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'ServiceEntityLogModel', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
        },
        getI18nPath: function () {
            return 'coreFunction/';
        },
        loadModuleList: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(searchModel.searchModuleURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                vm.$set(vm, 'items', JSON.parse(response.data).content);
                setTimeout(function () {
                    vm.datatable.build();
                }, 0);
            });
        },
        refreshTableItems: function (items) {
            this.datatable = new ServiceDataTable(this.tableId);
            this.$set(this, 'items', items);
            setTimeout(function () {
                this.datatable.build();
            }, 0);

        },
        editModule: function (uuid) {
            var vm = this;
            // var requestData = generateServiceSimpleContentUnion("uuid", uuid, "refSEName", searchModel.content.refSEName);
            var paras = {};
            paras.processMode = PROCESSMODE_EDIT;
            paras.uuid = uuid;
            paras.refSEName = searchModel.content.refSEName;
            var resultURL = "ServiceEntityLogModelEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },
        preLock: function () {
        }
    }
});
