var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        processButtonMeta:[],
        author:{
            resourceId:'RegisteredProduct',
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        serviceUIMeta: {},
        downloadExcelURL: '../registeredProduct/downloadExcel.html',
        searchModuleURL: '../registeredProduct/searchModuleService.html'
    },

    created: function(){
        this.initAuthorResourceCheck();
        this.initSubComponents();
    },

    methods: {
        searchModule: function () {
            listVar.searchModuleList();
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        downloadExcel: function () {
            var vm = this;
            var excelType = ServiceUIMetaProxy.filterKeyValue(vm.serviceUIMeta, 'excelType');
            ServiceExcelHelper.downloadExcel({
                url: vm.downloadExcelURL,
                $http: vm.$http,
                excelType: excelType,
                busyLoader: vm.$refs.refBusyLoader,
                requestData: searchModel.content,
                reportTitle: listVar.label.modelTitle,
                errorHandle: listVar.errorHandle
            });
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                downloadExcel: {
                    formatClass: vm.displayForExcel,
                    callback: vm.downloadExcel
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        }

    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            traceStatus: "",
            cargoType: "",
            supplyType: "",
            referenceDateLowStr: "",
            referenceDateHighStr: "",
            validFromDateLowStr: "",
            validFromDateHighStr: "",
            validToDateLowStr: "",
            validToDateHighStr: "",
            productionDateLowStr: "",
            productionDateHighStr: "",
            uuid: "",
            serialId: "",
            refMaterialSKUUUID: "",
            salesOrganizationId: "",
            salesOrganizationName: "",
            salesOrgContactName: "",
            productOrganizationId: "",
            productOrganizationName: "",
            productOrgContactName: "",
            corporateSupplierId: "",
            corporateSupplierName: "",
            refMaterialSKUName: "",
            refMaterialSKUId: "",
            packageStandard: "",
            purchaseOrganizationId: "",
            purchaseOrganizationName: "",
            id: "",
            name: ""
        },
        controlAreaArray: ['.area0', '.area1', '.area2'],
        label: RegisteredProductManager.label.registeredProduct,
        eleReferenceDateLow: '#x_referenceDateLow',
        eleReferenceDateHigh: '#x_referenceDateHigh',
        eleValidFromDateLow: '#x_validFromDateLow',
        eleValidFromDateHigh: '#x_validFromDateHigh',
        eleValidToDateLow: '#x_validToDateLow',
        eleValidToDateHigh: '#x_validToDateHigh',
        eleProductionDateLow: '#x_productionDateLow',
        eleProductionDateHigh: '#x_productionDateHigh',
        eleTraceStatus: '#x_traceStatus',
        eleRefSupplyType: '#x_supplyType',
        eleRefCargoType: '#x_cargoType',
        getSupplyTypeURL: '../material/getSupplyType.html',
        getCargoTypeURL: '../material/getCargoType.html',
        getTraceStatusURL: '../materialStockKeepUnit/getTraceStatus.html',
        loadSalesOrganizationSelectListURL: '../organization/loadModuleListService.html',
        loadCorporateCustomerSelectListURL: '../corporateCustomer/loadModuleListService.html',
        loadCorporateSupplierSelectListURL: '../corporateCustomer/loadModuleListService.html'
    },

    created: function(){
        this.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            vm.initDatePickerConfigure();
            MaterialManager.loadDefaultMetaBatch({
                'vm': vm,
                'addEmptyFlag': true,
                'uiModel':vm.content
            });
            MaterialStockKeepUnitManager.loadDefaultMetaBatch({
                'vm': vm,
                'addEmptyFlag': true,
                'uiModel':vm.content
            });

            RegisteredProductManager.loadDefaultMetaBatch({
                'vm': vm,
                'addEmptyFlag': true,
                'uiModel':vm.content
            });
        });
    },
    methods: {

        /**
         * Initial register sub component
         */
        initSubComponents: function(){
            "use strict";
            Vue.component("expand-toggle-button", ExpandToggleButton);
            Vue.component("expand-button-pair", ExpandButtonPair);
        },

        clearSearch: function () {
            clearSearchModel(this.content);
            clearDefSearchSelectElements([this.eleRefPurchaseOrgUUID, this.eleRefCustomerUUID, this.eleRefSalesOrgUUID,
                this.eleRefSupplierUUID, this.eleCargoType, this.eleSupplyType, this.eleTraceStatus]);
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleRefPurchaseOrgUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refPurchaseOrgUUID', $(vm.eleRefPurchaseOrgUUID).val());
            });
            $(vm.eleRefCustomerUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refCustomerUUID', $(vm.eleRefCustomerUUID).val());
            });
            $(vm.eleRefSalesOrgUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refSalesOrgUUID', $(vm.eleRefSalesOrgUUID).val());
            });
            MaterialManager.initDefSelectConfigure({
                'vm':vm,
                'uiModel': vm.content
            });

            MaterialStockKeepUnitManager.initDefSelectConfigure({
                'vm':vm,
                'uiModel': vm.content
            });
        },


        initDatePickerConfigure: function () {
            var vm = this;
            // Init Plan start time high
            ServiceDataPickerHelper.initDatePicker({
                element:vm.eleReferenceDateLow,
                callBack: function(val){
                    vm.content.eleReferenceDateLow = val;
                }
            });

            ServiceDataPickerHelper.initDatePicker({
                element:vm.eleReferenceDateHigh,
                callBack: function(val){
                    vm.content.referenceDateHighStr = val;
                }
            });

            ServiceDataPickerHelper.initDatePicker({
                element:vm.eleValidFromDateLow,
                callBack: function(val){
                    vm.content.validFromDateLowStr = val;
                }
            });

            ServiceDataPickerHelper.initDatePicker({
                element:vm.eleValidFromDateHigh,
                callBack: function(val){
                    vm.content.validFromDateHighStr = val;
                }
            });

            ServiceDataPickerHelper.initDatePicker({
                element:vm.eleValidToDateLow,
                callBack: function(val){
                    vm.content.validToDateLowStr = val;
                }
            });

            ServiceDataPickerHelper.initDatePicker({
                element:vm.eleValidFromDateHigh,
                callBack: function(val){
                    vm.content.validFromDateHighStr = val;
                }
            });

            ServiceDataPickerHelper.initDatePicker({
                element:vm.eleValidToDateHigh,
                callBack: function(val){
                    vm.content.validToDateHighStr = val;
                }
            });

            ServiceDataPickerHelper.initDatePicker({
                element:vm.eleProductionDateLow,
                callBack: function(val){
                    vm.content.productionDateLowStr = val;
                }
            });
            ServiceDataPickerHelper.initDatePicker({
                element:vm.eleProductionDateHigh,
                callBack: function(val){
                    vm.content.productionDateHighStr = val;
                }
            });
        }

    }
});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: RegisteredProductManager.label.registeredProduct,
        loadModuleListURL: '../registeredProduct/loadModuleListService.html',
        preLockURL: '../registeredProduct/preLockService.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('logistics', 'RegisteredProduct');
            this.setI18nProperties(processModel.initProcessButtonMeta);
            this.loadModuleList();
        });
    },
    methods: {

        initSubComponents: function(){
            "use strict";
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nCommonReflective(this.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nCommonReflective(searchModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nCommonReflective(processModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
        },


        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties, serviceUIMeta: processModel.serviceUIMeta,
                fnCallback: fnCallback, modelId: 'RegisteredProduct', coreModelId: 'RegisteredProduct',
                label: [vm.label, processModel.label, searchModel.label], vm: processModel, errorHandle: vm.errorHandle,
                configList:[{
                    name: 'Material',
                    callback: this.setNodeI18nPropertiesCore
                },{
                    name: 'MaterialStockKeepUnit',
                    callback: this.setNodeI18nPropertiesCore
                },{
                    name: 'RegisteredProduct',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        refreshTableItems: function (items) {
            this.datatable = new ServiceDataTable(this.tableId);
            this.$set(this, 'items', items);
            setTimeout(function () {
                this.datatable.build();
            }, 0);
        },

        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                $http:vm.$http,
                author:processModel.author,
                editorPage:"RegisteredProductEditor.html",
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        searchModuleList: function () {
            this.$refs.dataTableFrame.searchModuleList();
        },

        buildSearchData: function (data) {
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../registeredProduct/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'serialId',
                labelKey: 'serialId',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.RegisteredProduct,
                    uuidFieldName: 'uuid'
                }
            }, {
                fieldName: 'refMaterialSKUId',
                labelKey: 'refMaterialSKUId',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.MaterialStockKeepUnit,
                    uuidFieldName: 'uuid'
                }
            },{
                fieldName: 'refMaterialSKUName',
                labelKey: 'refMaterialSKUName',
                minWidth: '180px'
            },{
                fieldName: 'traceStatusValue',
                fieldKey: 'traceStatus',
                labelKey: 'traceStatus',
                iconArray: MaterialStockKeepUnitManager.getTraceStatusIconArray()
            }, {
                fieldName: 'referenceDate',
                labelKey: 'referenceDate',
                minWidth: '180px'
            },{
                fieldName: 'productionDate',
                labelKey: 'productionDate',
                minWidth: '150px'
            }];
            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        }

    }
});
