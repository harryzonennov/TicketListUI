/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var EmployeeManager = function () {

};

EmployeeManager.label = {
    employee: ServiceUtilityHelper.getComLabelObject({
        cityName: '',
        stateName: '',
        countryName: '',
        streetName: '',
        driverLicenseNumber: '',
        houseNumber: '',
        age: '',
        gender: '',
        workRole: '',
        birthDate: '',
        jobLevel: '',
        logonUserTitle: '',
        driverLicenseType: '',
        webPage: '',
        identification: '',
        status: '',
        modelTitle: '',
        statusValue: '',
        active: '',
        activeTitle:'',
        archive: '',
        archiveTitle: '',
        reInit: '',
        reInitTitle: '',
        subArea: '',
        address: '',
        townZone: '',
        postcode: '',
        operateType: '',
        mobile: '',
        fax: '',
        boardDate: '',
        telephone: '',
        accountType: '',
        note: '',
        email: '',
        regularType: '',
        employeeRole: '',
        organizationId: '',
        organizationName: '',
        logonUserId: '',
        logonUserName: '',
        addEmployee: '',
        addEmployeeOrgReference: '',
        addEmpLogonUserReference: '',
        employeeAttachmentSection: '',
        employeeSection: '',
        employeeContactSection: '',
        organizationSection: '',
        logonUserSection: '',
        newOrganization: '',
        tab1Title: '',
        tab2Title: '',
        advancedSearchCondition: ''
    }),
    employeeOrg: ServiceUtilityHelper.getComLabelObject({
        employeeRole: '',
        organizationId: '',
        organizationName: '',
        organizationFunction: '',
        addressInfo: ''
    }),
};

EmployeeManager.content = {
    employeeUIModel: ServiceUtilityHelper.extendObject({
        refCityUUID: '',
        gender: '',
        workRole: '',
        cityName: '',
        stateName: '',
        countryName: '',
        streetName: '',
        driverLicenseNumber: '',
        houseNumber: '',
        age: '',
        birthDate: '',
        jobLevel: '',
        driverLicenseType: '',
        webPage: '',
        identification: '',
        subArea: '',
        address: '',
        townZone: '',
        postcode: '',
        operateType: '',
        mobile: '',
        fax: '',
        boardDate: '',
        telephone: '',
        accountType: '',
        email: '',
        employeeRole: '',
        logonUserUUID: '',
        logonUserId: '',
        logonUserName: '',
        organizationUUID: '',
        organizationId: '',
        organizationName: ''
    }, ServiceUtilityHelper.getDefContent()),
};

EmployeeManager.labelTemplate = {
    data: function () {
        return {
            label: {
                "employeeOrg": EmployeeManager.label.employeeOrg,
                "actionNode": ServiceActionCodeNodeHelper.defLabelObj
            }
        };
    }
};

/**
 * Definition of Tab on UI
 * @type {{}}
 */
EmployeeManager.documentTab = {
    employeeSection: 'tabEmployeeSection',
    organizationSection: 'tabOrganizationSection'
};


EmployeeManager.DOC_ACTION_CODE = {
    APPROVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_APPROVE,
    REJECT_APPROVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REJECT_APPROVE,
    SUBMIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_SUBMIT,
    REVOKE_SUBMIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REVOKE_SUBMIT,
    REINIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REINIT,
    ACTIVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_ACTIVE,
    ARCHIVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_ARCHIVE
};


EmployeeManager.getCustomActionCodeIconMap = function () {
    return [
        {
            id: EmployeeManager.DOC_ACTION_CODE.ACTIVE,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_ACTIVE
        },
        {
            id: EmployeeManager.DOC_ACTION_CODE.REINIT,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_ACTIVE
        }
    ];
};

EmployeeManager.getActionCodeIconMap = function () {
    var actionCodeIconMap = ServiceUtilityHelper.getMergedActionCodeIconMap(EmployeeManager.getCustomActionCodeIconMap());
    return actionCodeIconMap;
};
/**
 * [API] Get root node inst id
 */
EmployeeManager.getRootNodeInstId = function(){
    return "employee";
};

/**
 * [API]Get item node inst id
 */
EmployeeManager.getItemNodeInstId = function(){
    return "employeeOrg";
};


/**
 * [API] Get resource id for checking authorization
 */
EmployeeManager.getResourceId = function(){
    return ServiceModuleConstants.Employee;
};

/**
 * [API] Get document type
 */
EmployeeManager.getDocumentType = function(){
    return DocumentConstants.DummyDocumentType.Employee;
};

/**
 * [API]Get root 18n config
 */
EmployeeManager.getI18nRootConfig = function () {
    return {
        i18nPath: 'coreFunction/',
        mainName: 'Employee',
        modelId: 'Employee', coreModelId: 'Employee',
        configList: [{
            name: 'EmployeeOrg',
            subLabelPath: 'employeeOrg'
        }, {
            actionNodePath: 'actionNode'
        }]
    };
};

/**
 * [API]Get item 18n config
 */
EmployeeManager.getI18nItemConfig = function () {
    "use strict";
    return {
        i18nPath: 'coreFunction/',
        labelObject: EmployeeManager.label.employeeOrg,
        mainName: 'EmployeeOrg',
        modelId: 'Employee', coreModelId: 'EmployeeOrg',
        configList: [{
            name: 'EmployeeOrg'
        }]
    };
};


EmployeeManager.getActionCodeIconMap = function () {
    var actionCodeIconMap = ServiceUtilityHelper.getMergedActionCodeIconMap(EmployeeManager.getCustomActionCodeIconMap());
    return actionCodeIconMap;
};

EmployeeManager.getGenderIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.StandardPropety.Gender.MALE, iconClass: 'fa fa-male content-lightblue'},
        {id: DocumentConstants.StandardPropety.Gender.FEMALE, iconClass: 'fa fa-female content-pink'}
    ];
};

EmployeeManager.formatGenderIconClass = function (gender) {
    "use strict";
    var genderIconArray = EmployeeManager.getGenderIconArray();
    var $element = ServiceCollectionsHelper.filterArray(gender, 'id', genderIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

EmployeeManager.formatGender = function (gender) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(gender, EmployeeManager.getGenderIconArray(), true);
    return $element;
};

EmployeeManager.formatStatusIconClass = function (status) {
    "use strict";
    var statusIconArray = EmployeeManager.getStatusIconArray();
    var $element = ServiceCollectionsHelper.filterArray(status, 'id', statusIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

EmployeeManager.formatStatus = function (status) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(status, EmployeeManager.getStatusIconArray(), true);
    return $element;
};

EmployeeManager.getStatusIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.Employee.status.INIT, iconClass: 'md md-remove-circle-outline content-grey'},
        {id: DocumentConstants.Employee.status.ACTIVE, iconClass: 'md md-spellcheck content-peach-red'},
        {id: DocumentConstants.Employee.status.ARCHIVE, iconClass: 'md md-sd-card content-grey'}
    ];
};

/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
EmployeeManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../employee/loadModuleViewService.html';
};


/**
 * Constants method: Get URL for load status metadata
 * @returns {*[]}
 */
EmployeeManager.prototype.getStatusURL = function (status) {
    "use strict";
    return '../employee/getStatusMap.html';
};

EmployeeManager.prototype.getModelTitle = function () {
    return EmployeeManager.label.employee.modelTitle;
};

/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
EmployeeManager.prototype.getI18nWrap = function (fnCallback) {
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "coreFunction/",
        commonCallback: this.setI18nCommonProperties,
        fnCallback: fnCallback,
        configList: [{
            name: 'Employee',
            callback: this.setNodeI18nPropertiesCore
        }]
    });
};


/**
 * @override Set Basic path for i18n function.
 * @returns {string}
 */
EmployeeManager.getI18nPath = function () {
    return "coreFunction/";
};

EmployeeManager.prototype.getI18nCommonMap = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(EmployeeManager.label.employee, $.i18n.prop);
};

EmployeeManager.prototype.getI18nDocMap = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(EmployeeManager.label.employee, $.i18n.prop, true);

};

EmployeeManager.prototype.getDefaultDocumentEditorPage = function () {
    "use strict";
    return "EmployeeEditor.html";
};

EmployeeManager.prototype.getDefaultDocumentItemEditorPage = function () {
    "use strict";
    return undefined;
};

EmployeeManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: vm.getDefaultDocumentEditorPage(),
        url: vm.getLoadDocumentBaseURL(),
        subPath: 'employeeUIModel',
        docType: DocumentConstants.DummyDocumentType.Employee,
        label: EmployeeManager.label.employee,
        getI18nWrap: vm.getI18nWrap.bind(vm)
    });

    var fieldMetaList = [{
        fieldName: 'id',
    }, {
        fieldName: 'name',
    }, {
        fieldName: 'mobile',
    }, {
        fieldName: 'statusValue',
        fieldKey: 'status',
        labelKey: 'status',
        iconArray: EmployeeManager.getStatusIconArray()
    }, {
        fieldName: 'jobLevelValue',
        fieldKey: 'jobLevel',
        labelKey: 'jobLevel',
        iconArrayRequest: {
            url: '../employee/getJobLevel.html'
        }
    }, {
        fieldName: 'workRoleValue',
        fieldKey: 'workRole',
        labelKey: 'workRole',
        iconArrayRequest: {
            url: '../employee/getWorkRole.html'
        }
    }, {
        fieldName: 'genderValue',
        fieldKey: 'gender',
        labelKey: 'gender',
        iconArray: EmployeeManager.getGenderIconArray()
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};

