
var ExcelUploadAttach = function () {
    
};

ExcelUploadAttach.IMAGE_PATH = {
    XLS_BIG : "assets/images/excel_256.png"
};

var ExcelUploadAttach = function(){

};

ExcelUploadAttach.prototype.label = {
    attachment: {
        dragUploadExcelMessage: '',
        uploadFileTooBig: '',
        commitUpload: '',
        uploadInvalidFileType: '',
        attachmentTitle: '',
        attachmentDescription: '',
        uploadExcel: '',
        deleteAttachment: '',
        confirm:''
    }
};



/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
ExcelUploadAttach.prototype.getI18nWrap = function (fnCallback) {
    var vm = this;
    jQuery.i18n.properties({
        name: 'ComElements', //properties file name
        path: getI18nRootPath() + "coreFunction/",
        mode: 'map', //Using map mode to consume properties files
        language: getLan(),
        cache:true,
        callback: function(){
            vm.getI18nCommonMap();
            if(fnCallback && typeof fnCallback === 'function'){
                fnCallback();
            }
        }.bind(this)
    });
};

ExcelUploadAttach.prototype.getI18nCommonMap = function () {
    this.label.attachment.drapUploadExcelMessage = $.i18n.prop('drapUploadExcelMessage');
    this.label.attachment.uploadFileTooBig = $.i18n.prop('uploadFileTooBig2M');
    this.label.attachment.commitUpload = $.i18n.prop('commitUpload');
    this.label.attachment.uploadInvalidFileType = $.i18n.prop('uploadInvalidFileType');
    this.label.attachment.attachmentTitle = $.i18n.prop('attachmentTitle');
    this.label.attachment.attachmentDescription = $.i18n.prop('attachmentDescription');
    this.label.attachment.deleteAttachment = $.i18n.prop('deleteAttachment');
    this.label.attachment.confirm = $.i18n.prop('confirm');
};

ExcelUploadAttach.showFile = function(blob, reportTitle){

    // It is necessary to create a new blob object with mime-type explicitly set
    // otherwise only Chrome works like it should
    var newBlob = new Blob([blob], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"})

    // IE doesn't allow using a blob object directly as link href
    // instead it is necessary to use msSaveOrOpenBlob
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(newBlob);
        return;
    }

    // For other browsers:
    // Create a link pointing to the ObjectURL containing the blob.
    var data = window.URL.createObjectURL(newBlob);
    var link = document.createElement('a');
    link.href = data;
    var date = new Date();
    var fileName = reportTitle + date.getFullYear() + (date.getMonth() + 1) + date.getDate() + ".xls";
    link.download=fileName;
    link.click();
};


/**
 * Initialization drop zone plugin for attachment uploading
 * @param {object} oSettings
 *         --{function} refreshEditView
 *         --{string} eleAttachmentDropzone
 *         --{string} uploadAttachmentURL
 *         --{function} deleteAttachmentCallback
 *         --{object} $http
 *         --{object} attachmentDropzone
 */
ExcelUploadAttach.prototype.initAttachmentPlugin = function (oSettings) {
    var vm = this;

    var defAcceptedFiles = ".xls, .xlsx";
    var eleUploadAttachment = oSettings.eleUploadAttachment? oSettings.eleUploadAttachment:'x_uploadExcelAttachment';

    return new Promise(function(resolve, reject){
        var callBack = function () {
            oSettings.attachmentDropzone = new Dropzone(oSettings.eleAttachmentDropzone, {
                url: oSettings.uploadAttachmentURL,                                      // url to load files to server
                uploadMultiple: true,                                                    // Accept Multiple files upload
                dictDefaultMessage: oSettings.dictDefaultMessage? oSettings.dictDefaultMessage: vm.label.attachment.dragUploadExcelMessage,       // Message to show on empty dropzone
                dictFileTooBig: vm.label.attachment.uploadFileTooBig,                    // Error Message when file is too big
                dictInvalidFileType: vm.label.attachment.uploadInvalidFileType,          // Error Message when file type is not accepted
                autoProcessQueue: true,
                maxFilesize: 10,                                                         // Max File Size *(MB)
                acceptedFiles: oSettings.acceptedFiles? oSettings.acceptedFiles: defAcceptedFiles,                  // Accepted file types
                queuecomplete: oSettings.queuecomplete? oSettings.queuecomplete: function(){},                      // file uploaded done call-back function
                init: function () {
                    this.on("success", function (file, responseText) {
                        if(oSettings.successCallback){
                            oSettings.successCallback(file, responseText);
                        }
                    });
                    this.on("error", function (file, message) {
                        this.removeFile(file);
                        if(oSettings.errorCallback){
                            oSettings.errorCallback(message, file);
                        }
                    });
                    this.on("addedfile", function (file) {
                        // Create the remove button
                        var removeButton = Dropzone.createElement("<button class='btn btn-rounded waves-effect waves-light'>" +
                            vm.label.attachment.deleteAttachment + "</button>");
                        // Capture the Dropzone instance as closure.
                        var _this = this;
                        // Listen to the click event
                        removeButton.addEventListener("click", function (e) {
                            // Make sure the button click doesn't submit the form:
                            e.preventDefault();
                            e.stopPropagation();
                            // Remove the file preview.
                            _this.removeFile(file);
                            // If you want to the delete the file on the server as well,
                            // you can do the AJAX request here.
                        });
                        // Add the button to the file preview element.
                        file.previewElement.appendChild(removeButton);
                    });
                }
            });


            $(".iconDeleteAttachment").on("click", function (e) {
                var uuid = $(this).children("input").attr("value");
                vm.deleteAttachment(oSettings, uuid);
                e.stopPropagation();
            });
            oSettings.attachmentDropzone.on('addedfile', vm.getDefaultAddedAttachment());
            resolve(oSettings.attachmentDropzone);
        }.bind(this);
        vm.getI18nWrap(callBack);
    });
};


/**
 * Default Added event function for attachment display
 * @returns {_func}
 */
ExcelUploadAttach.prototype.getDefaultAddedAttachment = function(){
    var _func = function (file) {
        var ext = file.name.split('.').pop();
        if (ext.indexOf("xls") != -1) {
            $(file.previewElement).find(".dz-image img").attr("src", "assets/images/excel_128.png");
        } else if (ext.indexOf("xlsx") != -1) {
            $(file.previewElement).find(".dz-image img").attr("src", "assets/images/excel_128.png");
        }
    };
    return _func;
};


