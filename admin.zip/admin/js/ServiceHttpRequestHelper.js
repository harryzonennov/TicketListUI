/**
 * Document manager factory
 * Should based on ["PurchaseContractManager", "SalesContractManager"]
 */

var ServiceApplicationFactory = (function () {
    var instance;

    function createInstance() {
        var serviceApplication = new ServiceApplication();
        return serviceApplication;
    }

    return {
        getInstance: function () {
            if (!instance) {
                instance = createInstance();
            }
            return instance;
        }
    };
})();

ServiceApplicationFactory.getMessageListPromise = function ($http) {
    var serviceApplication = ServiceApplicationFactory.getInstance();
    return serviceApplication.getMessageListPromise($http);
};

ServiceApplicationFactory.getRoleListPromise = function ($http) {
    var serviceApplication = ServiceApplicationFactory.getInstance();
    return serviceApplication.getRoleListPromise($http);
};

ServiceApplicationFactory.getAuthorizationACUnionListPromise = function ($http) {
    var serviceApplication = ServiceApplicationFactory.getInstance();
    return serviceApplication.getAuthorizationACUnionListPromise($http);
};

ServiceApplicationFactory.getNavigationListPromise = function ($http) {
    var serviceApplication = ServiceApplicationFactory.getInstance();
    return serviceApplication.getNavigationListPromise($http);
};

ServiceApplicationFactory.checkAuthorization = function ($http, resourceId, actionCodeId) {
    var serviceApplication = ServiceApplicationFactory.getInstance();
    return serviceApplication.checkAuthorization($http, resourceId, actionCodeId);
};

ServiceApplicationFactory.filterResourceModel = function (resourceId, roleList) {
    var serviceApplication = ServiceApplicationFactory.getInstance();
    return serviceApplication.filterResourceModel(resourceId, roleList);
};

ServiceApplicationFactory.filterAuthorizationACUninon = function (resourceId, authorizationACUnionList) {
    var serviceApplication = ServiceApplicationFactory.getInstance();
    return serviceApplication.filterAuthorizationACUninon(resourceId, authorizationACUnionList);
};


ServiceApplicationFactory.getAuthorizationObject = function ($http, resourceId, actionCodeObject) {
    var serviceApplication = ServiceApplicationFactory.getInstance();
    return serviceApplication.getAuthorizationObject($http, resourceId, actionCodeObject);
};

ServiceApplicationFactory.getAuthorizationUnion = function ($http, resourceId, actionCodeObject) {
    var serviceApplication = ServiceApplicationFactory.getInstance();
    return serviceApplication.getAuthorizationUnion($http, resourceId, actionCodeObject);
};


/**
 * Utility class to simplify Auhtorization API.
 * @constructor
 */
var ServiceAuthorHelper = function () {

};


/**
 * Wrapper method to update authorization object
 * @param {object} oSettings
 *    --- {vue} vm
 *    --- {object} author
 *    --- {function} errorHandle
 */
ServiceAuthorHelper.initDefaultAuthorObject = function (oSettings) {
    var vm = oSettings.vm;
    var authorPromise = ServiceApplicationFactory.getAuthorizationObject(vm.$http, vm.author.resourceId, vm.author.actionCode);
    authorPromise.then(function (oResult) {
        vm.$set(vm, 'author', oResult);
    }, function (reason) {
        if (oSettings.loadingComponent && oSettings.loadingComponent.hideBusyLoading) {
            oSettings.loadingComponent.hideBusyLoading();
        }
        ServiceAuthorHelper._processSpecError(reason);
        oSettings.errorHandle(reason);
    }).catch(function (error) {
        if (oSettings.loadingComponent && oSettings.loadingComponent.hideBusyLoading) {
            oSettings.loadingComponent.hideBusyLoading();
        }
        ServiceAuthorHelper._processSpecError(error);
        oSettings.errorHandle(error);
    });
    return authorPromise;
};

ServiceAuthorHelper._processSpecError = function (error) {
    if (error && error.errorCode * 1 === HttpStatus.SC_NO_CONTENT) {
        error.errorMessage = '权限资源加载错误';
    }
};

/**
 * Wrapper method to update authorization object
 * @param {object} oSettings
 *    --- {$http} $http
 *    --- {object} author
 *    --- {function} errorHandle
 */
ServiceAuthorHelper.getAuthorPromise = function (oSettings) {
    return ServiceApplicationFactory.getAuthorizationUnion(oSettings.$http, oSettings.author.resourceId, oSettings.author.actionCode);
};


var ServiceApplication = function () {
    "use strict";
    this.roleList = undefined;
    this.authorizationACUnionList = undefined;
    this.navigationItemList = undefined;
    this.actionCodeSelectList = undefined;
    this.loadUserMessageURL = '../logonUser/loadUserMessageService.html';
    this.loadUserRoleURL = '../logonUser/loadUserRoleService.html';
    this.getAuthorizationACUnionListURL = '../logonUser/getAuthorizationACUnionList.html';
    this.searchActiveModuleServiceURL = '../navigationItemSetting/searchActiveModuleService.html';
    this.loadActionCodeSelectListURL = '../actionCode/loadModuleListService.html';
};

ServiceApplication.prototype.getMessageListPromise = function ($http) {
    "use strict";
    return new Promise(function (resolve, reject) {
        $http.get(this.loadUserMessageURL).then(function (response) {
            var oData = JSON.parse(response.data);
            if (!oData.content) {
                ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                reject(oData);
            }
            this.messageList = oData.content;
            resolve(this.messageList);
        }).catch(function () {
            resolve();
        });
    }.bind(this));
};


ServiceApplication.prototype.getRoleListPromise = function ($http) {
    "use strict";
    var vm = this;
    return new Promise(function (resolve, reject) {
        if (vm.roleList) {
            resolve(vm.roleList);
        } else {
            $http.get(vm.loadUserRoleURL).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    reject(oData);
                }
                vm.roleList = oData.content;
                resolve(vm.roleList);
            });
        }
    }.bind(this));
};


ServiceApplication.prototype.getAuthorizationACUnionListPromise = function ($http) {
    "use strict";
    return new Promise(function (resolve, reject) {
        if (this.authorizationACUnionList) {
            resolve(this.authorizationACUnionList);
        } else {
            $http.get(this.getAuthorizationACUnionListURL).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    reject(oData);
                }
                this.authorizationACUnionList = oData.content;
                resolve(this.authorizationACUnionList);
            });
        }
    }.bind(this));
};


ServiceApplication.prototype.getNavigationListPromise = function ($http) {
    "use strict";
    return new Promise(function (resolve, reject) {
        if (this.navigationItemList) {
            resolve(this.navigationItemList);
        } else {
            $http.post(this.searchActiveModuleServiceURL, {}).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    reject(oData);
                }
                this.navigationItemList = oData.content;
                resolve(this.navigationItemList);
            });
        }
    }.bind(this));
};

ServiceApplication.prototype.getActionCodeListPromise = function ($http) {
    var vm = this;
    return new Promise(function (resolve, reject) {
        if (vm.actionCodeSelectList) {
            resolve(vm.actionCodeSelectList);
        } else {
            $http.get(this.loadActionCodeSelectListURL).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    reject(oData);
                }
                vm.actionCodeSelectList = oData.content;
                resolve(vm.actionCodeSelectList);
            });
        }
    }.bind(this));
};

/**
 * @Deprecated
 * @param $http
 * @param resourceId
 * @param actionCodeObject
 * @returns {Promise<unknown>}
 */
ServiceApplication.prototype.getAuthorizationObject = function ($http, resourceId, actionCodeObject) {
    var vm = this;
    var roleListPromise = this.getRoleListPromise($http);
    var actionCodeListPromise = this.getActionCodeListPromise($http);
    var promises = [roleListPromise, actionCodeListPromise];
    if (!actionCodeObject) {
        // reject({'error': 'no action code'});
        return;
    }
    return new Promise(function (resolve, reject) {
        Promise.all([roleListPromise, actionCodeListPromise]).then(function (values) {
            var roleList = values[0];
            var codeList = values[1];
            var roleAuthorizationUIModel = this.filterResourceModel(resourceId, roleList);
            if (roleAuthorizationUIModel) {
                var result = {
                    "resourceId": resourceId,
                    "actionCode": {}
                };
                for (var i in actionCodeObject) {
                    var actionCodeResult = vm.filterActionCodeResult(roleAuthorizationUIModel, codeList, i);
                    if (actionCodeResult) {
                        result.actionCode[i] = true;
                    } else {
                        result.actionCode[i] = false;
                    }
                }
                resolve(result);
            } else {
                reject({'errorCode': HttpStatus.SC_NO_CONTENT});
            }
        }.bind(this));
    }.bind(this));
};


ServiceApplication.prototype.getAuthorizationUnion = function ($http, resourceId, actionCodeObject) {
    var vm = this;
    var authorizationACUnionListPromise = this.getAuthorizationACUnionListPromise($http);
    var actionCodeListPromise = this.getActionCodeListPromise($http);
    if (!actionCodeObject) {
        reject({'error': 'no action code'});
    }
    return new Promise(function (resolve, reject) {
        Promise.all([authorizationACUnionListPromise, actionCodeListPromise]).then(function (values) {
            var authorizatonACList = values[0];
            var codeList = values[1];
            var authorizationACUnion = this.filterAuthorizationACUninon(resourceId, authorizatonACList);
            var authorizationObject = authorizationACUnion.authorizationObject;
            var codeListToCheck = authorizationACUnion.actionCodeList;
            if (authorizationObject) {
                var result = {
                    "resourceId": resourceId,
                    "actionCode": {}
                };
                for (var i in actionCodeObject) {
                    var actionCodeResult = vm.filterActionCodeList(codeListToCheck, codeList, i);
                    if (actionCodeResult) {
                        result.actionCode[i] = true;
                    } else {
                        result.actionCode[i] = false;
                    }
                }
                resolve(result);
            } else {
                reject({'errorCode': HttpStatus.SC_NO_CONTENT});
            }
        }.bind(this));
    }.bind(this));
};

/**
 * @Deprecated
 * @param $http
 * @param resourceId
 * @param actionCodeId
 * @returns {Promise<unknown>}
 */
ServiceApplication.prototype.checkAuthorization = function ($http, resourceId, actionCodeId) {
    var vm = this;
    var roleListPromise = this.getRoleListPromise($http);
    var actionCodeListPromise = this.getActionCodeListPromise($http);
    var promises = [roleListPromise, actionCodeListPromise];
    return new Promise(function (resolve, reject) {
        Promise.all([roleListPromise, actionCodeListPromise]).then(function (values) {
            var roleList = values[0];
            var codeList = values[1];
            var roleAuthorizationUIModel = this.filterResourceModel(resourceId, roleList);
            if (roleAuthorizationUIModel) {
                var actionCodeResult = vm.filterActionCodeResult(roleAuthorizationUIModel, codeList, actionCodeId);
                if (actionCodeResult) {
                    resolve(true);
                } else {
                    resolve(false);
                }
            } else {
                reject({'error': 'no resource'});
            }
        }.bind(this));
    }.bind(this));
};

ServiceApplication.prototype.getRoleAuthorizationObject = function ($http, resourceId) {
    return new Promise(function (resolve, reject) {
        var roleListPromise = this.getRoleListPromise($http);
        roleListPromise.then(function (values) {
            var roleAuthorizationUIModel = this.filterResourceModel(resourceId, values);
            resolve(roleAuthorizationUIModel);
        }.bind(this)).catch(function (reason) {
            reject({'error': reason});
        }.bind(this));
    }.bind(this));
};

ServiceApplication.prototype.filterResourceModel = function (resourceId, roleList) {
    if (!roleList || roleList.length === 0) {
        return;
    }
    var len = roleList.length, i = 0, j = 0, simObjectArray;
    for (i; i < len; i++) {
        var roleAuthorizationUIModelList = roleList[i].roleAuthorizationUIModelList;
        if (roleAuthorizationUIModelList && roleAuthorizationUIModelList.length) {
            for (j = 0; j < roleAuthorizationUIModelList.length; j++) {
                if (resourceId === roleAuthorizationUIModelList[j].roleAuthorizationUIModel.id) {
                    return roleAuthorizationUIModelList[j].roleAuthorizationUIModel;
                }
                simObjectArray = undefined;
                simObjectArray = roleAuthorizationUIModelList[j].roleAuthorizationUIModel.simObjectArray;
                if (simObjectArray && simObjectArray.indexOf(resourceId) !== -1) {
                    return roleAuthorizationUIModelList[j].roleAuthorizationUIModel;
                }
            }
        }
    }
};


ServiceApplication.prototype.filterAuthorizationACUninon = function (resourceId, authorizationACUnionList) {
    if (!authorizationACUnionList || authorizationACUnionList.length === 0) {
        return;
    }
    var len = authorizationACUnionList.length, i = 0, j = 0, simObjectArray;
    for (i; i < len; i++) {
        var authorizationObject = authorizationACUnionList[i].authorizationObject;
        if (resourceId === authorizationObject.id) {
            return authorizationACUnionList[i];
        }
        simObjectArray = undefined;
        simObjectArray = authorizationObject.simObjectArray;
        if (simObjectArray && simObjectArray.indexOf(resourceId) !== -1) {
            return authorizationACUnionList[i];
        }
    }
};


ServiceApplication.prototype.filterActionCodeList = function (actionCodeListToCheck, actionCodeList, actionCodeId) {
    var actionCode = ServiceCollectionsHelper.filterArray(actionCodeId, 'id', actionCodeList);
    if (!actionCode) {
        return;
    }
    if (!actionCodeListToCheck || actionCodeListToCheck.length === 0) {
        return;
    }
    var len = actionCodeListToCheck.length, i = 0, codeUUID;
    for (i = 0; i < len; i++) {
        codeUUID = actionCodeListToCheck[i].uuid;
        if (codeUUID === actionCode.uuid) {
            return codeUUID;
        }
    }
};


ServiceApplication.prototype.filterActionCodeResult = function (roleAuthorizationUIModel, actionCodeList, actionCodeId) {
    var actionCode = ServiceCollectionsHelper.filterArray(actionCodeId, 'id', actionCodeList);
    if (!actionCode) {
        return;
    }
    var actionCodeUUIDList = roleAuthorizationUIModel.actionCodeArray;
    if (!actionCodeUUIDList || actionCodeUUIDList.length === 0) {
        return;
    }
    var len = actionCodeUUIDList.length, i = 0, codeUUID;
    for (i = 0; i < len; i++) {
        codeUUID = actionCodeUUIDList[i];
        if (codeUUID === actionCode.uuid) {
            return codeUUID;
        }
    }
};

/**
 * Reflective Utility To check if class definition existed or not
 * @constructor
 */
var ServiceClassCheck = function () {

};


ServiceClassCheck.checkActionCodeTab = function () {
    if (typeof ActionCodeTab !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkButtonCore = function () {
    if (typeof ButtonCore !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkCustomerContactUnion = function () {
    if (typeof CustomerContactUnion !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkDocActionModal = function () {
    if (typeof DocActionModal !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkDocAdminDataUnion = function () {
    if (typeof DocAdminDataUnion !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkDocumentLineTab = function () {
    if (typeof DocumentLineTab !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkExcelUploadModal = function () {
    if (typeof ExcelUploadModal !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkItemQuickAction = function () {
    if (typeof ItemQuickAction !== 'undefined') {
        Vue.component("item-quick-action", ItemQuickAction);
    }
};

ServiceClassCheck.checkLabelHelpIcon = function () {
    if (typeof LabelHelpIcon !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkMaterialRegisteredProductUnion = function () {
    if (typeof MaterialRegisteredUnit !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkMaterialTypeSelect = function () {
    if (typeof MaterialTypeSelect !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkMaterialSkuSelect = function () {
    if (typeof MaterialSkuSelect !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkMessageDataUnion = function () {
    if (typeof MessageDataUnion !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkMessageTemplateSelect = function () {
    if (typeof MessageTemplateSelect !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkPopPanelCompensateSection = function () {
    if (typeof PopPanelCompensateSection !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkPopBottomPanel = function () {
    if (typeof PopBottomPanel !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkPopupLabel = function () {
    if (typeof PopupLabel !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkPortTitleHelpIcon = function () {
    if (typeof PortTitleHelpIcon !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkRightBarTimeline = function () {
    if (typeof RightBarTimeline !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkRightBarDocFlow = function () {
    if (typeof RightBarDocFlow !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkStoreAvailableItemList = function () {
    if (typeof StoreAvailableItemList !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkWarehouseAndAreaUnion = function () {
    if (typeof WarehouseAndAreaUnion !== 'undefined') {
        return true;
    }
};

ServiceClassCheck.checkWarehouseSelect = function () {
    if (typeof WarehouseSelect !== 'undefined') {
        return true;
    }
};

var DocFlowContextProxy = function () {

};


DocFlowContextProxy.RESERVED_STATUS = {
    UNKNOWN: 0,
    FREE: 1,
    PARTLY_FREE: 2,
    OWN: 3,
    SHARED: 4,
    OTHER: 5
};


DocFlowContextProxy.getReservedStatusIconArray = function () {
    "use strict";
    return [
        {
            id: DocFlowContextProxy.RESERVED_STATUS.FREE,
            iconClass: 'glyphicon glyphicon-ok content-green'
        },
        {id: DocFlowContextProxy.RESERVED_STATUS.PARTLY_FREE, iconClass: 'nmd nmd-lock content-green'},
        {id: DocFlowContextProxy.RESERVED_STATUS.OWN, iconClass: 'nmd nmd-lock content-green'},
        {id: DocFlowContextProxy.RESERVED_STATUS.SHARED, iconClass: 'nmd nmd-lock content-green'},
        {id: DocFlowContextProxy.RESERVED_STATUS.OTHER, iconClass: 'nmd nmd-lock content-peach-red'}
    ];
};


DocFlowContextProxy.formatReservedStatusIcon = function (reservedStatus) {
    "use strict";
    var reservedStatusIconArray = DocFlowContextProxy.getReservedStatusIconArray();
    var $element = ServiceCollectionsHelper.filterArray(reservedStatus, 'id', reservedStatusIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

var ServiceResourseHelper = function () {
    "use strict";
    this.roleCategoryList = undefined;
    this.loadModuleListURL = '../systemConfigureCategory/loadModuleListService.html';
    this.loadSystemConfigureCategoryURL = '../systemConfigureCategory/loadModuleViewService.html';
};

/**
 * Load all the system wide configure category list
 * @param oSettings
 * @returns {Promise$2|*}
 */
ServiceResourseHelper.prototype.loadAllResourcePromise = function (oSettings) {
    "use strict";
    return new Promise(function (resolve, reject) {
        var resourceInCache = this.getResourceFromCache();
        if (resourceInCache) {
            resolve(resourceInCache);
            return;
        }
        oSettings.$http.get(this.loadModuleListURL).then(function (response) {
            var oData = JSON.parse(response.data);
            this.roleCategoryList = oData.content;
            if (oData.content && oData.content.length > 0) {
                var promises = [];
                for (var i = 0, len = oData.content.length; i < len; i++) {
                    var category = oData.content[i];
                    var subSettings = {
                        $http: oSettings.$http,
                        uuid: category.uuid
                    };
                    var _promise = this.loadCategoryServiceModel(subSettings);
                    promises.push(_promise);
                }
                Promise.all(promises).then(function (values) {
                    this.setResourceToCache(values);
                    resolve(values);
                }.bind(this));
            }
        }.bind(this)).catch(function (oError) {
            console.log(oError);
        });
    }.bind(this));
};

ServiceResourseHelper.prototype.getResourceFromCache = function () {
    "use strict";
    // if(Navigator && Navigator.resourceCache){
    //     return Navigator.resourceCache;
    // }else{
    //     return null;
    // }
    if (sessionStorage) {
        var str = sessionStorage.getItem('resourceCache');
        if (str) {
            return JSON.parse(str);
        }
    }

};

ServiceResourseHelper.prototype.setResourceToCache = function (values) {
    "use strict";
    // if(Navigator){
    //     Navigator.resourceCache = values;
    // }
    if (sessionStorage) {
        sessionStorage.setItem('resourceCache', JSON.stringify(values));
    }
};

/**
 * Load each system category service model from back-end
 * @param {Object} oSettings
 *       --{Object} $http
 *       --{String} uuid: uuid of system category
 */
ServiceResourseHelper.prototype.loadCategoryServiceModel = function (oSettings) {
    "use strict";
    var url = this.loadSystemConfigureCategoryURL + "?uuid=" + oSettings.uuid;
    return new Promise(function (resolve, reject) {
        oSettings.$http.get(url).then(function (response) {
            var oData = JSON.parse(response.data);
            resolve(oData.content);
        }.bind(this));
    }.bind(this));
};

/**
 *
 * @param oSettings:
 *    --{String} resourceLevel
 *    --{String} id
 *    --{String} extensionId
 * @returns {Promise$2|*}
 */
ServiceResourseHelper.prototype.getExtensionValue = function (oFilterSettings) {
    "use strict";
    return new Promise(function (resolve, reject) {
        var resourceInCache = this.getResourceFromCache();
        if (resourceInCache) {
            var result = this.filterResourceInCache(oFilterSettings, resourceInCache);
            resolve(result);
        } else {
            var resourcePromise = this.loadAllResourcePromise(oFilterSettings);
            resourcePromise.then(function (oValue) {
                var result = this.filterResourceInCache(oFilterSettings, resourceInCache);
                resolve(result);
            }.bind(this));
        }
    }.bind(this));
};


ServiceResourseHelper.prototype.filterExtensionUnion = function (oFilterSettings, resourceUnion) {
    "use strict";
    if (!oFilterSettings || !resourceUnion) {
        return;
    }
    var systemConfigureExtensionUnionUIModelList = [];
    var result = undefined;
    if (oFilterSettings.resourceLevel === ServiceResourseHelper.ResourceLevel.ConfigureResource) {
        if (resourceUnion["systemConfigureResourceUIModel"]) {
            systemConfigureExtensionUnionUIModelList = resourceUnion["systemConfigureExtensionUnionUIModelList"];
            if (systemConfigureExtensionUnionUIModelList && systemConfigureExtensionUnionUIModelList.length > 0) {
                result = ServiceCollectionsHelper.filterArray(oFilterSettings.filterExtendKeyValue,
                    oFilterSettings.filterExtendKeyName, systemConfigureExtensionUnionUIModelList);
                if (result) {
                    return result;
                }
            }
        }
    }
    if (oFilterSettings.resourceLevel === ServiceResourseHelper.ResourceLevel.ConfigureElement) {
        if (resourceUnion["systemConfigureElementUIModelList"]) {
            var elementUnion = this.filterResourceInElement(resourceUnion["systemConfigureElementUIModelList"]);
            if (elementUnion) {
                systemConfigureExtensionUnionUIModelList = elementUnion["systemConfigureExtensionUnionUIModelList"];
                if (systemConfigureExtensionUnionUIModelList && systemConfigureExtensionUnionUIModelList.length > 0) {
                    result = ServiceCollectionsHelper.filterArray(oFilterSettings.filterExtendKeyValue,
                        oFilterSettings.filterExtendKeyName, systemConfigureExtensionUnionUIModelList);
                    if (result) {
                        return result;
                    }
                }
            }
        }
    }


};

ServiceResourseHelper.prototype.filterResourceInCache = function (oFilterSettings, resourceInCache) {
    "use strict";
    for (var i = 0, len = resourceInCache.length; i < len; i++) {
        var category = resourceInCache[i];
        // In case current resource Level from filter is 'Category'
        if (oFilterSettings.resourceLevel === ServiceResourseHelper.ResourceLevel.ConfigureCategory) {
            if (oFilterSettings.id === category.systemConfigureCategoryUIModel.id) {
                return category;
            } else {
                continue;
            }
        }
        var resource = this.filterResourceInCategory(oFilterSettings, category);
        if (resource) {
            return resource;
        }
    }
};


ServiceResourseHelper.prototype.filterResourceInCategory = function (oFilterSettings, category) {
    if (!category || !category.systemConfigureResourceUIModelList) {
        return null;
    }
    for (var i = 0, len = category.systemConfigureResourceUIModelList.length; i < len; i++) {
        var systemConfigureResource = category.systemConfigureResourceUIModelList[i];
        if (oFilterSettings.resourceLevel === ServiceResourseHelper.ResourceLevel.ConfigureResource) {
            if (oFilterSettings.id === systemConfigureResource.systemConfigureResourceUIModel.id) {
                return systemConfigureResource;
            } else {
                continue;
            }
        }
        var resource = this.filterResourceInResource(oFilterSettings, systemConfigureResource);
        if (resource) {
            return resource;
        }
    }
};

ServiceResourseHelper.prototype.filterResourceInResource = function (oFilterSettings, systemConfigureResource) {
    if (!systemConfigureResource || !systemConfigureResource.systemConfigureElementUIModelList) {
        return null;
    }
    for (var i = 0, len = systemConfigureResource.systemConfigureElementUIModelList.length; i < len; i++) {
        var systemConfigureElement = systemConfigureResource.systemConfigureElementUIModelList[i];
        var result = this.filterResourceInElement(oFilterSettings, systemConfigureElement);
        if (result) {
            return result;
        }
    }

};

ServiceResourseHelper.prototype.filterResourceInElement = function (oFilterSettings, systemConfigureElement) {
    if (!systemConfigureElement) {
        return null;
    }
    if (oFilterSettings.resourceLevel === ServiceResourseHelper.ResourceLevel.ConfigureElement) {
        if (oFilterSettings.id === systemConfigureElement.systemConfigureElementUIModel.id) {
            return systemConfigureElement;
        }
        var subElementList = systemConfigureElement.systemConfigureElementUIModelList;
        if (subElementList && subElementList.length > 0) {
            for (var i = 0, len = subElementList.length; i < len; i++) {
                var subystemConfigureElement = this.filterResourceInElement(oFilterSettings, subElementList[i]);
                if (subystemConfigureElement) {
                    return subystemConfigureElement;
                }
            }
        }
    }
};

ServiceResourseHelper.ResourceLevel = {
    "ConfigureCategory": "SystemConfigureCategory",
    "ConfigureResource": "SystemConfigureResource",
    "ConfigureElement": "SystemConfigureElement",
    "ConfigureExtensionUnion": "SystemConfigureExtensionUnion"
};

ServiceResourseHelper.FilterSettingsFields = {
    "id": "id",
    "resourceLevel": "resourceLevel",
    "fiterExtendKeyName": "fiterExtendKeyName",
    "fiterExtendKeyValue": "fiterExtendKeyValue"
};


/**
 * Utility method to get Multiple Currency setting element, and set call back
 * @param fnCallback
 */
ServiceResourseHelper.prototype.utilGetMutiCurrencyElement = function ($http, fnCallback) {
    "use strict";
    var oFilterSetting = {
        $http: $http,
        resourceLevel: ServiceResourseHelper.ResourceLevel.ConfigureResource,
        id: 'PriceCurrencyConfig'
    };
    var resultPromise = this.getExtensionValue(oFilterSetting);
    resultPromise.then(function (result) {
        if (result && result.systemConfigureElementUIModelList && result.systemConfigureElementUIModelList.length > 0) {
            var multipleCurrencyConfigure = ServiceCollectionsHelper.filterArray('MultipleCurrency', 'id', result.systemConfigureElementUIModelList, 'systemConfigureElementUIModel');
            multipleCurrencyConfigure = multipleCurrencyConfigure.systemConfigureElementUIModel;
            if (fnCallback && typeof fnCallback === 'function') {
                fnCallback(multipleCurrencyConfigure);
            }
        }
    }.bind(this));
};

/**
 * Utility method to get Multiple Currency setting element, and set call back
 * @param fnCallback
 */
ServiceResourseHelper.prototype.utilGetLogDeliveryCategory = function ($http, fnCallback) {
    "use strict";
    var oFilterSetting = {
        $http: $http,
        resourceLevel: ServiceResourseHelper.ResourceLevel.ConfigureResource,
        id: 'InboundDelivery'
    };
    var resultPromise = this.getExtensionValue(oFilterSetting);
    var oSetting = {
        resourceLevel: ServiceResourseHelper.ResourceLevel.ConfigureResource,
        id: 'InboundDelivery',
        filterExtendKeyName: 'id',
        filterExtendKeyValue: SysConfigureConstants.ExtensionUnion.LogDeliveryCategory
    };
    resultPromise.then(function (result) {
        var logDeliveryCategory = this.filterExtensionUnion(oSetting, result);
        if (fnCallback) {
            fnCallback(logDeliveryCategory);
        }
    }.bind(this));
};

/**
 * Utility class for price info
 * @constructor
 */
ServicePriceUtility = function () {

};

ServicePriceUtility.buildDefPriceInfoUnit = function (document, td, actionCodePrice, price) {
    if (actionCodePrice === true) {
        td.innerHTML = price;
        ServiceDataTable.buildValueStyleCore(document, td, ServicePriceUtility.getPriceIconClass(true));
    }
};

/**
 * Get Price by diff field according to actionCode
 * @param oSettings
 * @returns {*}
 */
ServicePriceUtility.getPrice = function (oSettings) {
    if (oSettings.actionCodePrice) {
        return ServiceUtilityHelper.fetchObjValueByPath(oSettings.model, oSettings.priceField);
    } else {
        return ServiceUtilityHelper.fetchObjValueByPath(oSettings.model, oSettings.priceDisplayField);
    }
};

ServicePriceUtility.getPriceIconClass = function (actionCodePrice) {
    if (actionCodePrice) {
        return "nmd nmd-lock-outline content-red";
    }
};

/**
 * Utlity method to give price left icon to be displayed in edit input field
 * @param priceConfig
 * @return {string}
 */
ServicePriceUtility.calculatePriceLeftIcon = function (priceConfig) {
    if (!priceConfig) {
        return;
    }
    if (priceConfig.role && priceConfig.role === ServicePriceUtility.PriceConfigRole.internal) {
        return "nmd nmd-lock-outline content-red";
    }
};

ServicePriceUtility.PriceConfigRole = {
    internal: "internal",
    display: "display"
};

/**
 * Helper Class for
 * @constructor
 */
var ServiceExtensionSettingHelper = function () {
    "use strict";
    this.extensionMap = {};
    this.loadModuleListURL = '../serviceExtensionSetting/loadModuleListService.html';
    this.loadModelByIdURL = '../serviceExtensionSetting/loadModuleByIdService.html';
};

ServiceExtensionSettingHelper.prototype.getExtensionById = function (id, $http) {
    "use strict";
    return new Promise(function (resolve, reject) {
        var extension = this.extensionMap[id];
        if (extension) {
            resolve(extension);
        }
        var url = this.loadModelByIdURL + "?id=" + id;
        $http.get(url).then(function (response) {
            var oData = JSON.parse(response.data);
            if (oData.content) {
                this.extensionMap[id] = oData.content;
                resolve(oData.content);
                return;
            } else {
                resolve();
            }
        }.bind(this));
    }.bind(this));

};

ServiceExtensionSettingHelper.prototype.getCustomFieldList = function (serviceExtendFieldSettingList, lan) {
    if (serviceExtendFieldSettingList && serviceExtendFieldSettingList.length > 0) {
        var customFiledList = ServiceCollectionsHelper.filterToArray(true, 'customI18nFlag', serviceExtendFieldSettingList, 'serviceExtendFieldSettingUIModel');
        if (customFiledList && customFiledList.length) {
            var resultList = [];
            for (var i = 0, len = customFiledList.length; i < len; i++) {
                var labelUnion = ServiceCollectionsHelper.filterArray(lan, 'lanKey', customFiledList[i].serviceExtendFieldI18nSettingUIModelList);
                if (labelUnion) {
                    // Copy attr: 'fieldName' to labelUnion
                    labelUnion.fieldName = customFiledList[i].serviceExtendFieldSettingUIModel['fieldName'];
                    resultList.push(labelUnion);
                }
            }
            return resultList;
        }
    }
};

ServiceExtensionSettingHelper.prototype.getFieldSettingList = function (serviceExtendFieldSettingList, lan) {
    if (serviceExtendFieldSettingList && serviceExtendFieldSettingList.length > 0) {
        var customFiledList = ServiceCollectionsHelper.filterToArray(true, 'customI18nFlag', serviceExtendFieldSettingList, 'serviceExtendFieldSettingUIModel');
        if (customFiledList && customFiledList.length) {
            var resultList = [];
            for (var i = 0, len = customFiledList.length; i < len; i++) {
                var labelUnion = ServiceCollectionsHelper.filterArray(lan, 'lanKey', customFiledList[i].serviceExtendFieldI18nSettingUIModelList);
                if (labelUnion) {
                    // Copy attr: 'fieldName' to labelUnion
                    labelUnion.fieldName = customFiledList[i].serviceExtendFieldSettingUIModel['fieldName'];
                    resultList.push(labelUnion);
                }
            }
            return resultList;
        }
    }
};

ServiceExtensionSettingHelper.prototype.setCustomI18n = function ($http, resourceId, labelObject) {
    var resultPromise = this.getExtensionById(resourceId, $http);
    resultPromise.then(function (result) {
        if (!result) {
            return;
        }
        var fieldList = this.getCustomFieldList(result.serviceExtendFieldSettingUIModelList, getLan());
        if (fieldList && fieldList.length > 0) {
            for (var i = 0, len = fieldList.length; i < len; i++) {
                var field = fieldList[i];
                if (labelObject[field.fieldName]) {
                    labelObject[field.fieldName] = field.labelValue;
                }
            }
        }
    }.bind(this));
};

var ServiceUtilityHelper = function () {

};

ServiceUtilityHelper.toggleDetailCore = function ($targetElement, event) {
    if ($targetElement) {
        if ($targetElement.hasClass("hide-display")) {
            $targetElement.toggleClass("hide-display", false);
            if (event && event.currentTarget) {
                var iconElement = $(event.currentTarget).children("i");
                iconElement.toggleClass("ion-chevron-down", false);
                iconElement.toggleClass("ion-chevron-up", true);
            }
        } else {
            $targetElement.toggleClass("hide-display", true);
            if (event && event.currentTarget) {
                var iconElement = $(event.currentTarget).children("i");
                iconElement.toggleClass("ion-chevron-down", true);
                iconElement.toggleClass("ion-chevron-up", false);
            }
        }
    }
};

ServiceUtilityHelper.defSetTooltip = function (oSettings) {
    if (oSettings && oSettings.label) {
        $(".ion-chevron-up").tooltip({title: oSettings.label.unfoldMoreTitle});
        $(".ion-chevron-down").tooltip({title: oSettings.label.expandMoreTitle});
    }
};

ServiceUtilityHelper.formatSelectWithIcon = function (selectOption, selectOptionMap, backDirection) {
    "use strict";
    var iconElement;
    var selectOptionMapUnion = ServiceCollectionsHelper.filterArray(selectOption.id, 'id', selectOptionMap);
    if (selectOptionMapUnion && selectOptionMapUnion.iconClass) {
        iconElement = document.createElement("i");
        iconElement.setAttribute("class", selectOptionMapUnion.iconClass);
    }
    var $element = selectOption.text;
    if (iconElement) {
        $element = document.createElement('span');
        var spanTextNode = document.createTextNode(" " + selectOption.text);

        if (backDirection && backDirection === true) {
            var seperate = document.createElement('span');
            seperate.appendChild(document.createTextNode("- "));
            seperate.setAttribute("class", "ts-transparent");
            $element.appendChild(spanTextNode);
            $element.appendChild(seperate);
            $element.appendChild(iconElement);
        } else {
            $element.appendChild(iconElement);
            $element.appendChild(spanTextNode);
        }

    }
    return $element;
};

/**
 * Switch to tab by retrieving tab key information by parsing URL paras
 */
ServiceUtilityHelper.switchToTab = function () {
    var tabKey = getUrlVar(LABEL_TABKEY);
    if (tabKey && !isNaN(tabKey)) {
        $('.nav.nav-tabs li:eq(' + tabKey + ') a').click();
    }
    // In case tab key is class value
    if (tabKey && isNaN(tabKey) && typeof tabKey === 'string') {
        //$('.nav.nav-tabs li.' + tabKey + ' a').click();
        ServiceUtilityHelper.clickTab({
            tabKey: tabKey
        });
    }
};

/**
 * Click and trigger tab switch by tabkey on purpose
 * @param oSettings
 *   -- containerId: container id in order to specify scopy of nav tabs
 */
ServiceUtilityHelper.clickTab = function (oSettings) {
    "use strict";
    var navClass = '.nav.nav-tabs li.';
    var tabElement = navClass + oSettings.tabKey + ' a';
    if (oSettings.containerId) {
        tabElement = '#' + oSettings.containerId + ' ' + tabElement;
    }
    $(tabElement).click();
};


ServiceUtilityHelper.copyObjectFields = function (fieldsList, sourceObj, targetObj) {
    "use strict";
    var i, len = 0;
    if (!fieldsList || !sourceObj || !targetObj || fieldsList.length === 0) {
        return;
    }
    len = fieldsList ? fieldsList.length : 0;
    for (i = 0; i < len; i++) {
        if (sourceObj[fieldsList[i]]) {
            targetObj[fieldsList[i]] = sourceObj[fieldsList[i]];
        }
    }
    return targetObj;
};

ServiceUtilityHelper.resetObject = function (targetObj, initObj) {
    "use strict";
    if (!targetObj) {
        return;
    }
    if (initObj) {
        targetObj = Object.assign({}, initObj);
    } else {
        targetObj = {};
    }
    return targetObj;
};

ServiceUtilityHelper.cloneObj = function (targetObj) {
    "use strict";
    if (!targetObj) {
        return;
    }
    return Object.assign({}, targetObj);
};

/**
 * Merge list of object into one object with all the possible fields
 * @param rawObjList
 * @returns {*}
 */
ServiceUtilityHelper.mergeToObject = function (rawObjList) {
    "use strict";
    var targetObject = {};
    if (!rawObjList || rawObjList.length === 0) {
        return;
    }
    targetObject = rawObjList[0];
    if (rawObjList.length === 1) {
        return targetObject;
    }
    var i = 1, j = 0, lenObj = 0, len = rawObjList.length;
    for (i = 1; i < len; i++) {
        if (!rawObjList[i]) {
            continue;
        }
        var keys = Object.keys(rawObjList[i]);
        lenObj = keys.length;
        for (j = 0; j < lenObj; j++) {
            if (rawObjList[i][keys[j]]) {
                targetObject[keys[j]] = rawObjList[i][keys[j]];
            }
        }
    }
    return targetObject;
};

/**
 * Precheck before execution/http request send by checking 'executionTime'.
 * @param oSettings
 *   --{vue} vm
 *   --{object} cache
 */
ServiceUtilityHelper.preCheckExecute = function (oSettings) {
    if (!oSettings.cache['execTimes']) {
        // initial execTimes if not exist
        oSettings.vm.$set(oSettings.cache, 'execTimes', 0);
    }
    if (oSettings.cache['execTimes'] >= 1) {
        // in case already executed, just return undefined.
        return;
    }
    // set already execution flag
    oSettings.vm.$set(oSettings.cache, 'execTimes', 1);
    return true;
};

/**
 * build common Address format
 * @param oSettings
 *     -- stateName: {string} state/province name
 *     -- cityName: {string} city name
 *     -- townZone: {string} town zone
 *     -- streetName: {string} street name
 *     -- houseNumber: {string} house number
 *     -- postcode: {string} post code
 *     -- telephone: {string} telephone number
 */
ServiceUtilityHelper.buildAddressInfo = function (oSettings) {
    "use strict";
    var addressInfo = '';
    addressInfo += oSettings.stateName ? oSettings.stateName + "省 " : "";
    addressInfo += oSettings.cityName ? oSettings.cityName + "市 " : "";
    addressInfo += oSettings.townZone ? oSettings.townZone + " " : "";
    addressInfo += oSettings.streetName ? oSettings.streetName + " " : "";
    addressInfo += oSettings.houseNumber ? oSettings.houseNumber + " " : "";
    addressInfo += oSettings.postcode ? " 邮编：" + oSettings.postcode : "";
    addressInfo += oSettings.telephone ? " 电话：" + oSettings.telephone : "";
    return addressInfo;
};


ServiceUtilityHelper.unlockAll = function () {
    var unLockAllURL = '../common/unLockAll.html';
    this.$http.post(unLockAllURL, {}).then(function (response) {
        $.Notification.notify('success', 'top center', this.label.common.unlockSuccessTitle, this.label.common.unlockSystemSuccessComment);
    });
};

/**
 * build common Address format
 * @param oSettings
 *     -- length: {number} length
 *     -- width: {number} width
 */
ServiceUtilityHelper.directCalculateArea = function (oSettings) {
    "use strict";
    var length = (!isNaN(oSettings.length) && (oSettings.length > 0)) ? oSettings.length : 0;
    var width = (!isNaN(oSettings.width) && (oSettings.width > 0)) ? oSettings.width : 0;
    return length * width;
};

/**
 * build common Address format
 * @param oSettings
 *     -- length: {number} length
 *     -- width: {number} width
 */
ServiceUtilityHelper.directCalculateVolume = function (oSettings) {
    "use strict";
    var length = (!isNaN(oSettings.length) && (oSettings.length > 0)) ? oSettings.length : 0;
    var width = (!isNaN(oSettings.width) && (oSettings.width > 0)) ? oSettings.width : 0;
    var height = (!isNaN(oSettings.height) && (oSettings.height > 0)) ? oSettings.height : 0;
    return length * width * height;
};

/**
 * Get the format value of price: > 0
 * @param {number} rawValue
 */
ServiceUtilityHelper.formatPositiveNumber = function (rawValue) {
    var number = (!isNaN(rawValue) && (rawValue > 0)) ? rawValue : 0;
    return number;
};

/**
 * Get the format value of percentage value 1 ~ 100
 * @param {number} rawValue
 */
ServiceUtilityHelper.formatPercentage = function (rawValue) {
    var percentage = (!isNaN(rawValue) && (rawValue > 0)) ? ((rawValue > 100) ? 100 : rawValue) : 0;
    return percentage;
};
/**
 * build common Address format
 * @param oSettings
 *     -- length: {number} taxRate 1 ~ 100
 *     -- rawValue: {number} raw value without tax
 */
ServiceUtilityHelper.calculateValueWithTax = function (oSettings) {
    "use strict";
    var taxRate = ServiceUtilityHelper.formatPercentage(oSettings.taxRate);
    var rawValue = (!isNaN(oSettings.rawValue) && (oSettings.rawValue > 0)) ? oSettings.rawValue : 0;
    var result = rawValue * (100 + taxRate * 1) / 100;
    return changeTwoDecimal(result);
};

/**
 * build common Address format
 * @param oSettings
 *     -- length: {number} taxRate 1 ~ 100
 *     -- rawValue: {number} raw value with tax
 */
ServiceUtilityHelper.calculateValueNoTax = function (oSettings) {
    "use strict";
    var taxRate = ServiceUtilityHelper.formatPercentage(oSettings.taxRate);
    var rawValue = (!isNaN(oSettings.rawValue) && (oSettings.rawValue > 0)) ? oSettings.rawValue : 0;
    var result = rawValue * 100 / (100 + taxRate * 1);
    return changeTwoDecimal(result);
};

ServiceUtilityHelper.checkPathContainsKey = function (path, key) {
    "use strict";
    if (!path) {
        return;
    }
    var i, len, pathUnion, pathElements = path.split('.');
    if (!pathElements || pathElements.length === 0) {
        return;
    }
    for (i = 0, len = pathElements.length; i < len; i++) {
        pathUnion = pathElements[i];
        if (pathUnion === key) {
            return true;
        }
    }
};

/**
 * Convert multiple dom classes (seperated with space) to dom equation (seperated with dot)
 */
ServiceUtilityHelper.convertMultiClassToDOMEquation = function (classesArray) {
    "use strict";
    if (!classesArray) {
        return null;
    }
    var classesList = ServiceStringHelper.splitBySpace(classesArray);
    var resultClass;
    for (var i = 0, len = classesList.length; i < len; i++) {
        resultClass = "." + classesList[i];
    }
    return resultClass;
};

/**
 * Utility method to pass too long value if possible.
 * @param oSettings
 * @returns {{value: string, changed: boolean}}
 */
ServiceUtilityHelper.processValueIfTooLong = function (oSettings) {
    var value = oSettings.value;
    var maxLength = oSettings.maxLength ? oSettings.maxLength : 22;
    var changed = false;
    if (value && value.length > maxLength) {
        value = value.slice(0, maxLength) + "...";
        changed = true;
    }
    return {value: value, changed: changed};
};

ServiceUtilityHelper.fetchObjValueByPathList = function (obj, pathList) {
    "use strict";
    if (ServiceCollectionsHelper.checkNullList(pathList)) {
        return null;
    }
    var value;
    ServiceCollectionsHelper.traverseListInterrupt(pathList, function (path, index) {
        var tmpValue = ServiceUtilityHelper.fetchObjValueByPath(obj, path);
        value = value + tmpValue;
        if (index < pathList.length - 1) {
            value = value + '-';
        }
        return true;
    });
    return value;
};

/**
 * split the path value to multiple path elements by seperator .
 * @param path
 * @return {*}
 */
ServiceUtilityHelper.parseToPathElements = function (path) {
    return path.split('.');
};

/**
 * Fetch objet type's instance field value by path
 * @param {object} obj: object type value
 * @param {string} path: object value path, seperated with '.'
 */
ServiceUtilityHelper.fetchObjValueByPath = function (obj, path) {
    "use strict";
    if (!path) {
        return null;
    }
    // in case multiple path
    if (path && path.split('-').length > 1) {
        return ServiceUtilityHelper.fetchObjValueByPathList(obj, path.split('-'));
    }
    var i, len, pathUnion, subObj = obj, pathElements = ServiceUtilityHelper.parseToPathElements (path);
    if (!pathElements || pathElements.length === 0) {
        return null;
    }
    for (i = 0, len = pathElements.length; i < len; i++) {
        pathUnion = pathElements[i];
        if (pathUnion === 'label') {
            continue;
        }
        if (!subObj) {
            continue; // In case subObj is null, just return
        }
        if (subObj[pathElements[i]] && typeof subObj[pathElements[i]] === 'string') {
            return subObj[pathElements[i]];
        }
        if (subObj[pathElements[i]] && typeof subObj[pathElements[i]] === 'number') {
            return subObj[pathElements[i]];
        }
        // Dive to deeper layer
        subObj = subObj[pathElements[i]];
        if (subObj && typeof subObj === 'string') {
            return subObj;
        }
        if (subObj && typeof subObj === 'number') {
            return subObj;
        }
        if (subObj === 0 && typeof subObj === 'number') {
            return 0;
        }
    }
    return subObj;
};

/**
 * Fetch Object value by path precisely, in case empty value retrieved, will retry each sub elements
 * @param obj
 * @param path
 */
ServiceUtilityHelper.fetchObjValueByPathRetry = function (obj, path) {
    "use strict";
    var resultValue = ServiceUtilityHelper.fetchObjValueByPath(obj, path);
    if (!resultValue) {
        var i, len, pathElements = ServiceUtilityHelper.parseToPathElements (path);
        for (len = pathElements.length, i = len - 1; i > 0; i--) {
            resultValue = ServiceUtilityHelper.fetchObjValueByPath(obj, pathElements[i]);
            if (resultValue) {
                break;
            }
        }
    }
    return resultValue;
};

/**
 * Default logic to get label value for field meta object
 * @param oSettings
 *    --{Object} fieldMeta
 *       --{String} labelKey: field name for retrieve label value from label object
 *       --{String} fieldName: default field name
 *       --{String} fieldLabel: field to store label value directly, and the computed field value will also stored in this field.
 *    --{Object} labelObject
 */
ServiceUtilityHelper.getDefLabelFieldMeta = function (oSettings) {
    var labelObject = oSettings.labelObject;
    var fieldMeta = oSettings.fieldMeta;
    if (labelObject) {
        if (fieldMeta.labelKey) {
            fieldMeta.fieldLabel = ServiceUtilityHelper.fetchObjValueByPath(labelObject, fieldMeta.labelKey);
        } else {
            fieldMeta.fieldLabel = ServiceUtilityHelper.fetchObjValueByPath(labelObject, fieldMeta.fieldName);
        }
    } else {
        fieldMeta.fieldLabel = fieldMeta.fieldName;
    }
};


ServiceUtilityHelper.navigateToNewModule = function (oSettings) {
    var uuid = oSettings.uuid ? oSettings.uuid : oSettings.baseUUID;
    var editorPage = oSettings.editorPage;
    var paras = {};
    paras.processMode = PROCESSMODE_NEW;
    paras.uuid = uuid;
    var resultURL = editorPage + "?" + urlEncode(paras);
    if (oSettings.forceNewWindow && oSettings.forceNewWindow === true) {
        window.open(resultURL, '_blank');
    }
    window.location.href = resultURL;
};

/**
 * Utility to get the column size element take by parsing the colClass
 * @param {String}colClass: column class,  such as col-md-12, col-md-6, col-md-4
 * @return {*}
 */
ServiceUtilityHelper.parseColSize = function (colClass) {
    var colArray = colClass.split('-');
    return colArray[colArray.length - 1] * 1;
};

/**
 * Utlity to update new column size to col class
 * @param colClass
 * @param colSize
 * @return {*}
 */
ServiceUtilityHelper.updateColSize = function (colClass, colSize) {
    var colArray = colClass.split('-');
    colArray[colArray.length - 1] = colSize;
    return colArray.join('-');
};


/**
 * Utility to calculate how many elements one row could contain, give the colClass
 * @param {String}colClass: column class,  such as col-md-12, col-md-6, col-md-4
 * @return {*}
 */
ServiceUtilityHelper.calculateRowSize = function (colClass) {
    var colSize = ServiceUtilityHelper.parseColSize(colClass);
    return 12 / colSize;
};

/**
 * Wrapper method to control navigate into editor page from list page
 * @param oSettings
 *     -- {string} uuid: uuid
 *     -- {string} editorpage: target editor page.
 *     -- {string} preLockURL: preLock URL if possible
 *     -- {author} author: authorization object
 *     -- {boolean} forceNewWindow: force open an new window
 *     -- {function} postHandle: standard handle method
 *     -- {function} errorHandle: error handling method
 *     -- {function} lockFailureHandle: lock failure handle method
 */
ServiceUtilityHelper.navigateToEditModule = function (oSettings) {
    var uuid = oSettings.uuid;
    var editorPage = oSettings.editorPage;
    var author = oSettings.author;
    var requestData = generateServiceSimpleContentUnion("uuid", uuid);
    var actionCode = getUrlVar(LABEL_ACTIONCODE);
    if (author && author.actionCode.Edit === true && oSettings.preLockURL) {
        oSettings.$http.post(oSettings.preLockURL, requestData).then(function (response) {
            var oData = JSON.parse(response.data);
            if (!oData.RC) {
                oSettings.errorHandle(oData);
                return;
            }
            if (oData.RC * 1 === HttpStatus.SC_OK) {
                if (!oSettings.postHandle) {
                    var resultURL = genCommonEditURL(editorPage, uuid);
                    if (actionCode) {
                        resultURL = resultURL + urlEncode({"actionCode": actionCode});
                    }
                    if (oSettings.forceNewWindow && oSettings.forceNewWindow === true) {
                        window.open(resultURL, '_blank');
                    }
                    window.location.href = resultURL;
                } else {
                    oSettings.postHandle(oData);
                }
            } else {
                oSettings.lockFailureHandle(oData);
            }
        }).catch(function (error) {
            oSettings.errorHandle(error);
        });
    } else {
        var resultURL = genCommonEditURL(editorPage, uuid);
        if (actionCode) {
            resultURL = resultURL + urlEncode({"actionCode": actionCode});
        }
        if (oSettings.forceNewWindow && oSettings.forceNewWindow === true) {
            window.open(resultURL, '_blank');
        }
        window.location.href = resultURL;
    }
};

/**
 * Utility method to check something with loop and timeout
 * @param oSettings
 *    --{function} checkCallback: call back method to check if can return
 *    --{function} postCallback: call back method
 *
 */
ServiceUtilityHelper.traverseCheckTimeout = function (oSettings) {
    var i = 0, maxLimit = oSettings.maxLimit ? oSettings.maxLimit : 1000,
        interval = oSettings.interval ? oSettings.interval : 100;
    for (i = 0; i < maxLimit; i++) {
        var input = {
            i: i,
            maxLimit: maxLimit,
            interval: interval
        };
        var result = oSettings.checkCallback(input);
        if (result && result === true) {
            oSettings.postCallback(input);
            return true;
        }
        setTimeout(function () {

        }, interval);
    }
};


/**
 * Utility method to loop call some thing until reaches max limits
 * @param oSettings
 *    --{function} callback: call back method to be executed in loop
 *    --{number} call method will end until it reaches to max limits
 *    --{interval} an intervening time by milli-seconds
 *    --{function} breakCallback: return true then break
 *
 */
ServiceUtilityHelper.loopCallByTimeout = function (oSettings) {
    var i = 1;                  //  set your counter to 1
    function myLoop() {         //  create a loop function
        setTimeout(function () {
            i++;
            oSettings.callback({
                index: i
            });
            var breakFlag = false;
            if (oSettings.breakCall) {
                breakFlag = oSettings.breakCall();
                if (breakFlag === true) {
                    i = oSettings.maxLimit;
                }
            }
            if (i < oSettings.maxLimit) {
                myLoop();
            }
        }, oSettings.interval);
    }
    myLoop();
};


/**
 * Utility method to load edit module/view module by author check
 * @param oSettings
 *     --{string} editUrl
 *     --{string} viewUrl
 *     --{string} uuid
 *     --{$http} $http
 *     --{object} author
 */
ServiceUtilityHelper.loadEditModulePromise = function (oSettings) {
    var uuid = oSettings.uuid;
    var editUrl = oSettings.editUrl;
    var viewUrl = oSettings.viewUrl;
    var author = oSettings.author;
    var url = oSettings.viewUrl;
    if (author && author.actionCode.Edit === true) {
        // Navigate to edit module
        url = oSettings.editUrl;
    }
    if (uuid) {
        url = url + "?uuid=" + uuid;
    }
    return oSettings.$http.get(url);
};

ServiceUtilityHelper.newModuleDefault = function (oSettings) {
    if ($('.editBlock')) {
        $('.editBlock').hide();
    }
    var url = oSettings.newModuleServiceURL;
    var vm = oSettings.vm;
    var baseUUID = oSettings.baseUUID ? oSettings.baseUUID : getUrlVar("baseUUID");
    var errorHandle = oSettings.errorHandle ? oSettings.errorHandle : vm.errorHandle;
    var requestData = {};
    if (baseUUID) {
        requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
    }
    var postSet = oSettings.postSet ? oSettings.postSet : vm.setModuleToUI;
    vm.$http.post(url, requestData).then(function (response) {
        var oData = JSON.parse(response.data);
        if (!oData.content) {
            errorHandle(oData);
            return;
        }
        postSet(oData.content);
    }).catch(function (error) {
        errorHandle(error);
    });
};


/**
 * Utility method to load edit module/view module by author check
 * @param oSettings
 *     --{string} editUrl
 *     --{string} viewUrl
 *     --{string} uuid
 *     --{object} author
 *     --{$http} $http
 *     --{jQuery} messageContainer
 *     --{object} loadingComponent
 *     --{function} initAuthor: update author object
 *     --{function} postSet: after read handle method
 *     --{function} errorHandle: error handle method
 */
ServiceUtilityHelper.loadEditModuleDefault = function (oSettings) {
    "use strict";
    ServiceMessageBarHelper.removeMessageBar({
        container: oSettings.messageContainer
    });
    if (oSettings.author) {
        // In case need to check authorization by promise
        ServiceAuthorHelper.getAuthorPromise(oSettings).then(function (authorResponse) {
            oSettings.author = authorResponse;
            if (oSettings.initAuthor) {
                oSettings.initAuthor(authorResponse);
            }
            ServiceUtilityHelper._loadEditModuleDefCore(oSettings);
        });
    } else {
        // In case don't need to check authorization
        ServiceUtilityHelper._loadEditModuleDefCore(oSettings);
    }
};

ServiceUtilityHelper._loadEditModuleDefCore = function (oSettings) {
    "use strict";
    ServiceUtilityHelper.loadEditModulePromise({
        editUrl: oSettings.editUrl,
        viewUrl: oSettings.viewUrl,
        uuid: oSettings.uuid,
        $http: oSettings.$http,
        author: oSettings.author
    }).then(function (response) {
        if (oSettings.loadingComponent && oSettings.loadingComponent.hideBusyLoading) {
            oSettings.loadingComponent.hideBusyLoading();
        }
        var oData = JSON.parse(response.data);
        if (!oData.content) {
            if (oSettings.errorHandle) {
                oSettings.errorHandle(oData);
            } else {
                ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                    container: oSettings.messageContainer
                });
            }
            return;
        }
        if (oSettings.postSet) {
            oSettings.postSet(oData.content);
        }
    }).catch(function (error) {
        if (oSettings.errorHandle) {
            oSettings.errorHandle(error);
        } else {
            ServiceHttpRequestHelper.handleErrorWithBarWrap(error, {
                container: oSettings.messageContainer
            });
        }
    });
};

/**
 * Provide default UI handler method for saving data
 * @param oSettings
 *   --{function} Required: fnGetBaseUUID
 *   --{string} Required: editorPage
 *   --{vue} Required: vm
 */
ServiceUtilityHelper.defSaveModuleWrapper = function (oSettings) {
    var targetSettings = oSettings;
    var vm = targetSettings.vm;
    targetSettings.$http = targetSettings.$http ? targetSettings.$http : vm.$http;
    targetSettings.method = targetSettings.method ? targetSettings.method : 'post';
    targetSettings.requestData = targetSettings.requestData ? targetSettings.requestData : vm.content;
    targetSettings.errorHandle = targetSettings.errorHandle ? targetSettings.errorHandle : vm.errorHandle;
    targetSettings.saveModuleURL = targetSettings.saveModuleURL ? targetSettings.saveModuleURL : vm.saveModuleURL;
    targetSettings.setModuleToUI = targetSettings.setModuleToUI ? targetSettings.setModuleToUI : vm.setModuleToUI;
    ServiceUtilityHelper.httpRequest({
        url: targetSettings.saveModuleURL,
        $http: targetSettings.$http,
        method: targetSettings.method,
        requestData: targetSettings.requestData,
        errorHandle: targetSettings.errorHandle,
        postHandle: function (oData) {
            $.Notification.notify('success', 'top center', vm.label.msgSaveOK, vm.label.msgSaveOKComment);
            targetSettings.setModuleToUI(oData.content);
            var baseUUID = targetSettings.fnGetBaseUUID();
            if (baseUUID) {
                window.location.href = genCommonEditURL(targetSettings.editorPage, baseUUID);
            }
        }
    });
};

ServiceUtilityHelper.checkInvolveTaskStatus = function (oSettings) {
    ServiceUtilityHelper.httpRequest({
        url: '../serviceFlowRuntime/checkInvolveTaskStatus.html',
        $http: oSettings.$http,
        method: 'post',
        requestData: oSettings.requestData,
        errorHandle: oSettings.errorHandle,
        postHandle: oSettings.postHandle
    });
};

/**
 * Utility method to launch http request as well as wrap error handle method
 * @param oSettings
 *     --{string} url
 *     --{string} uuid
 *     --{string} method: get(default), or post
 *     --{string} requestData
 *     --{Array} promiseList
 *     --{$http} $http
 *     --{boolean} skipCheckError: skip default check error logic
 *     --{function} postHandle: after read handle method
 *     --{function} errorHandle: error handle method
 */
ServiceUtilityHelper.httpRequest = function (oSettings) {
    var rawPromise = ServiceUtilityHelper._genHttpRequestPromise(oSettings);
    rawPromise.then(function (response) {
        var oData = JSON.parse(response.data);
        ServiceUtilityHelper.checkResponseError({
            oData: oData,
            postHandle: oSettings.postHandle,
            errorHandle: oSettings.errorHandle,
            skipCheckError: oSettings.skipCheckError
        });
    }.bind(this)).catch(function (error) {
        oSettings.errorHandle(error);
    }.bind(this));
    return rawPromise;
};


ServiceUtilityHelper.handleErrorUIDefault = function (oData) {
    ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
        container: $('.main.message-container')
    });
};

ServiceUtilityHelper.loadTypeAheadRequest = function (oSettings) {
    var minLength = oSettings.minLength ? oSettings.minLength : 0;
    var limit = oSettings.limit ? oSettings.limit : 0;
    return ServiceUtilityHelper.httpRequestForArray({
        url: oSettings.url,
        $http: oSettings.$http,
        errorHandle: oSettings.errorHandle,
        postHandle: function (oData) {
            var resultList = oData;
            setTimeout(function () {
                $(oSettings.element).typeahead({
                    hint: true,
                    highlight: true,
                    minLength: minLength
                }, {
                    name: 'unitList',
                    displayKey: 'text',
                    source: subModelMatcher(resultList, 'text'),
                    limit: limit /* Specify max number of suggestions to be displayed */
                });
            }, 0);
        }.bind(this)
    });
};

/**
 * Utility method to launch http request for array type data
 */
ServiceUtilityHelper.httpRequestForArray = function (oSettings) {
    return new Promise(function (resolve, reject) {
        // [Step1] Pre process custom error handle
        var customErrorHandle = oSettings.errorHandle ? oSettings.errorHandle : null;
        var _errorHandle = function (error) {
            reject(error);
            if (customErrorHandle) {
                customErrorHandle(error);
            }
        };
        oSettings.errorHandle = _errorHandle;
        // [Step2] Call http request core
        var rawPromise = ServiceUtilityHelper._genHttpRequestPromise(oSettings);
        rawPromise.then(function (response) {
            if (!JSON.parse(response.body)) {
                _errorHandle(response);
                return;
            }
            var resultList = JSON.parse(response.body);
            if (oSettings.postHandle) {
                oSettings.postHandle(resultList);
            }
        }).catch(function (error) {
            oSettings.errorHandle(error);
        });
    });
};


/**
 *
 * @param oSettings
 *        --{function} selectHandler: error handle method
 *        --{Dom} parentTable: # & parent table id
 */
ServiceUtilityHelper.initTableSelect = function (oSettings) {
    setTimeout(function () {
        var parentTable = oSettings.parentTable;
        $(parentTable + ' tbody').on('click', 'tr', function () {
            // Step1: clear previous selected item
            $(parentTable + ' tbody tr').removeClass('selected');
            // Step2: set toggle select class
            var oEvent = $(this);
            oEvent.toggleClass('selected');
            if (oSettings.selectHandler) {
                oSettings.selectHandler(oEvent);
            }
            // Step3 scroll to top
            if (oEvent && oEvent.offset && oEvent.length > 0) {
                console.log("top:" + oEvent.offset().top);
                // 60 px is the approx height of topbar
                // anothor 60px is the proper space to topbar
                $('html').scrollTop(oEvent.offset().top - 120);
            }
        });
    }.bind(this), 300);
};

ServiceUtilityHelper.convToSearchFieldMulValue = function (valueList) {
    var value = '';
    if (valueList && valueList.length > 0) {
        valueList.forEach(function (tempValue) {
            value = value + tempValue + " ";
        });
        return value;
    }
};

ServiceUtilityHelper.convSearchFieldMulValueToArray = function (value) {
    if (value) {
        return ServiceStringHelper.splitBySpace(value);
    }
};
/**
 * Utility method for loading promise or available data and also update data back when promise is ready
 * as well as provide then call back method
 * @param oSettings *
 *     --{Object} promiseCache: promise cache
 *     --{string} key
 *     --{string} [optional] method: get(default), or post
 *     --{string} [optional] requestData
 *     --{vue} vm
 *     --{function} errorHandle: error handle method
 *     --{function} postHandle: then call back as soon as promise is ready
 *
 */
ServiceUtilityHelper.loadPromiseWrapper = function (oSettings) {
    var vm = oSettings.vm; // vue instance
    var promiseCache = oSettings.promiseCache;
    var promiseMeta = oSettings.promiseCache[oSettings.key];
    if (promiseMeta.value) {
        // In case value is already available
        oSettings.postHandle(promiseMeta.value);
    }
    oSettings.url = promiseMeta.url;
    oSettings.$http = vm.$http;
    var rawPromise = ServiceUtilityHelper._genHttpRequestPromise(oSettings);
    rawPromise.then(function (response) {
        if (!JSON.parse(response.body)) {
            // pop up error message
            if (oSettings.errorHandle) {
                oSetting.errorHandle(response);
                return;
            }
        }
        var content = JSON.parse(response.body);
        // set value to promiseCache
        vm.$set(promiseCache[key], 'value', content);
        oSettings.postHandle(content);
    });
};

/**
 * Utility method to check if current selected value is empty or not
 * @param oSettings
 * @returns {Boolean} true: empty value,
 */
ServiceUtilityHelper.checkSelectEmptyValue = function (oSettings) {
    var value = oSettings.value;
    if (!value || value === 0 || value === '0' || value === '') {
        return true;
    }
    // in case space
    return value.replace(/(^s*)|(s*$)/g, "").length === 0;
};

/**
 * Initialize and register select2 select / select:close event handler
 * @param oSettings
 *    -- {Object} parentContent: parent content object to contains the selection value
 *    -- {Array} fieldList
 *    -- {String} [Optional] fieldName: fieldName in parent content
 *    -- {Vue} vm: vue instance
 */
ServiceUtilityHelper.initSelectConfigBatch = function (oSettings) {
    var fieldList = oSettings.fieldList;
    var parentContent = oSettings.parentContent;
    var vm = oSettings.vm;
    ServiceCollectionsHelper.traverseListInterrupt(fieldList, function (fieldConfig) {
        fieldConfig.vm = vm;
        fieldConfig.parentContent = parentContent;
        ServiceUtilityHelper.initSelectConfig(fieldConfig);
    });
};
/**
 * Initialize and register select2 select / select:close event handler
 * @param oSettings
 *    -- {String/DOM} element:element id
 *    -- {Function} [Optional] handler: handler method for select event
 *    -- {Object} parentContent: parent content object to contains the selection value
 *    -- {String} [Optional] fieldName: fieldName in parent content
 *    -- {Vue} vm: vue instance
 */
ServiceUtilityHelper.initSelectConfig = function (oSettings) {
    var $element = ServiceUtilityHelper.getDomElement(oSettings.element);
    var fieldName = oSettings.fieldName;
    var parentContent = oSettings.parentContent;
    var handler = oSettings.handler;
    var postCallback = oSettings.postCallback;
    var vm = oSettings.vm;

    var postLoadUrl = oSettings.postLoadUrl;
    if (!handler) {
        if (postLoadUrl) {
            // In case need to post load data
            handler = ServiceUtilityHelper.genDefSelect2CloseHandler(oSettings);
        } else {
            if (fieldName && parentContent) {
                // Simple and Direct: In case No customize handler, then generate default one
                handler = function (e) {
                    vm.$set(parentContent, fieldName, $($element).val());
                };
            }
        }
    }
    if (!handler) {
        // should raise exception if no settings
        ServiceExceptionHelper.raiseException({
            exceptionType: ServiceExceptionHelper.EXCEPTION_TYPE.AsyncControlException,
            errorCode: 'para3MissOrConfigSelectField',
            paras:[vm.getFieldName(), 'postLoadUrl', 'parentContent-fieldName']
        });
    }
    var resultHandler = function (e) {
        handler(e);
        if (postCallback) {
            postCallback({
                value: $($element).val()
            });
        }
    };
    $($element).on("select2:close", resultHandler);
    $($element).on("select2:select", resultHandler);
};

/**
 * Utility Method to get Dom element by input raw value (element id) or
 * @param element
 */
ServiceUtilityHelper.getDomElement = function (element) {
    if (!element) {
        return;
    }
    var head = element.substring(0, 1);
    if (head === '#') {
        // in case already wrapped with dom id header
        return element;
    }
    if (head === '.') {
        // in case already wrapped with dom class header
        return element;
    }
    return "#" + element;
};

/**
 * Actively trigger select2 select event
 * @param oSettings
 *   -- {String} element:element id
 *   -- {String/Number} key: key value
 */
ServiceUtilityHelper.triggerSelect = function (oSettings) {
    var element = oSettings.element;
    var key = oSettings.key;
    var $element = ServiceUtilityHelper.getDomElement(element);
    $($element).val(key);
    $($element).trigger("change");
    $($element).trigger({
        type: 'select2:select',
        params: {
            data: {'id': key}
        }
    });
};


/**
 * Actively trigger typeahead select event
 * @param oSettings
 *   -- {String} element:element id
 *   -- {String/Number} key: key value
 */
ServiceUtilityHelper.triggerTypeaheadSelect = function (oSettings) {
    var element = oSettings.element;
    var key = oSettings.key;
    var $element = ServiceUtilityHelper.getDomElement(element);
    $($element).val(key).trigger('change');
    $($element).typeahead('val', key);
};
/**
 * Utility method for loading the meta data
 * @param oSettings *
 *     --{string} url
 *     --{string} [optional] method: get(default), or post
 *     --{string} [optional] requestData
 *     --{Array} [optional] filteredKeyList: in case need to filter key by specific list
 *     --{$http} $http
 *     --{function} processEmptyCallback: callback function to process list with empty label
 *     --{boolean} addEmptyFlag: weather need to add empty value
 *     --{function} errorHandle: error handle method
 *     --{function} postHandle: post handle method
 *     --{function} formatMeta: format meta method
 *     --{function} fnSetInitKey: in case need to auto set init value
 *     --{boolean} multiple: weather use multiple select
 *     --{Element} element: DOM element
 *     --{Object} initValue: initial value
 *
 */
ServiceUtilityHelper.loadMetaRequest = function (oSettings) {
    return ServiceUtilityHelper._loadMetaRequestCore(oSettings);
};


/**
 * Utility method for loading the meta data
 * @param oSettings *
 *     --{string} url
 *     --{string} [optional] method: get(default), or post
 *     --{string} [optional] requestData
 *     --{Array} [optional] filteredKeyList: in case need to filter key by specific list
 *     --{$http} $http
 *     --{boolean} addEmptyFlag: weather need to add empty value
 *     --{string} emptyLabel: weather need to add empty value
 *     --{function} errorHandle: error handle method
 *     --{function} postHandle: post handle method
 *     --{function} formatMeta: format meta method
 *     --{function} fnSetInitKey: in case need to auto set init value
 *     --{function} processEmptyCallback: callback function to process list with empty label
 *     --{boolean} multiple: weather use multiple select
 *     --{Element} element: DOM element
 *     --{Object} initValue: initial value
 *
 */
ServiceUtilityHelper._loadMetaRequestCore = function (oSettings) {
    return new Promise(function (resolve, reject) {
        // [Step1] Pre process custom error handle
        var customErrorHandle = oSettings.errorHandle ? oSettings.errorHandle : null;
        var _errorHandle = function (error) {
            reject(error);
            if (customErrorHandle) {
                customErrorHandle(error);
            }
        };
        oSettings.errorHandle = _errorHandle;
        // [Step2] Call http request core
        var rawPromise = ServiceUtilityHelper._genHttpRequestPromise(oSettings);
        rawPromise.then(function (response) {
            if (!JSON.parse(response.body)) {
                _errorHandle(response);
                return;
            }
            var rawResultList = JSON.parse(response.body);
            oSettings.content = JSON.parse(response.body).content;
            var resultList = rawResultList;
            if (oSettings.processSelectOptions) {
                resultList = oSettings.processSelectOptions(rawResultList);
            }
            rawResultList = resultList;
            resultList = resultList ? resultList : [];
            // [Step3] In case need to filter raw selection options
            if (oSettings.filteredKeyList && oSettings.filteredKeyList.length > 0 && rawResultList.length > 0) {
                resultList = [];
                rawResultList.forEach(function (selectUnion) {
                    var result = ServiceCollectionsHelper.filterPrimArray(selectUnion.id, oSettings.filteredKeyList);
                    if (result) {
                        resultList.push(selectUnion);
                    }
                });
            }
            // [Step4] In case need to exclude list
            if (oSettings.execludeKeyList && oSettings.execludeKeyList.length > 0 && rawResultList.length > 0) {
                rawResultList = resultList;
                oSettings.execludeKeyList.forEach(function (execludeKey) {
                    var index = ServiceCollectionsHelper.filterArrayIndex(execludeKey, 'id', resultList);
                    if (index > -1) {
                        resultList.splice(index, 1);
                    }
                });
            }
            // [Step5] In case fnSetInitKey callback
            if (!oSettings.initValue || oSettings.initValue === 0) {
                if (oSettings.fnSetInitKey && typeof oSettings.fnSetInitKey === 'function') {
                    if (resultList && resultList.length && resultList.length > 0) {
                        oSettings.initValue = resultList[0].id;
                        oSettings.fnSetInitKey(oSettings.initValue);
                    }
                }
            }
            var emptyLabel = oSettings.emptyLabel ? oSettings.emptyLabel : ' ';
            // [Step4] In case need to add empty option
            if (oSettings.processEmptyCallback) {
                resultList = resultList ? resultList : [];
                // in case custom process empty call back
                resultList = oSettings.processEmptyCallback(resultList);
            } else {
                if (oSettings.addEmptyFlag) {
                    resultList.splice(0, 0, {'id': '0', 'text': emptyLabel});
                }
            }
            oSettings.resultList = resultList;
            // [Step5] Render the selection element
            setTimeout(function () {
                if (oSettings.element) {
                    if (oSettings.multiple && oSettings.multiple === true) {
                        var localSettings = oSettings;
                        localSettings.multiple = true;
                        localSettings.resultList = resultList;
                        // process multiple value into array
                        if (localSettings.initValue && typeof localSettings.initValue === 'string') {
                            localSettings.initValue = ServiceStringHelper.splitBySpace(localSettings.initValue);
                        }
                        ServiceUtilityHelper._updateSelect2Element(localSettings);
                    } else {
                        ServiceUtilityHelper._updateSelectElementWrapper(oSettings);
                    }
                }
            }, 0);
            // [Step6] resolve result data and call post handle method
            resolve(resultList);
            if (oSettings.rightBar && oSettings.helpKey) {
                oSettings.rightBar.updateSelectMetaData(oSettings.helpKey, resultList);
            }
            if (oSettings.postHandle) {
                oSettings.postHandle(resultList);
            }
        }).catch(function (error) {
            oSettings.errorHandle(error);
        });
    });

};

/**
 * Utility method for loading the model type meta data
 * @param oSettings *
 *     --{string} url
 *     --{string} [optional] method: get(default), or post
 *     --{string} [optional] requestData
 *     --{string} idField
 *     --{string} textField
 *     --{$http} $http
 *     --{boolean} addEmptyFlag: weather need to add empty value
 *     --{function} errorHandle: error handle method
 *     --{function} formatMeta: format meta method
 *     --{Element} element: DOM element
 *     --{Object} initValue: initial value
 *     --{boolean} initTrigger: using non empty value to trigger selection
 *
 */
ServiceUtilityHelper.loadModelMetaRequest = function (oSettings) {
    oSettings.processSelectOptions = function (rawResultList) {
        return formatSelectResult(rawResultList.content, oSettings.idField, oSettings.textField);
    };
    return ServiceUtilityHelper._loadMetaRequestCore(oSettings);
};


/**
 * Utility method for loading the model type meta data as promise
 * @param oSettings *
 *     --{string} url
 *     --{string} [optional] method: get(default), or post
 *     --{string} [optional] requestData
 *     --{string} idField
 *     --{string} textField
 *     --{$http} $http
 *     --{boolean} addEmptyFlag: weather need to add empty value
 *     --{function} errorHandle: error handle method
 *     --{function} formatMeta: format meta method
 *     --{Element} element: DOM element
 *     --{Object} initValue: initial value
 *     --{boolean} initTrigger: using non empty value to trigger selection
 *     --{vue} vm: vue instance
 *     --{vue} cache: parent vue object to contain cache store the promise result data
 *     --{path} path: path to store promise result data in cache
 *     --{function:Promise} loadMetaCallback: method to get raw request selection data
 *
 */
ServiceUtilityHelper.loadMetaRequestPromise = function (oSettings) {
    return new Promise(function (resolve, reject) {
        if (oSettings.cache && oSettings.cache[oSettings.path]) {
            resolve(oSettings.cache[oSettings.path]);
        } else {
            var loadMetaCallback = oSettings.loadMetaCallback ? oSettings.loadMetaCallback : ServiceUtilityHelper.loadMetaRequest;
            loadMetaCallback(oSettings).then(function (resultList) {
                // write to cache
                oSettings.vm.$set(oSettings.cache, oSettings.path, resultList);
                resolve(resultList);
            }).catch(function (error) {
                reject(error);
            });
        }
    }.bind(this));
};

/**
 * Utility method for loading the model type meta data
 * @param oSettings *
 *     --{string} url
 *     --{string} [optional] method: get(default), or post
 *     --{string} [optional] requestData
 *     --{$http} $http
 *     --{function} errorHandle: error handle method
 *
 */
ServiceUtilityHelper._genHttpRequestPromise = function (oSettings) {
    var url = oSettings.url;
    var method = oSettings.method ? oSettings.method : 'get';
    var rawPromise;
    if (method === 'post') {
        rawPromise = oSettings.$http.post(url, oSettings.requestData);
        return rawPromise;
    } else {
        if (oSettings.uuid) {
            url = url + "?uuid=" + oSettings.uuid;
        }
        if (oSettings.requestData != null) {
            // in case need to parse requestData to path paras.
            url = ServiceHttpRequestHelper.changeURLParas(url, oSettings.requestData);
        }
        rawPromise = oSettings.$http.get(url);
        return rawPromise;
    }
};

ServiceUtilityHelper.checkEmptyString = function (rawValue) {
    if (!rawValue || rawValue == DocumentConstants.StandardPropety.EmptyString) {
        return true;
    }
    return undefined;
};

/**
 * Utility method for loading the meta data with handling custom configure in system code value collection
 * @param oSettings *
 *     --{string} url
 *     --{string} [optional] method: get(default), or post
 *     --{string} [optional] requestData
 *     --{$http} $http
 *     --{string} idField
 *     --{string} textFieldv
 *     --{boolean} addEmptyFlag: weather need to add empty value
 *     --{function} errorHandle: error handle method
 *     --{function} formatMeta: format meta method
 *     --{Element} element: DOM element
 *     --{Object} initValue: initial value
 *
 */
ServiceUtilityHelper.loadMetaWithCustomReq = function (oSettings) {
    var vm = this;
    var rawPromise = ServiceUtilityHelper._genHttpRequestPromise(oSettings);
    rawPromise.then(function (response) {
        if (!JSON.parse(response.body)) {
            if (oSettings.errorHandle) {
                oSetting.errorHandle(response);
                return;
            }
        }
        var oData = JSON.parse(response.body);
        if (!oData.content && oData.errorCode) {
            // in case error pop up error message
            if (oSettings.errorHandle) {
                oSetting.errorHandle(response);
                return;
            }
        }
        if (oData.content) {
            // in case custom service code value list
            var _formatFunction = ServiceUtilityHelper.genTemplateFormatFunction(oData.content);
            var resultList = formatSelectResult(oData.content, oSettings.idField, oSettings.textField);
            if (oSettings.addEmptyFlag) {
                resultList.splice(0, 0, {'id': '0', 'text': ' '});
            }
            setTimeout(function () {
                if (oSettings.element) {
                    oSettings.formatMeta = _formatFunction;
                    oSettings.resultList = resultList;
                    oSettings.content = oData.content;
                    ServiceUtilityHelper._updateSelectElementWrapper(oSettings);
                }
            }, 0);
        } else {
            // in case system default map
            var mapList = JSON.parse(response.body);
            if (oSettings.addEmptyFlag) {
                mapList.splice(0, 0, {'id': '0', 'text': ' '});
            }
            setTimeout(function () {
                if (oSettings.element) {
                    oSettings.resultList = mapList;
                    oSettings.content = oData.content;
                    ServiceUtilityHelper._updateSelectElementWrapper(oSettings);
                }
            }, 0);
        }
    });
};


ServiceUtilityHelper.convCodeValueIconMap = function (rawCodeValueUnionList) {
    if (!rawCodeValueUnionList || rawCodeValueUnionList.length === 0) {
        return;
    }
    var serviceCodeValue, iconClassArray = [];
    for (var i = 0, len = rawCodeValueUnionList.length; i < len; i++) {
        serviceCodeValue = rawCodeValueUnionList[i];
        if (serviceCodeValue && serviceCodeValue.iconClass && serviceCodeValue.id) {
            iconClassArray.push({
                id: serviceCodeValue.id,
                iconClass: serviceCodeValue.iconClass
            });
        }
    }
    return iconClassArray;
};

ServiceUtilityHelper.batchConvertFieldIconArrayRequest = function (oSettings, fieldMetaList) {
    var promiseList = [];
    ServiceCollectionsHelper.traverseList(fieldMetaList, function (fieldMeta, index) {
        if (fieldMeta.iconArrayRequest) {
            var promise = ServiceUtilityHelper.httpRequest({
                url: fieldMeta.iconArrayRequest.url,
                $http: oSettings.$http,
                method: fieldMeta.iconArrayRequest.method,
                requestData: fieldMeta.iconArrayRequest.requestData,
                postHandle: function (oData) {
                    var iconArray = ServiceUtilityHelper.convCodeValueIconMap(oData.content);
                    fieldMeta.iconArray = iconArray;
                }.bind(this)
            });
            if (promise) {
                promiseList.push(promise);
            }
        }
    });
    return promiseList;
};


ServiceUtilityHelper.genTemplateFormatFunction = function (rawCodeValueUnionList) {
    var iconClassMapArray = ServiceUtilityHelper.convCodeValueIconMap(rawCodeValueUnionList);
    var _formatTemplateSelect = function (value) {
        "use strict";
        var $element = ServiceUtilityHelper.formatSelectWithIcon(value, iconClassMapArray, true);
        return $element;
    };
    return _formatTemplateSelect;
};


ServiceUtilityHelper._updateSelectElementWrapper = function (oSettings) {
    var element = oSettings.element;
    var initValue = oSettings.initValue;
    if (ServiceCollectionsHelper.checkArrayFlag(element) && ServiceCollectionsHelper.checkArrayFlag(initValue)) {
        if (element.length > 0 && initValue.length > 0) {
            var i = 0;
            len = element.length;
            for (i = 0; i < len; i++) {
                oSettings['element'] = element[i];
                oSettings['initValue'] = initValue;
                ServiceUtilityHelper._updateSelectElement(oSettings);
            }
        }
    } else {
        // in case single element
        ServiceUtilityHelper._updateSelectElement(oSettings);
    }
};

ServiceUtilityHelper._updateSelectElement = function (oSettings) {
    var $element = ServiceUtilityHelper.getDomElement(oSettings.element);
    var formatMeta = oSettings.formatMeta;
    var formatMetaCallback = oSettings.formatMetaCallback;
    var resultList = oSettings.resultList;
    var initValue = oSettings.initValue;
    if (formatMetaCallback != null) {
        var dataList = oSettings.content ? oSettings.content: oSettings.resultList;
        $($element).select2({
            data: resultList,
            templateResult: formatMetaCallback({
                dataList: dataList
            }),
            templateSelection: formatMetaCallback({
                dataList: dataList
            })
        });
    } else {
        $($element).select2({
            data: resultList,
            templateResult: formatMeta,
            templateSelection: formatMeta
        });
    }

    // manually set initial value
    if (initValue) {
        ServiceUtilityHelper.triggerSelect({
            key: initValue,
            element: $element
        });
    }
};

ServiceUtilityHelper._updateSelect2Element = function (oSettings) {
    $(oSettings.element).select2({
        data: oSettings.resultList,
        templateResult: oSettings.formatMeta,
        multiple: oSettings.multiple,
        templateSelection: oSettings.formatMeta
    });
    // manually set initial value
    if (oSettings.initValue) {
        ServiceUtilityHelper.triggerSelect({
            key: initValue,
            element: element
        });
    }
};

/**
 * Generate simple load data URL by keyField Info
 * @param {Object} oSettings
 *   {String} loadUrl: basic load data url
 *   {String} keyFieldValue: key field value
 *   {String} keyFieldName: key field name, default value is uuid
 * @return {*|string}
 */
ServiceUtilityHelper.genSimpleLoadDataUrlByKey = function (oSettings) {
    var loadUrl = oSettings.loadUrl;
    var keyFieldName = oSettings.keyFieldName ? oSettings.keyFieldName : "uuid";
    var keyFieldValue = oSettings.keyFieldValue;
    var resultUrl = loadUrl;
    if (!ServiceStringHelper.containsSubStr(loadUrl, ".html")) {
        resultUrl = resultUrl + ".html";
    }
    var keyUnion = "?" + keyFieldName;
    if (!ServiceStringHelper.containsSubStr(loadUrl, keyUnion)) {
        resultUrl = resultUrl + keyUnion + "=" + keyFieldValue;
    }
    return resultUrl;
};

/**
 *
 * Default select2:close event handler, with default logic to load data when select2 is selected, and
 * set data each fields value to vm.content relative fields.
 *
 * @param {Object} oSettings
 *    {Vue} vm
 *    {method} postLoadUrlBack
 *    {Dom} element
 *    {Function} [Optional] postHandle: post method after default process is done
 *    {Function} [Optional] postHandle: after
 *    {Function} [Optional] errorHandle: set to vm.errorHandle if null value
 *    {Array} fieldList
 *    {String} keyField
 *    {String} uuidField: the uuid field to get model from backend
 *    {String} subUIModel:relative path to get model
 *    {String} subPath:relative path to 'content'
 */
ServiceUtilityHelper.defSelect2CloseHandler = function (oSettings) {
    var element = oSettings.element;
    $(element).on("select2:close", ServiceUtilityHelper.genDefSelect2CloseHandler(oSettings));
};


ServiceUtilityHelper.genDefSelect2CloseHandler = function (oSettings) {
    var element = ServiceUtilityHelper.getDomElement(oSettings.element);
    var subUIModel = oSettings.subUIModel;
    var subPath = oSettings.subPath;
    var keyField = oSettings.keyField;
    var uuidField = oSettings.uuidField;
    var postLoadUrl = oSettings.postLoadUrl;
    var parentContent = oSettings.parentContent;
    if (uuidField) {
        keyField = uuidField;
    }
    return function (e) {
        var vm = oSettings.vm;
        var errorHandle = oSettings.errorHandle ? oSettings.errorHandle : vm.errorHandle;
        vm.$set(parentContent, keyField, $(element).val());
        if (postLoadUrl) {
            postLoadUrl = ServiceUtilityHelper.genSimpleLoadDataUrlByKey({
                loadUrl: postLoadUrl,
                keyFieldValue: $(element).val()
            });
        } else {
            postLoadUrl = oSettings.postLoadUrlBack();
        }
        ServiceUtilityHelper.httpRequest({
            url: postLoadUrl,
            $http: vm.$http,
            method: oSettings.method,
            requestData: oSettings.requestData,
            errorHandle: errorHandle,
            postHandle: function (oData) {
                var uiModel = subUIModel ? oData.content[subUIModel] : oData.content;
                ServiceUtilityHelper.setSelect2ModelValue({
                    vm: vm,
                    uiModel: uiModel,
                    subPath: subPath,
                    parentContent: parentContent,
                    fieldList: oSettings.fieldList
                });
            }.bind(this)
        });
    };
};

/**
 * Post setting values after select2 model select event
 * @param oSettings
 *   {UIModel} uiModel: the uiModel from select 2 selection event
 *   {Vue} vm: controller vue instance
 *   {Content} parentContent: vue parent content where contains fields to be set
 *   {Array<Object|String>} fieldList: array of fields or object {sourceField:targetField} to be set value
 */
ServiceUtilityHelper.setSelect2ModelValue = function (oSettings) {
    var uiModel = oSettings.uiModel;
    var vm = oSettings.vm;
    var parentContent = oSettings.parentContent;
    var fieldName = oSettings.fieldName;
    var subPath = oSettings.subPath;
    var checkFlag = oSettings.checkFlag;
    if (uiModel || checkFlag === true) {
        ServiceCollectionsHelper.traverseListInterrupt(oSettings.fieldList, function (field, index) {
            ServiceUtilityHelper._select2SetFieldValueCore({
                subPath: subPath, uiModel: uiModel, vm: vm, field: field, index:index, parentContent: parentContent,
                checkFlag: checkFlag, fieldName: fieldName
            });
        });
        if (checkFlag !== true) {
            if (oSettings.postHandle) {
                oSettings.postHandle(uiModel);
            }
        }
    }
};


ServiceUtilityHelper._select2SetFieldValueCore = function (oSettings) {
    var parentContent = oSettings.parentContent;
    var uiModel = oSettings.uiModel;
    var vm = oSettings.vm;
    var checkFlag = oSettings.checkFlag;
    var fieldName = oSettings.fieldName;
    var index = oSettings.index;
    // By default field is field name in string type
    var sourceField = oSettings.field;
    var targetField = oSettings.field;
    if (typeof oSettings.field === 'object') {
        sourceField = oSettings.field['sourceField'];
        targetField = oSettings.field['targetField'];
        if (!sourceField) {
            ServiceExceptionHelper.raiseException({
                exceptionType: ServiceExceptionHelper.EXCEPTION_TYPE.AsyncControlException,
                errorCode: 'para2MissConfigSelectField',
                paras:[fieldName, 'settings.fieldList[' + index + '].sourceField']
            });
        }
        if (!targetField) {
            ServiceExceptionHelper.raiseException({
                exceptionType: ServiceExceptionHelper.EXCEPTION_TYPE.AsyncControlException,
                errorCode: 'para2MissConfigSelectField',
                paras:[fieldName, 'settings.fieldList[' + index + '].targetField']
            });
        }
    }
    if (checkFlag !== true) {
        vm.$set(parentContent, targetField, uiModel[sourceField]);
    }
};


/**
 *
 * @param oSettings
 *     --{string} swalWarnTitle
 *     --{string} swalWarnText
 *     --{string} okTitle
 *     --{string} okComment
 *     --{string} [optional] method, default is post
 *     --{method} preValidate pre validate method before execute
 *     --{DOM} messageContainer
 *     --{string} url
 *     --{$http} $http
 *     --{object} label: label object
 *     --{request} request data for post
 *     --{method} errorHandle
 *     --{method} postHandle
 */
ServiceUtilityHelper.executeActionWrapper = function (oSettings) {
    swal({
            title: oSettings.swalWarnTitle,
            text: oSettings.swalWarnText,
            type: "warning",
            showCancelButton: true,
            cancelButtonText: oSettings.label.cancel,
            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
            confirmButtonText: oSettings.label.confirm
        },
        function (isConfirm) {
            if (isConfirm) {
                if (oSettings.preValidate) {
                    var validateResult = oSettings.preValidate();
                    if (!validateResult || validateResult === false) {
                        return;
                    }
                }
                if (oSettings.messageContainer) {
                    ServiceMessageBarHelper.removeMessageBar({
                        container: oSettings.messageContainer
                    });
                }
                var method = oSettings.method ? oSettings.method : 'post';
                ServiceUtilityHelper.httpRequest({
                    url: oSettings.url,
                    uuid: oSettings.uuid,
                    $http: oSettings.$http,
                    method: method,
                    requestData: oSettings.request,
                    errorHandle: oSettings.errorHandle,
                    postHandle: function (oData) {
                        $.Notification.notify('success', 'top center', oSettings.okTitle, oSettings.okComment);
                        if (oSettings.postHandle) {
                            oSettings.postHandle(oData.content);
                        }
                    }.bind(this)
                });
            }
        });
};

/**
 * Wrapper method to execute action wrapper
 * @param oSettings
 *    --{String} uuid
 *    --{Object} label
 *    --{String} [Optional] deleteWarnTitle
 *    --{String} [Optional] deleteWarnText
 *    --{String} [Optional] deleteOKTitle
 *    --{String} [Optional] deleteOKComment
 *    --{DOM} [Optional] messageContainer
 *    --{Url} url
 *    --{Function} errorHandle
 *    --{Function} postHandle
 *    --{Object} request
 *    --{$http} $http
 */
ServiceUtilityHelper.deleteActionWrapper = function (oSettings) {
    var vm = this;
    var label = oSettings.label;
    var deleteWarnTitle = oSettings.deleteWarnTitle ? oSettings.deleteWarnTitle : label.deleteWarnTitle;
    var deleteWarnText = oSettings.deleteWarnText ? oSettings.deleteWarnText : label.deleteWarnText;
    var deleteOKTitle = oSettings.deleteOKTitle ? oSettings.deleteOKTitle : label.msgDeleteOK;
    var deleteOKComment = oSettings.deleteOKComment ? oSettings.deleteOKComment : label.msgDeleteOKComment;
    var messageContainer = oSettings.messageContainer ? oSettings.messageContainer : $('.main.message-container');
    var method = oSettings.method ? oSettings.method : 'get'; // default method is get
    ServiceUtilityHelper.executeActionWrapper({
        swalWarnTitle: deleteWarnTitle,
        swalWarnText: deleteWarnText,
        okTitle: deleteOKTitle,
        okComment: deleteOKComment,
        messageContainer: messageContainer,
        url: oSettings.url,
        uuid: oSettings.uuid,
        $http: oSettings.$http,
        method: method,
        label: oSettings.label,
        request: oSettings.request,
        errorHandle: vm.errorHandle,
        postHandle: oSettings.postHandle,
    });
};

/**
 * Core Logic to check if response with error or correct response
 * @param oSettings
 *     --{boolean} skipCheckError: skip default check error logic
 */
ServiceUtilityHelper.checkResponseError = function (oSettings) {
    var oData = oSettings.oData;
    var postHandle = oSettings.postHandle;
    var errorCode = oData.errorCode;
    if (ServiceUtilityHelper.checkHTTPResponseCode(errorCode)) {
        // in case correct return code
    } else {
        if (oSettings.skipCheckError && oSettings.skipCheckError === true) {
            // skip default check error logic

        } else {
            if (!oData.content) {
                oSettings.errorHandle(oData);
                return;
            }
        }
    }
    if (postHandle) {
        postHandle(oData);
    }

};

ServiceUtilityHelper.checkHTTPResponseCode = function (httpCode) {
    if (httpCode * 1 <= 299 && httpCode * 1 >= 200) {
        return true;
    }
};

ServiceUtilityHelper.getGlobalVueInstance = function () {
    if (typeof dataVar !== 'undefined') {
        return dataVar;
    }
    if (typeof searchModel !== 'undefined') {
        return searchModel;
    }
    if (typeof listVar !== 'undefined') {
        return listVar;
    }
};

ServiceUtilityHelper.getActionCodeMap = function (oSettings) {
    var documentType = oSettings.documentType;
    var getActionCodeMapURL = "../serviceDocActConfigureItem/getDocActionCodeMap.html?documentType=" + documentType;

    ServiceUtilityHelper.loadMetaRequest({
        url: getActionCodeMapURL,
        $http: oSettings.$http,
        addEmptyFlag: oSettings.addEmptyFlag,
        initValue: oSettings.initValue,
        formatMeta: ServiceUtilityHelper.formatActionCode,
        element: oSettings.element,
        errorHandle: oSettings.errorHandle
    });
};

ServiceUtilityHelper.getAuthActionCodeIconMap = function () {
    return [{
        id: DocumentConstants.StandardPropety.SystemAuthActionCode.ACID_EDIT,
        iconClass: DocumentConstants.StandardPropety.SystemAuthActionCodeIcon.ACID_EDIT
    }, {
        id: DocumentConstants.StandardPropety.SystemAuthActionCode.ACID_VIEW,
        iconClass: DocumentConstants.StandardPropety.SystemAuthActionCodeIcon.ACID_VIEW
    }, {
        id: DocumentConstants.StandardPropety.SystemAuthActionCode.ACID_LIST,
        iconClass: DocumentConstants.StandardPropety.SystemAuthActionCodeIcon.ACID_LIST
    }, {
        id: DocumentConstants.StandardPropety.SystemAuthActionCode.ACID_DELETE,
        iconClass: DocumentConstants.StandardPropety.SystemAuthActionCodeIcon.ACID_DELETE
    }, {
        id: DocumentConstants.StandardPropety.SystemAuthActionCode.ACID_AUDITDOC,
        iconClass: DocumentConstants.StandardPropety.SystemAuthActionCodeIcon.ACID_AUDITDOC
    }, {
        id: DocumentConstants.StandardPropety.SystemAuthActionCode.ACID_EXCEL,
        iconClass: DocumentConstants.StandardPropety.SystemAuthActionCodeIcon.ACID_EXCEL
    }, {
        id: DocumentConstants.StandardPropety.SystemAuthActionCode.ACID_PRICEINFO,
        iconClass: DocumentConstants.StandardPropety.SystemAuthActionCodeIcon.ACID_PRICEINFO
    }];
};

ServiceUtilityHelper.getAuthActionCodeIcon = function (actionCode) {
    var $element = ServiceCollectionsHelper.filterArray(actionCode, 'id', ServiceUtilityHelper.getAuthActionCodeIconMap());
    if ($element) {
        return $element.iconClass;
    } else {
        // return default action code
        return 'md md-alarm content-lightblue';
    }
};


ServiceUtilityHelper.formatAuthActionCode = function (actionCode) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(actionCode, ServiceUtilityHelper.getAuthActionCodeIconMap(), true);
    return $element;
};

ServiceUtilityHelper.getActionCodeIconMap = function () {
    return [
        {
            id: DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_NEW,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_NEW
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_SEARCH,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_SEARCH
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_BATCH_INBOUND,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_BATCH_INBOUND
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_BATCH_OUTBOUND,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_BATCH_OUTBOUND
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_APPROVE,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_APPROVE
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REJECT_APPROVE,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_REJECT_APPROVE
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_COUNTAPPROVE,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_COUNTAPPROVE
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_SUBMIT,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_SUBMIT
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_INPROCESS,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_INPROCESS
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REVOKE_SUBMIT,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_REVOKE_SUBMIT
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_UPDATE,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_UPDATE
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_DELIVERY_DONE,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_DELIVERY_DONE
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_PROCESS_DONE,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_PROCESS_DONE
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_ACTIVE,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_ACTIVE
        },
        {
            id: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_ARCHIVE,
            iconClass: DocumentConstants.StandardPropety.SystemDefDocActionCodeIcon.ACTION_ARCHIVE
        }
    ];
};

ServiceUtilityHelper.getMergedActionCodeIconMap = function (customActionCodeIconMap) {
    var actionCodeIconMap = ServiceCollectionsHelper.mergeList(ServiceUtilityHelper.getActionCodeIconMap(),
        customActionCodeIconMap, {'keyName': 'id', 'overwrite': true});
    return actionCodeIconMap;
};

ServiceUtilityHelper.getActionCodeIcon = function (actionCode, actionIconMap) {
    var actionIconArray = ServiceUtilityHelper.getActionCodeIconMap();
    if (actionIconMap) {
        actionIconArray = actionIconMap;
    }
    var $element = ServiceCollectionsHelper.filterArray(actionCode, 'id', actionIconArray);
    if ($element) {
        return $element.iconClass;
    } else {
        // return default action code
        return 'md md-alarm content-lightblue';
    }
};


ServiceUtilityHelper.formatActionCode = function (actionCode) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(actionCode, ServiceUtilityHelper.getActionCodeIconMap(), true);
    return $element;
};


ServiceUtilityHelper.getUpdateModelIconMap = function () {
    return [
        {
            id: DocumentConstants.StandardPropety.ServiceItemUpdateModel.NOCHANGE,
            iconClass: 'fa fa-plus-square-o content-linkblue'
        },
        {
            id: DocumentConstants.StandardPropety.ServiceItemUpdateModel.CREATE,
            iconClass: 'nmd nmd-youtube-searched-for content-lightblue'
        },
        {
            id: DocumentConstants.StandardPropety.ServiceItemUpdateModel.DELETE,
            iconClass: 'md md-file-download content-green'
        },
        {
            id: DocumentConstants.StandardPropety.ServiceItemUpdateModel.INCREASE,
            iconClass: 'nmd nmd-youtube-searched-for content-lightblue'
        },
        {
            id: DocumentConstants.StandardPropety.ServiceItemUpdateModel.DECREASE,
            iconClass: 'md md-file-download content-green'
        },
        {
            id: DocumentConstants.StandardPropety.ServiceItemUpdateModel.UPDATE,
            iconClass: 'nmd nmd-youtube-searched-for content-lightblue'
        }
    ];
};


ServiceUtilityHelper.getUpdateModelIconClass = function (updateModel) {
    var updateModelIconArray = ServiceUtilityHelper.getUpdateModelIconMap();
    var $element = ServiceCollectionsHelper.filterArray(updateModel, 'id', updateModelIconArray);
    if ($element) {
        return $element.iconClass;
    } else {
        // return default action code
        return 'md md-alarm content-lightblue';
    }
};


ServiceUtilityHelper.formatUpdateModel = function (updateModel) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(updateModel, ServiceUtilityHelper.getUpdateModelIconMap(), true);
    return $element;
};


ServiceUtilityHelper.getSerialParallelIconMap = function () {
    return [
        {
            id: DocumentConstants.StandardPropety.SystemSerialParallel.SERIAL,
            iconClass: 'nmd nmd-linear-scale content-lightblue'
        },
        {
            id: DocumentConstants.StandardPropety.SystemSerialParallel.PARALLEL,
            iconClass: 'md md-clear-all content-lightblue'
        }
    ];
};

ServiceUtilityHelper.getSerialParallelIcon = function (serialFlag) {
    var serialFlagArray = ServiceUtilityHelper.getSerialParalleIconMap();
    var $element = ServiceCollectionsHelper.filterArray(serialFlag, 'id', serialFlagArray);
    if ($element) {
        return $element.iconClass;
    }
};


ServiceUtilityHelper.formatSerialParallel = function (serialFlag) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(serialFlag, ServiceUtilityHelper.getSerialParallelIconMap(), true);
    return $element;
};


ServiceUtilityHelper.getMandatoryModeIconMap = function () {
    return [
        {
            id: DocumentConstants.StandardPropety.SystemMandatoryMode.MODE_MANDATORY,
            iconClass: 'nmd nmd-radio-button-checked content-peach-red'
        },
        {
            id: DocumentConstants.StandardPropety.SystemMandatoryMode.MODE_SELECTIVE,
            iconClass: 'nmd nmd-radio-button-unchecked content-lightblue'
        }
    ];
};

ServiceUtilityHelper.getMandatoryModeIcon = function (mandatoryMode) {
    var mandatoryArray = ServiceUtilityHelper.getMandatoryModeIconMap();
    var $element = ServiceCollectionsHelper.filterArray(mandatoryMode, 'id', mandatoryArray);
    if ($element) {
        return $element.iconClass;
    }
};


ServiceUtilityHelper.formatMandatoryModeIconMap = function (mandatoryMode) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(mandatoryMode, ServiceUtilityHelper.getMandatoryModeIconMap(), true);
    return $element;
};

/**
 * Utility method to set common i18n properties for DocMatItemNode
 * @param {object} oSettings
 */
ServiceUtilityHelper.getDocMatItemI18n = function (oSettings) {
    "use strict";
    oSettings.i18n.properties({
        name: 'DocMatItemNode', //properties file name
        path: getI18nRootPath() + getCommonI18nPath(), //path for properties files
        mode: 'map', //Using map mode to consume properties files
        cache: true,
        language: getLan(),
        callback: oSettings.callBack ? oSettings.callBack : function () {
            ServiceUtilityHelper.setI18nDocMatItemCallback(oSettings.label);
        }
    });
};

ServiceUtilityHelper.setI18nDocMatItemCallback = function (label) {
    "use strict";
    if (!label || !$.i18n) {
        return;
    }
    label.itemPrice = $.i18n.prop('itemPrice');
    label.unitPrice = $.i18n.prop('unitPrice');
    label.itemPriceDisplay = $.i18n.prop('itemPriceDisplay');
    label.unitPriceDisplay = $.i18n.prop('unitPriceDisplay');
    label.reservedDocType = $.i18n.prop('reservedDocType');
    label.reservedDocId = $.i18n.prop('reservedDocId');
    label.reservedDocName = $.i18n.prop('reservedDocName');
    label.prevDocType = $.i18n.prop('prevDocType');
    label.prevDocId = $.i18n.prop('prevDocId');
    label.prevDocName = $.i18n.prop('prevDocName');
    label.prevDocStatus = $.i18n.prop('prevDocStatus');
    label.nextDocType = $.i18n.prop('nextDocType');
    label.nextDocId = $.i18n.prop('prevDocId');
    label.nextDocName = $.i18n.prop('nextDocName');
    label.nextDocStatus = $.i18n.prop('nextDocStatus');
    label.refMaterialSKUId = $.i18n.prop('refMaterialSKUId');
    label.refMaterialSKUName = $.i18n.prop('refMaterialSKUName');
    label.packageStandard = $.i18n.prop('packageStandard');
    label.createdDate = $.i18n.prop('createdDate');
    label.createdById = $.i18n.prop('createdById');
    label.createdByName = $.i18n.prop('createdByName');
};

ServiceUtilityHelper.setI18nCommonCallback = function (label) {
    "use strict";
    if (!label || !$.i18n) {
        return;
    }
    ServiceUtilityHelper.setI18nUnitCore(label, 'msgSaveOK', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'msgSaveOKComment', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'msgSystemFailure', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'msgUnknowSystemFailure', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'lockFailureMessage', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'save', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'saveTitle', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'index', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'exit', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'close', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'commit', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'quickEdit', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'view', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'note', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'cancel', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'confirm', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'edit', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'editTitle', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'quickEditTitle', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'deleteWarnTitle', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'search', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'add', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'searchPlaceHolder', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'lastUpdateById', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'lastUpdateByName', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'lastUpdateTime', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'createdById', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'createdByName', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'finAccTitle', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'deleteWarnTitle', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'deleteWarnText', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'msgDeleteOK', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'advancedSearchCondition', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'msgDeleteOKComment', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'multiValueSearchComment', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'advancedSearchCondition', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'clearSearch', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'clearSearchComment', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'navToEdit', $.i18n.prop);
    ServiceUtilityHelper.setI18nUnitCore(label, 'navToEditTitle', $.i18n.prop);

};

ServiceUtilityHelper.getComLabelObject = function (rawLabel) {
    var comLabel = ServiceUtilityHelper.getCommon18nLabel();
    if (!rawLabel) {
        return comLabel;
    }
    return ServiceUtilityHelper.assignExtendObject(rawLabel, comLabel);
};

ServiceUtilityHelper.getCommon18nLabel = function () {
    return {
        id: '',
        name: '',
        save: '',
        edit: '',
        editTitle: '',
        navToEdit: '',
        navToEditTitle: '',
        exit: '',
        new: '',
        add: '',
        newModule: '',
        view: '',
        search: '',
        searchTitle: '',
        display: '',
        from: '',
        to: '',
        delete: '',
        index: '',
        confirm: '',
        cancel: '',
        chooseAll: '',
        clearAll: '',
        select: '',
        noImplementYet: '',
        print: '',
        printSetup: '',
        printReview: '',
        downloadExcel: '',
        downloadExcelTitle: '',
        titleGenFinAccount: '',
        warnGenFinAccount: '',
        titleGrantReEdit: '',
        warnGrantReEdit: '',
        modelTitle: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgDeleteOK: '',
        msgDeleteOKComment: '',
        msgConnectFailure: '',
        msgLoadDataFailure: '',
        msgSystemFailure: '',
        msgUnknowSystemFailure: '',
        genFinAccount: '',
        grantReEdit: '',
        grossPrice: '',
        grossPriceDisplay: '',
        audit: '',
        note: '',
        itemPrice: '',
        unitPrice: '',
        itemPriceDisplay: '',
        unitPriceDisplay: '',
        refUnitName: '',
        amount: '',
        status: '',
        packageStandard: '',
        parentDocId: '',
        parentDocName: '',
        parentDocStatus: '',
        switchFlag: '',
        setSwitchOn: '',
        setSwitchOff: '',
        scanBarcode: '',
        lockFailureMessage: '',
        advancedSearchCondition: '',
        return: '',
        actions: '',
        close: '',
        commit: '',
        commitUpload: '',
        priorityCode: '',
        drapUploadExcelMessage: '',
        dragUploadImagePdfMessage: '',
        dragUploadImageMessage: '',
        confirmToGenerate: '',
        uploadFileTooBig: '',
        uploadFileTooBig2M: '',
        uploadInvalidFileType: '',
        pictureTitle: '',
        uploadImage: '',
        uploadAttachment: '',
        uploadExcel: '',
        uploadExcelTitle: '',
        pictureDescription: '',
        attachmentTitle: '',
        attachmentDescription: '',
        deleteAttachment: '',
        multiValueSearchComment: '',
        refPrevOrderId: '',
        refPrevOrderType: '',
        searchPlaceHolder: '',
        searchNavTitle: '',
        searchNavExecuteTitle: '',
        relatedOrdersSection: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        saveAndNew: '',
        systemDefault: '',
        noneAuthorizedFailure: '',
        noneLogonUser: '',
        reloginSessionTimeout: '',
        logoutTitle: '',
        openRightBarTitle: '',
        closeRightBarTitle: '',
        unlock: '',
        unlockTitle: '',
        unlockAll: '',
        unlockAllTitle: '',
        logoutWarnTitle: '',
        logoutWarnComment: '',
        toggleNavBar: '',
        settingTitle: '',
        unlockSuccessTitle: '',
        unlockUserSuccessComment: '',
        unlockSystemSuccessComment: '',
        enterSysConfigure: '',
        enterSysConfigureTitle: '',
        enterSysApplication: '',
        enterSysApplicationTitle: '',
        lastUpdateById: '',
        lastUpdateByName: '',
        lastUpdateTime: '',
        createdById: '',
        createdByName: '',
        createdTime: '',
        clearSearch: '',
        clearSearchComment: '',
        CalendarTemplate: '',
        attachmentSection: '',
        referenceDate: '',
        refMaterialSKUId: '',
        refMaterialSKUName: '',
        refMaterialPopupTitle: '',
        refRegisteredPopupTitle: '',
        selectDetailMaterialTitle: '',
        selectDetailRegisteredProductTitle: '',
        documentType: '',
        serialId: '',
        productionNumberBatch: '',
        finAccTitle: '',
        userId: '',
        password: '',
        login: '',
        loginComment: '',
        loginSystemComment: '',
        saveTitle: '',
        quickEdit: '',
        quickEditTitle: '',
        editDetailTitle: '',
        deleteDataTitle: '',
        errorPostNotEmpty: '',
        errorPostPositive: '',
        errorPostNegative: '',
        openHelpDocTitle: '',
        updatedDateTitle: '',
        updatedDate: '',
        updatedByName: '',
        updatedByNameTitle: '',
        logonUserHeaderTitle: '',
        expandMoreTitle: '',
        unfoldMoreTitle: '',
        notifyMessageTitle: '',
        warnMessageTitle: '',
        errorMessageTitle: '',
        actionCode: '',
        executionTime: '',
        expandDownTitle: '',
        foldUpTitle: '',
        uploadItemExcel: '',
        uploadItemExcelTitle: '',
        downloadItemExcel: '',
        downloadItemExcelTitle: '',
        internalPriceTitle: '',
        displayPriceTitle: '',
        newModuleTitle: '',
        addChildTitle: '',
        reservedDocType: '',
        reservedDocId: '',
        reservedDocName: '',
        prevDocType: '',
        prevDocId: '',
        prevDocName: '',
        prevProfDocType: '',
        prevProfDocId: '',
        prevProfDocName: '',
        nextDocType: '',
        nextDocId: '',
        nextDocName: '',
        nextProfDocType: '',
        nextProfDocId: '',
        nextProfDocName: '',
        rightBar: {
            tab2Title: ' ',
            tab1Title: ' '
        }
    };
};

ServiceUtilityHelper.setCommonTitle = function (label) {
    $('button.save').tooltip({title: label.saveTitle});
    $('button.edit').tooltip({title: label.editTitle});
    $('button.quickEdit').tooltip({title: label.quickEditTitle});
    $('button.nav-to-edit').tooltip({title: label.navToEditTitle});
    $('i.quickEdit').tooltip({title: label.quickEditTitle});
    $('i.editDetail').tooltip({title: label.editDetailTitle});
};

ServiceUtilityHelper.setI18nUnitCore = function (label, fieldName, prop) {
    if (label && fieldName in label) {
        if (!prop) {
            return;
        }
        var localVal;
        if (prop && ServiceCollectionsHelper.checkArrayFlag(prop)) {
            var fieldUnion = ServiceCollectionsHelper.filterArray(fieldName, 'fieldName', prop);
            if (fieldUnion) {
                localVal = fieldUnion["fieldLabel"];
            }
        } else {
            localVal = prop(fieldName);
        }
        if (!ServiceUtilityHelper.checkEmptyLabel(localVal)) {
            label[fieldName] = localVal;
        }
    }
};

/**
 * Batch update custom props in reflective way
 * @param vue
 * @param inputConfig: input new custom props
 * @param configModel: existed/default configure model in vue, will be overwrite
 * @param overwrite: weather to overwrite
 * @param fillEmpty: weather to fill empty value
 */
ServiceUtilityHelper.batchUpateCustomProps = function (vue, inputConfig, configModel, overwrite, fillEmpty) {
    if (inputConfig) {
        var keys = Object.keys(inputConfig);
        var i, len = keys ? keys.length : 0;
        for (i = 0; i < len; i++) {
            if (overwrite === true || !configModel[keys[i]]) {
                if (inputConfig[keys[i]] || fillEmpty === true) {
                    vue.$set(configModel, keys[i], inputConfig[keys[i]]);
                }
            }
        }
    }
};

/**
 * Set I18n properties in reflective way
 * @param label
 * @param prop
 */
ServiceUtilityHelper.setI18nReflectiveAsync = function (label, prop, overwrite) {
    if (label) {
        ServiceUtilityHelper.traverseObjProperties(label, function (obj) {
            var value = obj.value;
            if (overwrite === true || !value) {
                if (value && typeof value === 'object') {
                    return;
                }
                ServiceUtilityHelper.setI18nUnitCore(label, obj.key, prop);
            }
        });
    }
};

/**
 * Set I18n properties in reflective way
 * @param label
 * @param prop
 */
ServiceUtilityHelper.setI18nReflective = function (label, prop, overwrite) {
    if (label) {
        ServiceUtilityHelper.traverseObjProperties(label, function (obj) {
            var value = obj.value;
            if (overwrite === true || !value) {
                if (value && typeof value === 'object') {
                    ServiceUtilityHelper.setI18nReflectiveEmbedObject(value, obj.key, prop, overwrite);
                    return;
                }
                ServiceUtilityHelper.setI18nUnitCore(label, obj.key, prop);
            }
        });
    }
};


ServiceUtilityHelper.setI18nReflectiveEmbedObject = function (label, parentKey, prop, overwrite) {
    if (label) {
        ServiceUtilityHelper.traverseObjProperties(label, function (obj) {
            var value = obj.value;
            if (overwrite === true || !value) {
                if (value && typeof value === 'object') {
                    return; // to avoid overwrite sub module
                }
                var localVal = prop(parentKey + '.' + obj.key);
                if (!ServiceUtilityHelper.checkEmptyLabel(localVal)) {
                    label[obj.key] = localVal;
                }
            }
        });
    }
};

/**
 * Utility method to set i18n properties by i18nConfig
 */
ServiceUtilityHelper.setNodeI18nPropertiesByConfig = function (oSettings) {
    var i18nConfig = oSettings.i18nConfig;
    var fnCallback = oSettings.fnCallback;
    ServiceUtilityHelper.setI18nCommonReflective(i18nConfig.labelObject, $.i18n.prop);
    if (i18nConfig) {
        // Generate common i18n config
        var targetLabelConfig = {
            path: i18nConfig.i18nPath,
            fnCallback: fnCallback,
            commonCallback: function () {
                ServiceUtilityHelper.setI18nReflective(i18nConfig.labelObject, $.i18n.prop);
            },
        };
        var subConfigList = i18nConfig.configList ? i18nConfig.configList : [];
        if (i18nConfig.mainName) {
            subConfigList.push({
                name: i18nConfig.mainName
            });
        }
        ServiceCollectionsHelper.traverseList(subConfigList, function (subConfig) {
            if (subConfig.name) {
                // Generate i18n main config
                if (i18nConfig.mainName === subConfig.name) {
                    subConfigList.push({
                        name: subConfig.name,
                        callback: function () {
                            ServiceUtilityHelper.setI18nReflective(i18nConfig.labelObject, $.i18n.prop, true);
                            // call outer callback
                            if (fnCallback) {
                                fnCallback(i18nConfig);
                            }
                        }
                    });
                } else {
                    var defCallback = function (subPath, labelObject, overwrite) {
                        var labelObj = subPath ? labelObject[subPath] : labelObject;
                        return function () {
                            ServiceUtilityHelper.setI18nReflective(labelObj, $.i18n.prop, overwrite);
                        };
                    };
                    // Generate other sub configure node
                    subConfigList.push({
                        name: subConfig.name,
                        callback: defCallback(subConfig.subLabelPath, i18nConfig.labelObject, true),
                    });
                }
            }
            // Generate action node
            if (subConfig.actionNodePath) {
                subConfigList.push({
                    actionNode: i18nConfig.labelObject[subConfig.actionNodePath]
                });
            }
        });
        targetLabelConfig.configList = subConfigList;
        targetLabelConfig.vm = oSettings.vm;
        targetLabelConfig.label = i18nConfig.labelObject;
        if (oSettings.vm) {
            targetLabelConfig.errorHandle = oSettings.vm.errorHandle;
        } else {
            targetLabelConfig.errorHandle = oSettings.errorHandle;
        }
        return ServiceUtilityHelper.setI18nPropertiesWrapper(targetLabelConfig);
    }
};

/**
 * Logic to check if label is empty or not translated
 * @param label
 */
ServiceUtilityHelper.checkEmptyLabel = function (label) {
    if (!label) {
        return true;
    }
    var _len = label.length;
    if (_len <= 0) {
        return;
    }
    var _start = label.indexOf('[');
    var _end = label.indexOf(']');
    if (_start === 0 && _end === _len - 1) {
        return true;
    }
};


/**
 * Basic content class, then same as backend: SEUIComModel
 *
 */
ServiceUtilityHelper.getDefContent = function () {
    return {
        uuid: '',
        parentNodeUUID: '',
        rootNodeUUID: '',
        id: '',
        client:'',
        name: '',
        note: ''
    };
};

/**
 * Basic content class for document content, then same as backend: DocumentUIModel
 *
 */
ServiceUtilityHelper.getDefDocContent = function () {
    return {
        uuid: '',
        parentNodeUUID: '',
        rootNodeUUID: '',
        id: '',
        name: '',
        note: '',
        createdDate: '',
        createdByUUID: '',
        createdById: '',
        createdByName: '',
        updatedDate: '',
        updatedByUUID: '',
        updatedById: '',
        updatedByName: '',
    };
};


/**
 * Basic content class for document item content, then same as backend: DocMatItemUIModel
 *
 **/
ServiceUtilityHelper.getDefMatItemContent = function () {
    return {
        uuid: '',
        parentNodeUUID: '',
        rootNodeUUID: '',
        id: '',
        parentDocId: '',
        parentDocName: '',
        parentDocStatus: '',
        parentDocStatusValue: '',
        reservedMatItemUUID: '',
        reservedDocType: '',
        reservedDocTypeValue: '',
        reservedDocId: '',
        reservedDocName: '',
        prevDocType: '',
        prevDocTypeValue: '',
        prevDocMatItemUUID: '',
        prevDocId: '',
        prevDocName: '',
        prevDocStatus: '',
        nextDocType: '',
        nextDocTypeValue: '',
        nextDocMatItemUUID: '',
        nextDocId: '',
        nextDocName: '',
        nextDocStatus: '',
        prevProfDocType: '',
        prevProfDocTypeValue: '',
        prevProfDocMatItemUUID: '',
        prevProfDocMatItemArrayUUID: '',
        prevProfDocId: '',
        prevProfDocName: '',
        prevProfDocStatus: '',
        prevProfDocStatusValue: '',
        nextProfDocType: '',
        nextProfDocTypeValue: '',
        nextProfDocMatItemUUID: '',
        nextProfDocMatItemArrayUUID: '',
        nextProfDocId: '',
        nextProfDocName: '',
        nextProfDocStatus: '',
        amount: '',
        amountLabel: '',
        refUnitUUID: '',
        refUnitName: '',
        refMaterialSKUUUID: '',
        refMaterialSKUId: '',
        refMaterialSKUName: '',
        packageStandard: '',
        refMaterialTemplateUUID: '',
        serialId: '',
        itemPrice: '',
        unitPrice: '',
        itemPriceDisplay: '',
        unitPriceDisplay: '',
        createdDate: '',
        createdByUUID: '',
        createdById: '',
        createdByName: '',
        updatedDate: '',
        updatedByUUID: '',
        updatedById: '',
        updatedByName: '',
        productionBatchNumber: '',
        purchaseBatchNumber: '',
        materialStatus: '',
        materialStatusValue: '',
        homeDocumentType: '',
        homeDocumentTypeValue: ''
    };
};

ServiceUtilityHelper.traverseObjProperties = function (obj, fnEach) {
    if (obj) {
        var keys = Object.keys(obj);
        var i, len = keys ? keys.length : 0;
        for (i = 0; i < len; i++) {
            var result = fnEach({
                'key': keys[i],
                'value': obj[keys[i]]
            });
            if (result && result['break'] === true) {
                break;
            }
        }
    }
};


ServiceUtilityHelper.getKeyFromValue = function (obj, value) {
    if (obj && value) {
        var keys = Object.keys(obj);
        var i, len = keys ? keys.length : 0;
        for (i = 0; i < len; i++) {
            if (obj[keys[i]] === value) {
                return keys[i];
            }
        }
    }
};

/**
 * Set I18n properties in reflective way
 * @param baseObject: base object to be extend properties
 * @param extendObj: temp object with extend properties
 * @param oSettings:
 *   --{Boolean} keepBase: Whether need to keep value of base object, default is overwrite
 *   --{Boolean} withEmpty: Whether need to extend the properties with empty value
 */
ServiceUtilityHelper.extendObject = function (baseObject, extendObj, oSettings) {
    if (!baseObject && extendObj) {
        // in case base object is null
        baseObject = {};
    }
    if (baseObject && !extendObj) {
        return baseObject;
    }
    var keepBase = oSettings ? oSettings.keepBase: false;
    var withEmpty = oSettings ? oSettings.withEmpty: false;
    if (baseObject && extendObj) {
        ServiceUtilityHelper.traverseObjProperties(extendObj, function (obj) {
            if (obj.value || withEmpty === true) {
                var baseValue = baseObject[obj.key];
                if (!baseValue) {
                    baseObject[obj.key] = obj.value;
                    return;
                }
                // Added or merge for simple property
                if (!keepBase || keepBase === false) {
                    baseObject[obj.key] = obj.value;
                }
            }
        });
        return baseObject;
    }
};

/**
 * Extend Object properties, including empty value properties
 * @param baseObject
 * @param extendObj
 * @return {*}
 */
ServiceUtilityHelper.assignExtendObject = function (baseObject, extendObj) {
    if (baseObject && extendObj) {
        return Object.assign(baseObject, extendObj);
    }
    return baseObject;
};

/**
 * Get & Check sub property by property name without ignore property name
 * @param object
 * @param propName
 */
ServiceUtilityHelper.getSubPropIgnoreCase = function (object, propName) {
    if (!object || !propName) {
        return;
    }
    var result;
    ServiceUtilityHelper.traverseObjProperties(object, function (obj) {
        if (ServiceStringHelper.equalIgnoreCase(propName, obj.key)) {
            result = obj.value;
            return {'break': true};
        }
    });
    if (result) {
        return result;
    } else {
        return;
    }
};
/**
 * copy all fields in reflective way
 * @param label
 * @param prop
 */
ServiceUtilityHelper.copyFieldsReflective = function (source, target, fnCopyField, overwrite) {
    if (source) {
        var keys = Object.keys(source);
        var i, len = keys ? keys.length : 0;
        for (i = 0; i < len; i++) {
            if (overwrite === true || ServiceUtilityHelper.checkEmptyValue(target[keys[i]])) {
                if (ServiceUtilityHelper.checkEmptyValue(source[keys[i]])) {
                    continue;
                }
                fnCopyField(source[keys[i]], keys[i]);
            }
        }
    }
};

/**
 * Utility method to check if current value is empty, regardless of value type
 */
ServiceUtilityHelper.checkEmptyValue = function (value) {
    if (!value) {
        return true;
    }
    if (typeof value === 'number') {
        return value === 0;
    }
    if (ServiceCollectionsHelper.checkArrayFlag(value)) {
        return value.length <= 0;
    }
    return false;
};

ServiceUtilityHelper.defCopyFieldsReflective = function (source, target, vm, overwrite) {
    ServiceUtilityHelper.copyFieldsReflective(source, target, function (value, fieldName) {
        vm.$set(target, fieldName, value);
    }, overwrite);
};

/**
 * copy all fields in reflective way
 * @param label
 * @param prop
 */
ServiceUtilityHelper.copyFieldsReCurReflective = function (oSettings) {
    var source = oSettings.source;
    var target = oSettings.target;
    var vm = oSettings.vm;
    var overwrite = oSettings.overwrite;
    if (source) {
        var keys = Object.keys(source);
        var i, len = keys ? keys.length : 0;
        for (i = 0; i < len; i++) {
            if (overwrite === true || ServiceUtilityHelper.checkEmptyValue(source[keys[i]])) {
                if (source[keys[i]] && typeof source[keys[i]] === 'object') {
                    ServiceUtilityHelper.copyFieldsReCurReflective({
                        source: source[keys[i]],
                        target: target[keys[i]],
                        vm: oSettings.vm,
                        overwrite: oSettings.overwrite
                    });
                    continue; // to avoid overwrite sub module
                }
                vm.$set(target, keys[i], source[keys[i]]);
            }
        }
    }
};


/**
 * Set I18n properties in reflective way
 * @param label
 * @param prop
 */
ServiceUtilityHelper.setI18nCommonReflective = function (label, prop, overwrite) {
    if (label) {
        ServiceUtilityHelper.setI18nReflective(label, prop, overwrite);
        ServiceUtilityHelper.setCommonTitle(label);
    }
};

/**
 * Wrapper method to set i18n properties
 * @param oSettings
 *    --{string} path: common path to access i18n resources
 *    --{function} commonCallback: callback for common i18n
 *    --{function} fnCallback: callback function after all i18n resources is loaded
 *    --{function} errorHandle: callback function for error handle
 *    --{string} modelId: in case need to get from backend, modelId
 *    --{string} coreModelId: in case need to get from backend, coreModelId
 *    --{array} status: configList
 *         --{string} name: i18n resource
 *         --{function} callback: i18n resource load callback
 *         --{object} label: [optional] in case special process label
 * @returns {list<Promise>>}
 */
ServiceUtilityHelper.setI18nPropertiesWrapper = function (oSettings) {
    var commonPath = oSettings.path;
    var commonCallback = oSettings.commonCallback;
    var configList = oSettings.configList;
    var modelId = oSettings.modelId;
    var coreModelId = oSettings.coreModelId;
    if (modelId && coreModelId) {
        // In case need to retrieve resource backend
        ServiceUtilityHelper.setI18nPropertiesAsyncWrapper({
            vm: oSettings.vm,
            modelId: modelId,
            coreModelId: coreModelId,
            label: oSettings.label,
            serviceUIMeta: oSettings.serviceUIMeta,
            fnCallback: oSettings.fnCallback,
            errorHandle: oSettings.errorHandle,
        });
    }
    var promiseList = [];
    if (commonCallback) {
        promiseList.push(getCommonI18n(jQuery.i18n, commonCallback));
    }
    if (!configList || configList.length <= 0) {

    } else {
        var i, len = configList.length, configUnion, configPath;
        for (i = 0; i < len; i++) {
            configUnion = configList[i];
            configPath = configUnion.path ? configUnion.path : commonPath;
            if (configUnion.name) {
                var promise = jQuery.i18n.properties({
                    name: configUnion.name, //properties file name
                    path: getI18nRootPath() + configPath, //path for properties files
                    mode: 'map', //Using map mode to consume properties files
                    language: getLan(),
                    cache: true,
                    callback: configUnion.callback
                });
                promiseList.push(promise);
            }
            if (configUnion.actionNode) {
                var actionNodePromise = ServiceActionCodeNodeHelper.setI18nActionNode(jQuery.i18n, function () {
                    ServiceActionCodeNodeHelper.setI18nProperties(configUnion.actionNode);
                });
                promiseList.push(actionNodePromise);
            }
            if (configUnion.docMatItem) {
                var matItemPromise = ServiceUtilityHelper.getDocMatItemI18n({
                    i18n: jQuery.i18n,
                    label: configUnion.docMatItem
                });
                promiseList.push(matItemPromise);
            }
        }
    }
    if (oSettings.fnCallback) {
        Promise.all(promiseList).then(function () {
            oSettings.fnCallback(oSettings);
        });
    }
    return promiseList;
};


/**
 * Handler method for set 18n properties to remote aysnc request
 * @param oSettings
 *    {Vue} vm: vue instance
 *    {String} modelId: model or document id
 *    {String} coreModelId: core model id
 *    {Object} label: label object
 *    {function} errorHandle: error call back method
 *    {function} fnCallback: call back after promise
 */
ServiceUtilityHelper.setI18nPropertiesAsyncWrapper = function (oSettings) {
    var vm = oSettings.vm;
    ServiceUtilityHelper.httpRequest({
        url: '../common/getServiceDocumentMeta.html?modelId=' + oSettings.modelId + '&coreModelId=' + oSettings.coreModelId,
        $http: vm.$http,
        errorHandle: oSettings.errorHandle,
        postHandle: function (oData) {
            ServiceUtilityHelper._postHandle18nAsyncWrapper(oSettings, oData);
            if (oSettings.serviceUIMeta) {
                var serviceUIMeta = ServiceUtilityHelper._filterServiceUIMeta(oSettings, oData);
                if (serviceUIMeta) {
                    vm.$set(vm, 'serviceUIMeta', serviceUIMeta);
                    oSettings.serviceUIMeta = serviceUIMeta;
                }
            }
            vm.$nextTick(function () {
                if (oSettings.fnCallback) {
                    oSettings.fnCallback(oData);
                }
            });
        }.bind(this)
    });
};

ServiceUtilityHelper._filterServiceUIMeta = function (oSettings, oData) {
    var serviceExtensionList = oData.content;
    if (!serviceExtensionList || serviceExtensionList.length <= 0) {
        return;
    }
    var i = 0, len = serviceExtensionList.length, serviceExtension;
    for (i = 0; i < len; i++) {
        serviceExtension = serviceExtensionList[i];
        if (oSettings.coreModelId === serviceExtension.modelId) {
            return serviceExtension.serviceUIMeta;
        }
    }

};


/**
 * Handler method for set 18n properties to remote aysnc request
 * @param oSettings
 *    {Vue} vm: vue instance
 */
ServiceUtilityHelper.setI18nPropertiesAsync = function (oSettings) {
    var vm = oSettings.vm;

    ServiceUtilityHelper.httpRequest({
        url: '../common/getServiceDocumentMeta.html?modelId=' + oSettings.modelId,
        $http: vm.$http,
        errorHandle: vm.errorHandle,
        postHandle: function (oData) {
            ServiceUtilityHelper._postHandle18nAsync(oSettings, oData);
            oSettings.fnCallback(oData);
        }.bind(this)
    });
};

ServiceUtilityHelper._postHandle18nAsync = function (oSettings, oData) {
    var configList = oSettings.configList;
    if (!configList || configList.length <= 0) {
        return;
    }
    var i = 0, len = configList.length, configUnion;
    for (i = 0; i < len; i++) {
        configUnion = configList[i];
        if (configUnion.name) {
            // filter by name from field list from oData
            var serviceExtension = ServiceCollectionsHelper.filterArray(configUnion.name, 'modelId', oData.content);
            if (serviceExtension) {
                configUnion.callback(serviceExtension.serviceExtendFieldList);
            }
        }
    }
};


ServiceUtilityHelper._postHandle18nAsyncWrapper = function (oSettings, oData) {
    var serviceExtensionList = oData.content;
    if (!serviceExtensionList || serviceExtensionList.length <= 0) {
        return;
    }
    var i = 0, len = serviceExtensionList.length, serviceExtension;
    for (i = 0; i < len; i++) {
        serviceExtension = serviceExtensionList[i];
        var subPath = serviceExtension.modelId;
        var rawLabel = oSettings.label;
        if (ServiceCollectionsHelper.checkArrayFlag(rawLabel)) {
            var k = 0, lenK = rawLabel.length;
            for (k = 0; k < lenK; k++) {
                ServiceUtilityHelper._postHandle18nLabelUnionAsync(serviceExtension, oSettings, subPath, rawLabel[k]);
            }
        } else {
            ServiceUtilityHelper._postHandle18nLabelUnionAsync(serviceExtension, oSettings, subPath, rawLabel);
        }
    }
};

ServiceUtilityHelper._postHandle18nLabelUnionAsync = function (serviceExtension, oSettings, subPath, labelUnion) {
    if (subPath === oSettings.coreModelId) {
        // in case core model id, just set value to label object
        ServiceUtilityHelper.setI18nReflectiveAsync(labelUnion, serviceExtension.serviceExtendFieldList, true);
        // Default action
        // BusyLoader.cleanPageBackground();
    } else {
        var subLabelObj = ServiceUtilityHelper.getSubPropIgnoreCase(labelUnion, subPath);
        ServiceUtilityHelper.setI18nReflectiveAsync(subLabelObj, serviceExtension.serviceExtendFieldList, true);
    }
};

/**
 * Utility method: check disabled flag by matching true value or not
 * @param firstDisableField
 * @param secondDisableFlag
 * @return {boolean}
 */
ServiceUtilityHelper.checkDisableFlag = function (firstDisableField, secondDisableFlag) {
    if (firstDisableField === true || firstDisableField === "true") {
        return true;
    }
    if (!secondDisableFlag) {
        return;
    }
    if (secondDisableFlag === true || secondDisableFlag === "true") {
        return true;
    }
};
/**
 * Check Display Logic by checking the authorization and status
 * @param oSettings
 *    --{boolean} accessActionCode
 *    --{number} currentStatus
 *    --{object} [optional] renderModel: in case need special render class
 *    --{number/array} status: target status to be checked
 *    --{number/array} excludeStatus: target status to be excluded
 *    --{number} [optional] processMode
 *    --{number} [optional] involveTaskStatus
 * @returns {*}
 */
ServiceUtilityHelper.checkDisplayCore = function (oSettings) {
    var currentStatus = oSettings.currentStatus;
    if (oSettings.accessActionCode && oSettings.accessActionCode !== true) {
        return undefined;
    }
    // In case customize call back function to check
    if (oSettings.checkCallback && typeof oSettings.checkCallback === 'function') {
        var result = oSettings.checkCallback();
        if (result && result === true) {
            if (!oSettings.status) {
                // In case don't need to check status anymore
                return true;
            }
        } else {
            return undefined;
        }
    }
    if (!oSettings.status && !oSettings.excludeStatus) {
        // In case don't need to check status
        return true;
    }
    if (oSettings.status) {
        if (ServiceCollectionsHelper.checkArrayFlag(oSettings.status)) {
            var filterResult = oSettings.status.filter(function (tempStatus) {
                return tempStatus === currentStatus;
            });
            if (filterResult && filterResult.length > 0) {
                return true;
            } else {
                return undefined;
            }
        } else {
            if (currentStatus === oSettings.status) {
                return true;
            }
        }
    }
    if (oSettings.excludeStatus) {
        if (ServiceCollectionsHelper.checkArrayFlag(oSettings.excludeStatus)) {
            var filterResult2 = oSettings.excludeStatus.filter(function (tempStatus) {
                return tempStatus === currentStatus;
            });
            if (filterResult2 && filterResult2.length > 0) {
                return undefined; // one wrong status is hit.
            } else {
                return true; // all the wrong status has been excluded.
            }
        } else {
            if (currentStatus !== oSettings.excludeStatus) {
                return true;
            }
        }
    }

};

ServiceUtilityHelper.formatActiveToDoCore = function (oSettings) {
    var checkResult = ServiceUtilityHelper.checkDisplayCore(oSettings);
    if (checkResult && checkResult === true) {
        return ServiceDisplayHelper.formatActiveToDoClass(true);
    } else {
        return ServiceDisplayHelper.formatActiveToDoClass(false);
    }
};

/**
 * Check Disable Logic by checking the authorization and status
 * @param oSettings
 *    --{boolean} accessActionCode
 *    --{number} currentStatus
 *    --{object} [optional] renderModel: in case need special render class
 *    --{number/array} status: target status to be checked
 *    --{number/array} excludeStatus: target status to be excluded
 *    --{number} [optional] processMode
 *    --{number} [optional] involveTaskStatus
 * @returns {*}
 */
ServiceUtilityHelper.disableForCore = function (oSettings) {
    var checkResult = ServiceUtilityHelper.checkDisplayCore(oSettings);
    if (checkResult && checkResult === true) {
        return true;
    }
};

/**
 * Utility to check if value equals true, by boolean and string type
 * @param {Object} oSettings
 *   --{String|Boolean} value
 */
ServiceUtilityHelper.checkEqualsTrue = function (oSettings) {
    if (!oSettings) {
        return ;
    }
    var value = oSettings.value ? oSettings.value : oSettings;
    if (value) {
        if (value === true || value === 'true') {
            return true;
        }
    }
};

/**
 * Provide Display Class method by checking the authorization and status
 * @param oSettings
 *    --{number} currentStatus
 *    --{object} [optional] renderModel: in case need special render class
 *    --{array} docActionConfigureList: document action code configure list
 *    --{object} accessActionCodeModel: access model
 *    --{number} targetActionCode: target document action code
 *    --{function} checkCallback: call back function to return
 *    --{number} [optional] processMode
 *    --{number} [optional] involveTaskStatus
 * @returns {*}
 */
ServiceUtilityHelper.displayForActionCodeConfig = function (oSettings) {
    if (!oSettings.docActionConfigureList || oSettings.docActionConfigureList.length === 0) {
        return DocumentManagerFactory.formatDisplayClass();
    }
    var docActionConfigure, docActionConfigureList = oSettings.docActionConfigureList;
    docActionConfigure = ServiceCollectionsHelper.filterArray(oSettings.targetActionCode, 'actionCode', docActionConfigureList);
    if (!docActionConfigure) {
        return DocumentManagerFactory.formatDisplayClass();
    }
    if (oSettings.accessActionCodeModel) {
        oSettings.accessActionCode = oSettings.accessActionCodeModel[docActionConfigure.authorActionCode];
    }
    oSettings.status = docActionConfigure.preStatusList;
    return ServiceUtilityHelper.displayForCore(oSettings);
};

/**
 * Provide Display Class method by checking the authorization and status
 * @param oSettings
 *    --{boolean} accessActionCode
 *    --{number} currentStatus
 *    --{object} [optional] renderModel: in case need special render class
 *    --{number/array} status: target status to be checked
 *    --{number/array} excludeStatus: target status to be excluded
 *    --{function} checkCallback: call back function to return
 *    --{number} [optional] processMode
 *    --{number} [optional] involveTaskStatus
 * @returns {*}
 */
ServiceUtilityHelper.displayForCore = function (oSettings) {
    if (oSettings.processMode) {
        // In case need to check if processMode is in EDIT
        if (oSettings.processMode * 1 === PROCESSMODE_NEW) {
            return DocumentManagerFactory.formatDisplayClass();
        }
    }
    var checkResult = ServiceUtilityHelper.checkDisplayCore(oSettings);
    if (checkResult && checkResult === true) {
        return ServiceUtilityHelper._finalRenderUnit(oSettings);
    }
    return DocumentManagerFactory.formatDisplayClass();
};

ServiceUtilityHelper.displayForArray = function (oSettingList) {
    if (ServiceCollectionsHelper.checkArrayFlag(oSettingList)) {
        var i = 0, len = oSettingList.length, checkResult;
        for (i = 0; i < len; i++) {
            checkResult = ServiceUtilityHelper.checkDisplayCore(oSettingList[i]);
            if (!checkResult) {
                return DocumentManagerFactory.formatDisplayClass();
            }
        }
        return ServiceUtilityHelper._finalRenderUnit(oSettingList[len - 1]);
    } else {
        var oSettings = oSettingList;
        return ServiceUtilityHelper.displayForCore(oSettings);
    }
};


/**
 * Check Display logic, return boolean value for display or not
 * @param oSettings
 * @returns {*} True/undefined
 */
ServiceUtilityHelper.displayForBoolean = function (oSettings) {
    var status = oSettings.currentStatus;
    if (oSettings.accessActionCode && oSettings.accessActionCode !== true) {
        return undefined;
    }
    if (oSettings.processMode) {
        // In case need to check if processMode is in EDIT
        if (oSettings.processMode * 1 === PROCESSMODE_NEW) {
            return undefined;
        }
    }
    if (ServiceCollectionsHelper.checkArrayFlag(oSettings.status)) {
        var filterResult = oSettings.status.filter(function (tempStatus) {
            return tempStatus === status;
        });
        if (filterResult && filterResult.length > 0) {
            return true;
        } else {
            return undefined;
        }
    } else {
        if (status === oSettings.status) {
            return true;
        }
    }
    if (!oSettings.status) {
        // In case don't need to check status
        return true;
    }
    return undefined;
};

/**
 * Internal method, generate the style class in case to be shown, special render logic is attached when "renderModel" exist.
 * @param oSettings
 *    {string}: baseClass
 * @returns {*}
 * @private
 */
ServiceUtilityHelper._finalRenderUnit = function (oSettings) {
    var baseClass = DocumentManagerFactory.formatDisplayClass(true);
    if (oSettings.renderModel) {
        // Special rendering logic
        oSettings.renderModel.baseClass = baseClass;
        oSettings.renderModel.involveTaskStatus = oSettings.involveTaskStatus;
        return ServiceMessageHandlerHelper.renderClass(oSettings.renderModel);
    } else {
        return baseClass;
    }

}

/**
 * Provide utility methods to disable when NOT in certain status
 * @param oSettings
 *    --{number} currentStatus
 *    --{number/array} status: target status which could enable edit
 * @returns {*}
 */
ServiceUtilityHelper.disableNotInCore = function (oSettings) {
    var status = oSettings.currentStatus;
    if (ServiceCollectionsHelper.checkArrayFlag(oSettings.status)) {
        var filterResult = oSettings.status.filter(function (tempStatus) {
            return tempStatus === status;
        });
        if (filterResult && filterResult.length > 0) {
            return false;
        } else {
            return true;
        }
    } else {
        if (status === oSettings.status) {
            return false;
        }
    }
    return true;
};

var ServiceVueUtility = function () {
};

/**
 * Utility method to collect all the sub refs from current vue instance into list in recursive way
 * @param oSettings
 */
ServiceVueUtility.collectSubRefRecursive = function (oSettings) {
    "use strict";
    var vm = oSettings.vm;
    var resultList = [];
    for (var key in vm.$refs) {
        if (vm.$refs[key]) {
            if (ServiceCollectionsHelper.checkArrayFlag(vm.$refs[key])) {
                ServiceCollectionsHelper.traverseList(vm.$refs[key], function (subRef) {
                    if (subRef) {
                        resultList = ServiceVueUtility._collectSingleSubRef({
                            resultList: resultList,
                            vm: subRef
                        });
                    }
                });
            } else {
                if (vm.$refs[key]) {
                    resultList = ServiceVueUtility._collectSingleSubRef({
                        resultList: resultList,
                        vm: vm.$refs[key]
                    });
                }
            }
        }
    }
    return resultList;
};

/**
 * Utility method to collect all the sub refs from current vue instance into list in recursive way
 * @param oSettings
 */
ServiceVueUtility.collectChildrenRecursive = function (oSettings) {
    "use strict";
    var vm = oSettings.vm;
    var resultList = [];
    for (var key in vm.$children) {
        if (vm.$children[key]) {
            if (oSettings.callback(vm.$children[key]) === true) {
                resultList.push(vm.$children[key]);
            }
            var subResultList = ServiceVueUtility.collectChildrenRecursive({
                vm: vm.$children[key],
                callback: oSettings.callback
            });
            if (!ServiceCollectionsHelper.checkNullList(subResultList)) {
                resultList = resultList.concat(subResultList);
            }
        }
    }
    return resultList;
};

ServiceVueUtility._collectSingleSubRef = function (oSettings) {
    "use strict";
    var vm = oSettings.vm;
    var resultList = oSettings.resultList;
    var subResultList = ServiceVueUtility.collectSubRefRecursive({
        vm: vm
    });
    if (!ServiceCollectionsHelper.checkNullList(subResultList)) {
        resultList = ServiceCollectionsHelper.directMergeArray(resultList, subResultList);
    }
    resultList.push(vm);
    return resultList;
};

/**
 * Filter
 * @param oSettings
 */
ServiceVueUtility.filterSubRefListRecursive = function (oSettings) {
    "use strict";
    var vm = oSettings.vm;
    var fnCallback = oSettings.fnCallback;
    var allSubRefList = ServiceVueUtility.collectSubRefRecursive({
        vm: vm
    });
    return ServiceCollectionsHelper.filterList(allSubRefList, fnCallback);
};


/**
 * Filter
 * @param oSettings
 */
ServiceVueUtility.filterChildrenListRecursive = function (oSettings) {
    "use strict";
    var vm = oSettings.vm;
    var fnCallback = oSettings.fnCallback;
    var allSubRefList = ServiceVueUtility.collectSubRefRecursive({
        vm: vm
    });
    return ServiceCollectionsHelper.filterList(allSubRefList, fnCallback);
};
/**
 * Batch execute one specified method (provided by method name) for all the sub vue instance
 * @param oSettings
 */
ServiceVueUtility.batchExecuteSubRefMethod = function (oSettings) {
    "use strict";
    var vm = oSettings.vm;
    var methodName = oSettings.methodName;
    var resultList = [];
    for (var key in vm.$refs) {
        if (vm.$refs[key]) {
            if (ServiceCollectionsHelper.checkArrayFlag(vm.$refs[key])) {
                ServiceCollectionsHelper.traverseList(vm.$refs[key], function (subRef) {
                    if (subRef && subRef[methodName]) {
                        resultList = AsyncPage.mergeExecuteResult({
                            result: subRef[methodName](oSettings),
                            resultList: resultList
                        });
                    }
                });
            } else {
                if (vm.$refs[key] && vm.$refs[key][methodName]) {
                    var result = vm.$refs[key][methodName](oSettings);
                    resultList = AsyncPage.mergeExecuteResult({
                        result: result,
                        resultList: resultList
                    });
                }
            }
        }
    }
    return resultList;
};

ServiceVueUtility.getFunctionBodyToString = function (func) {
    var functionAsString = func.toString();
    var functionBody = functionAsString.slice(functionAsString.indexOf("{") + 1, functionAsString.lastIndexOf("}"));
    return functionBody;
};

var ServiceExcelHelper = function () {
};

ServiceExcelHelper.CONSTANTS = {
    EXCEL_TYPE: {
        XLSX: "xlsx",
        XLS: "xls"
    },
    POST: {
        XLSX: "xlsx",
        XLS: "xls"
    }
};

ServiceExcelHelper.initFileTypePostMap = function () {
    var fileTypePostMap = [{
        fileType: ServiceExcelHelper.CONSTANTS.EXCEL_TYPE.XLS,
        post: ServiceExcelHelper.CONSTANTS.POST.XLS
    },
        {fileType: ServiceExcelHelper.CONSTANTS.EXCEL_TYPE.XLSX, post: ServiceExcelHelper.CONSTANTS.POST.XLSX}];
    return fileTypePostMap;
};

ServiceExcelHelper.getFilePost = function (fileType) {
    var fileTypePostMap = ServiceExcelHelper.initFileTypePostMap();
    return ServiceCollectionsHelper.filterArray(fileType, "fileType", fileTypePostMap);
};

/**
 * Utility method to trigger download excel
 * @param oSettings
 *   --{String} url:
 *   --{String} reportTitle:
 *   --{method} method: {post|get} default is post
 *   --{object} busyLoader
 *   --{object} requestData
 *   --{function} errorHandle
 */
ServiceExcelHelper.downloadExcel = function (oSettings) {
    oSettings.method = oSettings.method ? oSettings.method : 'post';
    // [Step2] Call http request core
    var busyLoader = oSettings.busyLoader;
    if (busyLoader && busyLoader.showBusyLoading) {
        busyLoader.showBusyLoading();
    }
    var rawPromise = ServiceUtilityHelper._genHttpRequestPromise(oSettings);
    rawPromise.then(function (response) {
        if (busyLoader && busyLoader.hideBusyLoading) {
            busyLoader.hideBusyLoading();
        }
        if (!response.body) {
            oSettings.errorHandle(response);
            return;
        }
        ServiceExcelHelper.showFile(response.body, oSettings);
    }).catch(function (error) {
        oSettings.errorHandle(error);
    });
};


ServiceExcelHelper.showFile = function (blob, oSettings) {

    // It is necessary to create a new blob object with mime-type explicitly set
    // otherwise only Chrome works like it should
    var newBlob = new Blob([blob], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});

    // IE doesn't allow using a blob object directly as link href
    // instead it is necessary to use msSaveOrOpenBlob
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(newBlob);
        return;
    }

    // For other browsers:
    // Create a link pointing to the ObjectURL containing the blob.
    var data = window.URL.createObjectURL(newBlob);
    var link = document.createElement('a');
    link.href = data;
    var date = new Date();
    var postfix = ServiceExcelHelper.getFilePost(oSettings.excelType);
    var fileName = oSettings.reportTitle + date.getFullYear() + (date.getMonth() + 1) + date.getDate() + "." + postfix.post;
    link.download = fileName;
    link.click();
};

class ServiceError extends Error {

    constructor(errorCode, context) {
        super(errorCode);
        this.errorCode = errorCode;
        this.name = 'ServiceError';
        this.context = context;
    }

    getLabelObject() {
        return {
            typeSystemError: '',
            paraSystemWrong: '',
            embActionError: '',
            paraWrongPreStatus: '',
            paraWrongConfig: '',
            paraMissConfig: '',
            typeNoSelectItem: '',
            typeNoValidData: '',
            paraMissConfigSpecifer: '',
            para2OverAmountPreprofDoc: ''
        };
    }

    get18nProperty() {
        return {
            i18nPath: 'systemResource/',
            mainName: 'ServiceError',
            label: this.getLabelObject()
        };
    }

    getErrorCode() {
        return this.errorCode;
    }

    setErrorCode(errorCode) {
        this.errorCode = errorCode;
    }

    getParas() {
        return this.paras;
    }

    setParas(paras) {
        this.paras = paras;
    }

    getMessage() {
       return this.message;
    }

    setMessage(message) {
        this.message = message;
    }

    getContext() {
        return this.context;
    }

    setContext(context) {
        this.context = context;
    }

    setI18nProperties(i18nSettings, fnCallback) {
        var vm = this;
        ServiceUtilityHelper.setNodeI18nPropertiesByConfig({
            i18nPath: 'systemResource/',
            labelObject: vm.getLabelObject(),
            fnCallback: fnCallback,
            mainName: 'ServiceError'
        });
        if (i18nSettings) {
            i18nSettings.fnCallback = fnCallback;
            ServiceUtilityHelper.setNodeI18nPropertiesByConfig(i18nSettings);
        }
    }
}

var ServiceExceptionHelper = function () {
};

ServiceExceptionHelper.EXCEPTION_TYPE = {
    ServiceError: 'ServiceError',
    AsyncControlException: 'AsyncControlException'
};

ServiceExceptionHelper.HANDLE_CATEGORY = {
    SKIP: 'skip',
    CONSOLE: 'console',
    MESSAGE_CONTAINER: 'messageContainer'
};

ServiceExceptionHelper.getExceptionClass = function (exceptionType) {
    if (exceptionType === ServiceExceptionHelper.EXCEPTION_TYPE.ServiceError) {
        return ServiceError;
    }
    if (exceptionType === ServiceExceptionHelper.EXCEPTION_TYPE.AsyncControlException) {
        return AsyncControlException;
    }
};

ServiceExceptionHelper.raiseException = function (oSettings) {
    var exceptionType = oSettings.exceptionType;
    var errorCode = oSettings.errorCode;
    var context = oSettings.context ? oSettings.context: errorCode;
    var paras = oSettings.paras;
    var exceptionClass = ServiceExceptionHelper.getExceptionClass(exceptionType);
    var exceptionIns = eval(`new exceptionClass(errorCode, context)`);
    if (paras) {
        exceptionIns.setParas(paras);
    }
    throw exceptionIns;
};

ServiceExceptionHelper.handleException = function (oSettings) {
    var handleCategory = oSettings.handleCategory;
    var exception = oSettings.exception;
    if (handleCategory === ServiceExceptionHelper.HANDLE_CATEGORY.SKIP) {
        return;
    }
    if (exception.get18nProperty) {
        // In case a standard service defined exception: inherit from service exception
        ServiceExceptionHelper.setI18nProperties(exception.get18nProperty(), function(oSettings){
            var label = oSettings.label ? oSettings.label: oSettings.labelObject;
            var message = ServiceUtilityHelper.fetchObjValueByPath(label, exception.getErrorCode());
            var paras = exception.getParas();
            if (!ServiceCollectionsHelper.checkNullList(paras)) {
                message = ServiceStringHelper.formatStrings(message, paras);
            }
            oSettings.message = message;
            oSettings.exception = exception;
            ServiceExceptionHelper.handleExceptionCore(oSettings);
        });
    } else {
        oSettings.message = exception.message;
        oSettings.exception = exception;
        ServiceExceptionHelper.handleExceptionCore(oSettings);
    }
};

ServiceExceptionHelper.handleExceptionCore = function(oSettings) {
    var handleCategory = oSettings.handleCategory;
    var message = oSettings.message;
    var exception = oSettings.exception;
    // In case handle in message container
    if (handleCategory === ServiceExceptionHelper.HANDLE_CATEGORY.MESSAGE_CONTAINER) {
        ServiceValidatorHelper.throwErrorMessageWrap({
            messageContainer: oSettings.messageContainer? oSettings.messageContainer:'.main.message-container',
            errorMessage: message,
            valueContainer: oSettings.valueContainer,
            context: exception.errorCode ? exception.errorCode: message
        });
    }
    // In case handle in console
    if (handleCategory === ServiceExceptionHelper.HANDLE_CATEGORY.CONSOLE) {
        console.error(message);
    }
};

ServiceExceptionHelper.getBaseLabelObject = function () {
    return {
        typeSystemError: '',
        paraSystemWrong: '',
        embActionError: '',
        paraWrongPreStatus: '',
        paraWrongConfig: '',
        paraMissConfig: '',
        typeNoSelectItem: '',
        typeNoValidData: '',
        paraMissConfigSpecifer: '',
        para2OverAmountPreprofDoc: ''
    };
};

ServiceExceptionHelper.setI18nProperties = function (i18nSettings, fnCallback) {
    var labelObject = ServiceUtilityHelper.extendObject(ServiceExceptionHelper.getBaseLabelObject(), i18nSettings.label, {
        withEmpty: true
    });
    var i18nPath = i18nSettings.i18nPath ? i18nSettings.i18nPath: 'systemResource';
    var configList = [];
    configList.push({
        name: 'ServiceError',
        i18nPath: 'systemResource'
    });
    if (!ServiceCollectionsHelper.checkNullList(i18nSettings.configList)) {
        configList = configList.concat(i18nSettings.configList);
    }
    var localI18nConfig = {
        i18nPath: i18nPath,
        mainName: i18nSettings.mainName,
        labelObject: labelObject,
        configList: configList
    };
    return ServiceUtilityHelper.setNodeI18nPropertiesByConfig({
        i18nConfig:localI18nConfig,
        fnCallback:fnCallback
    });
};

var ServiceMessageHandlerHelper = function () {
};

ServiceMessageHandlerHelper.defaultHandleUUIDArray = function (uuidArray, oSettings) {
    if (!oSettings.uuidArray) {
        return;
    }
    oSettings.uuidArray.value = uuidArray;
    ServiceMessageHandlerHelper._defaultProcessCore(oSettings.uuidArray, oSettings);
};


/**
 * Default post process
 * default rule: 1. checking field 'status' from search model, 2, checking 'eleStatus' in search model
 *
 * @param oSettings
 *     {vue} searchModel,
 *     {object} approve:
 *         --{string} message
 *         --{fromStatus} status which could trigger approve
 *
 *
 */
ServiceMessageHandlerHelper.defaultProcessByDocStatus = function (oSettings) {
    var defProcessConfigure = {
        uuidArray: {
            callback: function (uuidArray) {
                ServiceMessageHandlerHelper.defSetSearchModel({
                    searchModel: oSettings.searchModel,
                    field: {
                        name: 'uuid',
                        value: uuidArray
                    }
                });
            }
        }
    };
    if (oSettings.approve) {
        defProcessConfigure.approve = {
            message: oSettings.approve.message,
            callback: function () {
                ServiceMessageHandlerHelper.defSetSearchModel({
                    searchModel: oSettings.searchModel,
                    field: {
                        name: 'status',
                        value: oSettings.approve.fromStatus,
                        element: oSettings.searchModel.eleStatus
                    }
                });
            }
        };
    }
    if (oSettings.reject) {
        defProcessConfigure.reject = {
            message: oSettings.reject.message,
            callback: function () {
                ServiceMessageHandlerHelper.defSetSearchModel({
                    searchModel: oSettings.searchModel,
                    field: {
                        name: 'status',
                        value: oSettings.reject.fromStatus,
                        element: oSettings.searchModel.eleStatus
                    }
                });
            }
        };
    }
    if (oSettings.deliveryDone) {
        defProcessConfigure.deliveryDone = {
            message: oSettings.deliveryDone.message,
            callback: function () {
                ServiceMessageHandlerHelper.defSetSearchModel({
                    searchModel: oSettings.searchModel,
                    field: {
                        name: 'status',
                        value: oSettings.deliveryDone.fromStatus,
                        element: oSettings.searchModel.eleStatus
                    }
                });
            }
        };
    }
    if (oSettings.processDone) {
        defProcessConfigure.processDone = {
            message: oSettings.processDone.message,
            callback: function () {
                ServiceMessageHandlerHelper.defSetSearchModel({
                    searchModel: oSettings.searchModel,
                    field: {
                        name: 'status',
                        value: oSettings.processDone.fromStatus,
                        element: oSettings.searchModel.eleStatus
                    }
                });
            }
        };
    }
    if (oSettings.startProcess) {
        defProcessConfigure.startProcess = {
            message: oSettings.startProcess.message,
            callback: function () {
                ServiceMessageHandlerHelper.defSetSearchModel({
                    searchModel: oSettings.searchModel,
                    field: {
                        name: 'status',
                        value: oSettings.startProcess.fromStatus,
                        element: oSettings.searchModel.eleStatus
                    }
                });
            }
        };
    }
    if (oSettings.outboundBatch) {
        defProcessConfigure.outboundBatch = {
            message: oSettings.outboundBatch.message,
            callback: function () {
                ServiceMessageHandlerHelper.defSetSearchModel({
                    searchModel: oSettings.searchModel,
                    field: {
                        name: 'status',
                        value: oSettings.outboundBatch.fromStatus,
                        element: oSettings.searchModel.eleStatus
                    }
                });
            }
        };
    }

    ServiceMessageHandlerHelper.defaultProcess(defProcessConfigure);
};


/**
 *
 * @param {object} oSettings
 *     --{boolean} keepMessage
 *     --{String} messageContainer
 *     --{object} approve
 *     --{object} reject
 *     --{object} deliveryDone
 *     --{object} processDone
 *     --{object} startProcess
 *
 */
ServiceMessageHandlerHelper.defaultProcess = function (oSettings) {
    var vm = this;
    var actionCode = getUrlVar(LABEL_ACTIONCODE);
    var uuidArray = getUrlVar(LABEL_UUIDARRAY);
    if (uuidArray) {
        uuidArray = decodeURI(uuidArray);
        ServiceMessageHandlerHelper.defaultHandleUUIDArray(uuidArray, oSettings);
    }
    if (!actionCode) {
        return;
    }
    if (!oSettings.keepMessage) {
        // clear previous message
        var container = oSettings.container ? oSettings.container : '.main.message-container';
        ServiceMessageBarHelper.removeMessageBar({
            container: $(container)
        });
    }
    if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_APPROVE)) {
        ServiceMessageHandlerHelper._defaultProcessCore(oSettings.approve, oSettings);
    }
    if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REJECT)) {
        ServiceMessageHandlerHelper._defaultProcessCore(oSettings.reject, oSettings);
    }
    if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_DELIVERY_DONE)) {
        ServiceMessageHandlerHelper._defaultProcessCore(oSettings.deliveryDone, oSettings);
    }
    if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_PROCESS_DONE)) {
        ServiceMessageHandlerHelper._defaultProcessCore(oSettings.processDone, oSettings);
    }
    if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_START_PROCESS)) {
        ServiceMessageHandlerHelper._defaultProcessCore(oSettings.startProcess, oSettings);
    }
    if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_BATCH_OUTBOUND)) {
        ServiceMessageHandlerHelper._defaultProcessCore(oSettings.outboundBatch, oSettings);
    }
    if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_BATCH_INBOUND)) {
        ServiceMessageHandlerHelper._defaultProcessCore(oSettings.inboundBatch, oSettings);
    }
    if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_SEARCH)) {
        ServiceMessageHandlerHelper._defaultProcessCore(oSettings.search, oSettings);
    }
    if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_NEW)) {
        ServiceMessageHandlerHelper._defaultProcessCore(oSettings.new, oSettings);
    }
};

ServiceMessageHandlerHelper.renderClass = function (oSettings) {
    var vm = this;
    // [Step1] Check Block condition:
    if (oSettings.involveTaskStatus === DocumentConstants.StandardPropety.ServiceFlowInvolveTask.STATUS_BLOCK_OTHER) {
        return DocumentManagerFactory.formatDisplayClass();
    }
    var actionCode = getUrlVar(LABEL_ACTIONCODE);
    if (actionCode) {
        if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_APPROVE)) {
            return ServiceMessageHandlerHelper.renderClassCore(oSettings.approve, oSettings);
        }
        if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REJECT)) {
            return ServiceMessageHandlerHelper.renderClassCore(oSettings.reject, oSettings);
        }
        if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_DELIVERY_DONE)) {
            return ServiceMessageHandlerHelper.renderClassCore(oSettings.deliveryDone, oSettings);
        }
        if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_PROCESS_DONE)) {
            return ServiceMessageHandlerHelper.renderClassCore(oSettings.processDone, oSettings);
        }
        if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_START_PROCESS)) {
            return ServiceMessageHandlerHelper.renderClassCore(oSettings.startProcess, oSettings);
        }
        if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_BATCH_OUTBOUND)) {
            return ServiceMessageHandlerHelper.renderClassCore(oSettings.outboundBatch, oSettings);
        }
        if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_BATCH_INBOUND)) {
            return ServiceMessageHandlerHelper.renderClassCore(oSettings.inboundBatch, oSettings);
        }
        if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_SEARCH)) {
            return ServiceMessageHandlerHelper.renderClassCore(oSettings.search, oSettings);
        }
        if (vm.checkActionCode(actionCode, DocumentConstants.StandardPropety.SystemDefExtServiceActionCode.ACTION_NEW)) {
            return ServiceMessageHandlerHelper.renderClassCore(oSettings.new, oSettings);
        }
    }
    // [Step3] Check focus render logic
    if (oSettings.involveTaskStatus === DocumentConstants.StandardPropety.ServiceFlowInvolveTask.STATUS_HIT) {
        return ServiceMessageHandlerHelper.renderClassCore({}, oSettings);
    }
    return oSettings.baseClass;
};

ServiceMessageHandlerHelper.renderClassCore = function (subSettings, globalSettings) {
    if (!subSettings) {
        return globalSettings.baseClass;
    }
    var _targetClass = subSettings.targetClass ? subSettings.targetClass : globalSettings.targetClass;
    var _baseClass = subSettings.baseClass ? subSettings.targetClass : globalSettings.baseClass;
    _targetClass = _targetClass ? _targetClass : 'focus-info';
    _baseClass = _baseClass ? (_baseClass + ' ' + _targetClass) : _targetClass;
    return _baseClass;
};

ServiceMessageHandlerHelper._defaultProcessCore = function (subSettings, globalSettings) {
    if (!subSettings) {
        return;
    }
    if (subSettings.message) {
        var container = globalSettings.container ? globalSettings.container : '.main.message-container';
        var msgCategory = subSettings.msgCategory ? subSettings.msgCategory : ServiceMessageBarHelper.MSG_CATEGORY.INFO;
        ServiceMessageBarHelper.generateMessageBar({
            msgCategory: msgCategory,
            message: subSettings.message,
            container: $(container),
            context: 'ACTION_'
        });
    }
    if (subSettings.callback) {
        subSettings.callback(subSettings.value);
    }
};


ServiceMessageHandlerHelper.defSetSearchModel = function (oSettings) {
    if (!oSettings.searchModel) {
        return;
    }
    var vm = oSettings.searchModel;
    if (oSettings.field && oSettings.field.value) {
        // update single field
        vm.$set(vm.content, oSettings.field.name, oSettings.field.value);
        if (oSettings.field.element) {
            $(oSettings.field.element).val(oSettings.field.value);
            $(oSettings.field.element).trigger("change");
            $(oSettings.field.element).addClass("focus-info");
        }
    }
    if (oSettings.fieldList && oSettings.fieldList.length > 0) {
        // update field array
        var i, field, len = oSettings.fieldList.length;
        for (i = 0; i < len; i++) {
            field = oSettings.fieldList[i];
            if (!field.value) {
                continue;
            }
            vm.$set(vm.content, field.name, field.value);
            if (field.element) {
                $(field.element).val(field.value);
                $(field.element).trigger("change");
                $(field.element).addClass("focus-info");
            }
        }
    }
};

ServiceMessageHandlerHelper.checkActionCode = function (actionCode, targetActionCode) {
    if (actionCode == targetActionCode) {
        return true;
    }
};

ServiceMessageHandlerHelper.filterMessageResponseByDocUUID = function (messageList, uuid) {
    if (ServiceCollectionsHelper.checkNullList(messageList)) {
        return;
    }
    var resultMessageList = [];
    ServiceCollectionsHelper.traverseList(messageList, function (messageResponse) {
        if (messageResponse.rawSEList) {
            var existedSE = ServiceCollectionsHelper.filterArray(uuid, 'uuid', messageResponse.rawSEList);
            if (existedSE) {
                messageResponse.document = existedSE;
                resultMessageList.push(messageResponse);
            }
        }
    });
    return resultMessageList;
};

/**
 * Utlity method to
 * @param {Object} oSettings
 *    --{Array} messageList
 *    --{String} uuid
 *    --{Vue} vm
 *    --{Object} parentComponent
 * @returns {Object} message response with add default 'document' attr
 */
ServiceMessageHandlerHelper.genDefEditorMessageMeta = function (oSettings) {
    var messageList = oSettings.messageList;
    var uuid = oSettings.uuid;
    var resultMessageList = ServiceMessageHandlerHelper.filterMessageResponseByDocUUID(messageList, uuid);
    if (!ServiceCollectionsHelper.checkNullList(resultMessageList)) {
        var resultMessageResponse = ServiceMessageHandlerHelper.mergeMessageListToOne(messageList);
        if (oSettings.vm && oSettings.parentComponent) {
            oSettings.vm.$set(oSettings.parentComponent, 'messageResponse', resultMessageResponse);
        }
        return resultMessageResponse;
    }
};

/**
 * Utlity method to
 * @param {Object} oSettings
 *    --{Array} messageList
 *    --{Vue} vm
 *    --{Object} parentComponent
 * @returns {Object} message response with add default 'document' attr
 */
ServiceMessageHandlerHelper.genDefListMessageMeta = function (oSettings) {
    var messageList = oSettings.messageList;
    var uuid = oSettings.uuid;
    if (!ServiceCollectionsHelper.checkNullList(messageList)) {
        if (oSettings.vm && oSettings.parentComponent) {
            oSettings.vm.$set(oSettings.parentComponent, 'messageList', messageList);
        }
        return messageList;
    }
};

/**
 * Default logic when need to show multiple messages: merge into one message
 * @param messageList
 */
ServiceMessageHandlerHelper.mergeMessageListToOne = function (messageList) {
    if (!messageList) {
        return;
    }
    // Step1: merge message list by level code firstly
    var squashMessageList = ServiceMessageHandlerHelper.mergeMessageListByLevelCode(messageList);
    // Step2: choose highest level code
    var highLevelMessageList = ServiceMessageHandlerHelper.groupHighestLevelMessageList(squashMessageList);
    return highLevelMessageList[0];
};


/**
 * Group message list by the possible highest level code
 * @param messageList
 */
ServiceMessageHandlerHelper.groupHighestLevelMessageList = function (messageList) {
    if (!messageList) {
        return;
    }
    var curLevelCode = DocumentConstants.StandardPropety.MessageLevelCode.INFO, groupMessageList = [];
    ServiceCollectionsHelper.traverseList(messageList, function (messageResponse) {
        if (messageResponse.messageLevelCode === curLevelCode) {
            groupMessageList.push(messageResponse);
        }
        if (messageResponse.messageLevelCode > curLevelCode) {
            curLevelCode = messageResponse.messageLevelCode;
            groupMessageList = [];
            groupMessageList.push(messageResponse);
        }
    });
    return groupMessageList;
};

/**
 * Merge message response list by each level code, and summary message number for each level code
 * @param messageList
 * @returns {*[]}
 */
ServiceMessageHandlerHelper.mergeMessageListByLevelCode = function (messageList) {
    var resultMessageList = [];
    if (!messageList) {
        return;
    }
    ServiceCollectionsHelper.traverseList(messageList, function (messageResponse) {
        var existMessage = ServiceCollectionsHelper.filterArray(messageResponse.messageLevelCode, "messageLevelCode", resultMessageList);
        if (!existMessage) {
            resultMessageList.push(messageResponse);
        } else {
            // In case need to merge by level code
            ServiceMessageHandlerHelper.mergeMessageResponse(existMessage, messageResponse);
        }
    });
    return resultMessageList;
};

ServiceMessageHandlerHelper.mergeMessageResponse = function (existMessage, toMergeMessage) {
    // In case the same level code, just sum number
    if (existMessage.messageLevelCode === toMergeMessage.messageLevelCode) {
        existMessage.dataNum = existMessage.dataNum + toMergeMessage.dataNum;
    }
    // In case different level code, choose higer level
    if (existMessage.messageLevelCode < toMergeMessage.messageLevelCode) {
        existMessage = toMergeMessage;
    }
};


var ServiceRightBarPanelHelper = function () {

};

ServiceRightBarPanelHelper.defTimelineMinxin = {
    data: function () {
        return {
            label: {
                rightBar: {
                    tab2Title: ' ',
                    tab1Title: ' '
                }
            },
            cache: {
                activeKey: '',
                documentList: [],
                actionCodeList: []
            },
            selectMeta: {
                iconClassMap: {},
                data: {}
            }
        };
    },

    created: function () {
        var vm = this;
        vm.initSuperSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.setI18nProperties();
        }.bind(this));
    },

    methods: {
        initSuperSubComponents: function () {
            Vue.component("right-bar-timeline", RightBarTimeline);
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            this.label.rightBar.tab1Title = $.i18n.prop('tab1Title');
            this.label.rightBar.tab2Title = $.i18n.prop('tab2Title');
        },

        updateSelectMetaData: function (key, resultList) {
            var vm = this;
            vm.$set(vm.selectMeta.data, key, resultList);
        },

        /**
         * Standard function, should be implemented in each rightBar
         * @returns {string}
         */
        getDefaultTab: function () {
            return RightBarTemplate.TABS.tab1;
        },

        /**
         * Some initial tasks should be executed before open side bar
         */
        initTasks: function () {
            if (this.$refs.rightbarTimeline && this.$refs.rightbarTimeline.initTabTitle) {
                this.$refs.rightbarTimeline.initTabTitle();
            }
        },

        /**
         * Standard function, should set active key
         * @returns {string}
         */
        setActiveKey: function (key) {
            "use strict";
            var vm = this;
            vm.$set(vm.cache, 'activeKey', key);
        },

        /**
         * Default logic to call set18n, could be executed in automatic way if "i18nPath" and "coreModelId" has been set
         * @param uuid
         */
        setI18nProperties: function (fnCallback) {
            ServiceRightBarPanelHelper.setDefI18nTemplate({vm: this, fnCallback: fnCallback});
        },

        /**
         * ! Should be implemented in sub vue class
         * @param uuid
         */
        getI18nPath: function () {

        },

        /**
         * ! Should be implemented in sub vue class
         * @param uuid
         */
        initHelpDocumentList: function (uuid) {

        }
    }
};

ServiceRightBarPanelHelper.setDefI18nTemplate = function (oSettings) {
    var vm = oSettings.vm;
    var configList = [];
    if (vm.coreModelId) {
        configList = [{
            name: vm.coreModelId,
            callback: vm.setNodeI18nPropertiesCore
        }];
    }
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: vm.i18nPath,
        commonCallback: vm.setNodeI18nPropertiesCore,
        fnCallback: oSettings.fnCallback,
        label: vm.label, vm: vm,
        configList: configList
    });
};

ServiceRightBarPanelHelper.defDocFlowMinxin = {
    data: function () {
        return {
            label: {
                rightBar: {
                    tab2Title: ' ',
                    tab1Title: ' '
                }
            },
            cache: {
                activeKey: '',
                documentList: [],
                docFlowList: []
            },
            selectMeta: {
                iconClassMap: {},
                data: {}
            }
        };
    },


    created: function () {
        var vm = this;
        vm.initSuperSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.setI18nProperties();
        }.bind(this));
    },

    methods: {
        initSuperSubComponents: function () {
            Vue.component("right-bar-doc-flow", RightBarDocFlow);
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            this.label.rightBar.tab1Title = $.i18n.prop('tab1Title');
            this.label.rightBar.tab2Title = $.i18n.prop('tab2Title');
        },

        updateSelectMetaData: function (key, resultList) {
            var vm = this;
            vm.$set(vm.selectMeta.data, key, resultList);
        },

        /**
         * Standard function, should be implemented in each rightBar
         * @returns {string}
         */
        getDefaultTab: function () {
            return RightBarTemplate.TABS.tab1;
        },

        /**
         * Some initial tasks should be executed before open side bar
         */
        initTasks: function () {
            if (this.$refs.rightbarDocFlow && this.$refs.rightbarDocFlow.initTabTitle) {
                this.$refs.rightbarDocFlow.initTabTitle();
            }
        },

        /**
         * Standard function, should set active key
         * @returns {string}
         */
        setActiveKey: function (key) {
            "use strict";
            var vm = this;
            vm.$set(vm.cache, 'activeKey', key);
        },

        /**
         * ! Should be implemented in sub vue class
         * @param uuid
         */
        setI18nProperties: function (fnCallback) {
            ServiceRightBarPanelHelper.setDefI18nTemplate({vm: this, fnCallback: fnCallback});
        },

        /**
         * ! Should be implemented in sub vue class
         * @param uuid
         */
        getI18nPath: function () {

        },

        /**
         * ! Should be implemented in sub vue class
         * @param uuid
         */
        initHelpDocumentList: function (uuid) {

        }
    }
};
/**
 * Provide default template for initHelpDocument with action code list
 * @param oSettings
 *   --{String}  getDocActionNodeListURL
 *   --{Vue} vm
 *   --{Object} selectMeta: object to contains selectMeta for help document
 *   --{Object} parentCache: parentCache to contains property: documentList
 *   --{String} uuid
 *   --{String} helpDocumentName
 *   --{Array} metaArray
 *   --{Int} documentType
 *   --{Function} errorHandle
 */
ServiceRightBarPanelHelper.initHelpDocumentWithAction = function (oSettings) {
    var vm = oSettings.vm, metaArray = oSettings.metaArray;
    var parentCache = oSettings.parentCache ? oSettings.parentCache : vm.cache;
    if (metaArray && metaArray.length > 0) {
        var dataPromiseList = [];
        ServiceCollectionsHelper.traverseList(metaArray, function (meta) {
            dataPromiseList.push(meta.data);
        });
        Promise.all(dataPromiseList).then(function (resultList) {
            ServiceCollectionsHelper.traverseListInterrupt(resultList, function (dataList, index) {
                vm.updateSelectMetaData(metaArray[index].key, dataList);
            });
            // post call back
            ServiceRightBarPanelHelper._initHelpDocumentCore(oSettings);
        }).catch(function (error) {
            oSettings.errorHandle(error);
        });
    } else {
        ServiceRightBarPanelHelper._initHelpDocumentCore(oSettings);
    }

    if (oSettings.getDocActionNodeListURL) {
        ActionCodeTab.loadActionList({
            $http: vm.$http,
            actionCodeListUrl: oSettings.getDocActionNodeListURL,
            uuid: oSettings.uuid,
            documentType: oSettings.documentType,
            errorHandle: oSettings.errorHandle,
            postHandle: function (actionCodeList) {
                vm.$set(parentCache, 'actionCodeList', actionCodeList);
            }.bind(this)
        });
    }

};

ServiceRightBarPanelHelper._initHelpDocumentCore = function (oSettings) {
    var vm = oSettings.vm, documentList = [];
    var selectMeta = oSettings.selectMeta ? oSettings.selectMeta : vm.selectMeta;
    var parentCache = oSettings.parentCache ? oSettings.parentCache : vm.cache;
    var label = oSettings.label ? oSettings.label : vm.label;
    var callback = function (rawJson) {
        documentList = DocumentLineTab.mergeToFieldDocument(rawJson, label, selectMeta);
        vm.$set(parentCache, 'documentList', documentList);
    };
    var i18nPath = vm.i18nPath ? vm.i18nPath : vm.getI18nPath();
    i18nPath = oSettings.i18nPath ? oSettings.i18nPath : i18nPath;
    DocumentLineTab.loadI18nDocument({
        name: oSettings.helpDocumentName,
        path: getI18nRootPath() + i18nPath, //path for properties files
        language: getLan(),
        callback: callback
    });
};

/**
 * Provide default template for initHelpDocument with action code list
 * @param oSettings
 *   --{String}  getDocFlowListURL
 *   --{Vue} vm
 *   --{String} uuid
 *   --{String|Array} helpDocumentName
 *   --{Array} helpDocumentConfig
 *   --{Int} documentType
 *   --{Function} errorHandle
 */
ServiceRightBarPanelHelper.initHelpDocumentWithDocFlow = function (oSettings) {
    var vm = oSettings.vm, metaArray = oSettings.metaArray;
    var parentCache = oSettings.parentCache ? oSettings.parentCache : vm.cache;
    if (metaArray && metaArray.length > 0) {
        var dataPromiseList = [];
        ServiceCollectionsHelper.traverseList(metaArray, function (meta) {
            dataPromiseList.push(meta.data);
        });
        Promise.all(dataPromiseList).then(function (resultList) {
            ServiceCollectionsHelper.traverseListInterrupt(resultList, function (dataList, index) {
                vm.updateSelectMetaData(metaArray[index].key, dataList);
            });
            // post call back
            ServiceRightBarPanelHelper._initHelpDocumentCore(oSettings);
        }).catch(function (error) {
            oSettings.errorHandle(error);
        });
    } else {
        ServiceRightBarPanelHelper._initHelpDocumentCore(oSettings);
    }

    if (oSettings.getDocFlowListURL) {
        DocMatItemFlowTab.loadDocFlowList({
            $http: vm.$http,
            docFlowListUrl: oSettings.getDocFlowListURL,
            uuid: oSettings.uuid,
            errorHandle: oSettings.errorHandle,
            postHandle: function (docFlowList) {
                vm.$set(parentCache, 'docFlowList', docFlowList);
                vm.$set(parentCache, 'activeKey', oSettings.uuid);
            }.bind(this)
        });
    }
};

ServiceRightBarPanelHelper.mergeHelpDocConfigure = function (oSettings, docConfigList) {
    var vmInstance = oSettings.vm;
    var configList = [];
    if (oSettings.helpDocumentName) {
        // in case set document name
        configList.push({
            path: vmInstance.i18nPath,
            name: oSettings.helpDocumentName
        });
    }
    if (oSettings.docConfig) {
        configList = configList.concat(oSettings.docConfig);
    }
    if (docConfigList) {
        configList = configList.concat(docConfigList);
    }
    oSettings.docConfig = configList;
    return oSettings;
};

var ServicePopBottomPanelHelper = function () {

};

ServicePopBottomPanelHelper.buildDefProcessLabel = function (label) {
    $('button.save').tooltip({title: label.saveTitle});
    $('button.edit').tooltip({title: label.editTitle});
    $('button.quickEdit').tooltip({title: label.quickEditTitle});
    $('button.nav-to-edit').tooltip({title: label.navToEditTitle});
};


ServicePopBottomPanelHelper.defControlMinxin = {
    data: function () {
        "use strict";
        return {
            label: ServiceUtilityHelper.getComLabelObject(),
            content: {},
            author: {},
            metaConfig: {
                pageCategory: DocumentConstants.StandardPropety.PageCategory.PAGE
            },
            itemEvent: undefined,
            processMode: undefined,
            postLoadData: undefined,
            coreUUID: undefined,
            postRefresh: undefined,
            postRefreshContent: undefined,
            customErrorHandle: undefined
        };
    },

    computed: {

        coreControlId: function () {
            return 'coreControl' + this.coreUUID;
        },

        eleMessageContainer: function () {
            return 'message-container-' + this.coreUUID;
        },

        eleBgSectionId: function () {
            return 'bgSection' + this.coreUUID;
        }
    },

    created: function () {
        var vm = this;
        vm.initCoreUUID();
        vm.initSubComponents();
        vm.initAuthorResourceCheck();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.setI18nPropertiesBasic();
            if (vm.initSelectConfigure) {
                vm.initSelectConfigure();
            }
        });
    },

    methods: {
        /**
         * Initial register sub component
         */
        initSubComponents: function () {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
        },

        initCoreUUID: function () {
            "use strict";
            this.coreUUID = genRamdomPostIndex();
        },

        initAuthorResourceCheck: function () {
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm: vm,
                errorHandle: ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        checkEditAccess: function () {
            "use strict";
            var vm = this;
            return vm.author && vm.author.actionCode && vm.author.actionCode.Edit === true;
        },

        saveModuleSync: function () {
            "use strict";
            var vm = this;
            var newPromise = new Promise(function (resolve) {
                if (vm.checkEditAccess()) {
                    vm.saveModule({
                        blockRefreshContent: true,
                        blockPostRefresh: true
                    }).then(function () {
                        resolve(true);
                    }).catch(function () {
                        resolve(false);
                    });
                } else {
                    // In case don't have access to execute
                    resolve(true);
                }
            });
            return newPromise;
        },

        newModuleSync: function (baseUUID) {
            "use strict";
            var vm = this;
            var newPromise = new Promise(function (resolve) {
                if (vm.checkEditAccess()) {
                    vm.newModuleService({
                        baseUUID: baseUUID
                    }).then(function () {
                        resolve(true);
                    }).catch(function () {
                        resolve(false);
                    });
                } else {
                    // In case don't have access to execute
                    resolve(true);
                }
            });
            return newPromise;

        },

        initItemQuickHandler: function (baseUUID) {
            "use strict";
            var vm = this;
            if (vm.$refs.itemQuickAction && vm.$refs.itemQuickAction.initConfig) {
                vm.$refs.itemQuickAction.initConfig({
                    processMode: vm.processMode,
                    seperatorFlag: true,
                    baseUUID: baseUUID,
                    updateHandler: vm.saveModuleSync,
                    newModuleHandler: vm.newModuleSync,
                    itemEvent: vm.itemEvent
                });
            }
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nCommonCallback(this.label);
            $('button.save').tooltip({title: this.label.saveTitle});
            $('button.nav-to-edit').tooltip({title: this.label.navToEditTitle});
        },

        setI18nPropertiesBasic: function () {
            ServiceUtilityHelper.setI18nCommonCallback(this.label);
        },

        /**
         * Logic to current message container id
         */
        getDefMessageContainer: function () {
            var targetMessageCon = $('#' + this.eleMessageContainer);
            if (targetMessageCon && targetMessageCon.length > 0) {
                return '#' + this.eleMessageContainer;
            } else {
                return '.main.message-container';
            }
        },

        checkForPage: function () {
            var pageCategory = this.metaConfig.pageCategory;
            var ConstPage = DocumentConstants.StandardPropety.PageCategory;
            return pageCategory === ConstPage.PAGE;
        },

        checkForPanel: function () {
            var pageCategory = this.metaConfig.pageCategory;
            var ConstPage = DocumentConstants.StandardPropety.PageCategory;
            return pageCategory === ConstPage.PANEL_DOWN || pageCategory === ConstPage.PANEL_RIGHT;
        },

        displayForNavToPage: function () {
            var vm = this;
            if (vm.processMode === PROCESSMODE_EDIT) {
                return DocumentManagerFactory.formatDisplayClass(this.checkForPanel());
            }
            return DocumentManagerFactory.formatDisplayClass(this.checkForPanel());
        },

        displayForPanel: function () {
            return DocumentManagerFactory.formatDisplayClass(this.checkForPanel());
        },

        displayForPage: function () {
            return DocumentManagerFactory.formatDisplayClass(this.checkForPage());
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true : undefined);
        },

        displayForEditInPanel: function () {
            var vm = this;
            return ServiceUtilityHelper.displayForCore({
                accessActionCode: this.author.actionCode.Edit,
                checkCallback: function () {
                    return vm.checkForPanel();
                }
            });
        },

        newModuleService: function (oSettings) {
            "use strict";
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("baseUUID", oSettings.baseUUID);
            return ServiceUtilityHelper.httpRequest({
                url: vm.newModuleServiceURL,
                $http: vm.$http,
                method: 'post',
                requestData: requestData,
                errorHandle: vm.customErrorHandle ? vm.customErrorHandle : vm.errorHandle,
                postHandle: function (oData) {
                    if (vm.startTabKey) {
                        // in case need to switch to tab
                        ServiceUtilityHelper.clickTab({
                            containerId: vm.coreControlId,
                            tabKey: vm.startTabKey
                        });
                    }
                    vm.setModuleToUI(oData.content);
                    if (oSettings && oSettings.blockPostRefresh === true) {
                        // in case block post refresh
                    } else {
                        if (vm.postLoadData) {
                            vm.postLoadData(oData.content);
                        }
                    }
                }.bind(this)
            });
        },


        /**
         * Main entrance to init and load data
         * @param oSettings
         *   --{function} postRefresh
         *   --{function} errorHandle
         *   --{function} validateUpdate
         *   --{Dom event} $event
         *   --{String} tabKey: startTabKey
         *   --{number} pageCategory
         */
        loadModule: function (oSettings) {
            var vm = this;
            var baseUUID = oSettings.baseUUID;
            var processMode = oSettings.processMode * 1;
            var postLoadData = oSettings.postLoadData;
            if (processMode > 0) {
                vm.$set(vm, 'processMode', processMode);
            }
            if (oSettings.postRefresh) {
                vm.$set(vm, "postRefresh", oSettings.postRefresh);
            }
            if (oSettings.postRefreshContent) {
                vm.$set(vm, "postRefreshContent", oSettings.postRefreshContent);
            }
            if (oSettings.$event) {
                vm.$set(vm, "itemEvent", oSettings.$event);
            }
            if (oSettings.validateUpdate) {
                vm.$set(vm, "validateUpdate", oSettings.validateUpdate);
            }
            if (oSettings.errorHandle) {
                vm.$set(vm, "errorHandle", oSettings.errorHandle);
            }
            if (oSettings.customErrorHandle) {
                vm.$set(vm, "customErrorHandle", oSettings.customErrorHandle);
            }
            if (oSettings.postLoadData) {
                vm.$set(vm, "postLoadData", oSettings.postLoadData);
            }
            vm.$set(vm.metaConfig, 'pageCategory', oSettings.pageCategory);
            if (vm.$refs.itemQuickAction) {
                vm.initItemQuickHandler(baseUUID);
            }
            if (vm.processMode === PROCESSMODE_NEW) {
                vm.newModuleService({baseUUID: baseUUID});
            }
            if (vm.processMode === PROCESSMODE_EDIT) {
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl: this.loadModuleEditURL,
                    viewUrl: this.loadModuleViewURL,
                    messageContainer: $(vm.getDefMessageContainer()),
                    uuid: baseUUID,
                    author: vm.author,
                    $http: vm.$http,
                    errorHandle: vm.customErrorHandle ? vm.customErrorHandle : vm.errorHandle,
                    postSet: function (content) {
                        if (vm.startTabKey) {
                            // in case need to switch to tab
                            ServiceUtilityHelper.clickTab({
                                containerId: vm.coreControlId,
                                tabKey: vm.startTabKey
                            });
                        }
                        var promiseAllList = vm.setModuleToUI(content);
                        // setModuleToUI can return promise list
                        if (promiseAllList && oSettings.promiseAllCallback) {
                            Promise.all(promiseAllList).then(function (value) {
                                oSettings.promiseAllCallback(value);
                            }).catch(function (error) {
                                vm.errorHandle(error);
                            });
                        }
                        if (postLoadData) {
                            postLoadData(content);
                        }
                        // vm._postRefresh();
                    }.bind(this)
                });
            }
        },

        saveModule: function (oSettings) {
            var vm = this;
            if (vm.validateUpdate) {
                if (vm.validateUpdate() === false) {
                    return;
                }
            }
            return ServiceUtilityHelper.httpRequest({
                url: vm.saveModuleURL,
                $http: vm.$http,
                method: 'post',
                requestData: vm.content,
                errorHandle: vm.errorHandle,
                postHandle: function (oData) {
                    $.Notification.notify('success', 'top center', vm.label.msgSaveOK, vm.label.msgSaveOKComment);
                    if (oSettings && oSettings.blockRefreshContent === true) {

                    } else {
                        vm.setModuleToUI(oData.content);
                    }
                    if (oSettings && oSettings.blockPostRefresh === true) {
                        // In case need to refresh whole parent content
                        if (vm.postRefreshContent) {
                            vm.postRefreshContent(oData.content);
                        }
                    } else {
                        // In case need to refresh whole parent page page
                        if (vm.postRefresh) {
                            vm.postRefresh(oData.content);
                        }
                    }
                }.bind(this)
            });
        },

        errorHandle: function (oData) {
            var vm = this;
            vm.$emit('errorRaise', oData);
            if (vm.customErrorHandle && typeof vm.customErrorHandle === 'function') {
                vm.customErrorHandle(oData);
            } else {
                ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                    container: $(vm.getDefMessageContainer())
                });
            }
        },

        navToEditAPI: function (oSettings) {
            var vm = this;
            if (vm.processMode === PROCESSMODE_NEW) {
                ServiceUtilityHelper.navigateToNewModule({
                    uuid: oSettings.parentNodeUUID,
                    $http: vm.$http,
                    author: vm.author,
                    editorPage: vm.editorPage,
                });
            }
            if (vm.processMode === PROCESSMODE_EDIT) {
                ServiceUtilityHelper.navigateToEditModule({
                    uuid: oSettings.uuid,
                    $http: vm.$http,
                    author: vm.author,
                    editorPage: vm.editorPage,
                    preLockURL: vm.preLockURL,
                    errorHandle: vm.errorHandle,
                    lockFailureHandle: function (oData) {
                        swal(vm.label.lockFailureMessage, oData.MSG);
                    }
                });
            }
        }

    }
};

ServicePopBottomPanelHelper.defPopButtomPanelMinxin = {
    data: function () {
        "use strict";
        return {
            label: ServiceUtilityHelper.getComLabelObject(),
            postPanel: {}
        };
    },

    created: function () {
        this.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            this.setI18nProperties();
        });
    },

    methods: {
        /**
         * Initial register sub component
         */
        initSubComponents: function () {
            "use strict";
            Vue.component("pop-bottom-panel", PopBottomPanel);
        },

        saveModule: function () {
            var vm = this;
            vm.$refs.control.saveModule();
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nCommonCallback(this.label);
        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
        },

        openRightSideBar: function (key) {
            NavigationPanelIns.openRightSideBar(RightBarTemplate.TABS.tab2, key);
        },

        controlErrorHandle: function (oData) {
            var vm = this;
            vm.$refs.popBottomPanel.hideBusyLoading();
            vm.$refs.popBottomPanel.refreshPanel();
        },

        /*
         * Common handler method for event 'changeUI', will refresh panel
         */
        changeUIHandler: function () {
            var vm = this;
            if (vm.$refs.popBottomPanel) {
                vm.$refs.popBottomPanel.refreshPanel();
            }
        },

        /**
         * Entry method to load Panel
         *
         * @param oSettings
         * @param {function} promiseAllCallback: call back after all promise list from control meet
         */
        loadPanel: function (oSettings) {
            var vm = this;
            vm.loadPanelCore(oSettings);
        },

        /**
         * Entrance to load & init panel
         * @param baseUUID
         * @param processMode
         * @param {function} postPanel: call back after panel job is done & closed
         * @param {function} promiseAllCallback: call back after all promise list from control meet
         */
        loadPanelCore: function (oSettings) {
            var vm = this;
            vm.$set(vm, 'postPanel', oSettings.postPanel);
            vm.$refs.popBottomPanel.showBusyLoading();
            vm.$refs.popBottomPanel.showPanel({
                elementClass: oSettings.elementClass,
                compensateSection: oSettings.compensateSection,
                postLoadPanel: function () {
                    ServicePopBottomPanelHelper.buildDefProcessLabel(vm.label);
                }
            });
            var $event;
            if (oSettings.$event) {
                $event = oSettings.$event.oEvent ? oSettings.$event.oEvent : oSettings.$event;
            }
            var parentControl = vm.$refs.control ? vm.$refs.control: vm;
            var promiseAllList = parentControl.loadModule({
                baseUUID: oSettings.baseUUID,
                $event: $event,
                processMode: oSettings.processMode,
                pageCategory: DocumentConstants.StandardPropety.PageCategory.PANEL_DOWN,
                errorHandle: oSettings.errorHandle,
                postRefresh: oSettings.postRefresh,
                postRefreshContent: oSettings.postRefreshContent,
                postPanel: oSettings.postPanel,
                postLoadData: function (oData) {
                    vm.$refs.popBottomPanel.hideBusyLoading();
                    setTimeout(function () {
                        vm.$refs.popBottomPanel.refreshPanel();
                    }, 500);
                },
                promiseAllCallback: oSettings.promiseAllCallback
            });
        }

    },
};


var ServiceInvolvePartyHelper = function () {

};

ServiceInvolvePartyHelper.defLabelObj = {
    partyId: '',
    partyName: '',
    refUUID: '',
    email: '',
    fax: '',
    telephone: '',
    depositBank: '',
    involvePartyTitle: '',
    taxNumber: '',
    bankAccount: '',
    postcode: '',
    cityName: '',
    townZone: '',
    subArea: '',
    streetName: '',
    houseNumber: '',
    refContactUUID: '',
    contactName: '',
    contactId: '',
    contactMobile: '',
    address: ''
};

ServiceInvolvePartyHelper.defContentObj = {
    partyRole: '',
    uuid: '',
    parentNodeUUID: '',
    partyId: '',
    partyName: '',
    refUUID: '',
    email: '',
    fax: '',
    telephone: '',
    depositBank: '',
    involvePartyTitle: '',
    taxNumber: '',
    bankAccount: '',
    postcode: '',
    cityName: '',
    townZone: '',
    subArea: '',
    streetName: '',
    houseNumber: '',
    refContactUUID: '',
    contactName: '',
    contactId: '',
    contactMobile: '',
    address: ''
};


var ServiceActionCodeNodeHelper = function () {
};

ServiceActionCodeNodeHelper.defLabelObj = {
    submit: '',
    submitTitle: '',
    submitWarnTitle: '',
    submitWarnText: '',
    submitOKTitle: '',
    submitOKComment: '',
    revokeSubmit: '',
    revokeSubmitTitle: '',
    revokeSubmitWarnTitle: '',
    revokeSubmitWarnText: '',
    revokeSubmitOKTitle: '',
    revokeSubmitOKComment: '',
    rejectApprove: '',
    rejectApproveTitle: '',
    rejectApproveWarnTitle: '',
    rejectApproveWarnText: '',
    rejectApproveOKTitle: '',
    rejectApproveOKComment: '',
    approve: '',
    approveTitle: '',
    approveWarnTitle: '',
    approveWarnText: '',
    approveOKTitle: '',
    approveOKComment: '',
    active: '',
    activeTitle: '',
    activeWarnTitle: '',
    activeWarnText: '',
    activeOKTitle: '',
    activeOKComment: '',
    archive: '',
    archiveTitle: '',
    archiveWarnTitle: '',
    archiveWarnText: '',
    archiveOKTitle: '',
    archiveOKComment: '',
    countApprove: '',
    countApproveTitle: '',
    countApproveWarnTitle: '',
    countApproveWarnText: '',
    countApproveOKTitle: '',
    countApproveOKComment: '',
    setDeliveryCompleteWarnTitle: '',
    setDeliveryCompleteWarnText: '',
    setDeliveryCompleteOKTitle: '',
    setDeliveryCompleteOKComment: '',
    setCompleteWarnTitle: '',
    setCompleteWarnText: '',
    setCompleteOKTitle: '',
    setCompleteOKComment: '',
};

ServiceActionCodeNodeHelper.getDefLabel = function () {
    return ServiceActionCodeNodeHelper.defLabelObj;

};

ServiceActionCodeNodeHelper.setI18nActionNodeWrapper = function (i18n) {
    ServiceActionCodeNodeHelper.setI18nActionNode(i18n, ServiceActionCodeNodeHelper.setI18nProperties);
};

ServiceActionCodeNodeHelper.setI18nActionNode = function (i18n, callback) {
    return i18n.properties({
        name: 'DocActionNode', //properties file name
        path: getI18nRootPath() + 'foundation/', //path for properties files
        mode: 'map', //Using map mode to consume properties files
        cache: true,
        language: getLan(),
        callback: callback
    });
};

ServiceActionCodeNodeHelper.setI18nProperties = function (labelObj) {

    ServiceUtilityHelper.setI18nReflective(labelObj, $.i18n.prop, true);

    $("button.approve").tooltip({title: labelObj.approveTitle});
    $("button.countApprove").tooltip({title: labelObj.countApproveTitle});
    $("button.rejectApprove").tooltip({title: labelObj.rejectApproveTitle});
    $("button.submit").tooltip({title: labelObj.submitTitle});
    $("button.revokeSubmit").tooltip({title: labelObj.revokeSubmitTitle});
    $("button.setComplete").tooltip({title: labelObj.setCompleteTitle});
};


/**
 * Service Extension helper is used to manage the extension page
 * @constructor
 */
var ServiceExtensionHelper = function () {
};

ServiceExtensionHelper.constants = {
    loadPageURL: "../serExtendPageSetting/loadModuleViewById.html"
};

ServiceExtensionHelper.prototype.getResourceFromCache = function () {
    "use strict";
    if (sessionStorage) {
        var str = sessionStorage.getItem('extensionCache');
        if (str) {
            return JSON.parse(str);
        }
    }

};

ServiceExtensionHelper.prototype.setResourceToCache = function (values) {
    "use strict";
    if (sessionStorage) {
        sessionStorage.setItem('extensionCache', JSON.stringify(values));
    }
};


/**
 * Load all the system wide configure category list
 * @param oSettings
 * @returns {Promise$2|*}
 */
ServiceExtensionHelper.prototype.loadResourcePromise = function (oSettings) {
    "use strict";
    return new Promise(function (resolve, reject) {
        var resourceInCache = this.getResourceFromCache();
        if (resourceInCache) {
            resolve();
            return;
        } else {
            resolve();
            return;
        }
    }.bind(this));
};

/**
 * Load all the system wide configure category list
 * @param oSettings
 * @returns {Promise$2|*}
 */
ServiceExtensionHelper.prototype.loadResByPageIdPromise = function (oSettings) {
    "use strict";
    var vm = this;
    return new Promise(function (resolve, reject) {
        var extensionResourcePromise = this.loadResourcePromise(oSettings);
        extensionResourcePromise.then(function (extensionResource) {
            if (extensionResource && extensionResource[oSettings.id]) {
                resolve(extensionResource[oSettings.id]);
            } else {
                oSettings.$http.get(ServiceExtensionHelper.constants.loadPageURL + "?id=" + oSettings.id).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        reject(oData);
                    }
                    extensionResource = extensionResource ? extensionResource : {};
                    extensionResource[oSettings.id] = oData.content;
                    vm.setResourceToCache(extensionResource);
                    resolve(extensionResource[oSettings.id]);
                });
            }
        });
    }.bind(this));
};

/**
 * Get the section
 * @param oSettings
 * @returns {Promise$2|*}
 */
ServiceExtensionHelper.prototype.loadSectionFieldsList = function (oSettings) {
    "use strict";
    return new Promise(function (resolve, reject) {
        var extendPagePromise = this.loadResByPageIdPromise(oSettings);
        extendPagePromise.then(function (extendPageResource) {
            var serExtendUIControlSetUIModelList = ServiceExtensionHelper.filterSecUIControlList(extendPageResource, oSettings);
            var fieldConfigureList = ServiceExtensionHelper.convertUIControlList(serExtendUIControlSetUIModelList);
            resolve(fieldConfigureList);
        }).catch(function (e) {
            reject(e);
        });
    }.bind(this));
};

/**
 * Filter out the section's UI control list inside whole page
 * @param oSettings
 * @returns {Promise$2|*}
 */
ServiceExtensionHelper.filterSecUIControlList = function (extendPageResource, oSettings) {
    "use strict";
    if (!extendPageResource || !extendPageResource.serExtendPageSectionUIModelList) {
        return;
    }
    var resultList;
    extendPageResource.serExtendPageSectionUIModelList.forEach(function (serExtendPageSectionServiceUIModel) {
        if (serExtendPageSectionServiceUIModel.serExtendPageSectionUIModel.id === oSettings.sectionId) {
            resultList = serExtendPageSectionServiceUIModel.serExtendUIControlSetUIModelList;
        }
    });
    return resultList;
};

/**
 * Main Entrance to process extends fields
 * @param oSettings
 * @returns {Promise$2|*}
 */
ServiceExtensionHelper.prototype.processExtendFieldsWrapper = function (oSettings, extendMeta, serviceExtendUIModelList) {
    "use strict";
    return new Promise(function (resolve, reject) {
        var extendPagePromise = this.loadResByPageIdPromise(oSettings);
        extendPagePromise.then(function (extendPageResource) {
            var i = 0, len, sectionId, keys = Object.keys(extendMeta);
            for (i = 0, len = keys.length; i < len; i++) {
                sectionId = keys[i];
                oSettings.sectionId = sectionId;
                var serExtendUIControlSetUIModelList = ServiceExtensionHelper.filterSecUIControlList(extendPageResource, oSettings);
                var fieldConfigureList = ServiceExtensionHelper.convertUIControlList(serExtendUIControlSetUIModelList);
                extendMeta[sectionId] = fieldConfigureList;
                ServiceExtensionHelper.mergeExtendUIModelList(serviceExtendUIModelList, fieldConfigureList);
            }
            resolve(extendMeta);
        }).catch(function (e) {
            reject(e);
        });
    }.bind(this));
};

/**
 * Filter out the section's UI control list inside whole page
 * @param oSettings
 * @returns {Promise$2|*}
 */
ServiceExtensionHelper.convertUIControlList = function (serExtendUIControlSetUIModelList) {
    "use strict";
    if (!serExtendUIControlSetUIModelList) {
        return;
    }
    var fieldConfigureList = serExtendUIControlSetUIModelList.map(function (serExtendUIControlSetUIModel) {
        return {
            "fieldName": serExtendUIControlSetUIModel.fieldName,
            "fieldType": serExtendUIControlSetUIModel.fieldType,
            "inputControlType": serExtendUIControlSetUIModel.inputControlType,
            "rowNumber": serExtendUIControlSetUIModel.rowNumber,
            "customI18nFlag": true,
            "refFieldUUID": serExtendUIControlSetUIModel.refFieldUUID,
            "sectionId": serExtendUIControlSetUIModel.sectionId,
            "labelValue": serExtendUIControlSetUIModel.labelValue ? serExtendUIControlSetUIModel.labelValue : serExtendUIControlSetUIModel.fieldName,
            "settings": {
                refMetaCodeUUID: serExtendUIControlSetUIModel.refMetaCodeUUID
                // getMetaDataUrl:serExtendUIControlSetUIModel.getMetaDataUrl

            }
        };
    });
    return fieldConfigureList;
};


/**
 * Filter out the section's UI control list inside whole page
 * @param oSettings
 * @returns {Promise$2|*}
 */
ServiceExtensionHelper.mergeExtendUIModelList = function (serviceExtendUIModelList, fieldConfigureList) {
    "use strict";
    if (!serviceExtendUIModelList || !fieldConfigureList) {
        return;
    }
    serviceExtendUIModelList.forEach(function (serviceExtendUIModel) {
        var fieldConfigure = ServiceCollectionsHelper.filterArray(serviceExtendUIModel.refFieldUUID, 'refFieldUUID', fieldConfigureList);
        if (fieldConfigure) {
            fieldConfigure.serviceExtendUIModel = serviceExtendUIModel;
        }
    });
};


var ServiceDisplayHelper = function () {
};

ServiceDisplayHelper.FORMAT_CLASS = {
    ACTIVE_TODO: "active-todo"
};

ServiceDisplayHelper.formatActiveToDoClass = function (flag) {
    "use strict";
    if (flag && flag === true) {
        return ServiceDisplayHelper.FORMAT_CLASS.ACTIVE_TODO;
    }
};

/**
 * String utility class
 * @constructor
 */
var ServiceStringHelper = function () {

};

/**
 * Set string header to Upper case
 * @param rawStr
 */
ServiceStringHelper.headerToUpperCase = function (rawStr) {
    'use strict';
    if (!rawStr || rawStr === '') {
        return;
    }
    return rawStr.slice(0, 1).toUpperCase() + rawStr.slice(1);
};

/**
 * Set string header to Lower case
 * @param rawStr
 */
ServiceStringHelper.headerToLowerCase = function (rawStr) {
    'use strict';
    if (!rawStr || rawStr === '') {
        return;
    }
    return rawStr.slice(0, 1).toLowerCase() + rawStr.slice(1);
};

/**
 * Split string into array by space(multiple space)
 * @param rawStr
 * @returns {string[]}
 */
ServiceStringHelper.splitBySpace = function (rawStr) {
    'use strict';
    if (!rawStr || rawStr === '') {
        return;
    }
    return rawStr.trim().split(/\s+/);
};

/**
 * Formate String with multiple parameters
 * @param templateStr
 * @param paras
 * @return {*}
 */
ServiceStringHelper.formatStrings = function (templateStr, paras) {
    'use strict';
    if (!templateStr || templateStr === '') {
        return;
    }
    var formatStr = templateStr;
    ServiceCollectionsHelper.traverseListInterrupt(paras, function(para, index) {
        formatStr = formatStr.replace("[%S]", para);
    });
    return formatStr;
};

/**
 * Equal 2 strings ignoring the case
 * @param str1
 * @param str2
 * @return {boolean}
 */
ServiceStringHelper.isEqualIgnoreCase = function (str1, str2) {
    'use strict';
    if (!str1 || !str2) {
        return;
    }
    return str1.toUpperCase() === str2.toUpperCase();
};

ServiceStringHelper.isEmpty = function (rawStr) {
    'use strict';
    if (!rawStr || rawStr === '') {
        return true;
    }
    if (typeof rawStr !== 'string') {
        return true; // in case it is object
    }
    return undefined;
};

ServiceStringHelper.isEmptyExtend = function (rawStr) {
    'use strict';
    var emptyCore = ServiceStringHelper.isEmpty(rawStr);
    if (emptyCore === true) {
        return true;
    }
    if (rawStr === ServiceStringHelper.constants.ZEROSTRING) {
        return true;
    }
    return undefined;
};

ServiceStringHelper.equalIgnoreCase = function (strA, strB) {
    'use strict';
    if (!strA || !strB) {
        return undefined;
    }
    if (strA.toLowerCase() === strB.toLowerCase()) {
        return true;
    }
    return undefined;
};

/**
 * Utility Method to handle String content for long length
 * @param rawStr
 * @param maxLength: specify max length, default value is 15.
 * @returns {string}
 */
ServiceStringHelper.handleContentByLength = function (rawStr, maxLength) {
    'use strict';
    var locMaxLength = (maxLength && maxLength > 0) ? maxLength : 15;
    if (rawStr && rawStr.length > locMaxLength) {
        rawStr = rawStr.slice(0, locMaxLength) + "...";
    }
    return rawStr;
};

ServiceStringHelper.containsSubStr = function (rawStr, subStr) {
    if (!rawStr || !subStr) {
        return;
    }
    return rawStr.indexOf(subStr) !== -1;
};

ServiceStringHelper.endWithSubStr = function (rawStr, subStr) {
    if (!rawStr || !subStr) {
        return;
    }
    var length = rawStr.length;
    var subLength = subStr.length;
    var subIndex = rawStr.indexOf(subStr);
    if (subIndex === -1) {
        return;
    }
    return subIndex === length - subLength;
};

ServiceStringHelper.startWithSubStr = function (rawStr, subStr) {
    if (!ServiceStringHelper.containsSubStr(rawStr, subStr)) {
        return;
    }
    return rawStr.indexOf(subStr) === 0;
};


ServiceStringHelper.constants = {
    ZEROSTRING: '0'
};

var ServiceDataPickerHelper = function () {

};

/**
 *
 * @param {Object}oSettings
 *     -- {DOM element}: element
 *     -- {Vue} vue
 *     -- {Object} content: parent content of changed field
 *     -- {String}: fieldName
 */
ServiceDataPickerHelper.initDataPicker = function (oSettings) {
    $(oSettings.element).datepicker({
        language: "zh-CN",
        autoclose: true,
        clearBtn: true,
        todayBtn: true,
        format: "yyyy-mm-dd"
    });

    $(oSettings.element).datepicker().on(
        'changeDate', function (oEvent) {
            var val = $(oSettings.element).val();
            oSettings.content[oSettings.fieldName] = val;
            // oSettings.vue.$set(oSettings.content, oSettings.fieldName, val);
        }.bind(this));
};

ServiceDataPickerHelper.initDatePicker = function (oSettings) {
    $(oSettings.element).datepicker({
        language: "zh-CN",
        autoclose: true,
        clearBtn: true,
        todayBtn: true,
        format: "yyyy-mm-dd"
    });

    $(oSettings.element).datepicker().on(
        'changeDate', function (oEvent) {
            var val = $(oSettings.element).val();
            if (oSettings.callBack) {
                oSettings.callBack(val);
            }
        }.bind(this));
};

/**
 * Generate the DateTimeValue ('"yyyy-MM-dd HH:mm"') by combine date value ('yyyy-mm-dd') and time value ('HH:mm') together
 * @param date
 * @param time
 */
ServiceDataPickerHelper.genDateTime = function (date, time) {
    if (date) {
        if (time) {
            return date + ' ' + time;
        } else {
            return date + ' ' + getCurrentTime();
        }
    }
};


ServiceDataPickerHelper.splitDatetime = function (datetime) {
    var datetimeArray = ServiceStringHelper.splitBySpace(datetime);
    if (datetimeArray && datetimeArray.length > 1) {
        return {
            date: datetimeArray[0],
            time: datetimeArray[1]
        };
    }
};


/**
 * Service UI Meta, used to manage the UI Meta in Service UI Model
 * @constructor
 */
var ServiceUIMetaProxy = function () {

};

ServiceUIMetaProxy.filterKeyStructure = function (serviceUIMeta, key) {
    if (!serviceUIMeta || !serviceUIMeta.keyValueList || !key) {
        return;
    }
    var filterList = serviceUIMeta.keyValueList.filter(function (tempStructure) {
        return key === tempStructure.keyName;
    });
    if (!filterList) {
        return;
    }
    return filterList[0];
};

ServiceUIMetaProxy.filterKeyValue = function (serviceUIMeta, key) {
    var keyStructure = ServiceUIMetaProxy.filterKeyStructure(serviceUIMeta, key);
    if (!keyStructure) {
        return;
    }
    return keyStructure.keyValue;
};

ServiceUIMetaProxy.fillKeyValue = function (serviceUIMeta, key, keyValue) {
    if (!serviceUIMeta) {
        serviceUIMeta = {
            keyValueList: []
        };
    }
    serviceUIMeta.push({
        keyName: key,
        keyValue: keyValue
    });
    return serviceUIMeta;
};

/**
 * System Standard metadata, please refer to back-end resources in platform.foundation.logicManager package
 * @constructor
 */
var SystemStandrdMetadataProxy = function () {

};

SystemStandrdMetadataProxy.FIELDTYPE = {
    int: 'int',
    double: 'double',
    Date: 'Date'
};

SystemStandrdMetadataProxy.getLogicOperatorIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.StandardPropety.StandardLogicOperator.AND, iconClass: 'ion-close content-lightblue'},
        {id: DocumentConstants.StandardPropety.StandardLogicOperator.OR, iconClass: 'ion-plus content-lightblue'}
    ];
};

SystemStandrdMetadataProxy.formatLogicOperatorExpress = function (logicOperator, operatorExpressMap) {
    "use strict";
    var express = ServiceCollectionsHelper.filterArray(logicOperator, 'id', operatorExpressMap);
    return express;
};

SystemStandrdMetadataProxy.formatLogicOperatorIconClass = function (logicOperator) {
    "use strict";
    var logicOperatorIconArray = SystemStandrdMetadataProxy.getLogicOperatorIconArray();
    var $element = ServiceCollectionsHelper.filterArray(logicOperator, 'id', logicOperatorIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

SystemStandrdMetadataProxy.formatLogicOperator = function (logicOperator) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(logicOperator, SystemStandrdMetadataProxy.getLogicOperatorIconArray(), true);
    return $element;
};

SystemStandrdMetadataProxy.getHideFlagIconArray = function () {
    "use strict";
    return [
        {
            id: DocumentConstants.StandardPropety.SystemHideFlag.HIDE_FLAG,
            iconClass: 'md md-visibility-off content-darkblue'
        },
        {
            id: DocumentConstants.StandardPropety.SystemHideFlag.UNHIDE_FLAG,
            iconClass: 'md md-visibility content-lightblue'
        }
    ];
};

SystemStandrdMetadataProxy.formatHideFlagIconClass = function (hideFlag) {
    "use strict";
    var hideFlagIconArray = SystemStandrdMetadataProxy.getHideFlagIconArray();
    var $element = ServiceCollectionsHelper.filterArray(hideFlag, 'id', hideFlagIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

SystemStandrdMetadataProxy.formatHideFlag = function (hideFlag) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(hideFlag, SystemStandrdMetadataProxy.getHideFlagIconArray(), true);
    return $element;
};

SystemStandrdMetadataProxy.getKeyResourceIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.StandardPropety.KeyFlag.KEY, iconClass: 'fa fa-key content-red'},
        {id: DocumentConstants.StandardPropety.KeyFlag.NON_KEY, iconClass: 'md md-remove-circle-outline content-grey'}
    ];
};

SystemStandrdMetadataProxy.formatKeyResourceIconClass = function (keyFlag) {
    "use strict";
    var logicOperatorIconArray = SystemStandrdMetadataProxy.getKeyResourceIconArray();
    var $element = ServiceCollectionsHelper.filterArray(keyFlag, 'id', logicOperatorIconArray);
    return $element.iconClass;
};

SystemStandrdMetadataProxy.formatKeyResource = function (keyFlag) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(keyFlag, SystemStandrdMetadataProxy.getKeyResourceIconArray(), true);
    return $element;
};

SystemStandrdMetadataProxy.getDocFlowDirectionIconArray = function () {
    "use strict";
    return [
        {
            id: DocumentConstants.StandardPropety.StandardDocFlowDirection.DIREC_PREV,
            iconClass: 'fa fa-level-up content-green'
        },
        {
            id: DocumentConstants.StandardPropety.StandardDocFlowDirection.DIREC_NEXT,
            iconClass: 'fa fa-level-down content-green'
        },
        {
            id: DocumentConstants.StandardPropety.StandardDocFlowDirection.DIREC_PREV_PROF,
            iconClass: 'fa fa-level-up content-darkblue2'
        },
        {
            id: DocumentConstants.StandardPropety.StandardDocFlowDirection.DIREC_NEXT_PROF,
            iconClass: 'fa fa-level-down content-darkblue2'
        },
        {
            id: DocumentConstants.StandardPropety.StandardDocFlowDirection.RESERVED,
            iconClass: 'md md-lock-outline content-pink'
        }
    ];
};

SystemStandrdMetadataProxy.getDocFlowDirectionPrefix = function () {
    "use strict";
    return [
        {id: DocumentConstants.StandardPropety.StandardDocFlowDirection.DIREC_PREV, prefix: 'prev'},
        {id: DocumentConstants.StandardPropety.StandardDocFlowDirection.DIREC_NEXT, prefix: 'next'},
        {id: DocumentConstants.StandardPropety.StandardDocFlowDirection.DIREC_PREV_PROF, prefix: 'prevProf'},
        {id: DocumentConstants.StandardPropety.StandardDocFlowDirection.DIREC_NEXT_PROF, prefix: 'nextProf'},
        {id: DocumentConstants.StandardPropety.StandardDocFlowDirection.RESERVED, prefix: 'reserved'}
    ];
};

SystemStandrdMetadataProxy.formatDocFlowDirectionIconClass = function (docFlowDirection) {
    "use strict";
    var docFlowDirectionIconArray = SystemStandrdMetadataProxy.getDocFlowDirectionIconArray();
    var $element = ServiceCollectionsHelper.filterArray(docFlowDirection, 'id', docFlowDirectionIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

SystemStandrdMetadataProxy.formatDocFlowDirectionPrefix = function (docFlowDirection) {
    "use strict";
    var docFlowDirectionPrefixArray = SystemStandrdMetadataProxy.getDocFlowDirectionPrefix();
    var $element = ServiceCollectionsHelper.filterArray(docFlowDirection, 'id', docFlowDirectionPrefixArray);
    if ($element) {
        return $element.prefix;
    }
};

SystemStandrdMetadataProxy.formatDocFlowDirection = function (docFlowDirection) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(docFlowDirection, SystemStandrdMetadataProxy.getDocFlowDirectionIconArray(), true);
    return $element;
};


/**
 * Constants method: Generate the array for mapping 'default priority' and its icon
 * @returns {*[]}
 */
SystemStandrdMetadataProxy.getDefaultPrirityCodeIconArray = function () {
    "use strict";
    return [{
        id: DocumentConstants.Document.priorityCode.LOW, iconClass: 'fa fa-angle-down content-green'
    }, {
        id: DocumentConstants.Document.priorityCode.MIDDLE, iconClass: 'fa fa-angle-up content-orange'
    }, {
        id: DocumentConstants.Document.priorityCode.HIGH, iconClass: 'fa fa-angle-double-up content-red'
    }, {
        id: DocumentConstants.Document.priorityCode.VERYHIGH, iconClass: 'fa fa-warning content-red'
    }];
};

SystemStandrdMetadataProxy.formatDefaultPrirityCode = function (priorityCode) {
    "use strict";
    var $element = ServiceUtilityHelper.formatSelectWithIcon(priorityCode, SystemStandrdMetadataProxy.getDefaultPrirityCodeIconArray(), true);
    return $element;
};


SystemStandrdMetadataProxy.getKeyValueOperatorIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.StandardPropety.ValueOperator.OPERATOR_EQUAL, iconClass: 'fa fa-key content-red'},
        {id: DocumentConstants.StandardPropety.ValueOperator.OPERATOR_BETWEEN, iconClass: 'fa fa-key content-red'},
        {id: DocumentConstants.StandardPropety.ValueOperator.OPERATOR_NOT_BETWEEN, iconClass: 'fa fa-key content-red'},
        {id: DocumentConstants.StandardPropety.ValueOperator.OPERATOR_GREATER_EQ, iconClass: 'fa fa-key content-red'},
        {id: DocumentConstants.StandardPropety.ValueOperator.OPERATOR_GREATER, iconClass: 'fa fa-key content-red'},
        {id: DocumentConstants.StandardPropety.ValueOperator.OPERATOR_LESS_EQ, iconClass: 'fa fa-key content-red'},
        {id: DocumentConstants.StandardPropety.ValueOperator.OPERATOR_LESS, iconClass: 'fa fa-key content-red'},
        {id: DocumentConstants.StandardPropety.ValueOperator.OPERATOR_NOT_EQ, iconClass: 'fa fa-key content-red'},
        {
            id: DocumentConstants.StandardPropety.ValueOperator.OPERATOR_CONTAINS,
            iconClass: 'nmd nmd-picture-in-picture content-lightblue'
        }
    ];
};

SystemStandrdMetadataProxy.formatKeyResourceIconClass = function (keyFlag) {
    "use strict";
    var logicOperatorIconArray = SystemStandrdMetadataProxy.getKeyResourceIconArray();
    var $element = ServiceCollectionsHelper.filterArray(keyFlag, 'id', logicOperatorIconArray);
    return $element.iconClass;
};

SystemStandrdMetadataProxy.formatKeyResource = function (keyFlag) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(keyFlag, SystemStandrdMetadataProxy.getKeyResourceIconArray(), true);
    return $element;
};


/**
 * Constants method: Generate the array for mapping 'default priority' and its icon
 * @returns {*[]}
 */
SystemStandrdMetadataProxy.getDefaultSwitchIconArray = function () {
    "use strict";
    return [{
        id: DocumentConstants.StandardPropety.Switch.ON, iconClass: 'ion-checkmark-round content-green'
    }, {
        id: DocumentConstants.StandardPropety.Switch.OFF, iconClass: 'ion-close-circled content-grey'
    }, {
        id: DocumentConstants.StandardPropety.Switch.INITIAL, iconClass: 'fa fa-angle-double-up content-red'
    }, {
        id: DocumentConstants.StandardPropety.Switch.DELETE, iconClass: 'fa fa-warning content-red'
    }];
};

SystemStandrdMetadataProxy.formatDefaultSwitchCode = function (switchCode) {
    "use strict";
    var $element = ServiceUtilityHelper.formatSelectWithIcon(switchCode, SystemStandrdMetadataProxy.getDefaultSwitchIconArray(), true);
    return $element;
};

SystemStandrdMetadataProxy.formatSwitchClass = function (itemSwitch) {
    var switchIconArray = SystemStandrdMetadataProxy.getDefaultSwitchIconArray();
    var $element = ServiceCollectionsHelper.filterArray(itemSwitch, 'id', switchIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

/**
 * Constants method: Generate the array for mapping 'default priority' and its icon
 * @returns {*[]}
 */
SystemStandrdMetadataProxy.getDefaultSystemCategoryIconArray = function () {
    "use strict";
    return [{
        id: DocumentConstants.StandardPropety.SystemCategory.SYSTEM_STANDARD, iconClass: 'fa fa-gear content-darkblue'
    }, {
        id: DocumentConstants.StandardPropety.SystemCategory.SELF_DEFINED, iconClass: 'md md-portrait content-lightblue'
    }];
};

SystemStandrdMetadataProxy.formatDefaultSystemCategory = function (systemCategory) {
    "use strict";
    var $element = ServiceUtilityHelper.formatSelectWithIcon(systemCategory, SystemStandrdMetadataProxy.getDefaultSystemCategoryIconArray(), true);
    return $element;
};

SystemStandrdMetadataProxy.formatSystemCategoryClass = function (systemCategory) {
    var systemCategoryIconArray = SystemStandrdMetadataProxy.getDefaultSystemCategoryIconArray();
    var $element = ServiceCollectionsHelper.filterArray(systemCategory, 'id', systemCategoryIconArray);
    if ($element) {
        return $element.iconClass;
    }
};


var ServiceValidatorHelper = function () {

};

ServiceValidatorHelper.DEF_VALID_TYPE = {
    NON_EMPTY: 1,
    POSITIVE: 2,
    NEGATIVE: 3,
    NON_EMPTY_ARRAY: 4,
    NOT_NEGATIVE: 5,
    NOT_POSITIVE: 6,
    BOOLEAN_TRUE: 7,
    HTTP_RESPONSE: 8
};


ServiceValidatorHelper.VALID_VALUE_TYPE = {
    NUMBER: 1,
    STRING: 2,
    ARRAY: 3,
    BOOLEAN: 4,
    OTHERS: 99
};

ServiceValidatorHelper.label = {
    errorPostNotEmpty: '',
    errorPostPositive: '',
    errorPostNegative: '',
    errorPostNotEmptyArray: '',
    errorPostNotNegative: '',
    errorPostNotPositive: ''
};

/**
 * Constant method: mapping valid type to value type
 * @param validType
 */
ServiceValidatorHelper.mapValidToValueType = function (validType) {
    if (validType === ServiceValidatorHelper.DEF_VALID_TYPE.POSITIVE ||
        validType === ServiceValidatorHelper.DEF_VALID_TYPE.NEGATIVE ||
        validType === ServiceValidatorHelper.DEF_VALID_TYPE.NOT_POSITIVE ||
        validType === ServiceValidatorHelper.DEF_VALID_TYPE.NOT_NEGATIVE) {
        return ServiceValidatorHelper.VALID_VALUE_TYPE.NUMBER;
    }
    if (validType === ServiceValidatorHelper.DEF_VALID_TYPE.BOOLEAN_TRUE) {
        return ServiceValidatorHelper.VALID_VALUE_TYPE.BOOLEAN;
    }
    if (validType === ServiceValidatorHelper.DEF_VALID_TYPE.NON_EMPTY_ARRAY) {
        return ServiceValidatorHelper.VALID_VALUE_TYPE.ARRAY;
    }
    if (validType === ServiceValidatorHelper.DEF_VALID_TYPE.NON_EMPTY) {
        return ServiceValidatorHelper.VALID_VALUE_TYPE.STRING;
    }
    return ServiceValidatorHelper.VALID_VALUE_TYPE.OTHERS;
};
/**
 * Helper Class for validating values
 * @param {object} oSettings
 *         --{Dom element} messageContainer
 *         --{Array<Dom element>} messageContainerArray
 *         --{Array} configList *
 *              --{object} validType
 *                   --{enum} defType
 *               --{Dom element} valueContainer
 *               --{string} errorMessage
 *               --{string} errorMessagePrefix
 */
ServiceValidatorHelper.defaultValidateCheckArray = function (oSettings) {
    "use strict";
    var i = 0, oSet = {};
    if (oSettings.configList && oSettings.configList.length > 0) {
        for (i = 0; i < oSettings.configList.length; i++) {
            oSet = oSettings.configList[i];
            if (!oSet.messageContainer) {
                oSet.messageContainer = oSettings.messageContainer;
            }
            if (!oSet.messageContainerArray) {
                oSet.messageContainerArray = oSettings.messageContainerArray;
            }
            var tmpResult = ServiceValidatorHelper.defaultValidateCheck(oSet);
            if (tmpResult === false) {
                return false;
            }
        }
    }
    return true;
};

/**
 * Get validate check result array
 * @param oSettings
 * @return {*[]}
 */
ServiceValidatorHelper.getDefValidateCheckArray = function (oSettings) {
    "use strict";
    var i = 0, oSet = {}, resultArray = [];
    if (oSettings.configList && oSettings.configList.length > 0) {
        for (i = 0; i < oSettings.configList.length; i++) {
            oSet = oSettings.configList[i];
            var tmpResult = ServiceValidatorHelper.defaultValidateCheck(oSet);
            if (tmpResult === false) {
                resultArray.push(oSet);
            }
        }
    }
    return resultArray;
};


/**
 * Helper Class for validating values
 * @param {object} oSettings
 *         --{object} validType
 *             --{enum} defType
 *         --{Dom element} valueContainer
 *         --{string} errorMessage
 *         --{Dom element} messageContainer
 */
ServiceValidatorHelper.defaultValidateCheck = function (oSettings) {
    "use strict";
    var checkResult = ServiceValidatorHelper._checkLogicCore(oSettings);
    var $valueContainer = ServiceValidatorHelper._getValueContainer(oSettings);
    if (checkResult === false) {
        // should raise error
        ServiceValidatorHelper.throwErrorMessageWrap(oSettings, $valueContainer);
        return false;
    } else {
        // should clear error
        ServiceValidatorHelper._clearMessageWrap(oSettings, $valueContainer);
        return true;
    }
};


/**
 * [Internal] Validate check core logic, and return the problematic configures
 * @param oSettings
 * @return {array}
 * @private
 */
ServiceValidatorHelper._checkLogicCore = function (oSettings) {
    "use strict";
    if (oSettings.validFunction && typeof oSettings.validFunction === 'function') {
        return oSettings.validFunction();
    }
    if (oSettings.validType && oSettings.validType.defType) {
        var valueType = ServiceValidatorHelper.mapValidToValueType(oSettings.validType.defType);
        if (valueType === ServiceValidatorHelper.VALID_VALUE_TYPE.NUMBER) {
            // in case for NUMBER value
            var numberValue = ServiceValidatorHelper._getNumberValue(oSettings.value);
            if (numberValue || numberValue === 0) {
                if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.POSITIVE) {
                    return numberValue > 0;
                }
                if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.NOT_NEGATIVE) {
                    return numberValue >= 0;
                }
                if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.NEGATIVE) {
                    return numberValue < 0;
                }
                if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.NOT_POSITIVE) {
                    return numberValue <= 0;
                }
            }
        }
        if (valueType === ServiceValidatorHelper.VALID_VALUE_TYPE.STRING) {
            // in case for STRING value
            if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.NON_EMPTY) {
                return !ServiceUtilityHelper.checkEmptyValue(oSettings.value);
            }
        }
        if (valueType === ServiceValidatorHelper.VALID_VALUE_TYPE.ARRAY) {
            // in case for ARRAY value
            if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.NON_EMPTY_ARRAY) {
                if (!oSettings.value || oSettings.value.length === 0) {
                    return false;
                }
            }
        }
        if (valueType === ServiceValidatorHelper.VALID_VALUE_TYPE.BOOLEAN) {
            // in case for ARRAY value
            if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.BOOLEAN_TRUE) {
                return oSettings.value === true;
            }
        }
        if (valueType === ServiceValidatorHelper.VALID_VALUE_TYPE.OTHERS) {
            // in case for other unkown tupe
            if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.HTTP_RESPONSE) {
                var response = ServiceUtilityHelper.checkHTTPResponseCode(oSettings.value.errorCode);
                return response === true;
            }
        }
    }
};

ServiceValidatorHelper._getNumberValue = function (rawValue) {
    if (typeof rawValue === 'number') {
        return rawValue;
    }
    if (!isNaN(rawValue)) {
        return rawValue * 1;
    }
};

/**
 *
 * @param {Object} oSettings
 *     -- {String} message
 *     -- {DOM} messageContainer
 *     -- {String} context
 * @param $valueContainer
 */
ServiceValidatorHelper.throwErrorMessageWrap = function (oSettings, $valueContainer) {
    "use strict";
    if (checkArrayFlag($valueContainer)) {
        if ($valueContainer.length > 0) {
            $valueContainer.forEach(function (item) {
                item.toggleClass("parsley-error", true);
            });
        }
    } else {
        if ($valueContainer) {
            $valueContainer.toggleClass("parsley-error", true);
        }
    }
    ServiceValidatorHelper._conbineErrorMessage(oSettings, function (errorMessage) {
        if (oSettings.messageContainer) {
            ServiceMessageBarHelper.generateMessageBar({
                msgCategory: ServiceMessageBarHelper.MSG_CATEGORY.ERROR,
                message: errorMessage,
                container: $(oSettings.messageContainer),
                context: oSettings.context
            });
        }
        if (oSettings.messageContainerArray && !ServiceCollectionsHelper.checkNullList(oSettings.messageContainerArray)) {
            oSettings.messageContainerArray.forEach(function (messageContainer) {
                ServiceMessageBarHelper.generateMessageBar({
                    msgCategory: ServiceMessageBarHelper.MSG_CATEGORY.ERROR,
                    message: errorMessage,
                    container: $(messageContainer),
                    context: oSettings.context
                });
            });
        }
    }.bind(this));

};

ServiceValidatorHelper._conbineErrorMessage = function (oSettings, fnCallback) {
    "use strict";
    if (oSettings.errorMessage) {
        fnCallback(oSettings.errorMessage);
    }
    if (oSettings.errorMessagePrefix) {
        if (oSettings.validType) {
            ServiceHttpRequestHelper.getI18nWrap(function () {
                ServiceValidatorHelper._getI18nCommonMap();
                if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.NON_EMPTY) {
                    fnCallback(oSettings.errorMessagePrefix + ' ' + ServiceValidatorHelper.label.errorPostNotEmpty);
                }
                if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.POSITIVE) {
                    fnCallback(oSettings.errorMessagePrefix + ' ' + ServiceValidatorHelper.label.errorPostPositive);
                }
                if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.NEGATIVE) {
                    fnCallback(oSettings.errorMessagePrefix + ' ' + ServiceValidatorHelper.label.errorPostNegative);
                }
                if (oSettings.validType.defType === ServiceValidatorHelper.DEF_VALID_TYPE.NON_EMPTY_ARRAY) {
                    fnCallback(oSettings.errorMessagePrefix + ' ' + ServiceValidatorHelper.label.errorPostNotEmptyArray);
                }
            }.bind(this));
        }
    }
};

ServiceValidatorHelper._getI18nCommonMap = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(ServiceValidatorHelper.label, $.i18n.prop, true);
};

ServiceValidatorHelper._clearMessageWrap = function (oSettings, $valueContainer) {
    "use strict";
    if (checkArrayFlag($valueContainer)) {
        if ($valueContainer.length > 0) {
            $valueContainer.forEach(function (item) {
                item.toggleClass("parsley-error", false);
            });
        }
    } else {
        if ($valueContainer) {
            $valueContainer.toggleClass("parsley-error", false);
        }
    }
    ServiceMessageBarHelper.removeMessageBar({
        container: $(oSettings.messageContainer),
        context: oSettings.context
    });
    if (oSettings.messageContainerArray && !ServiceCollectionsHelper.checkNullList(oSettings.messageContainerArray)) {
        oSettings.messageContainerArray.forEach(function (messageContainer) {
            ServiceMessageBarHelper.removeMessageBar({
                container: $(messageContainer),
                context: oSettings.context
            });
        });
    }
};


ServiceValidatorHelper._getValueContainer = function (oSettings) {
    "use strict";
    if (checkArrayFlag(oSettings.valueContainer)) {
        var resultArray = [];
        if (oSettings.valueContainer.length > 0) {
            oSettings.valueContainer.forEach(function (item) {
                var itemResult = ServiceValidatorHelper._getValueContainerUnion(item);
                if (itemResult) {
                    resultArray.push(itemResult);
                }
            });
        }
        return resultArray;
    } else {
        return ServiceValidatorHelper._getValueContainerUnion(oSettings.valueContainer);
    }
};

ServiceValidatorHelper._getValueContainerUnion = function (valueContainer) {
    "use strict";
    valueContainer = ServiceUtilityHelper.getDomElement(valueContainer);
    if (!$(valueContainer) && $(valueContainer).length <= 0) {
        return;
    }
    if ($(valueContainer) && $(valueContainer).length > 0) {
        // Special handling
        if ($(valueContainer)[0].tagName === "SELECT") {
            return $(valueContainer).next("span.select2-container").find(".select2-selection");
        }
        return $(valueContainer);
    }
};

/**
 * Service Message bar helper class
 * @constructor
 */
var ServiceMessageBarHelper = function () {

};

ServiceMessageBarHelper.MSG_CATEGORY = {
    SUCCESS: 1,
    INFO: 2,
    WARNING: 3,
    ERROR: 4
};

/**
 * Contants: Should be constistent with SimpleSEMessageResponse
 * @type {{INFO: number, WARN: number, ERROR: number}}
 */
ServiceMessageBarHelper.MESSAGELEVEL = {
    INFO: 1,
    WARN: 2,
    ERROR: 3
};

ServiceMessageBarHelper.getMsgCategoryIconArray = function () {
    "use strict";
    return [{
        id: ServiceMessageBarHelper.MSG_CATEGORY.SUCCESS, iconClass: 'md md-flag'
    }, {
        id: ServiceMessageBarHelper.MSG_CATEGORY.INFO, iconClass: 'nmd nmd-notifications-active'
    }, {
        id: ServiceMessageBarHelper.MSG_CATEGORY.WARNING, iconClass: 'md md-warning'
    }, {
        id: ServiceMessageBarHelper.MSG_CATEGORY.ERROR, iconClass: 'md md-cancel'
    }];
};

ServiceMessageBarHelper.getMsgCategoryIcon = function (msgCategory) {
    "use strict";
    var backGroundClass = ServiceCollectionsHelper.filterArray(msgCategory, 'id', ServiceMessageBarHelper.getMsgCategoryIconArray());
    if (backGroundClass) {
        return backGroundClass.iconClass;
    }
};

ServiceMessageBarHelper.getMsgCategoryBackGroundClassArray = function () {
    "use strict";
    return [{
        id: ServiceMessageBarHelper.MSG_CATEGORY.SUCCESS, class: 'background-messageSuccess'
    }, {
        id: ServiceMessageBarHelper.MSG_CATEGORY.INFO, class: 'background-actionGreen'
    }, {
        id: ServiceMessageBarHelper.MSG_CATEGORY.WARNING, class: 'background-messageWarn'
    }, {
        id: ServiceMessageBarHelper.MSG_CATEGORY.ERROR, class: 'background-messageError'
    }];
};

ServiceMessageBarHelper.getMsgCategoryBackGroundClass = function (msgCategory) {
    "use strict";
    var backGroundClass = ServiceCollectionsHelper.filterArray(msgCategory, 'id', ServiceMessageBarHelper.getMsgCategoryBackGroundClassArray());
    if (backGroundClass) {
        return backGroundClass.class;
    }
};
/**
 * Handler method for "close button", for removing the current message bar
 * @param event
 */
ServiceMessageBarHelper.removeMessage = function (event) {
    var el = event.currentTarget;
    var messageBody = el.closest(".row.message-title");
    messageBody.remove();
};

/**
 * Main Entrance method to generate message bar html element
 * @param {object}oSettings
 *         --{enum}msgCategory
 *         --{string}message
 *         --{Dom element}container
 *         --{string}context
 */
ServiceMessageBarHelper.generateMessageBar = function (oSettings) {
    var ser = new XMLSerializer();
    var messageRowElement = ServiceMessageBarHelper.generateMessageBarCore(oSettings);
    // remove the duplicate with same context
    ServiceMessageBarHelper.removeMessageBar({
        container: oSettings.container,
        context: oSettings.context
    });
    var htmlContent = ser.serializeToString(messageRowElement);
    oSettings.container.prepend(htmlContent);
    $(".close-messageBar").on("click", function (event) {
        ServiceMessageBarHelper.removeMessage(event);
    });
};

ServiceMessageBarHelper.generateMessageBarCore = function (oSettings) {
    var messageRowElement = document.createElement('div');

    var messageTitleClass = oSettings.context ? "row message-title " + oSettings.context : "row message-title";
    messageRowElement.setAttribute("class", messageTitleClass);
    var col12Element = document.createElement('div');
    col12Element.setAttribute("class", "col-sm-12");
    messageRowElement.appendChild(col12Element);

    var messageTitleBox = document.createElement('div');
    var backgroundClass = ServiceMessageBarHelper.getMsgCategoryBackGroundClass(oSettings.msgCategory);
    messageTitleBox.setAttribute("class", "message-title-box " + backgroundClass);
    col12Element.appendChild(messageTitleBox);

    var iconElement = document.createElement('i');
    var iconClass = ServiceMessageBarHelper.getMsgCategoryIcon(oSettings.msgCategory);
    iconElement.setAttribute("class", iconClass);
    messageTitleBox.appendChild(iconElement);
    ServiceDOMUtilityHelper.createSpaceNode(messageTitleBox);

    var spanMessage = ServiceDOMUtilityHelper.createDefElement({
        class: "page-title content-darkblue",
        element: 'span',
        parentElement: messageTitleBox
    });
    ServiceDOMUtilityHelper.createTextNode(spanMessage, oSettings.message);

    var portletWidgets = ServiceDOMUtilityHelper.createDefElement({
        class: "portlet-widgets",
        element: 'div',
        parentElement: messageTitleBox
    });

    var closeMessageButton = ServiceDOMUtilityHelper.createDefElement({
        element: 'button',
        type: 'button',
        atClick: 'closeMessage',
        parentElement: portletWidgets
    });

    var ionClose = ServiceDOMUtilityHelper.createDefElement({
        class: "ion-close-round close-messageBar",
        element: 'i',
        parentElement: closeMessageButton
    });

    return messageRowElement;
};


/**
 * Main Entrance method to remove message bar under message container
 * @param {object}oSettings
 *         --{Dom element}container
 *         --{string}context
 */
ServiceMessageBarHelper.removeMessageBar = function (oSettings) {
    if (oSettings && oSettings.container) {
        if (oSettings.context) {
            // Replace all periods with \\. to
            oSettings.context = oSettings.context.replace(/\./g, '\\\\.');
            var deleteContent = oSettings.container.children(".message-title" + "." + oSettings.context);
            if (deleteContent) {
                deleteContent.remove();
            }
        } else {
            oSettings.container.empty();
        }
    } else {
        // in case delete all possible
        var container = $(".message-container");
        if (container) {
            var deleteContent2 = container.children(".message-title");
            if (deleteContent2) {
                deleteContent2.remove();
            }
        }
    }
};


ServiceMessageBarHelper.showPreCheckMessage = function (messageResponseList, oSetting) {
    var warnMessageResponseList = ServiceMessageBarHelper.filterMessageByLevel(ServiceMessageBarHelper.MESSAGELEVEL.WARN, messageResponseList);
    var errorMessageResponseList = ServiceMessageBarHelper.filterMessageByLevel(ServiceMessageBarHelper.MESSAGELEVEL.ERROR, messageResponseList);
    var i = 0, messageResponse, len = warnMessageResponseList.length;
    if (warnMessageResponseList && warnMessageResponseList.length > 0) {
        for (i = 0, len = warnMessageResponseList.length; i < len; i++) {
            messageResponse = warnMessageResponseList[i];
            ServiceMessageBarHelper.generateMessageBar({
                msgCategory: ServiceMessageBarHelper.MSG_CATEGORY.WARNING,
                message: messageResponse.messageContent,
                container: oSetting.container,
                context: 'warnMessage' + i
            });
        }
    }
    if (errorMessageResponseList && errorMessageResponseList.length > 0) {
        for (i = 0, len = errorMessageResponseList.length; i < len; i++) {
            messageResponse = errorMessageResponseList[i];
            ServiceMessageBarHelper.generateMessageBar({
                msgCategory: ServiceMessageBarHelper.MSG_CATEGORY.ERROR,
                message: messageResponse.messageContent,
                container: oSetting.container,
                context: 'errorMessage' + i
            });
        }
    }
};

ServiceMessageBarHelper.filterMessageByLevel = function (level, messageResponseList) {
    if (messageResponseList && messageResponseList.length > 0) {
        var i = 0, messageResponse, resultList = [], len = messageResponseList.length;
        for (i = 0; i < len; i++) {
            messageResponse = messageResponseList[i];
            if (level == messageResponse.messageLevel) {
                resultList.push(messageResponse);
            }
        }
        return resultList;
    }
};


/**
 * Utility Class for Integration Parsley message
 * @constructor
 */
var ServiceParselyMessageHelper = function () {

};

ServiceParselyMessageHelper.getErrorContext = function (fieldInstance) {
    var classList = fieldInstance.$element[0].classList, i, len;
    if (ServiceCollectionsHelper.checkNullList(classList)) {
        return null;
    }
    var rawMsg;
    for (i = 0, len = classList.length; i < len; i++) {
        if (classList[i] && classList[i].indexOf('content.') !== -1) {
            var context = ServiceParselyMessageHelper.formatContext(classList[i]);
            return context;
        }
        if (classList[i] && classList[i].indexOf('cache.') !== -1) {
            var contextCache = ServiceParselyMessageHelper.formatContext(classList[i]);
            return contextCache;
        }
    }
};

ServiceParselyMessageHelper.getParsleyMessageCore = function (fieldInstance, labelObj) {
    var classList = fieldInstance.$element[0].classList, i, len, labelValue,
        errorMessages = fieldInstance.getErrorsMessages();
    var message = errorMessages ? errorMessages[0] : '';
    if (ServiceCollectionsHelper.checkNullList(classList)) {
        return null;
    }
    var rawMsg;
    for (i = 0, len = classList.length; i < len; i++) {
        if (classList[i] && classList[i].indexOf('label.') !== -1) {
            rawMsg = classList[i];
            break;
        }
    }
    if (rawMsg) {
        labelValue = ServiceUtilityHelper.fetchObjValueByPath(labelObj, rawMsg);
        if (labelValue) {
            message = labelValue + ' ' + message;
        }
    }
    return message;
};

ServiceParselyMessageHelper.findMessageContainer = function (fieldInstance) {
    var messageContainer;
    messageContainer = ServiceParselyMessageHelper.findMessageContainerCore(fieldInstance, ServiceParselyMessageHelper.Constants.ModalBodyClass);
    if (messageContainer) {
        return messageContainer;
    }
    messageContainer = ServiceParselyMessageHelper.findMessageContainerCore(fieldInstance, ServiceParselyMessageHelper.Constants.containerClass);
    if (messageContainer) {
        return messageContainer;
    }
    messageContainer = ServiceParselyMessageHelper.findMessageContainerCore(fieldInstance, ServiceParselyMessageHelper.Constants.PortletBodyClass);
    if (messageContainer) {
        return messageContainer;
    }
};

ServiceParselyMessageHelper.findMessageContainerCore = function (fieldInstance, parentContainerClass) {
    var $element = fieldInstance.$element ? fieldInstance.$element : fieldInstance;
    var messageContainer, parentContainer = $element.closest('.' + parentContainerClass);

    if (parentContainer && parentContainer[0]) {
        messageContainer = parentContainer.children('.' + ServiceParselyMessageHelper.Constants.MessageContainerClass);
        if (messageContainer && messageContainer[0]) {
            return messageContainer;
        }
    }
};

ServiceParselyMessageHelper.findDefGlobalContainer = function () {
    var messageContainer;
    messageContainer = $('.' + ServiceParselyMessageHelper.Constants.MainContainer + '.' + ServiceParselyMessageHelper.Constants.MessageContainerClass);
    if (messageContainer) {
        return messageContainer;
    }
    messageContainer = $('.' + ServiceParselyMessageHelper.Constants.MessageContainerClass);
    if (messageContainer) {
        return messageContainer;
    }
    messageContainer = $('.' + ServiceParselyMessageHelper.Constants.containerClass);
    if (messageContainer) {
        return messageContainer;
    }
    messageContainer = $('.' + ServiceParselyMessageHelper.Constants.ModalBodyClass);
    if (messageContainer) {
        return messageContainer;
    }
    messageContainer = $('.' + ServiceParselyMessageHelper.Constants.PortletBodyClass);
    if (messageContainer) {
        return messageContainer;
    }

};

ServiceParselyMessageHelper.Constants = {
    MainContainer: 'main',
    MessageContainerClass: 'message-container',
    PortletBodyClass: 'portlet-body',
    ModalBodyClass: 'modal-body',
    containerClass: 'container'
};

ServiceParselyMessageHelper.initParsleyConfigureWrapper = function (oSettings) {
    "use strict";
    var customContainer = oSettings.$container ? $(oSettings.$container) : undefined;
    window.Parsley.on('field:error', function () {
        var message = ServiceParselyMessageHelper.getParsleyMessageCore(this, oSettings.labelObj);
        var container = customContainer ? customContainer : ServiceParselyMessageHelper.findMessageContainer(this);
        var errorContext = ServiceParselyMessageHelper.getErrorContext(this);
        if (container) {
            ServiceMessageBarHelper.generateMessageBar({
                msgCategory: ServiceMessageBarHelper.MSG_CATEGORY.ERROR,
                message: message,
                container: container,
                context: errorContext
            });
        }
    });

    window.Parsley.on('field:success', function () {
        var container = customContainer ? customContainer : ServiceParselyMessageHelper.findMessageContainer(this);
        var errorContext = ServiceParselyMessageHelper.getErrorContext(this);
        ServiceMessageBarHelper.removeMessageBar({
            container: container,
            context: errorContext
        });
    });
};

ServiceParselyMessageHelper.formatContext = function (rawContext) {
    if (!rawContext) {
        return;
    }
    return rawContext.replace(/\./g, '-');

};


/**
 * Utility Class for DOM Helper
 * @constructor
 */
var ServiceDOMUtilityHelper = function () {

};

ServiceDOMUtilityHelper.createDefElement = function (oSettings) {
    var currentElement = document.createElement(oSettings.element);
    if (oSettings.class) {
        currentElement.setAttribute("class", oSettings.class);
    }
    if (oSettings.id) {
        currentElement.setAttribute("id", oSettings.id);
    }
    if (oSettings.parentElement) {
        oSettings.parentElement.appendChild(currentElement);
    }
    if (oSettings.type) {
        currentElement.setAttribute("type", oSettings.type);
    }
    if (oSettings.atClick) {
        currentElement.setAttribute(":click", oSettings.atClick);
    }
    if (oSettings.href) {
        currentElement.setAttribute("href", oSettings.href);
    }
    if (oSettings.target) {
        currentElement.setAttribute("target", oSettings.target);
    }
    if (oSettings.value) {
        currentElement.setAttribute("value", oSettings.value);
    }
    if (oSettings.iconClass && oSettings.textContent) {
        // In case need to create icon
        ServiceDOMUtilityHelper.createDefElement({
            parentElement: currentElement,
            element: 'i',
            class: oSettings.iconClass
        });
        ServiceDOMUtilityHelper.createSpaceNode(currentElement);
        ServiceDOMUtilityHelper.createTextNode(currentElement, oSettings.textContent);
    } else {
        if (oSettings.textContent) {
            ServiceDOMUtilityHelper.createTextNode(currentElement, oSettings.textContent);
        }
    }


    return currentElement;
};

ServiceDOMUtilityHelper.createTextNode = function (parentElement, message) {
    var textNode = document.createTextNode(message);
    parentElement.appendChild(textNode);
    return textNode;
};

ServiceDOMUtilityHelper.createSpaceNode = function (parentElement) {
    var textNode = document.createTextNode(" ");
    parentElement.appendChild(textNode);
    return textNode;
};


/**
 * Generate default popover element with display id and share icon, and pop-over navigate to target quick view
 * @param oSettings
 *          --{string} popClass
 *          --{string} uuid
 *          --{string} docType
 *          --{string} id
 */
ServiceDOMUtilityHelper.genDefPopOverElement = function (oSettings) {

    var popoverElement = document.createElement('div');
    if (!oSettings.id) {
        return popoverElement;
    }
    var popoverClass = "popover-info ";
    if (oSettings.popClass) {
        popoverClass += oSettings.popClass;
    }
    popoverElement.setAttribute("class", popoverClass);
    popoverElement.setAttribute("data-original-title", "");
    popoverElement.setAttribute("title", "");

    var iconElement = document.createElement('i');
    iconElement.setAttribute("class", "md md-chat content-green");
    popoverElement.appendChild(iconElement);
    popoverElement.appendChild(document.createTextNode(' '));

    var inputUUIDElement = document.createElement('input');
    inputUUIDElement.setAttribute("value", oSettings.uuid);
    inputUUIDElement.setAttribute("class", "input-UUID");
    inputUUIDElement.setAttribute("type", "hidden");

    var idText = document.createTextNode(oSettings.id);
    popoverElement.appendChild(idText);
    popoverElement.appendChild(inputUUIDElement);
    if (oSettings.docType) {
        var inputTypeElement = document.createElement('input');
        inputTypeElement.setAttribute("value", oSettings.docType);
        inputTypeElement.setAttribute("class", "input-docType");
        inputTypeElement.setAttribute("type", "hidden");
        popoverElement.appendChild(inputTypeElement);
    }
    return popoverElement;
};
/**
 * Constants of HTTP Status, the same as apache.common.HttpStatus
 * @type {{}}
 */
var HttpStatus = {
// --- 1xx Informational ---

    /** <tt>100 Continue</tt> (HTTP/1.1 - RFC 2616) */
    SC_CONTINUE: 100,
    /** <tt>101 Switching Protocols</tt> (HTTP/1.1 - RFC 2616)*/
    SC_SWITCHING_PROTOCOLS: 101,
    /** <tt>102 Processing</tt> (WebDAV - RFC 2518) */
    SC_PROCESSING: 102,

// --- 2xx Success ---

    /** <tt>200 OK</tt> (HTTP/1.0 - RFC 1945) */
    SC_OK: 200,
    /** <tt>201 Created</tt> (HTTP/1.0 - RFC 1945) */
    SC_CREATED: 201,
    /** <tt>202 Accepted</tt> (HTTP/1.0 - RFC 1945) */
    SC_ACCEPTED: 202,
    /** <tt>203 Non Authoritative Information</tt> (HTTP/1.1 - RFC 2616) */
    SC_NON_AUTHORITATIVE_INFORMATION: 203,
    /** <tt>204 No Content</tt> (HTTP/1.0 - RFC 1945) */
    SC_NO_CONTENT: 204,
    /** <tt>205 Reset Content</tt> (HTTP/1.1 - RFC 2616) */
    SC_RESET_CONTENT: 205,
    /** <tt>206 Partial Content</tt> (HTTP/1.1 - RFC 2616) */
    SC_PARTIAL_CONTENT: 206,
    /**
     * <tt>207 Multi-Status</tt> (WebDAV - RFC 2518) or <tt>207 Partial Update
     * OK</tt> (HTTP/1.1 - draft-ietf-http-v11-spec-rev-01?)
     */
    SC_MULTI_STATUS: 207,

// --- 3xx Redirection ---

    /** <tt>300 Mutliple Choices</tt> (HTTP/1.1 - RFC 2616) */
    SC_MULTIPLE_CHOICES: 300,
    /** <tt>301 Moved Permanently</tt> (HTTP/1.0 - RFC 1945) */
    SC_MOVED_PERMANENTLY: 301,
    /** <tt>302 Moved Temporarily</tt> (Sometimes <tt>Found</tt>) (HTTP/1.0 - RFC 1945) */
    SC_MOVED_TEMPORARILY: 302,
    /** <tt>303 See Other</tt> (HTTP/1.1 - RFC 2616) */
    SC_SEE_OTHER: 303,
    /** <tt>304 Not Modified</tt> (HTTP/1.0 - RFC 1945) */
    SC_NOT_MODIFIED: 304,
    /** <tt>305 Use Proxy</tt> (HTTP/1.1 - RFC 2616) */
    SC_USE_PROXY: 305,
    /** <tt>307 Temporary Redirect</tt> (HTTP/1.1 - RFC 2616) */
    SC_TEMPORARY_REDIRECT: 307,

// --- 4xx Client Error ---

    /** <tt>400 Bad Request</tt> (HTTP/1.1 - RFC 2616) */
    SC_BAD_REQUEST: 400,
    /** <tt>401 Unauthorized</tt> (HTTP/1.0 - RFC 1945) */
    SC_UNAUTHORIZED: 401,
    /** <tt>402 Payment Required</tt> (HTTP/1.1 - RFC 2616) */
    SC_PAYMENT_REQUIRED: 402,
    /** <tt>403 Forbidden</tt> (HTTP/1.0 - RFC 1945) */
    SC_FORBIDDEN: 403,
    /** <tt>404 Not Found</tt> (HTTP/1.0 - RFC 1945) */
    SC_NOT_FOUND: 404,
    /** <tt>405 Method Not Allowed</tt> (HTTP/1.1 - RFC 2616) */
    SC_METHOD_NOT_ALLOWED: 405,
    /** <tt>406 Not Acceptable</tt> (HTTP/1.1 - RFC 2616) */
    SC_NOT_ACCEPTABLE: 406,
    /** <tt>407 Proxy Authentication Required</tt> (HTTP/1.1 - RFC 2616)*/
    SC_PROXY_AUTHENTICATION_REQUIRED: 407,
    /** <tt>408 Request Timeout</tt> (HTTP/1.1 - RFC 2616) */
    SC_REQUEST_TIMEOUT: 408,
    /** <tt>409 Conflict</tt> (HTTP/1.1 - RFC 2616) */
    SC_CONFLICT: 409,
    /** <tt>410 Gone</tt> (HTTP/1.1 - RFC 2616) */
    SC_GONE: 410,
    /** <tt>411 Length Required</tt> (HTTP/1.1 - RFC 2616) */
    SC_LENGTH_REQUIRED: 411,
    /** <tt>412 Precondition Failed</tt> (HTTP/1.1 - RFC 2616) */
    SC_PRECONDITION_FAILED: 412,
    /** <tt>413 Request Entity Too Large</tt> (HTTP/1.1 - RFC 2616) */
    SC_REQUEST_TOO_LONG: 413,
    /** <tt>414 Request-URI Too Long</tt> (HTTP/1.1 - RFC 2616) */
    SC_REQUEST_URI_TOO_LONG: 414,
    /** <tt>415 Unsupported Media Type</tt> (HTTP/1.1 - RFC 2616) */
    SC_UNSUPPORTED_MEDIA_TYPE: 415,
    /** <tt>416 Requested Range Not Satisfiable</tt> (HTTP/1.1 - RFC 2616) */
    SC_REQUESTED_RANGE_NOT_SATISFIABLE: 416,
    /** <tt>417 Expectation Failed</tt> (HTTP/1.1 - RFC 2616) */
    SC_EXPECTATION_FAILED: 417,

    /**
     * Static constant for a 419 error.
     * <tt>419 Insufficient Space on Resource</tt>
     * (WebDAV - draft-ietf-webdav-protocol-05?)
     * or <tt>419 Proxy Reauthentication Required</tt>
     * (HTTP/1.1 drafts?)
     */
    SC_INSUFFICIENT_SPACE_ON_RESOURCE: 419,
    /**
     * Static constant for a 420 error.
     * <tt>420 Method Failure</tt>
     * (WebDAV - draft-ietf-webdav-protocol-05?)
     */
    SC_METHOD_FAILURE: 420,
    /** <tt>422 Unprocessable Entity</tt> (WebDAV - RFC 2518) */
    SC_UNPROCESSABLE_ENTITY: 422,
    /** <tt>423 Locked</tt> (WebDAV - RFC 2518) */
    SC_LOCKED: 423,
    /** <tt>424 Failed Dependency</tt> (WebDAV - RFC 2518) */
    SC_FAILED_DEPENDENCY: 424,

// --- 5xx Server Error ---

    /** <tt>500 Server Error</tt> (HTTP/1.0 - RFC 1945) */
    SC_INTERNAL_SERVER_ERROR: 500,
    /** <tt>501 Not Implemented</tt> (HTTP/1.0 - RFC 1945) */
    SC_NOT_IMPLEMENTED: 501,
    /** <tt>502 Bad Gateway</tt> (HTTP/1.0 - RFC 1945) */
    SC_BAD_GATEWAY: 502,
    /** <tt>503 Service Unavailable</tt> (HTTP/1.0 - RFC 1945) */
    SC_SERVICE_UNAVAILABLE: 503,
    /** <tt>504 Gateway Timeout</tt> (HTTP/1.1 - RFC 2616) */
    SC_GATEWAY_TIMEOUT: 504,
    /** <tt>505 HTTP Version Not Supported</tt> (HTTP/1.1 - RFC 2616) */
    SC_HTTP_VERSION_NOT_SUPPORTED: 505,

    /** <tt>507 Insufficient Storage</tt> (WebDAV - RFC 2518) */
    SC_INSUFFICIENT_STORAGE: 507

};


var ServiceHttpRequestHelper = {
    // constant area
    msgUnknowSystemFailure: 'msgUnknowSystemFailure',
    msgSystemFailure: 'msgSystemFailure'
};


ServiceHttpRequestHelper.loadModuleListTemplate = function (url, oSelectElement, selectKey, initValue, fnCallback) {
    var vm = this;
    $.ajax({
        url: url,
        dataType: "json",
        type: "get",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        success: function (oData) {
            var resultList = oData;
            var formatList = formatSelectResult(oData.content, 'uuid', selectKey);
            setTimeout(function () {
                $(oSelectElement).empty();
                $(oSelectElement).select2({
                    data: formatList
                });
                var rawValue = initValue ? initValue : undefined;
                if (!rawValue) {
                    if (formatList && formatList.length && formatList.length > 0) {
                        rawValue = formatList[0].id;
                    }
                }
                $(oSelectElement).val(rawValue);
                $(oSelectElement).trigger("change");
                if (fnCallback && typeof fnCallback === 'function') {
                    fnCallback(rawValue);
                }
            }, 0);
        },
        error: function () {
            // do nothing currently
        }
    });
};

ServiceHttpRequestHelper.getRoleList = function () {
    return ServiceHttpRequestHelper.roleList;
};

var HttpSubStatus = {
    SC_SUBERROR_LOGONFAILED: '401.1'
};

ServiceHttpRequestHelper.label = {
    msgSystemFailure: '',
    msgUnknowSystemFailure: '',
    noneAuthorizedFailure: ''

};


/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
ServiceHttpRequestHelper.getI18nWrap = function (fnCallback) {
    "use strict";
    jQuery.i18n.properties({
        name: 'ComElements', //properties file name
        path: getI18nRootPath() + ServiceHttpRequestHelper.getI18nPath(), //path for properties files
        mode: 'map', //Using map mode to consume properties files
        language: getLan(),
        cache: true,
        callback: fnCallback
    });
};


ServiceHttpRequestHelper.getI18nCommonMap = function () {
    "use strict";
    ServiceHttpRequestHelper.label.msgSystemFailure = $.i18n.prop('msgSystemFailure');
    ServiceHttpRequestHelper.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
    ServiceHttpRequestHelper.label.noneAuthorizedFailure = $.i18n.prop('noneAuthorizedFailure');
};

ServiceHttpRequestHelper.getI18nPath = function () {
    "use strict";
    return "foundation/";
};

ServiceHttpRequestHelper.handleLockErrorWithBarWrap = function (oData, oSettings) {
    oData.errorMessage = oData.MSG;
    ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, oSettings);
};

ServiceHttpRequestHelper.CONST = {
    Prop: {
        errorMessage: "errorMessage"
    }
};

/**
 * Generate error message
 *
 * @param oSettings
 * @returns {{}}
 */
ServiceHttpRequestHelper.genErrorMessage = function (oSettings) {
    var message = {};
    if (oSettings.text) {
        message[ServiceHttpRequestHelper.CONST.Prop.errorMessage] = oSettings.text;
        return message;
    }
    if (oSettings.label && oSettings.key) {
        message[ServiceHttpRequestHelper.CONST.Prop.errorMessage] = oSettings.label[oSettings.key];
        return message;
    }
};

ServiceHttpRequestHelper.handleErrorWithBarWrap = function (oData, oSettings) {
    ServiceHttpRequestHelper.getI18nWrap(function () {
        ServiceHttpRequestHelper.getI18nCommonMap();
        var errorMessage = oData.errorMessage ? oData.errorMessage : ServiceHttpRequestHelper.label[ServiceHttpRequestHelper.msgUnknowSystemFailure];
        var errorTitle = ServiceHttpRequestHelper.defineErrorTitle(oData);
        var oInnerSettings = {
            errorTitle: errorTitle,
            errorMessage: errorMessage
        };
        if (oSettings && oSettings.container) {
            oInnerSettings.container = oSettings.container;
        }
        if (oSettings && oSettings.fnHMessageCallback) {
            oSettings.fnHMessageCallback(oInnerSettings);
            return;
        }
        // Logic to locate the container
        ServiceHttpRequestHelper.handleErrorByWithBar(oData, oInnerSettings);


    });
};


/**
 * Utility wrap method to parsing the error message
 * @param {object} oData: data content parsing from object
 * @param (object} oSettings: compound object
 */
ServiceHttpRequestHelper.handleErrorCodeWrap = function (oData, oSettings) {
    ServiceHttpRequestHelper.getI18nWrap(function () {
        ServiceHttpRequestHelper.getI18nCommonMap();
        var errorMessage = oData.errorMessage ? oData.errorMessage : ServiceHttpRequestHelper.label[ServiceHttpRequestHelper.msgUnknowSystemFailure];
        var errorTitle = ServiceHttpRequestHelper.defineErrorTitle(oData);
        var oInnerSettings = {
            errorTitle: errorTitle,
            errorMessage: errorMessage
        };
        if (oSettings && oSettings.container) {
            oInnerSettings.container = oSettings.container ? oSettings.container : undefined;
        }
        if (oSettings && oSettings.fnHMessageCallback) {
            oSettings.fnHMessageCallback(oInnerSettings);
            return;
        }
        ServiceHttpRequestHelper.handleErrorByErrorCode(oData, errorTitle, errorMessage);
    });
};

ServiceHttpRequestHelper.defineErrorTitle = function (oData) {
    var errorTitle = oData.errorTitle || ServiceHttpRequestHelper.label[ServiceHttpRequestHelper.msgSystemFailure];
    var errorCode = oData.errorCode;
    var hitFlag = false;
    if (errorCode === HttpStatus.SC_UNAUTHORIZED) {
        errorTitle = ServiceHttpRequestHelper.label.noneAuthorizedFailure;
    }
    return errorTitle;
};

/**
 * Core Logic to handle logic by error code:
 * @param oData: raw oData parsing from http response
 * @param errorTitle: Refined error message title
 * @param errorMessage: Refined error message content
 */
ServiceHttpRequestHelper.handleErrorByErrorCode = function (oData, errorTitle, errorMessage) {
    var errorCode = oData.errorCode;
    var hitFlag = false;
    if (errorCode && errorCode === HttpStatus.SC_UNAUTHORIZED) {
        if (oData.subErrorCode && oData.subErrorCode === HttpSubStatus.SC_SUBERROR_LOGONFAILED) {
            hitFlag = true;
            ServiceHttpRequestHelper.handleLogonFailed(oData);
            return;
        }
    }
    // Default handling logic
    if (!hitFlag) {
        swal({
            title: errorTitle,
            text: errorMessage,
            type: "error",
            confirmButtonClass: 'btn btn-action btn-rounded-embedded',
            cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
            confirmButtonText: this.label.confirm
        });
    }
};

ServiceHttpRequestHelper.handleErrorByWithBar = function (oData, oSettings) {
    var errorCode = oData.errorCode;
    var hitFlag = false;
    if (errorCode && errorCode === HttpStatus.SC_UNAUTHORIZED) {
        if (oData.subErrorCode && oData.subErrorCode === HttpSubStatus.SC_SUBERROR_LOGONFAILED) {
            hitFlag = true;
            ServiceHttpRequestHelper.handleLogonFailed(oData);
            return;
        }
    }
    // Logic to locate the container
    if (!oSettings.container) {
        oSettings.container = ServiceParselyMessageHelper.findDefGlobalContainer();
    }
    if (oSettings.container) {
        ServiceMessageBarHelper.generateMessageBar({
            msgCategory: ServiceMessageBarHelper.MSG_CATEGORY.ERROR,
            message: oSettings.errorMessage,
            container: oSettings.container,
            context: oSettings.context
        });
    }

};


ServiceHttpRequestHelper.handleLogonFailed = function (oData) {
    var paras = {};
    paras.errorCode = oData.errorCode;
    paras.subErrorCode = oData.subErrorCode;
    var aunion = document.createElement("a");
    aunion.href = document.location.href;
    paras.pathname = aunion.pathname;
    if (aunion.pathname) {
        var array = aunion.pathname.split('/');
        if (array && array.length === 2) {
            paras.pathname = array[1];
        }
        if (array && array.length > 2) {
            paras.pathname = array[2];
        }
    }
    var preParas = getUrlVars();
    $.extend(true, paras, preParas);
    var resultURL = "index.html" + "?" + urlEncode(paras);
    window.location.href = resultURL;
};

/**
 * Change URL paras (GET) by parsing requestData:Object attributes
 * @param url
 * @param requestData
 * @returns {*}
 */
ServiceHttpRequestHelper.changeURLParas = function (url, requestData) {
    if (!requestData || typeof requestData !== "object") {
        return url;
    }
    var keys = Object.keys(requestData), resultUrl = url;
    var i, len = keys ? keys.length : 0;
    for (i = 0; i < len; i++) {
        if (typeof requestData[keys[i]] === "string" || typeof requestData[keys[i]] === "number") {
            if (!requestData[keys[i]]) {
                continue;
            }
            resultUrl = changeURLPar(resultUrl, keys[i], requestData[keys[i]]);
        }
        if (typeof requestData[keys[i]] === "object") {
            // just skip
        }
    }
    return resultUrl;
};

var ServiceSplitDocHelper = function () {

};

ServiceSplitDocHelper.displayEditSerialId = function (docMatItem) {
    if (docMatItem.editSerialIdFlag * 1 === DocumentConstants.StandardPropety.Switch.ON) {
        return true;
    } else {
        return undefined;
    }
};

ServiceSplitDocHelper.formatEditSerialIdIconClass = function (docMatItem) {
    if (docMatItem.emptySerialIdFlag * 1 === DocumentConstants.StandardPropety.Switch.ON) {
        return 'nmd nmd-filter-9 content-red';
    } else {
        return 'nmd nmd-filter-9 light-blue';
    }
};


