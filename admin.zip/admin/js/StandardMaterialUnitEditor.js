var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: StandardMaterialUnitManager.label.standardMaterialUnit,
        content: {
            id: '',
            name: '',
            languageCode: '',
            note: '',
            referUnitUUID: '',
            refMaterialUnitId: '',
            refMaterialUnitName: '',
            unitType: '',
            unitCategory: '',
            toReferUnitFactor: '',
            toReferUnitOffset: '',
            systemCategory: ''
        },
        author:{
            resourceId:'StandardMaterialUnit',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        eleUnitTypeMap: '#x_unitType',
        eleUnitCategoryMap: '#x_unitCategory',
        eleRefUnitUUID: '#x_refUnitUUID',
        eleSystemCategory: '#x_systemCategory',
        getUnitTypeMapURL: '../standardMaterialUnit/getUnitTypeMap.html',
        getUnitCategoryMapURL: '../standardMaterialUnit/getUnitCategoryMap.html',
        getSystemCategoryMapURL: '../standardMaterialUnit/getSystemCategoryMap.html',
        getRefUnitListSelectURL: '../standardMaterialUnit/loadModuleListService.html',
        loadModuleEditURL: '../standardMaterialUnit/loadModuleEditService.html',
        loadModuleURL: '../standardMaterialUnit/loadModule.html',
        saveModuleURL: '../standardMaterialUnit/saveModuleService.html',
        newModuleServiceURL: '../standardMaterialUnit/newModuleService.html',
        exitURL: 'StandardMaterialUnitList.html',
        exitModuleURL: '../standardMaterialUnit/exitEditor.html'

    },

    created: function(){
        "use strict";
        var vm = this;
        vm.initAuthorResourceCheck();
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'StandardMaterialUnit');
            this.setI18nProperties(vm.initProcessButtonMeta);
            this.loadModuleEdit();
            this.initSelectConfigure();
        });
    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        initSelectConfigure: function(){
            var vm = this;
            $(vm.eleRefUnitUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'referUnitUUID', $(vm.eleRefUnitUUID).val());
                var url = vm.loadModuleURL + "?uuid=" + $(vm.eleRefUnitUUID).val();
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                            container: $('.main.message-container')
                        });
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.content, 'refMaterialUnitName', content.name);
                });
            });

            $(vm.eleUnitTypeMap).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'unitType', $(vm.eleUnitTypeMap).val());
            });
            $(vm.eleUnitCategoryMap).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'unitCategory', $(vm.eleUnitCategoryMap).val());
            });
            $(vm.eleSystemCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'systemCategory', $(vm.eleSystemCategory).val());
            });

        },


        displayForEdit: function () {
            if (this.author.actionCode.Edit === true) {
                return true;
            }
            return undefined;
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: vm.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'StandardMaterialUnit',
                    callback: vm.setNodeI18nPropertiesCore
                }]
            });
        },


        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if ( processMode * 1 === PROCESSMODE_NEW) {
                // in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                ServiceUtilityHelper.httpRequest({
                    url:vm.newModuleServiceURL,
                    $http:vm.$http,
                    method:'post',
                    requestData: requestData,
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        vm.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if ( processMode * 1 === PROCESSMODE_EDIT ) {
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    initAuthor: function(author){vm.$set(vm, 'author', author);},
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }
        },

        saveModule: function () {
            var vm = this;
            ServiceUtilityHelper.defSaveModuleWrapper({
                vm: vm,
                editorPage: "StandardMaterialUnitEditor.html",
                fnGetBaseUUID: function (){
                    return vm.content.uuid;
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);

        },

        refreshEditView: function () {
            var baseUUID = this.content.uuid;
            window.location.href = genCommonEditURL("StandardMaterialUnitEditor.html", baseUUID);

        },

        loadRefUnitSelectList: function (content) {
            var vm = this;
            ServiceUtilityHelper.loadModelMetaRequest({
                url: vm.getRefUnitListSelectURL,
                $http: vm.$http,
                idField: 'uuid',
                textField: 'id',
                initValue: vm.content.referUnitUUID,
                element: '#' + vm.eleRefUnitUUID,
                errorHandle: vm.errorHandle
            });
        },

        loadUnitTypeSelectList: function (content) {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getUnitTypeMapURL,
                $http: vm.$http,
                initValue: vm.content.unitType,
                element: vm.eleUnitTypeMap,
                errorHandle: vm.errorHandle
            });
        },

        loadUnitCategorySelectList: function (content) {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getUnitCategoryMapURL,
                $http: vm.$http,
                initValue: vm.content.unitCategory,
                element: vm.eleUnitCategoryMap,
                formatMeta: StandardMaterialUnitManager.formatUnitCategory,
                errorHandle: vm.errorHandle
            });
        },

        loadSystemCategoryMap: function (content) {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getSystemCategoryMapURL,
                $http: vm.$http,
                initValue: vm.content.systemCategory,
                element: vm.eleSystemCategory,
                formatMeta: StandardMaterialUnitManager.formatSystemCategory,
                errorHandle: vm.errorHandle
            });
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm, 'content', content);
            vm.loadUnitTypeSelectList(content);
            vm.loadUnitCategorySelectList(content);
            vm.loadRefUnitSelectList(content);
            vm.loadSystemCategoryMap(content);
        }

    }
});
