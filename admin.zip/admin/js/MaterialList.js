var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: '',
            modelTitle:'',
            reportTitle:'物料列表'
        },
        processButtonMeta:[],
        author:{
            resourceId:'Material',
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        serviceUIMeta: {},
        downloadExcelURL: '../material/downloadExcel.html',
        searchModuleURL: '../material/searchModuleService.html'
    },

    created: function(){
        this.initSubComponents();
    },

    mounted: function(){
        this.initAuthorResourceCheck();
    },

    methods: {

        initAuthorResourceCheck: function(){
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function (){
            Vue.component('material-init', MaterialInit);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                downloadExcel: {
                    formatClass: vm.displayForExcel,
                    callback: vm.downloadExcel
                },
                uploadExcel: {
                    formatClass: vm.displayForExcel,
                    callback: vm.uploadExcel
                },
                newModule: {
                    formatClass: vm.displayForEdit,
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        searchModule: function () {
            listVar.searchModuleList();
        },

        uploadExcel: function(){
            listVar.uploadExcel();
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        downloadExcel: function () {
            var vm = this;
            var excelType = ServiceUIMetaProxy.filterKeyValue(vm.serviceUIMeta, 'excelType');
            ServiceExcelHelper.downloadExcel({
                url: vm.downloadExcelURL,
                $http: vm.$http,
                excelType: excelType,
                busyLoader: vm.$refs.refBusyLoader,
                requestData: searchModel.content,
                reportTitle: listVar.label.modelTitle,
                errorHandle: listVar.errorHandle
            });
        },

        newModule: function () {
            this.$refs.refMaterialInit.initCreation();
        },

        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});

var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            materialCategory: "",
            name: "",
            uuid: "",
            materialTypeUUID: "",
            id: "",
            materialTypeName: "",
            materialTypeId: ""
        },

        label: MaterialManager.label.material,
        controlAreaArray: ['.area0', '.area1'],
        eleRefMaterialType: '#x_refMaterialType',
        eleStatus:'#x_status',
        eleRefSupplyType: '#x_refSupplyType',
        eleRefCargoType: '#x_refCargoType',
        eleOperationMode: '#x_operationMode',
        eleMatQualityInspectFlag: '#x_matQualityInspectFlag',
        eleRefMaterialCategory: '#x_refMaterialCategory',
        loadMaterialTypeSelectListURL: '../materialType/loadModuleListService.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            MaterialManager.loadDefaultMetaBatch({
                'vm': vm,
                'addEmptyFlag': true,
                'uiModel':vm.content
            });
        });
    },

    methods: {
        clearSearch: function () {
            clearSearchModel(this.content);
        },
        /**
         * Initial register sub component
         */
        initSubComponents: function(){
            "use strict";
            Vue.component("expand-button-pair", ExpandButtonPair);
        },

        initSelectConfigure: function () {
            var vm = this;
            MaterialManager.initDefSelectConfigure({
                'vm':vm,
                'uiModel': vm.content
            });
        }
    }
});

var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: MaterialManager.label.material,
        configMetaUploadExcel:{
            uploadAttachmentURL: '../material/uploadExcel.html',
            successCallback:undefined
        },

        loadModuleListURL: '../material/loadModuleListService.html',
        preLockURL: '../material/preLockService.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
        this.setI18nProperties(processModel.initProcessButtonMeta);
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('logistics', 'Material');
            this.loadModuleList();
        });
    },

    methods: {

        initSubComponents: function(){
            "use strict";
            Vue.component("excel-upload-modal", ExcelUploadModal);
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },


        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties, serviceUIMeta: processModel.serviceUIMeta,
                fnCallback: fnCallback, modelId: 'Material', coreModelId: 'Material',
                label: [vm.label, processModel.label, searchModel.label], vm: processModel, errorHandle: vm.errorHandle,
                configList: [{
                    name: 'Material',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        refreshListView: function () {
            window.location.href = "MaterialList.html";
        },

        searchModuleList: function () {
            this.$refs.dataTableFrame.searchModuleList();
        },

        buildSearchData: function (data) {
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../material/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'id',
                labelKey: 'id',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.Material,
                    uuidFieldName: 'uuid'
                }
            }, {
                fieldName: 'name',
                labelKey: 'name',
                minWidth: '180px'
            },{
                fieldName: 'statusValue',
                fieldKey: 'status',
                labelKey: 'status',
                iconArray: MaterialManager.getStatusIconArray()
            }, {
                fieldName: 'materialCategoryValue',
                labelKey: 'materialCategory',
                fieldKey: 'materialCategory',
                iconArray: MaterialManager.getMaterialCategoryIconArray()
            }, {
                fieldName: 'materialTypeName',
                labelKey: 'materialTypeName',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.MaterialType,
                    uuidFieldName: 'refMaterialType'
                }
            },{
                fieldName: 'packageStandard',
                labelKey: 'packageStandard',
                minWidth: '150px'
            }];
            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        },

        uploadExcel: function () {
            // refresh success call back
            var vm = this;
            this.$set(vm.configMetaUploadExcel, 'successCallback', vm.refreshListView);
            this.$refs.excelUploadModal.popup(vm.configMetaUploadExcel);
        },

        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                author:processModel.author,
                $http:vm.$http,
                editorPage:"MaterialEditor.html",
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        }
    }
});
