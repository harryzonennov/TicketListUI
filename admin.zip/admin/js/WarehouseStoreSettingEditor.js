var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: {
            safeStoreCalculateCategory: '',
            maxStoreRatio: '',
            dataSourceType: '',
            maxSafeStoreAmount: '',
            minStoreRatio: '',
            errorType: '',
            minSafeStoreAmount: '',
            targetAverageStoreAmount: '',
            warehouseStoreSettingSection: '',
            msgSaveOK: '',
            msgSaveOKComment: '',
            msgConnectFailure: '',
            msgUnknowSystemFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            save: '',
            exit: '',
            close: '',
            refMaterialSKUName:'',
            refMaterialSKUId:'',
            pageTitle:'',
            parentPageTitle:'',
            deleteWarnTitle: '',
            deleteWarnText: '',
            cancel: '',
            commit: '',
            confirm: ''
        },
        content: {
            refMaterialSKUUUID: '',
            refActiveSysWarnMsgUUID: '',
            maxSafeStoreUnitUUID: '',
            minSafeStoreUnitUUID: '',
            refNodeName: '',
            targetAverageStoreUnitUUID: '',
            refUUID: '',
            safeStoreCalculateCategory: '',
            maxStoreRatio: '',
            dataSourceType: '',
            maxSafeStoreAmount: '',
            minStoreRatio: '',
            errorType: '',
            parentNodeId:'',
            minSafeStoreAmount: '',
            targetAverageStoreAmount: '',
            refWarehouseId:''
        },
        author:{
            resourceId:'WarehouseStoreSetting',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        STORE_CATE:{
            AMOUNT:1,
            RATIO:2
        },
        eleAverageStoreUnitUUID: '#x_averageStoreUnitUUID',
        eleMaxSafeStoreUnitUUID: '#x_maxSafeStoreUnitUUID',
        eleMinSafeStoreUnitUUID: '#x_minSafeStoreUnitUUID',
        eleSafeStoreCalculateCategory: '#x_safeStoreCalculateCategory',
        eleDataSourceType: '#x_dataSourceType',
        loadModuleEditURL: '../warehouseStoreSetting/loadModuleEditService.html',
        loadMaterialSKUUnitListURL: '../materialStockKeepUnit/getAllMaterialSKUUnitList.html',
        saveModuleURL: '../warehouseStoreSetting/saveModuleService.html',
        exitModuleURL: '../warehouseStoreSetting/exitEditor.html',
        newModuleServiceURL: '../warehouseStoreSetting/newModuleService.html',
        getDataSourceTypeMapURL: '../warehouseStoreSetting/getDataSourceTypeMap.html',
        getStoreCalculateMapURL: '../warehouseStoreSetting/getStoreCalculateMap.html'

    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'Warehouse');
            this.setI18nProperties();
            this.loadModuleEdit();
            this.initAuthorResourceCheck();
            this.initSelectConfigure();
        });
    },

    methods: {

        initAuthorResourceCheck: function(){
            var vm = this;
            var authorPromise = ServiceApplicationFactory.getAuthorizationObject(this.$http, this.author.resourceId, this.author.actionCode);
            authorPromise.then(function(oResult){
                vm.author = oResult;
            }, function (reason) {
                // don't do anything
            });
        },

        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.deleteWarnTitle = $.i18n.prop('deleteWarnTitle');
            this.label.deleteWarnText = $.i18n.prop('deleteWarnText');
            this.label.cancel = $.i18n.prop('cancel');
            this.label.commit = $.i18n.prop('commit');
            this.label.confirm = $.i18n.prop('confirm');
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            this.label.safeStoreCalculateCategory = $.i18n.prop('safeStoreCalculateCategory');
            this.label.maxStoreRatio = $.i18n.prop('maxStoreRatio');
            this.label.dataSourceType = $.i18n.prop('dataSourceType');
            this.label.maxSafeStoreAmount = $.i18n.prop('maxSafeStoreAmount');
            this.label.minStoreRatio = $.i18n.prop('minStoreRatio');
            this.label.errorType = $.i18n.prop('errorType');
            this.label.parentPageTitle = $.i18n.prop('parentPageTitle');
            this.label.pageTitle = $.i18n.prop('pageTitle');

            this.label.refMaterialSKUId = $.i18n.prop('refMaterialSKUId');
            this.label.refMaterialSKUName = $.i18n.prop('refMaterialSKUName');
            this.label.minSafeStoreAmount = $.i18n.prop('minSafeStoreAmount');
            this.label.targetAverageStoreAmount = $.i18n.prop('targetAverageStoreAmount');
            this.label.warehouseStoreSettingSection = $.i18n.prop('warehouseStoreSettingSection');

        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'WarehouseStoreSetting', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });

        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        loadMaterialSKUUnitSelectList: function (content) {
            var vm = this;
            var requestData = {"baseUUID": content.refMaterialSKUUUID};
            this.$http.post(vm.loadMaterialSKUUnitListURL, requestData).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    if(vm.eleAverageStoreUnitUUID){
                        $(vm.eleAverageStoreUnitUUID).select2({
                            data: resultList
                        });
                        if(content.targetAverageStoreUnitUUID){
                            $(vm.eleAverageStoreUnitUUID).val(content.targetAverageStoreUnitUUID);
                            $(vm.eleAverageStoreUnitUUID).trigger("change");
                        }
                    }

                    if(vm.eleMaxSafeStoreUnitUUID){
                        $(vm.eleMaxSafeStoreUnitUUID).select2({
                            data: resultList
                        });
                        if(content.targetAverageStoreUnitUUID){
                            $(vm.eleMaxSafeStoreUnitUUID).val(content.maxSafeStoreUnitUUID);
                            $(vm.eleMaxSafeStoreUnitUUID).trigger("change");
                        }

                    }

                    if(vm.eleMinSafeStoreUnitUUID){
                        $(vm.eleMinSafeStoreUnitUUID).select2({
                            data: resultList
                        });
                        if(content.minSafeStoreUnitUUID){
                            $(vm.eleMinSafeStoreUnitUUID).val(content.minSafeStoreUnitUUID);
                            $(vm.eleMinSafeStoreUnitUUID).trigger("change");
                        }
                    }
                }, 0);
            });
        },

        _setCaculateBlock: function(safeStoreCalculateCategory){
            var vm = this;
            if(safeStoreCalculateCategory * 1 === vm.STORE_CATE.AMOUNT * 1){
                $(".calculateByAmount").show();
                $(".calculateByRatio").hide();
            }else{
                $(".calculateByAmount").hide();
                $(".calculateByRatio").show();
            }
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleSafeStoreCalculateCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                var safeStoreCalculateCategory = $(vm.eleSafeStoreCalculateCategory).val();
                vm.$set(vm.content, 'safeStoreCalculateCategory', safeStoreCalculateCategory);
                vm._setCaculateBlock(safeStoreCalculateCategory);
            });
            $(vm.eleDataSourceType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'dataSourceType', $(vm.eleDataSourceType).val());
            });

            $(vm.eleAverageStoreUnitUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'targetAverageStoreUnitUUID', $(vm.eleAverageStoreUnitUUID).val());
            });

            $(vm.eleMaxSafeStoreUnitUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'maxSafeStoreUnitUUID', $(vm.eleMaxSafeStoreUnitUUID).val());
            });

            $(vm.eleMinSafeStoreUnitUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'minSafeStoreUnitUUID', $(vm.eleMinSafeStoreUnitUUID).val());
            });

        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if (processMode == PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                var url = this.newModuleServiceURL;
                baseUUID = getUrlVar("baseUUID");
                var uuid = getUrlVar("uuid");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID, "uuid", uuid);
                this.$http.post(url, requestData).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }
            if (processMode == PROCESSMODE_EDIT) {
// In case [Edit mode]
                var url = this.loadModuleEditURL + "?uuid=" + baseUUID;
                this.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }

        },

        setPageHeaderLink: function () {
            var vm = this;
            var baseUUID = vm.content.parentNodeUUID;
            var baseDocURL = genCommonEditURL("WarehouseEditor.html", baseUUID);
            var ser = new XMLSerializer();
            var xmlDoc = document.implementation.createDocument("", "", null);
            $("#x_linkToDoc").empty();
            var docText = vm.label.parentPageTitle + ":" + vm.content.refWarehouseId;
            var linkToRootDocElement = DocumentOrderMatPopInfo.createPageHeaderLinkToRootDoc(xmlDoc, docText, baseDocURL);
            var htmlContent = ser.serializeToString(linkToRootDocElement);
            $("#x_linkToDoc").prepend(htmlContent);

        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            this.$http.post(vm.saveModuleURL, vm.content).then(function (response) {
                $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                this.setModuleToUI(JSON.parse(response.data).content);
                var processMode = getUrlVar(LABEL_PROCESSMODE);
                if (processMode && processMode == PROCESSMODE_NEW) {
                    var baseUUID = vm.content.uuid;
                    if (baseUUID) {
                        window.location.href = genCommonEditURL("WarehouseStoreSettingEditor.html", baseUUID);
                    }
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.parentNodeUUID;
            window.location.href = genCommonEditURL("WarehouseEditor.html", baseUUID);

        },

        refreshEditView: function () {
            var baseUUID = this.content.uuid;
            window.location.href = genCommonEditURL("WarehouseStoreSettingEditor.html", baseUUID);

        },

        getSafeStoreCalculateCategoryMap: function (content) {
            var vm = this;
            this.$http.get(this.getStoreCalculateMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleSafeStoreCalculateCategory).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleSafeStoreCalculateCategory).val(content.safeStoreCalculateCategory);
                    $(vm.eleSafeStoreCalculateCategory).trigger("change");
                }, 0);
            });
        },

        getDataSourceTypeMap: function (content) {
            var vm = this;
            this.$http.get(this.getDataSourceTypeMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleDataSourceType).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleDataSourceType).val(content.safeStoreCalculateCategory);
                    $(vm.eleDataSourceType).trigger("change");
                }, 0);
            });
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm, 'content', content);
            this._setCaculateBlock(content.safeStoreCalculateCategory);
            vm.getSafeStoreCalculateCategoryMap(content);
            $(vm.eleSafeStoreCalculateCategory).val(content.safeStoreCalculateCategory);
            $(vm.eleSafeStoreCalculateCategory).trigger("change");
            this.setPageHeaderLink();
            this.getDataSourceTypeMap(content);
            this.loadMaterialSKUUnitSelectList(content);
        }

    }
});
