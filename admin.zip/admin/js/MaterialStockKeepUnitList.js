var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: "",
            search: ""
        },
        processButtonMeta:[],
        author:{
            resourceId:ServiceModuleConstants.MaterialStockKeepUnit,
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        serviceUIMeta: {},
        downloadExcelURL: '../materialStockKeepUnit/downloadExcel.html',
        searchModuleURL: '../materialStockKeepUnit/searchModuleService.html'
    },

    created: function(){
        this.initAuthorResourceCheck();
        this.initSubComponents();
    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                downloadExcel: {
                    formatClass: vm.displayForExcel,
                    callback: vm.downloadExcel
                },
                newModule: {
                    formatClass: vm.displayForEdit,
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        searchModule: function () {
            listVar.searchModuleList();
        },

        downloadExcel: function () {
            var vm = this;
            var excelType = ServiceUIMetaProxy.filterKeyValue(vm.serviceUIMeta, 'excelType');
            ServiceExcelHelper.downloadExcel({
                url: vm.downloadExcelURL,
                $http: vm.$http,
                excelType: excelType,
                busyLoader: vm.$refs.refBusyLoader,
                requestData: searchModel.content,
                reportTitle: listVar.label.modelTitle,
                errorHandle: listVar.errorHandle
            });
        },

        newModule: function () {
            listVar.newModuleModal();
        },

        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            materialCategory: "",
            name: "",
            uuid: "",
            supplyType: '',
            materialTypeUUID: "",
            id: "",
            traceMode:"",
            materialTypeName: "",
            materialTypeId:""
        },
        controlAreaArray: ['.area0', '.area1', '.area2'],
        label:MaterialStockKeepUnitManager.label.materialStockKeepUnit,
        eleRefSupplyType: '#x_refSupplyType',
        eleTraceMode: '#x_traceMode',
        eleRefMaterialType: '#x_refMaterialType',
        eleStatus:'#x_status',
        eleRefCargoType: '#x_refCargoType',
        eleOperationMode: '#x_operationMode',
        eleMatQualityInspectFlag: '#x_matQualityInspectFlag',
        eleRefMaterialCategory: '#x_refMaterialCategory',
        loadSupplyTypeListURL: '../material/getSupplyType.html',
        getTraceModeURL: '../materialStockKeepUnit/getTraceMode.html',
        loadMaterialTypeSelectListURL: '../materialType/loadModuleListService.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            MaterialManager.loadDefaultMetaBatch({
                'vm': vm,
                'addEmptyFlag': true,
                'uiModel':vm.content
            });
            MaterialStockKeepUnitManager.loadDefaultMetaBatch({
                'vm': vm,
                'addEmptyFlag': true,
                'uiModel':vm.content
            });
        });
    },

    methods: {
        clearSearch: function () {
            clearSearchModel(this.content);
        },
        /**
         * Initial register sub component
         */
        initSubComponents: function(){
            "use strict";
            Vue.component("expand-button-pair", ExpandButtonPair);
        },

        initSelectConfigure: function () {
            var vm = this;
            MaterialManager.initDefSelectConfigure({
                'vm':vm,
                'uiModel': vm.content
            });
            MaterialStockKeepUnitManager.initDefSelectConfigure({
                'vm':vm,
                'uiModel': vm.content
            });
        },

        switchMultiValueIcon: function(event){
            $(event.target).toggleClass("ion-plus-round");
            $(event.target).toggleClass("ion-minus-round");
        }

    }
});

var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: MaterialStockKeepUnitManager.label.materialStockKeepUnit,
        cache:{
            refMaterialUUID:'',
            refMaterialName:'',
            refMaterialID:''
        },
        author:{
            resourceId:'MaterialStockKeepUnit',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        eleNewMaterialSKUModal: '#x_eleNewMaterialSKUModal',
        eleRefMaterialUUID: '#x_refMaterialUUID',
        loadMaterialURL: '../material/loadModule.html',
        loadMaterialListURL: '../material/loadModuleListService.html',
        loadModuleListURL: '../materialStockKeepUnit/loadLeanModuleListService.html',
        newMaterialSKUURL: '../materialStockKeepUnit/newModuleService.html',
        preLockURL: '../materialStockKeepUnit/preLockService.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('logistics', 'MaterialStockKeepUnit');
            this.setI18nProperties(processModel.initProcessButtonMeta);
            this.loadModuleList();
            this.initSelectConfigure();
            this.loadMaterialSelectList();
        });
    },

    methods: {

        clearSearch: function(){
            clearSearchModel(this.content);
        },

        initSubComponents: function(){
            "use strict";
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleRefMaterialUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache, 'refMaterialUUID', $(vm.eleRefMaterialUUID).val());
                ServiceUtilityHelper.httpRequest({
                    url:vm.loadMaterialURL,
                    uuid:$(vm.eleRefMaterialUUID).val(),
                    $http:vm.$http,
                    errorHandle:ServiceUtilityHelper.handleErrorUIDefault,
                    postHandle:function(oData){
                        var content = oData.content;
                        vm.$set(vm.cache, 'refMaterialName', content.name);
                        vm.$set(vm.cache, 'refMaterialID', content.id);
                    }.bind(this)
                });
            });
        },

        newModuleModal:function(){
            $(this.eleNewMaterialSKUModal).modal('toggle');
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nCommonReflective(this.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nCommonReflective(searchModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nCommonReflective(processModel.label, $.i18n.prop, true);
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        refreshTableItems: function(items){
            this.datatable = new ServiceDataTable(this.tableId);
            this.$set(vm, 'items', items);
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties, serviceUIMeta: processModel.serviceUIMeta,
                fnCallback: fnCallback, modelId: 'MaterialStockKeepUnit', coreModelId: 'MaterialStockKeepUnit',
                label: [vm.label, processModel.label, searchModel.label], vm: processModel, errorHandle: vm.errorHandle,
                configList:[{
                    name: 'MaterialStockKeepUnit',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        loadMaterialSelectList: function () {
            var vm = this;

            ServiceUtilityHelper.httpRequest({
                url:vm.loadMaterialListURL,
                $http:vm.$http,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault,
                postHandle:function(oData){
                    var content = oData.content;
                    var resultList = formatSelectResult(content, 'uuid', 'name');
                    setTimeout(function () {
                        $(vm.eleRefMaterialUUID).select2({
                            data: resultList
                        });
                        if(resultList && resultList.length > 0){
                            vm.$set(vm.cache, 'refMaterialUUID', resultList[0].id);
                        }
                    }, 0);
                }.bind(this)
            });
        },

        createMaterialSKU:function(){
            var vm = this;
            var paras = {};
            paras.baseUUID = vm.cache.refMaterialUUID;
            paras.processMode = PROCESSMODE_NEW;
            window.location.href = "MaterialStockKeepUnitEditor.html" + "?" + urlEncode(paras);
        },

        searchModuleList: function(){
            this.$refs.dataTableFrame.searchModuleList();
        },

        buildSearchData: function(data){
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },


        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../materialStockKeepUnit/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'id',
                labelKey: 'id',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.MaterialStockKeepUnit,
                    uuidFieldName: 'uuid'
                }
            }, {
                fieldName: 'name',
                labelKey: 'name',
                minWidth: '180px'
            },{
                fieldName: 'statusValue',
                fieldKey: 'status',
                labelKey: 'status',
                iconArray: MaterialManager.getStatusIconArray()
            }, {
                fieldName: 'materialCategoryValue',
                labelKey: 'materialCategory',
                fieldKey: 'materialCategory',
                iconArray: MaterialManager.getMaterialCategoryIconArray()
            }, {
                fieldName: 'traceModeValue',
                labelKey: 'traceMode',
                fieldKey: 'traceMode',
                iconArray: MaterialStockKeepUnitManager.getTraceModeArray()
            },{
                fieldName: 'materialTypeName',
                labelKey: 'materialTypeName',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.MaterialType,
                    uuidFieldName: 'refMaterialType'
                }
            },{
                fieldName: 'packageStandard',
                labelKey: 'packageStandard',
                minWidth: '150px'
            }];
            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        },


        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                $http:vm.$http,
                author:processModel.author,
                editorPage:"MaterialStockKeepUnitEditor.html",
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        }
    }
});
