var dataVar = new Vue({
    el: "#x_data",
    mixins: [MaterialConfigureTemplateManager.labelTemplate, ServiceEditorControlHelper.defControlMinxin],
    data: {
        label: MaterialConfigureTemplateManager.label.materialConfigureTemplate,
        content: {
            materialConfigureTemplateUIModel: MaterialConfigureTemplateManager.content.materialConfigureTemplateUIModel,
            matDecisionValueSettingUIModelList: [],
            matConfigHeaderConditionUIModelList: [],
            matConfigExtPropertySettingUIModelList: []
        },
        deleteMatConfigHeaderConditionURL:'../matConfigHeaderCondition/deleteService.html',
        deleteMatConfigExtPropertySettingURL:'../matConfigExtPropertySetting/deleteService.html',
        deleteMatDecisionValueSettingURL:'../matDecisionValueSetting/deleteService.html',
        newModuleServiceURL: '../materialConfigureTemplate/newModuleService.html',
        newMatDecisionValueSettingServiceURL: '../matDecisionValueSetting/newModuleService.html',
        newMatConfigHeaderConditionServiceURL: '../matConfigHeaderCondition/newModuleService.html',
        newMatConfigExtPropertySettingServiceURL: '../matConfigExtPropertySetting/newModuleService.html',
        exitURL: 'MaterialConfigureTemplateList.html',
        exitModuleURL: '../materialConfigureTemplate/exitEditor.html'
    },

    created: function(){
        this.initSubComponentsController();
    },

    mounted: function () {
        NavigationPanelIns.initNavigation('systemAdmin', 'MaterialConfigureTemplate');
    },

    methods: {

        initSubComponentsController: function (){
            Vue.component("mat-config-value-setting-panel", MatConfigValueSettingPanel);
            Vue.component("mat-config-ext-property-setting-panel", MatConfigExtPropertySettingPanel);
            Vue.component("mat-config-header-condition-panel", MatConfigHeaderConditionPanel);
            Vue.component("service-tree-template", ServiceTreeTemplate);
        },

        /**
         * @Overwrite: Get document type for each edit controller
         */
        getDocumentType: function () {
            return DocumentConstants.DummyDocumentType.MaterialConfigureTemplate;
        },

        getServiceManager: function () {
            return MaterialConfigureTemplateManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "MaterialConfigureTemplateEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.materialConfigureTemplateUIModel.uuid;
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'materialConfigureTemplateUIModel', content.materialConfigureTemplateUIModel);
            vm.$set(vm.content, 'matDecisionValueSettingUIModelList', content.matDecisionValueSettingUIModelList);
            vm.$set(vm.content, 'matConfigHeaderConditionUIModelList', content.matConfigHeaderConditionUIModelList);
            vm.$set(vm.content, 'matConfigExtPropertySettingUIModelList', content.matConfigExtPropertySettingUIModelList);
            vm.postUpdateUIModel();
        },
        
        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'MaterialConfigureTemplateEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: MaterialConfigureTemplateManager,
                coreModelId: 'MaterialConfigureTemplate',
                i18nPath: 'coreFunction/',
                helpDocumentName: ['MaterialConfigureTemplateHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: vm.displayForEdit,
                        callback: vm.saveModule
                    },
                    exit: {
                        callback: vm.exitModule
                    }
                },
                tabMetaList: [{
                    tabId: 'materialConfigureTemplateSection',
                    tabTitleKey: 'materialConfigureTemplateSection',
                    titleLabelKey: 'materialConfigureTemplateSection',
                    titleHelpKey: 'materialConfigureTemplate.materialConfigureTemplateSection',
                    titleIcon: 'md md-straighten content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'materialConfigureTemplateSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'materialConfigureTemplateUIModel',
                        tabTitleKey: 'materialConfigureTemplateSection',
                        titleLabelKey: 'materialConfigureTemplateSection',
                        titleHelpKey: 'materialConfigureTemplate.materialConfigureTemplateSection',
                        titleIcon: 'md md-texture content-portlet-title',
                        fieldMetaList: [{
                            fieldName: 'id',
                            required: true,
                            newRow: true
                        },{
                            fieldName: 'name',
                            required: true
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        }]
                    },{
                        sectionId: 'matConfigHeaderConditionSection',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        tabTitleKey: 'matConfigHeaderConditionSection',
                        titleLabelKey: 'matConfigHeaderConditionSection',
                        labelPath: 'matConfigHeaderCondition',
                        parentContentPath: 'matConfigHeaderConditionUIModelList',
                        titleHelpKey: 'materialConfigureTemplate.matConfigHeaderConditionSection',
                        deleteModuleUrl:vm.deleteMatConfigHeaderConditionURL,
                        titleIcon: 'md md-center-focus-strong',
                        editModuleFlag: true,
                        editModuleModalFlag: true,
                        deleteModuleFlag:true,
                        refItemName: 'matHeaderPanel',
                        detailedPageUrl:'MatConfigHeaderConditionEditor.html',
                        requiredSubmit: true,
                        scrollX: true,
                        embedProcessButtonMeta: {
                            addTitle: 'addMatConfigHeaderConditionTitle',
                            newModuleFlag: true,
                            addLabel: 'addMatConfigHeaderCondition'
                        },
                        fieldMetaList: [{
                            fieldName: 'matConfigHeaderConditionUIModel.uuid',
                            labelKey: 'id',
                        },   {
                            fieldName: 'matConfigHeaderConditionUIModel.refNodeInstValue',
                            labelKey: 'refNodeInstValue',
                            minWidth: '180px'
                        }, {
                            fieldName: 'matConfigHeaderConditionUIModel.logicOperatorValue',
                            fieldKey: 'matConfigHeaderConditionUIModel.logicOperator',
                            labelKey: 'logicOperator',
                            iconArray: SystemStandrdMetadataProxy.getLogicOperatorIconArray(),
                            minWidth: '180px'
                        },{
                            fieldName: 'matConfigHeaderConditionUIModel.fieldName',
                            labelKey: 'fieldName',
                            minWidth: '180px'
                        }, {
                            fieldName: 'matConfigHeaderConditionUIModel.fieldValue',
                            labelKey: 'fieldValue',
                            minWidth: '150px'
                        }, {
                            fieldName: 'matConfigHeaderConditionUIModel.valueId',
                            labelKey: 'valueId',
                            minWidth: '150px'
                        }, {
                            fieldName: 'matConfigHeaderConditionUIModel.valueName',
                            labelKey: 'valueName',
                            minWidth: '150px'
                        }]
                    }]
                }, {
                    tabId: 'matConfigExtPropertySettingSection',
                    tabTitleKey: 'matConfigExtPropertySettingSection',
                    titleLabelKey: 'matConfigExtPropertySettingSection',
                    titleHelpKey: 'materialConfigureTemplate.matConfigExtPropertySettingSection',
                    titleIcon: 'md md-straighten content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'matConfigExtPropertySettingSection',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        parentContentPath: 'matConfigExtPropertySettingUIModelList',
                        tabTitleKey: 'matConfigExtPropertySettingSection',
                        labelPath: 'matConfigExtPropertySetting',
                        titleLabelKey: 'matConfigExtPropertySettingSection',
                        titleHelpKey: 'materialConfigureTemplate.matConfigHeaderConditionSection',
                        titleIcon: 'md md-straighten content-portlet-title',
                        deleteModuleUrl:vm.deleteMatConfigExtPropertySettingURL,
                        editModuleFlag: true,
                        editModuleModalFlag: true,
                        deleteModuleFlag:true,
                        refItemName: 'matHeaderPanel',
                        detailedPageUrl:'MatConfigHeaderConditionEditor.html',
                        requiredSubmit: true,
                        scrollX: true,
                        embedProcessButtonMeta: {
                            addTitle: 'addMatConfigExtPropertySetting',
                            newModuleFlag: true,
                            addLabel: 'addMatConfigExtPropertySetting'
                        },
                        fieldMetaList: [{
                            fieldName: 'matConfigExtPropertySettingUIModel.uuid',
                        },   {
                            fieldName: 'matConfigExtPropertySettingUIModel.id',
                            labelKey: 'id',
                            minWidth: '180px'
                        }, {
                            fieldName: 'matConfigExtPropertySettingUIModel.name',
                            labelKey: 'name',
                            minWidth: '180px'
                        },{
                            fieldName: 'matConfigExtPropertySettingUIModel.fieldTypeValue',
                            fieldKey: 'matConfigExtPropertySettingUIModel.fieldType',
                            labelKey: 'fieldType',
                            minWidth: '180px'
                        }, {
                            fieldName: 'matConfigExtPropertySettingUIModel.measureFlagValue',
                            fieldKey: 'matConfigExtPropertySettingUIModel.measureFlag',
                            labelKey: 'measureFlag',
                            iconArray: SystemStandrdMetadataProxy.getDefaultSwitchIconArray(),
                            minWidth: '150px'
                        }, {
                            fieldName: 'matConfigExtPropertySettingUIModel.qualityInspectValue',
                            fieldKey: 'matConfigExtPropertySettingUIModel.qualityInspectFlag',
                            labelKey: 'qualityInspectFlag',
                            iconArray: SystemStandrdMetadataProxy.getDefaultSwitchIconArray(),
                            minWidth: '150px'
                        }, {
                            fieldName: 'matConfigExtPropertySettingUIModel.refUnitValue',
                            fieldKey: 'refUnitValue',
                            labelKey: 'refUnitValue',
                            minWidth: '150px'
                        }, {
                            fieldName: 'matConfigExtPropertySettingUIModel.rawValue',
                            minWidth: '150px'
                        }]
                    }]
                }, {
                    tabId: 'matDecisionValueSettingSection',
                    tabTitleKey: 'matDecisionValueSettingSection',
                    titleLabelKey: 'matDecisionValueSettingSection',
                    titleHelpKey: 'materialConfigureTemplate.matDecisionValueSettingSection',
                    titleIcon: 'md md-tune content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'matDecisionValueSettingSection',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        tabTitleKey: 'matDecisionValueSettingSection',
                        titleLabelKey: 'matDecisionValueSettingSection',
                        labelPath: 'matDecisionValueSetting',
                        parentContentPath: 'matDecisionValueSettingUIModelList',
                        titleHelpKey: 'materialConfigureTemplate.matDecisionValueSettingSection',
                        titleIcon: 'md md-tune content-portlet-title',
                        deleteModuleUrl:vm.deleteMatDecisionValueSettingURL,
                        editModuleFlag: true,
                        editModuleModalFlag: true,
                        deleteModuleFlag: true,
                        refItemName: 'matDecisionValuePanel',
                        detailedPageUrl:'MatConfigValueSettingEditor.html',
                        requiredSubmit: true,
                        scrollX: true,
                        embedProcessButtonMeta: {
                            addTitle: 'addMatDecisionValueSettingTitle',
                            newModuleFlag: true,
                            addLabel: 'addMatDecisionValueSetting'
                        },
                        fieldMetaList: [{
                            fieldName: 'matDecisionValueSettingUIModel.uuid',
                        },  {
                            fieldName: 'matDecisionValueSettingUIModel.valueUsageValue',
                            fieldKey: 'valueUsage',
                            labelKey: 'valueUsage',
                            minWidth: '180px'
                        }, {
                            fieldName: 'matDecisionValueSettingUIModel.id',
                            labelKey: 'id',
                            minWidth: '180px'
                        }, {
                            fieldName: 'matDecisionValueSettingUIModel.name',
                            labelKey: 'name',
                            minWidth: '180px'
                        },{
                            fieldName: 'matDecisionValueSettingUIModel.valueName',
                            labelKey: 'valueName',
                            minWidth: '180px'
                        }, {
                            fieldName: 'matDecisionValueSettingUIModel.valueId',
                            labelKey: 'valueId',
                            minWidth: '150px'
                        }, {
                            fieldName: 'matDecisionValueSettingUIModel.rawValue',
                            labelKey: 'rawValue',
                            minWidth: '150px'
                        }]
                    }]
                },  {
                    tabId: 'materialConfigureTemplateTreeSection',
                    tabTitleKey: 'materialConfigureTemplateTreeSection',
                    titleLabelKey: 'materialConfigureTemplateTreeSection',
                    titleHelpKey: 'materialConfigureTemplate.materialConfigureTemplateTreeSection',
                    titleIcon: 'md md-straighten content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'materialConfigureTemplateTreeSection',
                        sectionCategory: AsyncSection.sectionCategory.TREE,
                        tabTitleKey: 'materialConfigureTemplateTreeSection',
                        titleLabelKey: 'materialConfigureTemplateTreeSection',
                        parentContentPath: 'materialConfigureTemplateUIModel',
                        titleHelpKey: 'materialConfigureTemplate.materialConfigureTemplateTreeSection',
                        titleIcon: 'md md-straighten content-portlet-title',
                        editModuleFlag: true,
                        refItemName: 'matHeaderPanel',
                        detailedPageUrl:'MatConfigHeaderConditionEditor.html',
                        requiredSubmit: true,
                        treeContent: {
                            subPath:'materialConfigureTemplateUIModel',
                            iconTitle: 'md md-texture content-lightblue',
                            spanContentPath:'id-name',
                            modelTitleKey:'modelTitle',
                            subNodeSettings:[{
                                modelTitleKey:'matConfigExtPropertySetting.modelTitle',
                                nodeInstId:'matConfigExtPropertySetting',
                                iconTitle:'md md-straighten content-lightblue',
                                newModule:'addMatConfigExtPropertySetting',
                                editModuleFlag:true,
                                editModuleModalFlag:true,
                                newModuleModalFlag: true,
                                deleteModuleFlag: true,
                                detailedPageUrl:'MatConfigHeaderConditionEditor.html',
                                deleteModuleUrl:vm.deleteMatConfigHeaderConditionURL,
                                refItemName: 'matExtPropertyPanel',
                                helpKey:"materialConfigureTemplate.matConfigExtPropertySettingSection",
                                listPath: 'matConfigExtPropertySettingUIModelList',
                                subPath:'matConfigExtPropertySettingUIModel',
                                spanContentPath:'id-name'
                            },{
                                modelTitleKey:'matConfigHeaderCondition.modelTitle',
                                iconTitle:'md md-center-focus-strong content-lightblue',
                                nodeInstId:'matConfigHeaderCondition',
                                refItemName: 'matHeaderPanel',
                                editModuleFlag:true,
                                editModuleModalFlag:true,
                                newModuleModalFlag: true,
                                deleteModuleFlag: true,
                                detailedPageUrl:'MatConfigHeaderConditionEditor.html',
                                deleteModuleUrl:vm.deleteMatConfigExtPropertySettingURL,
                                helpKey:"materialConfigureTemplate.matConfigHeaderConditionSection",
                                listPath: 'matConfigHeaderConditionUIModelList',
                                subPath:'matConfigHeaderConditionUIModel',
                                spanContentPath:'refNodeInstId'
                            },{
                                modelTitleKey:'matDecisionValueSetting.modelTitle',
                                iconTitle:'md md-tune content-lightblue',
                                nodeInstId:'matDecisionValueSetting',
                                refItemName: 'matDecisionValuePanel',
                                detailedPageUrl:'MatConfigValueSettingEditor.html',
                                deleteModuleUrl:vm.deleteMatDecisionValueSettingURL,
                                editModuleFlag:true,
                                editModuleModalFlag:true,
                                newModuleModalFlag: true,
                                deleteModuleFlag: true,
                                helpKey:"materialConfigureTemplate.matDecisionValueSettingSection",
                                listPath: 'matDecisionValueSettingUIModelList',
                                subPath:'matDecisionValueSettingUIModel',
                                spanContentPath:'valueUsageValue-name'
                            }]
                        }
                    }]
                }]
            };
        }

    }
});
