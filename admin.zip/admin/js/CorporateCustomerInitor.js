var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: {

            msgSystemFailure: '',
            msgUnknowSystemFailure: '',
            buttonConfirm: '',
            buttonCancel: '',
        },
        content: {}
        ,
        confirmCreateURL: ' ../CorporateCustomer/newModuleService.html'
    },


    ready: function () {
        var vm = this;
        this.setI18nProperties();

    }
    ,

    methods: {
        setI18nCommonProperties: function () {
            this.label.msgSystemFailure = $.i18n.prop('msgSystemFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.buttonConfirm = $.i18n.prop('nConfir');
            this.label.buttonCancel = $.i18n.prop('nCance');
            BusyLoader.cleanPageBackground();
        },


        setNodeI18nPropertiesCore: function () {

        },


        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'CorporateCustomer', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
        },


        getI18nPath: function () {
            return 'coreFunction/';
        },


        confirmCreate: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "CorporateCustomerEditor.html.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        }

    }
});
