var  SystemExecutorSettingManager = function(){
};


SystemExecutorSettingManager.label = {
    systemExecutorSetting:{
        id: '',
        executionType: '',
        proxyName: '',
        name: '',
        refActionCode: '',
        executeBatchNumber: '',
        refExecutorId:'',
        refExecutorName:'',
        refExecutorDescription:'',
        note: '',
        authorizationObjectId: '',
        authorizationObjectName: '',
        executeTitle:'',
        systemExecutorSettingSection: '',
        authorizationObjectSection: '',
        systemExecutorLogSection: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        quickEdit: '',
        buttonDelete: '',
        exit: '',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        cancel: '',
        commit: '',
        confirm: '',
        confirmExecuteComment:'',
        confirmExecuteTitle:'',
        execute:'',
        proxyCheckOk:'',
        proxyCheckError:'',
        addSystemExecutorSetting: '',
        addAuthorizationObject: '',
        addSystemExecutorLog: '',
        executeCompleteTitle:'',
        serviceEntityLogItemSection:'',
        executeCompleteComment:'',
        result: '',
        uuid: '',
        logonUserId: '',
        logonUserName: '',
        clearSearch:'',
        clearSearchComment:'',
        advancedSearchCondition: '',
        buttonEdit: '',
        buttonView: ''
    },
    systemExecutorLog: {
        result: '',
        id: '',
        logonUserId: '',
        name: '',
        logonUserName: '',
        note: '',
        executedDate:''
    }
};


SystemExecutorSettingManager.labelTemplate = {
    data: function() {
        return {
            label: {
                "systemExecutorLog":SystemExecutorSettingManager.label.systemExecutorLog
            }
        };
    }
};

SystemExecutorSettingManager.MetaData = {
    executionType:{
        EXECUTIONTYPE_SYSTEMINSTALL:1,
        EXECUTIONTYPE_SYSTEMUPGRADE:2,
        EXECUTIONTYPE_INITIALIZE:3,
        EXECUTIONTYPE_ADMINTOOL:4
    }
};

SystemExecutorSettingManager.getExecutionTypeIconArray = function () {
    "use strict";
    return [
        {id: SystemExecutorSettingManager.MetaData.executionType.EXECUTIONTYPE_SYSTEMINSTALL, iconClass: 'md md-laptop content-green'},
        {id: SystemExecutorSettingManager.MetaData.executionType.EXECUTIONTYPE_SYSTEMUPGRADE, iconClass: 'nmd nmd-queue-play-next content-orange'},
        {id: SystemExecutorSettingManager.MetaData.executionType.EXECUTIONTYPE_INITIALIZE, iconClass: 'md md-repeat content-lightblue'},
        {id: SystemExecutorSettingManager.MetaData.executionType.EXECUTIONTYPE_ADMINTOOL, iconClass: 'nmd nmd-power content-darkblue1'}
    ];
};


/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
SystemExecutorSettingManager.prototype.getI18nWrap = function (fnCallback) {
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "foundation/systemResource/",
        commonCallback: this.setI18nCommonProperties,
        fnCallback: fnCallback,
        configList: [{
            name: 'SystemExecutorSetting',
            callback: this.setNodeI18nPropertiesCore
        },{
            name: 'SystemExecutorLog',
            callback: this.setI18nExecutorLogProperties
        }]
    });
};


/**
 * @override Set Basic path for i18n function.
 * @returns {string}
 */
SystemExecutorSettingManager.getI18nPath = function () {
    return "coreFunction/";
};

SystemExecutorSettingManager.prototype.getI18nCommonMap = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(SystemExecutorSettingManager.label.systemExecutorSetting, $.i18n.prop);
};

SystemExecutorSettingManager.prototype.setNodeI18nPropertiesCore = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(SystemExecutorSettingManager.label.systemExecutorSetting, $.i18n.prop, true);

};

SystemExecutorSettingManager.prototype.setI18nExecutorLogProperties = function () {
    ServiceUtilityHelper.setI18nReflective(SystemExecutorSettingManager.label.systemExecutorLog, $.i18n.prop);
},

SystemExecutorSettingManager.formatExecutionTypeIconClass = function (executionType) {
    "use strict";
    var iconArray = SystemExecutorSettingManager.getExecutionTypeIconArray();
    var $element = ServiceCollectionsHelper.filterArray(executionType, 'id', iconArray);
    if ($element) {
        return $element.iconClass;
    }
};

SystemExecutorSettingManager.formatExecutionType = function (executionType) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(executionType, SystemExecutorSettingManager.getExecutionTypeIconArray(), true);
    return $element;
};

SystemExecutorSettingManager.getExecutorStatusIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.SystemExecutor.status.INIT, iconClass: 'md md-remove-circle-outline content-grey'},
        {id: DocumentConstants.SystemExecutor.status.ACTIVE, iconClass: 'glyphicon glyphicon-ok content-green'},
        {id: DocumentConstants.SystemExecutor.status.ARCHIVE, iconClass:  'md md-sd-card content-grey'}
    ];
};

SystemExecutorSettingManager.formatExecutorStatusIconClass = function (executorStatus) {
    "use strict";
    var iconArray = SystemExecutorSettingManager.getExecutorStatusIconArray();
    var $element = ServiceCollectionsHelper.filterArray(executorStatus, 'id', iconArray);
    if ($element) {
        return $element.iconClass;
    }
};

SystemExecutorSettingManager.formatExecutorStatus = function (executorStatus) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(executorStatus, SystemExecutorSettingManager.getExecutorStatusIconArray(), true);
    return $element;
};

SystemExecutorSettingManager.getLogResultIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.StandardPropety.ExecutionResult.RESULT_SUCCESS, iconClass: 'glyphicon glyphicon-ok content-green'},
        {id: DocumentConstants.StandardPropety.ExecutionResult.RESULT_ERROR, iconClass: 'md md-cancel'},
        {id: DocumentConstants.StandardPropety.ExecutionResult.RESULT_ABORT, iconClass:  'md md-remove-circle-outline content-grey'}
    ];
};

SystemExecutorSettingManager.formatLogResultIconClass = function (logResult) {
    "use strict";
    var iconArray = SystemExecutorSettingManager.getLogResultIconArray();
    var $element = ServiceCollectionsHelper.filterArray(logResult, 'id', iconArray);
    if ($element) {
        return $element.iconClass;
    }
};

SystemExecutorSettingManager.formatLogResult = function (logResult) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(logResult, SystemExecutorSettingManager.getLogResultIconArray(), true);
    return $element;
};


SystemExecutorSettingManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: "SystemExecutorSettingEditor.html",
        url: "../systemExecutorSetting/loadModuleViewService.html",
        label:SystemExecutorSettingManager.label.systemExecutorSetting,
        subPath: 'systemExecutorSettingUIModel',
        getI18nWrap:this.getI18nWrap.bind(vm),
        docType:DocumentConstants.DummyDocumentType.SystemExecutorSetting
    });

    var fieldMetaList = [{
        fieldName:'id'
    },{
        fieldName:'name'
    },{
        fieldName:'executeBatchNumber'
    },{
        fieldName: 'executionTypeValue',
        labelKey: 'executionType',
        fieldKey: 'executionType',
        iconArray:SystemExecutorSettingManager.getExecutionTypeIconArray()
    },{
        fieldName:'authorizationObjectName'
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};


