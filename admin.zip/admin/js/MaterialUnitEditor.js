var dataVar = new Vue({
    el: "#x_data",
    mixins: [ServiceItemEditorHelper.defControlMinxin],
    data: {
        label: MaterialManager.label.materialUnit,
        content: {
            materialUnitUIModel: MaterialManager.content.materialUnitUIModel,
            serviceUIMeta: {},
            materialUnitAttachmentUIModelList: []
        },
        searchStandardUnitURL:'../standardMaterialUnit/searchModuleService.html',
        getPageHeaderModelListURL: '../materialUnit/getPageHeaderModelList.html',
        loadStandardUnitSelectListURL: '../material/getStandardUnit.html'
    },

    mounted: function () {
        NavigationPanelIns.initNavigation('logistics', 'Material');
    },

    methods: {

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "MaterialUnitEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.materialUnitUIModel.uuid;
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getParentUUID: function () {
            return this.content.materialUnitUIModel.parentNodeUUID;
        },

        /**
         * @Overwrite get service manager class
         * @return {*}
         */
        getServiceManager: function (){
            return MaterialManager;
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'materialUnitUIModel', content.materialUnitUIModel);
            vm.$set(vm.content, 'materialUnitAttachmentUIModelList', content.materialUnitAttachmentUIModelList);
            vm.postUpdateUIModel();
        },

        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'MaterialUnitEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: MaterialManager,
                coreModelId: 'MaterialUnit',
                i18nPath: 'coreFunction/',
                helpDocumentName: ['MaterialUnitHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: vm.displayForEdit,
                        callback: vm.saveModule
                    },
                    exit: {
                        callback: vm.exitModule
                    }
                },
                pageHeaderConfig: [{
                    nodeInstId: 'material',
                    baseEditUrl:"MaterialEditor.html",
                    targetTab: MaterialManager.documentTab.materialUnitSection,
                    pageTitlePath: 'materialPageTitle' ,
                    pageTitleVarPath: 'parentDocId'
                },{
                    active: true,
                    nodeInstId: 'materialUnit',
                    baseEditUrl:"MaterialUnitEditor.html",
                    pageTitlePath: 'pageHeaderTitle' ,
                    pageTitleVarPath: 'name'
                }],
                tabMetaList: [{
                    tabId: 'materialUnitSection',
                    tabTitleKey: 'materialUnitSection',
                    titleLabelKey: 'materialUnitSection',
                    titleHelpKey: 'material.materialUnitSection',
                    titleIcon: 'md md-straighten content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'materialUnitSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'materialUnitUIModel',
                        tabTitleKey: 'materialUnitSection',
                        titleLabelKey: 'materialUnitSection',
                        titleHelpKey: 'material.materialUnitSection',
                        titleIcon: 'md md-texture content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'mainMaterialUnitName',
                            disabled: true,
                            newRow: true
                        },{
                            fieldName: 'mainUnitName',
                            disabled: true
                        }, {
                            fieldName: 'unitName',
                            newRow: true,
                            settings: {
                                getMetaDataUrl: vm.loadStandardUnitSelectListURL,
                                idField: 'uuid',
                                textField: 'name',
                                formatMeta: SystemStandrdMetadataProxy.formatCargoType
                            },
                            fieldType: AbsInput.FIELDTYPE.TypeAhead
                        }, {
                            fieldName: 'ratioToStandard',
                            placeholderLabelKey: "ratioToStandardPlaceholder"
                        }]
                    },{
                        sectionId: 'materialUnitSizeSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'materialUnitUIModel',
                        tabTitleKey: 'materialUnitSizeSection',
                        titleLabelKey: 'materialUnitSizeSection',
                        titleHelpKey: 'material.materialUnitSizeSection',
                        titleIcon: 'md md-straighten content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'length',
                            newRow: true,
                            postFieldMeta: [{
                                fieldName: 'refLengthUnit',
                                settings: {
                                    getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                    requestData : {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.LENGTH},
                                    method: 'post',
                                    idField: 'uuid',
                                    textField: 'name',
                                    formatMeta: SystemStandrdMetadataProxy.formatCargoType
                                },
                                fieldType: AbsInput.FIELDTYPE.Select2
                            }]
                        }, {
                            fieldName: 'width',
                        }, {
                            fieldName: 'height',
                        }, {
                            fieldName: 'volume',
                            newRow: true,
                            postFieldMeta: [{
                                fieldName: 'refVolumeUnit',
                                settings: {
                                    getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                    requestData : {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.VOLUME},
                                    method: 'post',
                                    idField: 'uuid',
                                    textField: 'name',
                                    formatMeta: SystemStandrdMetadataProxy.formatCargoType
                                },
                                fieldType: AbsInput.FIELDTYPE.Select2
                            }]
                        }, {
                            fieldName: 'netWeight',
                            postFieldMeta: [{
                                fieldName: 'refWeightUnit',
                                settings: {
                                    getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                    requestData : {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.WEIGHT},
                                    method: 'post',
                                    idField: 'uuid',
                                    textField: 'name',
                                    formatMeta: SystemStandrdMetadataProxy.formatCargoType
                                },
                                fieldType: AbsInput.FIELDTYPE.Select2
                            }]
                        },{
                            fieldName: 'grossWeight'
                        },{
                            fieldName: 'purchasePrice',
                            newRow: true,
                            helpKey:'material.purchasePrice'
                        }, {
                            fieldName: 'purchasePriceDisplay',
                            helpKey:'material.purchasePriceDisplay'
                        },{
                            fieldName: 'retailPrice',
                            newRow: true,
                            helpKey:'material.retailPrice'
                        }, {
                            fieldName: 'retailPriceDisplay',
                            helpKey:'material.retailPriceDisplay'
                        },{
                            fieldName: 'unitCost',
                            newRow: true,
                            helpKey:'material.unitCost'
                        }, {
                            fieldName: 'unitCostDisplay',
                            helpKey:'material.unitCostDisplay'
                        }]
                    }]
                }, {
                    tabId: 'materialUnitAttachment',
                    tabTitleKey: 'attachmentSection',
                    sectionMetaList: [{
                        sectionId: 'materialUnitAttachment',
                        editBlock: true,
                        sectionCategory: AsyncSection.sectionCategory.ATTACHMENT,
                        parentContentPath: 'materialUnitAttachmentUIModelList',
                        errorHandle: 'errorHandle',
                        settings: {
                            configMetaPath: 'attachmentMeta'
                        }
                    }]
                }]
            };
        }
    }
});
