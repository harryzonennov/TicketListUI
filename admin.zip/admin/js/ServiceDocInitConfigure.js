/**
 * Created by Zhang,Hang on 8/15/2016.
 */

var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: {
            resourceID: '',
            refInputUnionID: '',
            refInputUnionName: '',
            refOutputUnionID: '',
            refOutputUnionName: '',
            refOutputUnionNameComment: '',
            refInputUnionNameComment: '',
            refConsumerType:''
        },
        content: {
            uuid: '',
            resourceID: '',
            refInputUnionID: '',
            refInputUnionName: '',
            refInputUnionUUID: 'c7032244-20d5-4cc1-8167-e1704ee013d1',
            refConsumerUnionUUID: '5ae8cb8d-a631-4e58-8b89-26c233970bd8',
            refConsumerUnionName: '',
            refConsumerUnionID: '',
            refConsumerType: '',
            documentType: ''
        },
        loadConsumerUnionList: '../serviceDocConsumerUnion/loadList.html',
        loadServiceResource: '../serviceDocConfigure/loadServiceResource.html',
        confirmCreateURL: '../serviceDocConfigure/newModuleService.html'

    },

    ready: function () {
        this.initConfiguration();
        this.setI18nProperties();

    },

    methods: {

        initConfiguration: function(){
            this.$http.get(this.loadConsumerUnionList).then(function (response) {
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function(){
                    $("#x_refInputUnionUUID").select2({
                        data: resultList
                    });
                }, 0);

                setTimeout(function(){
                    $("#x_refOutputUnionUUID").select2({
                        data: resultList
                    })
                }, 0);
            });
            this.$http.get(this.loadServiceResource).then(function (response) {
                setTimeout(function(){
                    $("#x_documentType").select2({
                        data: resultList
                    })
                }, 0);
            });


        },

        confirmCreate: function () {
            var paras = {};
            this.refInputUnionUUID = 'c7032244-20d5-4cc1-8167-e1704ee013d1';
            this.refConsumerUnionUUID = '5ae8cb8d-a631-4e58-8b89-26c233970bd8';
            this.resourceID = 'SalesOrder';
            paras.documentType = this.documentType;
            paras.resourceID = this.resourceID;
            paras.refInputUnionUUID = this.refInputUnionUUID;
            paras.refConsumerUnionUUID = this.refConsumerUnionUUID;
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "ServiceDocConfigureEditor2.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'ServiceDocConfigure', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setI18nPropertiesCore
            });
        },


        setI18nCommonProperties: function () {
            this.label.index = $.i18n.prop('index');
            this.label.buttonSave = $.i18n.prop('save');
            this.label.buttonExit = $.i18n.prop('exit');
        },

        setI18nPropertiesCore: function () {
            this.label.id = $.i18n.prop('id');
            this.label.name = $.i18n.prop('name');
            this.label.note = $.i18n.prop('note');
            this.label.resourceID = $.i18n.prop('resourceID');
            this.label.documentType = $.i18n.prop('documentType');
            this.label.refInputUnionID = $.i18n.prop('refInputUnionID');
            this.label.refInputUnionName = $.i18n.prop('refInputUnionName');
            this.label.refOutputUnionID = $.i18n.prop('refOutputUnionID');
            this.label.refOutputUnionName = $.i18n.prop('refOutputUnionName');
            this.label.refOutputUnionNameComment = $.i18n.prop('refOutputUnionNameComment');
            this.label.refInputUnionNameComment = $.i18n.prop('refInputUnionNameComment');
        },

        getI18nPath: function () {
            return "foundation/systemResource/serviceDocConfigure/";
        }

    }
});





