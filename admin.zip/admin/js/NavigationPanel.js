/**
 * Created by Zhang,hang on 4/24/2017.
 */

var RightSideMenu = Vue.extend({
    name:'rightside-systemmenu',
    props:{
        /* using enable-right-bar in DOM */
        enableRightBar:[String, Boolean]
    },
    data: function () {
        "use strict";
        return {
            label: {
                common: {
                    settingTitle: "",
                    logoutWarnTitle: "",
                    closeRightBarTitle:"",
                    openRightBarTitle:"",
                    logoutWarnComment: "",
                    enterSysApplication:"",
                    enterSysConfigure:"",
                    enterSysApplicationTitle:"",
                    enterSysConfigureTitle:"",
                    toggleNavBar: "",
                    confirm: "",
                    cancel: "",
                    logoutTitle: "",
                    unlock: "",
                    unlockTitle: "",
                    unlockAll: "",
                    unlockAllTitle: "",
                    unlockSuccessTitle: "",
                    unlockUserSuccessComment: "",
                    unlockSystemSuccessComment: ""
                }
            },
            meta:{
                sideBarOpen:false
            },
            $body: '',
            $openLeftBtn: '',
            $menuItem: ''
        };
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            getCommonI18n(jQuery.i18n, vm.setI18nCommonProperties);
            this.initSideMenu();
            this.meta.sideBarOpen = $('#wrapper').hasClass('right-bar-enabled');
        }.bind(this));
    },

    ready: function () {
        var vm = this;
        getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
        this.initSideMenu();
    },

    computed: {
        rightBar:function(){
            "use strict";
            return this.enableRightBar;
        }

    },

    methods: {

        initSideMenu: function () {
            this.$body = $("body");
            this.$openLeftBtn = $(".open-left");
            this.$menuItem = $("#sidebar-menu a");
        },

        setI18nCommonProperties: function () {
            "use strict";
            var vm = this;
            ServiceUtilityHelper.setI18nReflective(vm.label.common, $.i18n.prop, true);
            $(".cs-open-right-bar").tooltip({title: this.label.common.openRightBarTitle, placement:'bottom'});
            $(".cs-close-right-bar").tooltip({title: this.label.common.closeRightBarTitle, placement:'bottom'});
            $(".cs-system-setting").tooltip({title: this.label.common.settingTitle, placement:'bottom'});
            $(".cs-logout").tooltip({title: this.label.common.logoutTitle, placement:'bottom'});
        },

        showRightBar:function(){
            "use strict";
            return this.enableRightBar;
        },

        logoutService: function () {
            var vm = this;
            swal({
                    title: vm.label.common.logoutWarnTitle,
                    text: vm.label.common.logoutWarnComment,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.common.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.common.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var requestData = {};
                        var url = '../common/logoutService.html';
                        vm.$http.post(url, requestData).then(function (response) {
                            window.location.href = "index.html";
                        });
                    } else {
                        // do nothing, just return
                    }
                });
        },

        openRightSideBar: function(tab, key, event, argus){
            if(event && event.stopPropagation){
                event.stopPropagation();
            }
            this.meta.sideBarOpen = true;
            var openTab = tab;
            //TODO patch: jump to openRightSideBarHandler
            if (typeof rightBar === 'undefined'){
                this.openRightSideBarHandler({
                    tab: tab,
                    key: key,
                    event: event,
                    controller: ServiceUtilityHelper.getGlobalVueInstance()
                });
                return;
            }
            // 'rightBar' is hard-code top level right bar vue component instance name
            if (!openTab && rightBar && rightBar.getDefaultTab){
                openTab = rightBar.getDefaultTab();
            }
            if(key && rightBar && rightBar.setActiveKey){
                rightBar.setActiveKey(key);
            }
            if(rightBar && rightBar.initTasks){
                // manually trigger some init tasks before open
                rightBar.initTasks();
            }
            if(RightBarTemplate){
                RightBarTemplate.openSideBar(openTab, key);
            }else{
                $('#wrapper').toggleClass('right-bar-enabled', true);
            }
        },

        openRightSideBarHandler: function(oSettings){
            var event = oSettings.event;
            var tab = oSettings.tab;
            var key = oSettings.key;
            var controller = oSettings.controller;
            if(event && event.stopPropagation){
                event.stopPropagation();
            }
            this.meta.sideBarOpen = true;
            var openTab = tab;
            // 'rightBar' is hard-code top level right bar vue component instance name
            if(!openTab && controller && controller.getDefaultTab){
                openTab = controller.getDefaultTab();
            }
            if(key && controller && controller.setActiveKey){
                controller.setActiveKey(key);
            }
            if(controller && controller.initTasks){
                // manually trigger some init tasks before open
                controller.initTasks();
            }
            if(RightBarTemplate){
                RightBarTemplate.openSideBar(openTab, key);
            }else{
                $('#wrapper').toggleClass('right-bar-enabled', true);
            }
        },


        closeRightSideBar: function(event){
            if(event && event.stopPropagation){
                event.stopPropagation();
            }
            this.meta.sideBarOpen = false;
            $('#wrapper').toggleClass('right-bar-enabled', false);
        },

        rightBarEnabled: function(){
            return this.meta.sideBarOpen;
        },

        enterSysConfigure: function () {
            window.location.href = "SystemExecutorSettingList.html";
        },

        enterSysApplication: function () {
            window.location.href = "LogonUserList.html";
        },

        unlock: function () {
            var unlockURL = '../common/unLock.html';
            this.$http.post(unlockURL, {}).then(function (response) {
                $.Notification.notify('success', 'top center', this.label.common.unlockSuccessTitle, this.label.common.unlockUserSuccessComment);
            });
        },

        unlockAll: function () {
            var unLockAllURL = '../common/unLockAll.html';
            this.$http.post(unLockAllURL, {}).then(function (response) {
                $.Notification.notify('success', 'top center', this.label.common.unlockSuccessTitle, this.label.common.unlockSystemSuccessComment);
            });
        }
    },


    template:
        '<ul class="nav navbar-nav navbar-right pull-right">\n' +
        '    <li class="hidden-xs" v-show="showRightBar()">\n' +
        '        <a id="cs-open-right-bar" class="right-bar-toggle cs-open-right-bar" v-show="rightBarEnabled() === false" :title="label.common.openRightBarTitle"><i\n' +
        '                class="ion-arrow-left-a content-darkblue1"  v-on:click="openRightSideBar(undefined, undefined, $event)"></i></a>\n' +
        '        <a class="right-bar-toggle waves-effect  cs-close-right-bar" v-show="rightBarEnabled() === true" :title="label.common.closeRightBarTitle"><i\n' +
        '                class="ion-arrow-right-a content-darkblue1"  v-on:click="closeRightSideBar($event)"></i></a>\n' +
        '    </li>\n' +
        '\n' +
        '    <li class="dropdown hidden-xs">\n' +

        '        <a :title="label.common.settingTitle" class="dropdown-toggle waves-effect waves-light cs-system-setting" data-toggle="dropdown" aria-expanded="true">\n' +
        '            <i class="ion-settings content-darkblue1"></i>\n' +
        '        </a>\n' +
        '        <ul class="dropdown-menu dropdown-menu-lg">\n' +
        '            <li class="list-group nicescroll notifi-title">' +
        '                    <div class="media"  >\n' +
        '                        <div class="pull-left p-r-10">\n' +
        '                             <em class="fa fa-cogs noti-action content-darkblue1"></em>\n' +
        '                        </div>\n' +
        '                        <div class="media-body">\n' +
        '                            <h5 class="media-heading">{{label.common.settingTitle}}</h5>\n' +
        '                        </div>\n' +
        '                    </div>\n' +
        '            </li>\n' +
        '            <li class="list-group nicescroll notification-list">\n' +
        '                <a class="list-group-item">\n' +
        '                    <div class="media" v-on:click="unlock()" >\n' +
        '                        <div class="pull-left p-r-10">\n' +
        '                            <em class="fa fa-unlock-alt noti-action content-pink"></em>\n' +
        '                        </div>\n' +
        '                        <div class="media-body">\n' +
        '                            <h5 class="media-heading">{{label.common.unlock}}</h5>\n' +
        '                            <p class="m-0">\n' +
        '                                <small>{{label.common.unlockTitle}}</small>\n' +
        '                            </p>\n' +
        '                        </div>\n' +
        '                    </div>\n' +
        '                </a>\n' +
        '\n' +
        '\n' +
        '                <a  class="list-group-item">\n' +
        '                    <div class="media" v-on:click="unlockAll()">\n' +
        '                        <div class="pull-left p-r-10">\n' +
        '                            <em class="fa fa-unlock noti-action content-red"></em>\n' +
        '                        </div>\n' +
        '                        <div class="media-body">\n' +
        '                            <h5 class="media-heading">{{label.common.unlockAll}}</h5>\n' +
        '                            <p class="m-0">\n' +
        '                                <small>{{label.common.unlockAllTitle}}</small>\n' +
        '                            </p>\n' +
        '                        </div>\n' +
        '                    </div>\n' +
        '                </a>\n' +
        '\n' +
        '\n' +
        '                <a  class="list-group-item">\n' +
        '                    <div class="media" v-on:click="enterSysConfigure()">\n' +
        '                        <div class="pull-left p-r-10">\n' +
        '                            <em class="ion-wrench noti-action"></em>\n' +
        '                        </div>\n' +
        '                        <div class="media-body">\n' +
        '                            <h5 class="media-heading">{{label.common.enterSysConfigure}}</h5>\n' +
        '                            <p class="m-0">\n' +
        '                                <small>{{label.common.enterSysConfigureTitle}}</small>\n' +
        '                            </p>\n' +
        '                        </div>\n' +
        '                    </div>\n' +
        '                </a>\n' +
        '\n' +
        '\n' +
        '                <a  class="list-group-item">\n' +
        '                    <div class="media" v-on:click="enterSysApplication()">\n' +
        '                        <div class="pull-left p-r-10">\n' +
        '                            <em class="md md-apps noti-action content-lightblue"></em>\n' +
        '                        </div>\n' +
        '                        <div class="media-body">\n' +
        '                            <h5 class="media-heading">{{label.common.enterSysApplication}}</h5>\n' +
        '                            <p class="m-0">\n' +
        '                                <small>{{label.common.enterSysApplicationTitle}}</small>\n' +
        '                            </p>\n' +
        '                        </div>\n' +
        '                    </div>\n' +
        '                </a>\n' +
        '            </li>\n' +
        '\n' +
        '        </ul>\n' +
        '    </li>\n' +
        '    <li class="hidden-xs">\n' +
        '        <a class="right-bar-toggle waves-effect cs-logout" :title="label.common.logoutTitle"><i\n' +
        '                class="fa fa-sign-out content-peach-red" v-on:click="logoutService()"></i></a>\n' +
        '    </li>\n' +
        '\n' +
        '</ul>'
});


var UserDetailBlock = Vue.extend({
    name:'user-detail-block',
    data: function () {
        "use strict";
        return {
            label: {
                logonUserHeaderTitle:'',
                searchPlaceHolder: ''
            },
            content:{
                logonUserUUID:'',
                logonUserName:'',
                logonUserId:'',
                status:'',
                statusValue:''
            },
            getLoginInfoServiceURL: '../common/getLoginInfoService.html'
        };
    },
    computed: {
        computedPupFunction: function(){
            "use strict";
            var logonUserManager = new LogonUserManager();
            if(logonUserManager && logonUserManager.getDocumentPopoverContent) {
                return logonUserManager.getDocumentPopoverContent.bind(logonUserManager);
            }
        }
    },
    created: function(){
        this.getLoginInfoService();
        this.initSubComponents();
    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            this.initSubComponents();
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
        }.bind(this));
    },
    methods:{
        setI18nCommonProperties: function(){
            "use strict";
            this.label.searchPlaceHolder = $.i18n.prop('searchPlaceHolder');
            this.label.logonUserHeaderTitle = $.i18n.prop('logonUserHeaderTitle');
        },

        initSubComponents:function(){
            Vue.component("popup-core", PopupCore);
        },

        resultPopTrigger: function(){
            "use strict";
            return '.dropdown-toggle.profile';
        },

        logonUserHeaderIconClass: function(){
            "use strict";
            return 'md md-perm-contact-cal';
        },

        getLoginInfoService: function(){
            "use strict";
            var vm = this;
            this.$http.get(vm.getLoginInfoServiceURL).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    return;
                }
                vm.$set(vm, 'content', oData.content);
            });
        },

        popup: function () {
            window.alert("poup");
        }
    },
    template:
        '<div class="user-detail">\n' +
        '   <popup-core :target-uid="content.logonUserUUID" :pop-trigger="resultPopTrigger()" :header-title="label.logonUserHeaderTitle"' +
        '    :header-icon-class="logonUserHeaderIconClass()" :popup-content-function = "computedPupFunction"></popup-core>\n' +
        '    <div class="dropup" >\n' +
        '            <a class="dropdown-toggle profile" data-toggle="dropdown" aria-expanded="true">\n' +
        '                            <img src="assets/images/users/avatar-2.jpg" alt="user-img" class="img-circle">\n' +
        '                            <span class="user-info-span">\n' +
        '                                <h5 class="m-t-0 m-b-0">{{content.logonUserId}}-{{content.logonUserName}}</h5>\n' +
        '                                <p class="text-muted m-b-0">\n' +
        '                                    <small><i class="fa fa-circle text-success"></i> <span>{{content.statusValue}}</span></small>\n' +
        '                                </p>\n' +
        '              </span>\n' +
        '          </a>\n' +
        '     </div>\n' +
        '</div>'

});
Vue.component('user-detail-block', UserDetailBlock);

var SearchNavigation = Vue.extend({
    name:'search-navigation',
    props:{
        /* using enable-right-bar in DOM */
        keywords:[String]
    },
    data: function () {
        "use strict";
        return {
            label: {
                searchPlaceHolder: '',
                searchNavTitle:'',
                searchNavExecuteTitle:''
            },
            content:{
                keyWords:''
            },
            meta:{
                switch:0,
            }
        };
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.setI18nProperties(vm.initSearchTitle);
        }.bind(this));
    },

    methods:{

        setI18nProperties: function (fnCallback){
            "use strict";
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                commonCallback:this.setI18nCommonProperties,
                fnCallback: fnCallback,
                label: vm.label, vm:vm
            });
        },

        setI18nCommonProperties: function(){
            var vm = this;
            ServiceUtilityHelper.setI18nReflective(vm.label, $.i18n.prop, true);
        },

        initSearchTitle: function(){
            "use strict";
            var vm = this;
            $("i.fa.fa-search.search-start").tooltip({title: vm.label.searchNavTitle, placement:'bottom'});
            $("i.fa.fa-search.search-trigger").tooltip({title: vm.label.searchNavExecuteTitle, placement:'bottom'});
        },

        searchNavByKeywords: function(){
            var paras = {};
            paras.keyWords = encodeURI(this.content.keyWords);
            var resultURL = "NavigationWelcome.html?keyWords=" + paras.keyWords;
            window.open(resultURL, '_blank');
        },

        switchOn: function(){
            var vm = this;
            vm.$set(vm.meta, 'switch', 1);
        },

        checkSwitchOn: function(){
            var vm = this;
            if(vm.meta.switch === 1){
                return true;
            }
        },

        checkSwitchOff: function(){
            var vm = this;
            if(vm.meta.switch === 0){
                return true;
            }
        }

    },

    template:
        '<span>' +
        '    <form v-show="checkSwitchOn()" role="search" class="navbar-left app-search pull-left hidden-xs">\n' +
        '         <input type="text" :placeholder="label.searchPlaceHolder" v-model="content.keyWords" class="form-control app-search-input m-l-20">\n' +
        '          <em><a><i class="fa fa-search search-trigger content-white" @click="searchNavByKeywords"></i></a></em>\n' +
        '     </form>' +
        '     <span class="app-avatar pull-left p-l-50 " v-show="checkSwitchOff()"><em><a >' +
        '         <i class="fa fa-search search-start content-lightblue" @click="switchOn"></i></a></em>' +
        '     </span>' +
        '</span>'
});
Vue.component('search-navigation', SearchNavigation);


var MessageConstant = function(){

};

MessageConstant.getMessageLevelCodeIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.StandardPropety.MessageLevelCode.INFO, iconClass: 'nmd nmd-alarm content-lightblue'},
        {id: DocumentConstants.StandardPropety.MessageLevelCode.WARN, iconClass: 'nmd nmd-remove-circle content-orange'},
        {id: DocumentConstants.StandardPropety.MessageLevelCode.ERROR, iconClass: 'nmd nmd-cancel content-peach-red'}
    ];
};

MessageConstant.getTreeNodeSpanClassArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.StandardPropety.MessageLevelCode.INFO, iconClass: 'focus-info'},
        {id: DocumentConstants.StandardPropety.MessageLevelCode.WARN, iconClass: 'focus-warning'},
        {id: DocumentConstants.StandardPropety.MessageLevelCode.ERROR, iconClass: 'focus-error'}
    ];
};


MessageConstant.filterArray = function(key, keyName, rawList){
    if(!rawList || rawList.length === 0){
        return;
    }
    if(!key){
        return null;
    }
    if(!keyName){
        return null;
    }
    var i, tempModel, _len = rawList.length;
    for( i = 0; i < _len; i++){
        tempModel = rawList[i];
        if(typeof key === 'number'){
            if(key === tempModel[keyName]){
                return rawList[i];
            }
        }else{
            if(key == tempModel[keyName]){
                return rawList[i];
            }
        }

    }
};


MessageConstant.formatMessageLevelCodeIconClass = function (messageLevelCode) {
    "use strict";
    var messageLevelIconArray = MessageConstant.getMessageLevelCodeIconArray();
    var $element = MessageConstant.filterArray(messageLevelCode, 'id', messageLevelIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

MessageConstant.formatMessageLevelTreeeNodeSpanClass = function (messageLevelCode) {
    "use strict";
    var messageLevelIconArray = MessageConstant.getTreeNodeSpanClassArray();
    var $element = MessageConstant.filterArray(messageLevelCode, 'id', messageLevelIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

var MessageMenu = Vue.extend({
    name:'message-menu',

    data: function () {
        "use strict";
        return {
            label: {
                searchPlaceHolder: '',
                errorMessageTitle: '',
                warnMessageTitle: '',
                notifyMessageTitle: ''
            },
            navigationItemList:[],
            messageList:
                [{
                    messageLevelCode:DocumentConstants.StandardPropety.MessageLevelCode.INFO,
                    iconHeader:'',
                    num:0,
                    displayflag: undefined,
                    messageResponseList:[]
                },{
                    messageLevelCode:DocumentConstants.StandardPropety.MessageLevelCode.WARN,
                    iconHeader:'',
                    num:0,
                    displayflag: undefined,
                    messageResponseList:[]
                },{
                    messageLevelCode:DocumentConstants.StandardPropety.MessageLevelCode.ERROR,
                    iconHeader:'',
                    num:0,
                    displayflag: undefined,
                    messageResponseList:[]
                }],
            loadUserMessageURL:'../logonUser/loadUserMessageService.html'

        };
    },

    created: function(){
        this.initMeta();
        this.getCommonI18n();
        this.initLoadMessage();
    },

    mounted: function () {
        this.$nextTick(function () {

        }.bind(this));
    },
    methods:{

        initLoadMessage: function(){
            "use strict";
            var vm = this;
            var messageListPromise = vm.getMessageListPromise(vm.$http);
            var navigationItemListPromise = vm.getNavigationListPromise();
            Promise.all([messageListPromise, navigationItemListPromise]).then(function(values){
                var messageList = values[0];
                var navigationItemList = values[1];
                vm.$emit('messageUpdate', messageList);
                //sessionStorage.setItem('messageList',this.messageList);
                vm.fillMessageResponse(messageList, navigationItemList);
            });
        },

        getNavigationListPromise: function () {
            var vm = this;
            return new Promise(function (resolve, reject) {
                if(vm.navigationItemList && vm.navigationItemList.length > 0){
                    resolve(vm.navigationItemList);
                }else{
                    var navigationItemListPromise = ServiceApplicationFactory.getNavigationListPromise(vm.$http);
                    navigationItemListPromise.then(function (values) {
                        vm.$set(vm, 'navigationItemList', values)
                        resolve(values);
                    });
                }
            }.bind(this));
        },

        getMessageListPromise: function () {
            "use strict";
            var vm = this;
            return new Promise(function (resolve, reject) {
                vm.$http.get(vm.loadUserMessageURL).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        reject(oData);
                    }
                    resolve(oData.content);
                }).catch(function(){
                    resolve();
                });
            }.bind(this));
        },

        initMeta: function(){
            "use strict";
            var vm = this;
            vm.getNavigationListPromise();
            // var messageListFromCache = sessionStorage.getItem('messageList');
            // if( !ServiceCollectionsHelper.checkNullList(messageListFromCache)){
            //     vm.$set(vm, 'messageList', messageListFromCache);
            // }
            if( !vm.messageList || vm.messageList.length === 0){
                return;
            }
            for(var i = 0; i < vm.messageList.length; i++){
                var iconHeader = MessageConstant.formatMessageLevelCodeIconClass(vm.messageList[i].messageLevelCode);
                if(iconHeader){
                    vm.messageList[i].iconHeader = iconHeader;
                    vm.$set(vm.messageList, i, vm.messageList[i]);
                }
            }
        },

        setI18nCommonProperties: function(){
            "use strict";
            this.label.errorMessageTitle = $.i18n.prop('errorMessageTitle');
            this.label.warnMessageTitle = $.i18n.prop('warnMessageTitle');
            this.label.notifyMessageTitle = $.i18n.prop('notifyMessageTitle');
        },

        getCommonI18n: function(){
            var promise1 = jQuery.i18n.properties({
                name: 'ComElements', //properties file name
                path: getI18nRootPath() + getCommonI18nPath(),
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache: true,
                callback: this.setI18nCommonProperties
            });
            return promise1;
        },

        fillMessageResponse: function( messageResponseList, navigationItemList){
            "use strict";
            var vm = this;
            if( !messageResponseList || messageResponseList.length === 0){
                return;
            }
            for(var i = 0; i < messageResponseList.length; i++){
                vm.insertIntoMessageList(messageResponseList[i], navigationItemList);
            }
            vm.fillTooltip();
        },

        fillTooltip: function(){
            var vm = this;

            var _infoClass = vm.formatMessageLevelClass(DocumentConstants.StandardPropety.MessageLevelCode.INFO);
            $('.' + _infoClass).tooltip({title: this.label.notifyMessageTitle, placement:'bottom'});
            var _warnClass = vm.formatMessageLevelClass(DocumentConstants.StandardPropety.MessageLevelCode.WARN);
            $('.' + _warnClass).tooltip({title: this.label.warnMessageTitle, placement:'bottom'});
            var _errorClass = vm.formatMessageLevelClass(DocumentConstants.StandardPropety.MessageLevelCode.ERROR);
            $('.' + _errorClass).tooltip({title: this.label.errorMessageTitle, placement:'bottom'});
        },

        getNavigationUrl: function(messageResponse, navigationSourceId, navigationItemList){
            var navUnion = ServiceCollectionsHelper.filterArray(navigationSourceId, 'id', navigationItemList);
            if(navUnion){
                var url = navUnion.targetUrl;
                if(url && messageResponse.actionCode){
                    url = url + "?actionCode=" + messageResponse.actionCode;
                }
                return url;
            }
        },

        navigateToTarget: function(messageResponse){
            "use strict";
            var url = messageResponse.navigationUrl;
            if(messageResponse.rawSEList && messageResponse.rawSEList.length > 0){
                var uuidArray = "";
                messageResponse.rawSEList.forEach(function(se){
                    uuidArray = uuidArray + se.uuid + " ";
                });
                url = changeURLPar(url, LABEL_UUIDARRAY, uuidArray);
            }
            window.open(url, '_blank');
        },

        formatMessageLevelClass: function(messageLevelCode){
            return "message-level-" + messageLevelCode;
        },

        insertIntoMessageList: function(messageResponse, navigationItemList){
            "use strict";
            var vm = this;
            var index = -1;
            var result = ServiceCollectionsHelper.filterWithIndex(vm.messageList, function(tempMessage){
                return tempMessage.messageLevelCode * 1 === messageResponse.messageLevelCode * 1;
            });
            if(!result){
                return;
            }
            index = result.index;
            var messageInContent = result.model;
            if( messageResponse.rawSEList && messageResponse.rawSEList.length > 0 ){
                messageInContent.displayflag = true;
            } else{
                return;
            }
            messageResponse.navigationUrl = vm.getNavigationUrl(messageResponse, messageResponse.navigationSourceId, navigationItemList);
            messageResponse.iconMessage = messageInContent.iconHeader;
            messageInContent.num = messageInContent.num? (messageInContent.num + 1): 1;
            messageInContent.messageResponseList = messageInContent.messageResponseList? messageInContent.messageResponseList: [];
            messageInContent.messageResponseList.push(messageResponse);
            vm.$set(vm.messageList, index, messageInContent);
        }

    },

    template:
        '<div>' +
        '<ul v-for="(message, index) in messageList" class="nav navbar-nav navbar-right pull-right">\n' +
        '    <li v-show="message.displayflag" class="dropdown hidden-xs">\n' +
        '        <a  class="dropdown-toggle waves-effect waves-light cs-message-setting " ' +
        '          :class="formatMessageLevelClass(message.messageLevelCode)" data-toggle="dropdown" aria-expanded="true">\n' +
        '            <i :class="message.iconHeader"></i>\n' +
        '            <span className="badge badge-xs badge-pink content-lightblue">{{message.num}}</span>\n' +
        '        </a>\n' +
        '        <ul  class="dropdown-menu dropdown-menu-lg">\n' +
        '            <li v-for="(messageResponse, inj) in message.messageResponseList" class="list-group nicescroll notifi-message">' +
        '                 <div class="media"  @click="navigateToTarget(messageResponse)">\n' +
        '                        <div class="pull-left p-r-10">\n' +
        '                             <em :class="messageResponse.iconMessage" ></em>\n' +
        '                        </div>\n' +
        '                        <div class="media-body">\n' +
        '                            <h5 class="media-heading">{{messageResponse.messageTitle}}</h5>\n' +
        '                        </div>\n' +
        '                        <span class="label label-success pull-right">{{messageResponse.dataNum}}</span>\n' +
        '                  </div>\n' +
        '            </li>\n' +
        '        </ul>\n' +
        '    </li>\n' +
        '</ul>'+
        '</div>'
});


Vue.component('message-menu', MessageMenu);


/**
 * BusyLoader:
 *    --{String} parentElement: parent element dom, target element to be hidden.
 */
var BusyLoader = Vue.extend({
    name:'busy-loader',
    props: {
        /* using parent-element */
        parentElement:String,
        /* using model */
        model: [String, Number],
        /* using embedded */
        embedded: [Boolean, String]
    },
    data: function () {
        "use strict";
        return {
            corePostfix: undefined
        };
    },

    computed:{
        coreLoaderId: function(){
            return 'x-busy-loader-' + this.corePostfix;
        },

        comLoading:function(){
            return 'busyLoading' + this.model;
        }
    },

    created:function(){
        "use strict";
        this.initCorePost();
    },

    mounted: function () {
    },

    methods:{

        initCorePost: function(){
            "use strict";
            this.corePostfix = genRamdomPostIndex();
        },

        showBusyLoading: function(){
            $('#' + this.coreLoaderId).removeClass(DocumentManagerFactory.DISPLAY_CLASS.HIDE);
            $('#' + this.coreLoaderId).addClass(DocumentManagerFactory.DISPLAY_CLASS.DISPLAY);
            if(this.embedded){
                if(this.embedded === true || this.embedded === 'true'){
                    $('#' + this.coreLoaderId).removeClass('window');
                }
            }
            if(this.parentElement){
                $(this.parentElement).css({opacity:0.3});
            }
        },

        hideBusyLoading: function(timeout){
            var localTimeOut = timeout ? timeout: 0;
            var vm = this;
            setTimeout(function(){
                $('#' + vm.coreLoaderId).removeClass('hold-display');
                $('#' + vm.coreLoaderId).addClass('hide-display');
                if(vm.parentElement){
                    $(vm.parentElement).css({opacity:1});
                }
            }, localTimeOut);
        }
    },

    template:
        '<div :class="comLoading" :id="coreLoaderId" style="z-index:100;" class="busy-loader-core window hide-display"></div>'
});

/**
 * Utility method to clear page blur background, should be used together as <code>hideBusyLoading</code>
 */
BusyLoader.cleanPageBackground = function(){
    if($(".content-page.init")){
        $(".content-page.init").removeClass("init");
    }
    if($(".container.init")){
        $(".container.init").removeClass("init");
    }
};

Vue.component('busy-loader', BusyLoader);


var SidePullRightUnion = Vue.extend({
    name:'side-pull-right-union',
    props:{
        /* using need-arrow in pom */
        needArrow: [Boolean, String],
        /* using navigation-element in pom */
        navigationElement: [Object]
    },

    data: function(){
        return {
            cache: {
                dataNum: ''
            },
            corePostfix:''
        };
    },

    created: function(){
        this.initCorePost();
    },

    mounted: function () {
        this.$nextTick(function () {
            "use strict";

        });
    },
    watch: {
        'navigationElement': function (navigationElement) {
            if(navigationElement){
                this.initMessageTitle();
            }
        }
    },

    computed:{
        comContainerId:function(){
            return 'side-pull-right-' + this.corePostfix;
        }
    },

    methods:{

        initCorePost: function(){
            "use strict";
            this.corePostfix = genRamdomPostIndex();
        },

        initMessageTitle: function(){
            var vm = this;
            if(vm.navigationElement.messageResponse && vm.navigationElement.messageResponse.messageTitle){
                var $element = $("#" + vm.comContainerId + " .message");
                $element.tooltip({title: vm.navigationElement.messageResponse.messageTitle, placement:'right', container:'body'});
            }
        },

        showInfoMessage: function(){
            var vm = this;
            return vm.showMessageCore(DocumentConstants.StandardPropety.MessageLevelCode.INFO);
        },

        showWarnMessage: function(){
            var vm = this;
            return vm.showMessageCore(DocumentConstants.StandardPropety.MessageLevelCode.WARN);
        },

        showErrorMessage: function(){
            var vm = this;
            return vm.showMessageCore(DocumentConstants.StandardPropety.MessageLevelCode.ERROR);
        },

        showMenuArrow: function(){
            var vm = this;
            if( vm.needArrow !== 'true' ){
                return;
            }
            if(vm.showMessageNumber() === true){
                return;
            }
            return true;
        },

        showMessageCore: function(targetMsgLevelCode){
            var vm = this;
            var messageLevelCode = vm.getMessageLevelCode();
            if(vm.showMessageNumber() !== true){
                return;
            }
            return messageLevelCode === targetMsgLevelCode;
        },

        getMessageLevelCode: function(){
            var vm = this;
            if(!vm.navigationElement || !vm.navigationElement.messageResponse){
                return 0;
            }
            return vm.navigationElement.messageResponse.messageLevelCode * 1;
        },

        showMessageNumber: function (){
            var vm = this;
            if(!vm.navigationElement || !vm.navigationElement.messageResponse){
                return ;
            }
            if(vm.navigationElement.messageResponse.dataNum > 0){
                vm.$set(vm.cache, 'dataNum', vm.navigationElement.messageResponse.dataNum);
                return true;
            }
        }

    },

    template:
        '<span :id="comContainerId">' +
        '         <span v-show="showMenuArrow()" class="menu-arrow"></span>' +
        '         <span v-show="showInfoMessage()" class="label message label-success pull-right">{{cache.dataNum}}</span>' +
        '         <span v-show="showWarnMessage()" class="label message label-primary pull-right">{{cache.dataNum}}</span>' +
        '         <span v-show="showErrorMessage()" class="label message label-danger pull-right">{{cache.dataNum}}</span>' +
        '</span>'

});

Vue.component('side-pull-right-union', SidePullRightUnion);

var SideBarNavigation = Vue.extend({
    name:'side-bar-navigation',

    data: function () {
        "use strict";
        return {
            meta: {
                label:''
            },
            cache:{
                title:'Good',
                navigationElementList:[]
            }
        };
    },

    created:function(){
        var vm = this;
    },

    mounted: function () {
        this.$nextTick(function () {
            "use strict";
            var vm = this;
        });
    },

    methods:{

        getNavigationListPromise: function(groupId, navigationGroupList){
            var navigationUnion = ServiceCollectionsHelper.filterArray(groupId, 'id', navigationGroupList);
            if (navigationUnion) {
                return $.getJSON("js/" + navigationUnion.url);
            }
        },

        getSubActiveIconClass: function(subNavigationElement){
            if(subNavigationElement.activeFlag === true){
                return "nmd nmd-directions-run content-peach-red m-r-24";
            }else{
                return "m-r-40";
            }
        },

        /**
         *
         * @param oSettings
         *   --{Object} label
         *   --{String} navigationId
         *   --{Promise<Array>} authorizationPromise
         *   --{Promise<Array>} navElementListPromise
         */
        initNaviConfigure:function(oSettings) {
            var vm = this;
            var navElementListPromise = oSettings.navElementListPromise;
            var authorizationPromise = oSettings.authorizationPromise;
            var navigationId = oSettings.navigationId;
            vm.$set(vm.meta, 'label', oSettings.label);
            var _processNavElement = function(rawNavElement, navigationElementList, messageList, noMessage){
                var navigationElement = rawNavElement;
                if(navigationElement.id === navigationId){
                    navigationElement.activeFlag = true;
                    navigationElement.activeClass = "active";
                }
                if(!noMessage || noMessage === false){
                    var messageResponseList = ServiceCollectionsHelper.filterToArray(navigationElement.id, 'navigationSourceId', messageList);
                    if(!ServiceCollectionsHelper.checkNullList(messageResponseList)){
                        var messageResponse = ServiceMessageHandlerHelper.mergeMessageListToOne(messageResponseList);
                        navigationElement.messageResponse = messageResponse;
                    }
                }
                navigationElement.label = NavigationPanel.getLabelById(navigationElement.id, vm.meta.label);
                navigationElementList.push(navigationElement);
                return navigationElement;
            };
            Promise.all([authorizationPromise, navElementListPromise]).then(function (values) {
                var authorizationACUnionList = values[0];
                var navElementList = SideBarNavigation.refineNavigationList(values[1], authorizationACUnionList);
                var navigationElementList = [];
                ServiceCollectionsHelper.traverseList(navElementList.navigationList, function (rawNavElement){
                    var subNavigationElementList = [];
                    var subNavSourceIdList = [];
                    var navigationElement = _processNavElement(rawNavElement, navigationElementList, oSettings.messageList, true);
                    ServiceCollectionsHelper.traverseList(rawNavElement.subNavigationList, function (rawSubNavElement){
                        subNavSourceIdList.push({keyValue:rawSubNavElement.id, keyName:'navigationSourceId', logicOperator:DocumentConstants.StandardPropety.StandardLogicOperator.OR});
                        var subNavigationElement = _processNavElement(rawSubNavElement, subNavigationElementList, oSettings.messageList);
                        if(subNavigationElement.activeFlag === true){
                            // in case sub navigation actived, also set active to parent
                            navigationElement.activeFlag = true;
                            navigationElement.activeClass = "active";
                        }
                    });
                    // merge all the sub message list
                    if(oSettings.messageList){
                        ServiceCollectionsHelper.filterToArrayByKeyList({
                            keyList: subNavSourceIdList,
                            rawList: oSettings.messageList,
                            assembleSub: true
                        });
                        var subMessageList = ServiceCollectionsHelper.filterToArrayByKeyList(subNavSourceIdList, oSettings.messageList);
                        var processedMessage = ServiceMessageHandlerHelper.mergeMessageListToOne(subMessageList);
                        navigationElement.messageResponse = processedMessage;
                    }
                    navigationElement.subNavigationList = subNavigationElementList;
                });
                vm.$set(vm.cache, 'navigationElementList', navigationElementList);
                vm.$nextTick(function(){
                    if(oSettings.init === true){
                        window.jQuery.Sidemenu.$menuItem = $("#sidebar-menu a");
                        window.jQuery.Sidemenu.init();
                    }
                });
            });
        }
    },

    template: '' +
        '<ul>' +
        '    <li class="has_sub" v-for="(navigationElement, index) in cache.navigationElementList" >' +
        '       <a  class="waves-effect waves-primary" :class="navigationElement.activeClass" >' +
        '        <em :class="navigationElement.emClass" class="m-r-10"><i  :class="navigationElement.icon"></i></em>' +
        '         <span> {{navigationElement.label}}</span>' +
        '         <side-pull-right-union need-arrow="true" :navigation-element="navigationElement"></side-pull-right-union>' +
        '       </a>' +
        '         <ul class="list-unstyled" style="">' +
        '            <li v-for="(subNavigationElement, j) in navigationElement.subNavigationList" :class="subNavigationElement.activeClass">' +
        '                 <a :href="subNavigationElement.url"><i  :class="getSubActiveIconClass(subNavigationElement)" ></i>' +
        '                        {{subNavigationElement.label}} ' +
        '                     <side-pull-right-union  :navigation-element="subNavigationElement"></side-pull-right-union>' +
        '                 </a>' +
        '            </li>' +
        '          </ul>' +
        '    </li>' +
        '</ul>'
});

/**
 * Utility Method: filter navigation element list by checking authorization list
 * @param navaigationGroupList
 * @param authorizationACUnionList
 * @returns {*[]}
 */
SideBarNavigation.refineNavigationList = function (data, authorizationACUnionList) {
    var refinedNavigationList = [];
    for (var i = 0, len = data.navigationList.length; i < len; i++) {
        var navigation = data.navigationList[i];
        if (navigation.resourceId) {
            // In case need to check group navigation's resource
            var resourceModel = ServiceApplicationFactory.filterAuthorizationACUninon(navigation.resourceId, authorizationACUnionList);
            if (!resourceModel) {
                continue;
            }
        }
        var subNavigationList = navigation.subNavigationList;
        var refinedSubNavigationList = [];
        if (subNavigationList && subNavigationList.length > 0) {
            for (var j = 0, lenJ = subNavigationList.length; j < lenJ; j++) {
                if (!subNavigationList[j].resourceId) {
                    refinedSubNavigationList.push(subNavigationList[j]);
                    continue;
                }
                var subResourceModel = ServiceApplicationFactory.filterAuthorizationACUninon(subNavigationList[j].resourceId, authorizationACUnionList);
                if (subResourceModel) {
                    refinedSubNavigationList.push(subNavigationList[j]);
                }
            }
        }

        // In case there is sub Navigation
        if (refinedSubNavigationList && refinedSubNavigationList.length > 0) {
            refinedNavigationList.push({
                "id": navigation.id,
                "icon": navigation.icon,
                "url": navigation.url,
                "subNavigationList": refinedSubNavigationList
            });
        } else {
            if (navigation.resourceId) {
                refinedNavigationList.push({
                    "id": navigation.id,
                    "icon": navigation.icon,
                    "url": navigation.url
                });
            }
        }
    }
    return {navigationList: refinedNavigationList};

};

Vue.component("side-bar-navigation", SideBarNavigation);



var NavigationGroup = Vue.extend({
    name:'navigation-group',

    data: function () {
        "use strict";
        return {
            meta: {
                label:''
            },
            cache:{
                navigationGroupList:[{
                    id:"logistics",
                    iconClass:"nmd nmd-add-shopping-cart",
                    backgroundClass:"background-green"
                }]
            }
        };
    },

    created:function(){
        var vm = this;
    },

    methods:{

        getNavigationGroupListPromise: function(oSettings){
            var groupConfigPath = oSettings.groupConfigPath ? oSettings.groupConfigPath : 'js/navigation.json';
            var groupResponse = $.getJSON(groupConfigPath, function (data) {

            });
            return groupResponse;
        },


        /**
         *
         * @param oSettings
         *   --{Object} label
         *   --{String} groupId
         *   --{Promise<Array>} authorizationList
         *   --{Promise<Array>} navigationGroupList
         */
        initGroupConfigure:function(oSettings){
            var vm = this;
            var navGroupList = oSettings.navigationGroupList;
            var authorizationList = oSettings.authorizationList;
            var groupId = oSettings.groupId;
            vm.$set(vm.meta, 'label', oSettings.label);
            var refineNavGroupList = NavigationGroup.refineNavigationGroupList(navGroupList, authorizationList);
            var navigationGroupList = [];
            ServiceCollectionsHelper.traverseList(refineNavGroupList, function (rawNavGroup){
                var navigationGroup = rawNavGroup;
                if(navigationGroup.id === groupId){
                    navigationGroup.activeFlag = true;
                    navigationGroup.activeClass = "active";
                }
                navigationGroup.title = NavigationPanel.getLabelById(navigationGroup.idTitle, vm.meta.label);
                navigationGroup.elementId = "nav-group-" + genRamdomPostIndex();
                navigationGroupList.push(navigationGroup);
            });
            // render the navigation group view
            vm.$set(vm.cache, 'navigationGroupList', navigationGroupList);
            // attach title
            vm.$nextTick(function (){
                ServiceCollectionsHelper.traverseList(navigationGroupList, function (navigationGroup){
                    $("#" + navigationGroup.elementId).tooltip({title: navigationGroup.title, placement:'bottom'});
                });
            });
        }

    },

    template:'' +
        '<ul class="nav navbar-nav hidden-xs">' +
        '     <li v-for="(navigationGroup, index) in cache.navigationGroupList" :class="navigationGroup.activeClass"> ' +
        '           <em class="nav navbar-nav " :id="navigationGroup.elementId">' +
        '               <a :class="navigationGroup.backgroundClass" :href="navigationGroup.defaultUrl">' +
        '                       <i :class="navigationGroup.iconClass"></i></a>' +
        '           </em>' +
        '      </li>' +
        '</ul>'
});

/**
 * Utility Method: filter navigation group by checking authorization list
 * @param navaigationGroupList
 * @param authorizationACUnionList
 * @returns {*[]}
 */
NavigationGroup.refineNavigationGroupList = function (navaigationGroupList, authorizationACUnionList) {
    var refinedNavigationGroupList = [];
    for (var i = 0, len = navaigationGroupList.length; i < len; i++) {
        var navigationGroup = navaigationGroupList[i];
        if (navigationGroup.resourceId) {
            // In case need to check group navigation's resource
            var resourceModel = ServiceApplicationFactory.filterAuthorizationACUninon(navigationGroup.resourceId, authorizationACUnionList);
            if (!resourceModel) {
            } else {
                refinedNavigationGroupList.push(navigationGroup);
            }
        } else {
            // In case don't need to check group navigation resource
            refinedNavigationGroupList.push(navigationGroup);
        }
    }
    return refinedNavigationGroupList;
};

Vue.component("navigation-group", NavigationGroup);

// Batch register common components
if ( typeof MessageDataUnion !== "undefined"){
    Vue.component("message-data-union", MessageDataUnion);
}

var NavigationPanel = Vue.extend({
    name:'navigation-panel',
    props:{
        /* using enable-right-bar in DOM */
        enableRightBar:[String, Boolean]
    },
    data: function() {
        return {
            label:{
                common: {
                    logoutWarnTitle: "",
                    logoutWarnComment: "",
                    confirm: "",
                    cancel: "",
                    logoutTitle: "",
                    unlock: "",
                    unlockTitle: "",
                    unlockAll: "",
                    unlockAllTitle: "",
                    enterSysConfigure: "",
                    enterSysConfigureTitle: "",
                    enterSysApplication: "",
                    enterSysApplicationTitle: ""
                },

                group: {
                    office: "",
                    salesDistribution: "",
                    finance: "",
                    warehouse: "",
                    logistics: "",
                    logisticsTitle:"",
                    productionTitle:"",
                    InternalConfigure:""
                },

                admin: {
                    ServiceDocumentSetting: "",
                    PricingSetting: "",
                    Role: "",
                    LogonUser: "",
                    Organization: "",
                    Employee: "",
                    MapConfigureModel: "",
                    ServiceFlowModel: "",
                    FlowRouter: "",
                    FlowableTask:"",
                    HtmlPageConfigure: "",
                    ServiceExtensionSetting: "",
                    SerialNumberSetting: "",
                    ServiceSpinner: "",
                    ServiceDocConsumerUnion: "",
                    MaterialConfigureTemplate:"",
                    ServiceMobileMessageResource: "",
                    FinanceResource: "",
                    reportTemplate: "",
                    StandardMaterialUnit: "",
                    SystemCodeValueCollection: "",
                    MessageTemplate: "",
                    NavigationElementResource: "",
                    NavigationSystemSetting:"",
                    AuthorizationGroup: "",
                    AuthorizationObject: "",
                    FinanceSetting: "",
                    FinAccount: "",
                    FinAccountTitle: "",
                    FinPayReceiveList: "",
                    ResFinSystemResource: "",
                    ServiceEntityLogModel: "",
                    BidInvitationLogModel: "",
                    InboundDeliveryLogModel: "",
                    OutboundDeliveryLogModel: "",
                    SystemExecutorSetting: "",
                    FinReceipt: "",
                    FinVoucher: "",
                    CalendarTemplate:"",
                    WorkCalendar:"",
                    ServiceDocConfigure:"",
                    SearchProxyConfig:"",
                    ServiceDocConsumer:""
                },
                logistics: {
                    SupplyChainCockpit:"",
                    Material: "",
                    MaterialType: "",
                    MaterialStockKeepUnit: "",
                    RegisteredProduct:"",
                    CorporateSupplier: "",
                    CorporateCustomer: "",
                    IndividualCustomer: "",
                    systemAdmin: "",
                    systemAdminTitle: "",
                    role: "",
                    PurchaseContract: "",
                    Inquiry: "",
                    InquiryMaterialItem: "",
                    PurchaseContractMaterialItem: "",
                    SalesContract: "",
                    SalesContractMaterialItem:"",
                    SalesReturnOrder:"",
                    SalesReturnMaterialItem:"",
                    SalesForcast:"",
                    SalesForcastMaterialItem:"",
                    PurchaseRequest:"",
                    PurchaseRequestMaterialItem:"",
                    PurchaseReturnOrder:"",
                    PurchaseReturnMaterialItem:"",
                    WasteProcessOrder:"",
                    SalesSettleOrder: "",
                    BidInvitationOrderManage: "",
                    BidInvitationOrder: "",
                    BidMaterialItem: "",
                    InboundDelivery: "",
                    QualityInspectOrderInbound:"",
                    Warehouse: "",
                    OutboundDelivery: "",
                    WarehouseStore: "",
                    WarehouseStoreItem: "",
                    WarehouseManagement:"",
                    InboundOutbound:"",
                    HostCompany: "",
                    InventoryCheckOrder: "",
                    SystemConfigureResource: "",
                    InboundItem: "",
                    OutboundItem: '',
                    InventoryTransferOrder:'',
                    InventoryTransferItem:''
                },

                production: {
                    ProductionCockpit:"",
                    ProductionPlan: "",
                    ProductionConfigure: "",
                    ProductionPlanManage: "",
                    BillOfMaterialOrder: "",
                    BillOfMaterialTemplate: "",
                    ProductionOrder: "",
                    RepairProdOrder: "",
                    ProductionOrderSwimChart: "",
                    ProdPickingOrder: "",
                    ProdOrderReport: "",
                    ProdOrderTargetMatItem: "",
                    ProcessBOMOrder: "",
                    ProdProcess: "",
                    ProcessRouteOrder: "",
                    WorkingCenter: "",
                    ProductionProcess:"",
                    ProductionResourceUnion: "",
                    ProdWorkCenter: "",
                    ProdBasicData: "",
                    ProdReturnOrder: "",
                    QualityInspectOrderProd: "",
                    ProdPickingOrderManage: "",
                    ProdPickingRefMaterialItem: "",
                    ProdReturnRefMaterialItem: ""
                }
            },
            corePostfix:'',
            groupId:'',
            navigationId:'',
            category:NavigationPanel.CONST.category.application,
            authorizationACUnionList:[]
        };
    },

    created: function (){
        var vm = this;
        vm.initSubComponents();
        vm.initCorePost();
        vm.setI18nNavigation();
    },

    computed:{
        comContainerId:function(){
            return 'document-modal-' + this.corePostfix;
        }
    },

    methods: {

        initCorePost: function(){
            "use strict";
            this.corePostfix = genRamdomPostIndex();
        },

        initSubComponents: function () {
            Vue.component("navigation-group", NavigationGroup);
            Vue.component("side-bar-navigation", SideBarNavigation);
            Vue.component("rightside-systemmenu", RightSideMenu);
            Vue.component("message-menu", MessageMenu);
            Vue.component("search-navigation", SearchNavigation);
        },

        setI18nNavigation: function (fnCallback) {
            var vm = this;
            var _fnCallback = function(){
                ServiceUtilityHelper.setI18nReflective(vm.label.group, $.i18n.prop, true);
                ServiceUtilityHelper.setI18nReflective(vm.label.admin, $.i18n.prop, true);
                ServiceUtilityHelper.setI18nReflective(vm.label.logistics, $.i18n.prop, true);
                ServiceUtilityHelper.setI18nReflective(vm.label.production, $.i18n.prop, true);
                vm.$refs.rightmenu.setI18nCommonProperties();
                if(fnCallback){
                    fnCallback();
                }
            };
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                commonCallback:this.setI18nCommonProperties,
                fnCallback: _fnCallback,
                path: "foundation/",
                label: vm.label, vm:vm, errorHandle: vm.errorHandle,
                configList:[{
                    name: 'NavigationElementResource',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        setI18nCommonProperties: function () {
            "use strict";
            var vm = this;
            ServiceUtilityHelper.setI18nReflective(vm.label.common, $.i18n.prop, true);
            if (this.serviceExtensionSettingHelper) {
                this.serviceExtensionSettingHelper.setCustomI18n(this.$http, "NavigationElementResource", this.label.common);
            }
            $(".button-menu-mobile").tooltip({title: this.label.common.toggleNavBar, placement:'bottom'});

        },

        initNavigation: function (groupId, navigationId) {
            var vm = this;
            vm.$set(vm, 'groupId', groupId);
            vm.$set(vm, 'navigationId', navigationId);
            vm.$set(vm, 'category', NavigationPanel.CONST.category.application);
            vm.setI18nNavigation(function (){
                vm.initNavigationCore({
                    groupId: groupId,
                    navigationId: navigationId,
                    label: vm.label,
                    init:true
                });
            });
        },

        /**
         * @public LoadNavigation entrance method, generate navigation dom.
         * @param groupId: current active navigation group id.
         * @param navigationId: current active navigation resource id.
         */
        initInternalNavigation: function (groupId, navigationId) {
            var vm = this;
            vm.$set(vm, 'groupId', groupId);
            vm.$set(vm, 'navigationId', navigationId);
            vm.$set(vm, 'category', NavigationPanel.CONST.category.systemConfig);
            vm.setI18nNavigation(function (){
                vm.initNavigationCore({
                    groupId: groupId,
                    navigationId: navigationId,
                    label: vm.label,
                    init:true,
                    groupConfigPath: 'js/navigationSysConfig.json'
                });
            });
        },

        messageUpdateHandler: function(messageList){
            var vm = this;
            vm.setI18nNavigation(function (){
                var groupConfigPath;
                if(vm.category * 1 === NavigationPanel.CONST.category.systemConfig){
                    groupConfigPath = 'js/navigationSysConfig.json'
                }
                vm.initNavigationCore({
                    groupId: vm.groupId,
                    navigationId: vm.navigationId,
                    label: vm.label,
                    groupConfigPath: groupConfigPath,
                    messageList: messageList
                });
            });
            var messageResponseList = ServiceCollectionsHelper.filterToArray(vm.navigationId, 'navigationSourceId', messageList);
            if(!ServiceCollectionsHelper.checkNullList(messageResponseList) ){
                if (typeof dataVar !== "undefined" && dataVar.handleMessageResponseList){
                    dataVar.handleMessageResponseList(messageResponseList);
                }
                if (typeof listVar !== "undefined" && listVar.handleMessageResponseList){
                    listVar.handleMessageResponseList(messageResponseList);
                }
            }
        },

        openLeftBarMenu: function(){
            $("#wrapper").toggleClass("enlarged");
            $("#wrapper").addClass("forced");

            if($("#wrapper").hasClass("enlarged") && $("body").hasClass("fixed-left")) {
                $("body").removeClass("fixed-left").addClass("fixed-left-void");
            } else if(!$("#wrapper").hasClass("enlarged") && $("body").hasClass("fixed-left-void")) {
                $("body").removeClass("fixed-left-void").addClass("fixed-left");
            }

            if($("#wrapper").hasClass("enlarged")) {
                $(".left ul").removeAttr("style");
            } else {
                $(".subdrop").siblings("ul:first").show();
            }

            toggle_slimscroll(".slimscrollleft");
            $("body").trigger("resize");
        },

        openRightSideBar: function(tab, key, event, argus){
            "use strict";
            var rightMenu = this.$refs.rightmenu;
            if(rightMenu && rightMenu.openRightSideBar){
                rightMenu.openRightSideBar(tab, key, event, argus);
            }
        },

        openRightSideBarHandler: function(oSettings){
            "use strict";
            var rightMenu = this.$refs.rightmenu;
            if(rightMenu && rightMenu.openRightSideBarHandler){
                rightMenu.openRightSideBarHandler(oSettings);
            }
        },


        closeRightSideBar: function(event){
            var rightMenu = this.$refs.rightmenu;
            if(rightMenu && rightMenu.closeRightSideBar){
                rightMenu.closeRightSideBar(event);
            }
        },

        getAuthorizationACUnionListPromise: function () {
            var vm = this;
            return new Promise(function (resolve, reject) {
                if (this.authorizationACUnionList && this.authorizationACUnionList.length > 0) {
                    resolve(this.authorizationACUnionList);
                } else {
                    var authorizationACUnionListPromise = ServiceApplicationFactory.getAuthorizationACUnionListPromise(vm.$http);
                    authorizationACUnionListPromise.then(function (values) {
                        this.authorizationACUnionList = values;
                        resolve(this.authorizationACUnionList);
                    });
                }
            }.bind(this));
        },

        initNavigationCore: function (oSettings) {
            var vm = this;
            var label = oSettings.label;
            var navGroupListPromise = vm.$refs.navigationGroup.getNavigationGroupListPromise(oSettings);
            var authorizationACUnionListPromise = vm.getAuthorizationACUnionListPromise(vm.$http);
            Promise.all([authorizationACUnionListPromise, navGroupListPromise]).then(function (values) {
                var navigationGroupList = values[1].navigationList;
                var authorizationList = values[0];
                vm.$refs.navigationGroup.initGroupConfigure({
                    navigationGroupList: navigationGroupList,
                    authorizationList: authorizationList,
                    label: label,
                    groupId: oSettings.groupId,
                    init: true
                });
            });

            navGroupListPromise.then(function (data) {
                var navigationGroupList = data.navigationList;
                var navElementListPromise = vm.$refs.sideBarNavigation.getNavigationListPromise(oSettings.groupId, navigationGroupList);
                vm.$refs.sideBarNavigation.initNaviConfigure({
                    navElementListPromise: navElementListPromise,
                    authorizationPromise: authorizationACUnionListPromise,
                    label: label,
                    navigationId: oSettings.navigationId,
                    messageList: oSettings.messageList,
                    init: oSettings.init
                });
            });
        }
    },

    template:'' +
        '<div :id="comContainerId">\n' +
        '      <div class="topbar">\n' +
        '                    <div class="topbar-left">\n' +
        '                        <div class="text-center">\n' +
        '                            <a href="index2.html" class="logo">\n' +
        '                                <i class="md md-equalizer"></i><span>Thorstein ERP</span>\n' +
        '                            </a>\n' +
        '                        </div>\n' +
        '                    </div>\n' +
        '                    <div class="navbar navbar-default" role="navigation">\n' +
        '                        <div class="container">\n' +
        '                            <div class="">\n' +
        '                                <div class="pull-left">\n' +
        '                                    <button class="button-menu-mobile open-left waves-effect" @click="openLeftBarMenu">\n' +
        '                                        <i class="md md-menu"></i>\n' +
        '                                    </button><span class="clearfix"></span>\n' +
        '                                </div>\n' +
        '                                <navigation-group ref="navigationGroup"></navigation-group>\n' +
        '                                <search-navigation></search-navigation>\n' +
        '                                <rightside-systemmenu ref="rightmenu" enable-right-bar="true"></rightside-systemmenu>\n' +
        '                                <message-menu @messageUpdate="messageUpdateHandler"></message-menu>\n' +
        '                            </div>\n' +
        '                        </div>\n' +
        '                    </div>\n' +
        '                </div>\n' +
        '                <div class="left side-menu">\n' +
        '                    <div id="sidebar-menu" class="sidebar-inner slimscrollleft">\n' +
        '                        <side-bar-navigation ref="sideBarNavigation"></side-bar-navigation>\n' +
        '                        <div class="clearfix"></div>\n' +
        '                    </div>\n' +
        '                    <div id="userLoginHoc">\n' +
        '                        <user-detail-block></user-detail-block>\n' +
        '                    </div>\n' +
        '     </div>\n' +
        '</div>'
});

NavigationPanel.getLabelById = function (id, label) {
    if (label.common[id]) {
        return label.common[id];
    }
    if (label.group[id]) {
        return label.group[id];
    }
    if (label.admin[id]) {
        return label.admin[id];
    }
    if (label.logistics[id]) {
        return label.logistics[id];
    }
    if (label.production[id]) {
        return label.production[id];
    }
    return id;
};

NavigationPanel.CONST = {
    category:{
        application: 1,
        systemConfig: 2
    }
};

Vue.component("navigation-panel", NavigationPanel);

var NavigationPanelIns = new NavigationPanel({
    el:'navigation-panel'
});