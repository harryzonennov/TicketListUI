var dataVar = new Vue({
    el: "#x_data",
    mixins: [RegisteredProductManager.labelTemplate,SerDocumentControlHelper.defControlMinxin],
    data: {
        label: RegisteredProductManager.label.registeredProduct,
        content: {
            registeredProductUIModel: RegisteredProductManager.content.registeredProductUIModel,
            salesBy: ServiceUtilityHelper.cloneObj(ServiceInvolvePartyHelper.defContentObj),
            salesTo: ServiceUtilityHelper.cloneObj(ServiceInvolvePartyHelper.defContentObj),
            purchaseBy: ServiceUtilityHelper.cloneObj(ServiceInvolvePartyHelper.defContentObj),
            productBy: ServiceUtilityHelper.cloneObj(ServiceInvolvePartyHelper.defContentObj),
            supportBy: ServiceUtilityHelper.cloneObj(ServiceInvolvePartyHelper.defContentObj),
            registeredProductExtendPropertyUIModelList: [],
            registeredProductAttachmentUIModelList:[]
        },
        getDocFlowListURL: '../registeredProduct/getDocFlowList.html',
        newRegisteredProductExtendPropertyServiceURL: '../registeredProductExtendProperty/newModuleService.html',
        getQualityInspectFlagMapURL: '../registeredProduct/getQualityInspectFlagMap.html',
        searchStandardUnitURL:'../standardMaterialUnit/searchModuleService.html',
        loadValueSettingListURL: '../matConfigExtPropertySetting/loadLeanModuleListService.html',
        loadValueSettingURL: '../matConfigExtPropertySetting/loadModule.html',
        getMeasureFlagMapURL: '../matConfigExtPropertySetting/getMeasureFlagMap.html'
    },


    mounted: function () {
        NavigationPanelIns.initNavigation('logistics', 'RegisteredProduct');
    },

    methods: {

        /**
         * @Overwrite: Get document type for each edit controller
         */
        getDocumentType: function () {
            return DocumentConstants.DummyDocumentType.RegisteredProduct;
        },

        getServiceManager: function () {
            return RegisteredProductManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "RegisteredProductEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.registeredProductUIModel.uuid;
        },

        /**
         * @Overwrite: get document status from content
         */
        getStatus: function () {
            return this.content.registeredProductUIModel.status;
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'registeredProductUIModel', content.registeredProductUIModel);
            vm.$set(vm.content, 'registeredProductExtendPropertyUIModelList', content.registeredProductExtendPropertyUIModelList);
            vm.$set(vm.content, 'registeredProductAttachmentUIModelList', content.registeredProductAttachmentUIModelList);
            vm.$set(vm.content, 'salesBy', content.salesBy);
            vm.$set(vm.content, 'salesTo', content.salesTo);
            vm.$set(vm.content, 'purchaseBy', content.purchaseBy);
            vm.$set(vm.content, 'productBy', content.productBy);
            vm.$set(vm.content, 'supportBy', content.supportBy);
            vm.postUpdateUIModel();
        },

        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'RegisteredProductEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: RegisteredProductManager,
                coreModelId: 'RegisteredProduct',
                i18nPath: 'coreFunction/',
                getDocActionNodeListURL: '../registeredProduct/getDocActionNodeList.html',
                helpDocumentName: ['RegisteredProductHelpDocument', 'RegisteredProductUnitHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: 'displayForEdit',
                        callback: 'saveModule'
                    },
                    placeholder: {
                        category: ProcessButtonConstants.placeholderCategory.DOC_ACTION_BTN
                    },
                    exit: {
                        callback: 'exitModule'
                    }
                },
                tabMetaList: [{
                    tabId: 'registeredProductSection',
                    tabTitleKey: 'registeredProductSection',
                    titleLabelKey: 'registeredProductSection',
                    titleHelpKey: 'registeredProduct.registeredProductSection',
                    titleIcon: 'md md-texture content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'materialStockKeepUnitSection',
                        updatedByUidPath: 'updatedByUUID',
                        updatedByNamePath: 'updatedByName',
                        updatedDatePath: 'updatedDate',
                        messageResponsePath: 'meta.messageResponse',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'registeredProductUIModel',
                        tabTitleKey: 'materialStockKeepUnitSection',
                        titleLabelKey: 'materialStockKeepUnitSection',
                        titleIcon: 'md md-texture content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'refMaterialSKUId',
                            disabled: true,
                            newRow: true,
                            popupConfigure: {
                                popupLabelClass: "popup-material",
                                documentFunction: "getDocumentPopoverContent",
                                documentType: "MaterialStockKeepUnit",
                                targetUidPath: 'refMaterialSKUUUID',
                                popupTitlePath: 'refMaterialSKUId',
                                headerTitlePath: 'refMaterialSKUId'
                            },
                        }, {
                            disabled: true,
                            fieldName: 'refMaterialSKUName',
                        }, {
                            disabled: true,
                            fieldName: 'packageStandard',
                        }, {
                            fieldName: 'materialCategory',
                            newRow: true,
                            disabled: true,
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.loadMaterialCategoryURL,
                                formatMeta: MaterialManager.formatMaterialCategory
                            },
                            helpKey: 'materialStockKeepUnit.materialCategory',
                            iconArray: MaterialManager.getMaterialCategoryIconArray(),
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'supplyType',
                            disabled: true,
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getSupplyTypeURL,
                                formatMeta: MaterialManager.formatSupplyType
                            },
                            helpKey: 'materialStockKeepUnit.supplyType',
                            iconArray: MaterialManager.getSupplyTypeIconArray(),
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }]
                    },{
                        sectionId: 'registeredProductSection',
                        updatedByUidPath: 'updatedByUUID',
                        updatedByNamePath: 'updatedByName',
                        updatedDatePath: 'updatedDate',
                        messageResponsePath: 'meta.messageResponse',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'registeredProductUIModel',
                        tabTitleKey: 'registeredProductSection',
                        titleLabelKey: 'registeredProductSection',
                        titleHelpKey: 'registeredProduct.registeredProductSection',
                        titleIcon: 'md md-texture content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'serialId',
                            required: true,
                            newRow: true
                        }, {
                            fieldName: 'traceStatus',
                            helpKey: 'registeredProduct.traceStatus',
                            disabled: true,
                            settings: {
                                getMetaDataUrl: MaterialStockKeepUnitManager.constants.getTraceStatusURL,
                                formatMeta: MaterialStockKeepUnitManager.formatTraceModeClass
                            },
                            iconArray: MaterialStockKeepUnitManager.getTraceStatusIconArray(),
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'id',
                            disabled: true,
                            newRow: true
                        }, {
                            fieldName: 'productionDate',
                        }, {
                            fieldName: 'productionPlace',
                        }, {
                            fieldName: 'qualityInspectFlag',
                            disabled: true,
                            helpKey: 'registeredProduct.qualityInspectFlag',
                            settings: {
                                getMetaDataUrl: MaterialManager.constants.getQualityInspectFlagMapURL,
                                formatMeta: SystemStandrdMetadataProxy.formatDefaultSwitchCode,
                            },
                            iconArray: SystemStandrdMetadataProxy.getDefaultSwitchIconArray(),
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        }]
                    }, {
                        sectionId: 'registeredProductAttachment',
                        sectionCategory: AsyncSection.sectionCategory.ATTACHMENT,
                        parentContentPath: 'registeredProductAttachmentUIModelList',
                        errorHandle: 'errorHandle',
                        settings: {
                            configMetaPath: 'attachmentMeta'
                        }
                    }]
                }, {
                    tabId: 'materialSizeSection',
                    tabTitleKey: 'materialSizeSection',
                    titleHelpKey: 'materialSizeSection',
                    titleLabelKey: 'materialSizeSection',
                    titleIcon: 'md md-straighten content-portlet-title',
                    sectionMetaList: [
                        {
                            sectionId: 'materialSizeSection',
                            sectionCategory: AsyncSection.sectionCategory.EDIT,
                            parentContentPath: 'registeredProductUIModel',
                            tabTitleKey: 'registeredProductSection',
                            titleLabelKey: 'registeredProductSection',
                            titleHelpKey: 'registeredProduct.registeredProductSection',
                            titleIcon: 'md md-straighten content-portlet-title',
                            disabled: 'disableNotInInit',
                            fieldMetaList: [{
                                fieldName: 'mainMaterialUnitName',
                                labelKey: 'mainMaterialUnit',
                                required: true,
                                newRow: true,
                                settings: {
                                    getMetaDataUrl: vm.loadStandardUnitSelectListURL,
                                    idField: 'uuid',
                                    textField: 'name',
                                    formatMeta: SystemStandrdMetadataProxy.formatCargoType
                                },
                                fieldType: AbsInput.FIELDTYPE.TypeAhead
                            }, {
                                fieldName: 'packageMaterialType',
                                settings: {
                                    getMetaDataUrl: MaterialManager.constants.loadPackageMaterialTypeURL,
                                },
                                fieldType: AbsInput.FIELDTYPE.Select2
                            }, {
                                fieldName: 'length',
                                newRow: true,
                                postFieldMeta: [{
                                    fieldName: 'refLengthUnit',
                                    settings: {
                                        getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                        requestData: {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.LENGTH},
                                        method: 'post',
                                        idField: 'uuid',
                                        textField: 'name',
                                        formatMeta: SystemStandrdMetadataProxy.formatCargoType
                                    },
                                    fieldType: AbsInput.FIELDTYPE.Select2
                                }]
                            }, {
                                fieldName: 'width',
                            }, {
                                fieldName: 'height',
                            }, {
                                fieldName: 'volume',
                                newRow: true,
                                postFieldMeta: [{
                                    fieldName: 'refVolumeUnit',
                                    settings: {
                                        getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                        requestData: {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.VOLUME},
                                        method: 'post',
                                        idField: 'uuid',
                                        textField: 'name',
                                        formatMeta: SystemStandrdMetadataProxy.formatCargoType
                                    },
                                    fieldType: AbsInput.FIELDTYPE.Select2
                                }]
                            }, {
                                fieldName: 'netWeight',
                                postFieldMeta: [{
                                    fieldName: 'refWeightUnit',
                                    settings: {
                                        getMetaDataUrl: MaterialManager.constants.searchStandardUnitURL,
                                        requestData: {unitCategory: DocumentConstants.StandardMaterialUnit.unitCategory.WEIGHT},
                                        method: 'post',
                                        idField: 'uuid',
                                        textField: 'name',
                                        formatMeta: SystemStandrdMetadataProxy.formatCargoType
                                    },
                                    fieldType: AbsInput.FIELDTYPE.Select2
                                }]
                            }, {
                                fieldName: 'grossWeight'
                            }, {
                                fieldName: 'minStoreNumber'
                            }]
                        },
                        {
                            sectionId: 'materialPriceSection',
                            sectionCategory: AsyncSection.sectionCategory.EDIT,
                            parentContentPath: 'registeredProductUIModel',
                            tabTitleKey: 'materialPriceSection',
                            titleLabelKey: 'materialPriceSection',
                            titleHelpKey: 'registeredProduct.materialPriceSection',
                            titleIcon: 'md md-attach-money content-portlet-title',
                            disabled: 'disableNotInInit',
                            fieldMetaList: [{
                                fieldName: 'purchasePrice',
                                newRow: true,
                                helpKey: 'registeredProduct.purchasePrice'
                            }, {
                                fieldName: 'purchasePriceDisplay',
                                helpKey: 'registeredProduct.purchasePriceDisplay'
                            }, {
                                fieldName: 'retailPrice',
                                newRow: true,
                                helpKey: 'registeredProduct.retailPrice'
                            }, {
                                fieldName: 'retailPriceDisplay',
                                helpKey: 'registeredProduct.retailPriceDisplay'
                            }, {
                                fieldName: 'unitCost',
                                newRow: true,
                                helpKey: 'registeredProduct.unitCost'
                            }, {
                                fieldName: 'unitCostDisplay',
                                helpKey: 'registeredProduct.unitCostDisplay'
                            }]
                        }
                    ]
                }, {
                    tabId: 'productOrganizationSection',
                    tabTitleKey: 'productOrganizationSection',
                    titleLabelKey: 'productOrganizationSection',
                    titleHelpKey: 'registeredProduct.productOrganizationSection',
                    titleIcon: 'ion-wrench content-portlet-title',
                    sectionMetaList: [
                        {
                            sectionId: 'productOrganization',
                            sectionCategory: AsyncSection.sectionCategory.CUSTOMERCONTACT,
                            labelPath: 'productBy',
                            parentContentPath: 'productBy',
                            tabTitleKey: 'productOrganization',
                            titleLabelKey: 'productOrganization',
                            customerRequired: true,
                            accountObjectType: DocumentConstants.AccountObject.AccountType.ORGANIZATION,
                            titleHelpKey: 'registeredProduct.productOrganization',
                            disabled: 'disableNotInInit',
                            sectionColClass: 'col-md-6',
                            helpConfigureList: [{
                                helpKey: 'registeredProduct.productOrganization',
                                fieldKey: 'involvePartyTitle'
                            }],
                        }, {
                            sectionId: 'supportOrganizationSection',
                            sectionCategory: AsyncSection.sectionCategory.CUSTOMERCONTACT,
                            labelPath: 'supportBy',
                            parentContentPath: 'supportBy',
                            tabTitleKey: 'supportOrganizationSection',
                            titleLabelKey: 'supportOrganizationSection',
                            disabled: 'disableNotInInit',
                            accountObjectType: DocumentConstants.AccountObject.AccountType.ORGANIZATION,
                            titleHelpKey: 'registeredProduct.supportOrganizationSection',
                            sectionColClass: 'col-md-6',
                            helpConfigureList: [{
                                helpKey: 'registeredProduct.supportOrganizationSection',
                                fieldKey: 'involvePartyTitle'
                            }],
                        }
                    ]
                }, {
                    tabId: 'corporateCustomerSection',
                    tabTitleKey: 'corporateCustomerSection',
                    titleLabelKey: 'corporateCustomerSection',
                    titleHelpKey: 'registeredProduct.corporateCustomerSection',
                    titleIcon: 'md md-alarm-on  content-portlet-title',
                    sectionMetaList: [
                        {
                            sectionId: 'corporateCustomerSection',
                            sectionCategory: AsyncSection.sectionCategory.CUSTOMERCONTACT,
                            labelPath: 'salesTo',
                            parentContentPath: 'salesTo',
                            tabTitleKey: 'corporateCustomerSection',
                            titleLabelKey: 'corporateCustomerSection',
                            customerRequired: true,
                            accountObjectType: DocumentConstants.AccountObject.AccountType.COR_CUSTOMER,
                            titleHelpKey: 'registeredProduct.corporateCustomerSection',
                            disabled: 'disableNotInInit',
                            sectionColClass: 'col-md-6',
                            helpConfigureList: [{
                                helpKey: 'registeredProduct.corporateCustomerSection',
                                fieldKey: 'involvePartyTitle'
                            }],
                        }, {
                            sectionId: 'salesOrganizationSection',
                            sectionCategory: AsyncSection.sectionCategory.CUSTOMERCONTACT,
                            labelPath: 'salesBy',
                            parentContentPath: 'salesBy',
                            tabTitleKey: 'salesOrganizationSection',
                            titleLabelKey: 'salesOrganizationSection',
                            disabled: 'disableNotInInit',
                            accountObjectType: DocumentConstants.AccountObject.AccountType.ORGANIZATION,
                            titleHelpKey: 'registeredProduct.salesOrganizationSection',
                            sectionColClass: 'col-md-6',
                            helpConfigureList: [{
                                helpKey: 'registeredProduct.salesOrganizationSection',
                                fieldKey: 'involvePartyTitle'
                            }],
                        }
                    ]
                }, {
                    tabId: 'corporateSupplierSection',
                    tabTitleKey: 'corporateSupplierSection',
                    titleLabelKey: 'corporateSupplierSection',
                    titleHelpKey: 'registeredProduct.corporateSupplierSection',
                    titleIcon: 'md md-alarm-on  content-portlet-title',
                    sectionMetaList: [
                        {
                            sectionId: 'corporateSupplierSection',
                            sectionCategory: AsyncSection.sectionCategory.CUSTOMERCONTACT,
                            labelPath: 'purchaseFrom',
                            parentContentPath: 'purchaseFrom',
                            tabTitleKey: 'corporateSupplierSection',
                            titleLabelKey: 'corporateSupplierSection',
                            customerRequired: true,
                            accountObjectType: DocumentConstants.AccountObject.AccountType.SUPPIER,
                            titleHelpKey: 'registeredProduct.corporateSupplierSection',
                            disabled: 'disableNotInInit',
                            sectionColClass: 'col-md-6',
                            helpConfigureList: [{
                                helpKey: 'registeredProduct.corporateSupplierSection',
                                fieldKey: 'involvePartyTitle'
                            }],
                        }, {
                            sectionId: 'purchaseOrganizationSection',
                            sectionCategory: AsyncSection.sectionCategory.CUSTOMERCONTACT,
                            labelPath: 'purchaseBy',
                            parentContentPath: 'purchaseBy',
                            tabTitleKey: 'purchaseOrganizationSection',
                            titleLabelKey: 'purchaseOrganizationSection',
                            disabled: 'disableNotInInit',
                            accountObjectType: DocumentConstants.AccountObject.AccountType.ORGANIZATION,
                            titleHelpKey: 'registeredProduct.purchaseOrganizationSection',
                            sectionColClass: 'col-md-6',
                            helpConfigureList: [{
                                helpKey: 'registeredProduct.purchaseOrganizationSection',
                                fieldKey: 'involvePartyTitle'
                            }],
                        }
                    ]
                }, {
                    tabId: 'registeredProductExtendSection',
                    tabTitleKey: 'registeredProductExtendSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'registeredProductExtendSection',
                        parentContentPath: 'registeredProductExtendPropertyUIModelList',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        editModule: 'editRegisteredProductExtendProperty',
                        refItemName: 'materialSkuUnitPanel',
                        requiredSubmit: true,
                        tabTitleKey: 'registeredProductExtendSection',
                        titleLabelKey: 'registeredProductExtendSection',
                        titleHelpKey: 'registeredProduct.registeredProductExtendSection',
                        titleIcon: 'md md-my-library-books content-portlet-title',
                        scrollX: true,
                        fieldMetaList: [{
                            fieldName: 'registeredProductExtendPropertyUIModel.uuid'
                        }, {
                            fieldName: 'registeredProductExtendPropertyUIModel.id',
                            labelKey: 'registeredProductExtendProperty.id',
                            minWidth: '180px'
                        }, {
                            fieldName: 'registeredProductExtendPropertyUIModel.name',
                            labelKey: 'registeredProductExtendProperty.name',
                            minWidth: '180px'
                        }, {
                            fieldName: 'registeredProductExtendPropertyUIModel.measureFlagValue',
                            labelKey: 'registeredProductExtendProperty.measureFlag',
                            fieldKey: 'registeredProductExtendPropertyUIModel.measureFlag',
                            iconArray: SystemStandrdMetadataProxy.getDefaultSwitchIconArray()
                        }, {
                            fieldName: 'registeredProductExtendPropertyUIModel.doubleValue',
                            labelKey: 'registeredProductExtendProperty.rawValue',
                        }, {
                            fieldName: 'registeredProductExtendPropertyUIModel.refUnitValue',
                            labelKey: 'registeredProductExtendProperty.refUnitUUID',
                        }, {
                            fieldName: 'registeredProductExtendPropertyUIModel.qualityInspectFlagValue',
                            fieldKey: 'registeredProductExtendPropertyUIModel.qualityInspectFlag',
                            labelKey: 'registeredProductExtendProperty.qualityInspectFlag',
                            iconArray: SystemStandrdMetadataProxy.getDefaultSwitchIconArray(),
                            minWidth: '180px'
                        }]
                    }]
                }]
            };
        },

        editRegisteredProductExtendProperty: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            window.location.href = genCommonEditURL("RegisteredProductExtendPropertyEditor.html", uuid);
        }

    }
});
