/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var CorporateCustomerManager = function () {

};

CorporateCustomerManager.label = {
    corporateCustomer: ServiceUtilityHelper.getComLabelObject({
        tagsSearchComment: '',
        contactPersonName:'',
        launchDate: '',
        weiXinID: '',
        status: '',
        weiboID: '',
        customerType: '',
        modelTitle:'',
        subDistributorType: '',
        faceBookID: '',
        fax:'',
        email:'',
        tags:'',
        tagsEditComment:'',
        address: '',
        telephone:'',
        deleteWarnTitle:'',
        deleteWarnText:'',
        confirm:'',
        taxNumber: '',
        depositBank:'',
        bankAccount: '',
        contactSection:'',
        countryName:'',
        customerLevel:'',
        stateName:'',
        cityName:'',
        townZone:'',
        streetName:'',
        systemDefault:'',
        systemDefaultComment:'',
        corporateCustomerSection: '',
        corporateContactPersonSection: '',
        customerAttachmentSection: '',
        advancedSearchCondition: ''
    }),
    corporateContactPerson: ServiceUtilityHelper.getComLabelObject({
        address: '',
        mobile: '',
        email:'',
        telephone: '',
        contactRole: '',
        contactPosition: '',
        contactPersonCustomerType: '',
        contactRoleNote: '',
        contactPersonNote: '',
        add: ''
    })
};

CorporateCustomerManager.content = {
    corporateCustomerUIModel: ServiceUtilityHelper.extendObject({
        baseCityUUID: '',
        refSalesAreaUUID: '',
        dealerTypeUUID: '',
        refRouteUUID: '',
        weiXinID: '',
        taxNumber: '',
        depositBank:'',
        countryName:'',
        stateName:'',
        cityName:'',
        telephone:'',
        townZone:'',
        streetName:'',
        bankAccount: '',
        status: '',
        fax: '',
        address:'',
        email:'',
        customerLevel:'',
        tags:'',
        customerType: '',
        launchReason: '',
        retireReason: '',
        launchDate: '',
        faceBookID: '',
        systemDefault:''
    }, ServiceUtilityHelper.getDefContent()),
    corporateContactPersonUIModel:ServiceUtilityHelper.extendObject({
        refNodeName: '',
        refUUID: '',
        contactRole: '',
        contactPosition: '',
        contactPositionNote: '',
        contactRoleNote: '',
        contactPersonId: '',
        contactPersonName: '',
        contactPersonCustomerType: '',
        contactPersonNote: ''
    }, ServiceUtilityHelper.getDefContent())
};

CorporateCustomerManager.labelTemplate = {
    data: function() {
        return {
            label: {
                "corporateContactPerson":CorporateCustomerManager.label.corporateContactPerson
            }
        };
    }
};

/**
 * Definition of Tab on UI
 * @type {{}}
 */
CorporateCustomerManager.documentTab = {
    corporateCustomerSection:"tabCorporateCustomerSection",
    contactSection:"tabContactSection",
    customerAttachmentSection:"tabCustomerAttachmentSection"
};

CorporateCustomerManager.DOC_ACTION_CODE = {
    APPROVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_APPROVE,
    REJECT_APPROVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REJECT_APPROVE,
    SUBMIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_SUBMIT,
    REVOKE_SUBMIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REVOKE_SUBMIT,
    REINIT: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_REINIT,
    ACTIVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_ACTIVE,
    ARCHIVE: DocumentConstants.StandardPropety.SystemDefDocActionCodeProxy.ACTION_ARCHIVE
};

/**
 * @override Get Basic URL for load document corporateCustomer item instance.
 * @returns {string}
 */
CorporateCustomerManager.prototype.getLoadDocItemBaseURL = function () {
    "use strict";
    return undefined;
};

/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
CorporateCustomerManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../corporateCustomer/loadModuleViewService.html';
};

/**
 * Constants method: Get URL for load status metadata
 * @returns {*[]}
 */
CorporateCustomerManager.prototype.getStatusURL = function(status) {
    "use strict";
    return undefined;
};

/**
 * Constants method: Generate the array for mapping 'status' and its icon
 * @returns {*[]}
 */
CorporateCustomerManager.prototype.getStatusIconArray = function () {
    "use strict";
    return CorporateCustomerManager.getStatusIconArray();
};

/**
 * @override Get Basic URL for load document list.
 * @returns {string}
 */
CorporateCustomerManager.prototype.getLoadSelectListURL = function () {
    "use strict";
    return '../corporateCustomer/loadModuleListService.html';
};

/**
 * [API] Get root node inst id
 */
CorporateCustomerManager.getRootNodeInstId = function(){
    return "corporateCustomer";
};

/**
 * [API]Get item node inst id
 */
CorporateCustomerManager.getItemNodeInstId = function(){
    return "corporateContactPerson";
};


/**
 * [API] Get resource id for checking authorization
 */
CorporateCustomerManager.getResourceId = function(){
    return ServiceModuleConstants.CorporateCustomer;
};

/**
 * [API] Get document type
 */
CorporateCustomerManager.getDocumentType = function(){
    return DocumentConstants.DummyDocumentType.CorporateCustomer;
};

/**
 * [API]Get root 18n config
 */
CorporateCustomerManager.getI18nRootConfig = function () {
    return {
        i18nPath: 'coreFunction/',
        mainName: 'CorporateCustomer',
        modelId: 'CorporateCustomer', coreModelId: 'CorporateCustomer',
        configList: [{
            name: 'CorporateContactPerson',
            subLabelPath: 'corporateContactPerson'
        }, {
            actionNodePath: 'actionNode'
        }]
    };
};

/**
 * [API]Get item 18n config
 */
CorporateCustomerManager.getI18nItemConfig = function () {
    "use strict";
    return {
        i18nPath: 'coreFunction/',
        labelObject: CorporateCustomerManager.label.corporateContactPerson,
        mainName: 'CorporateContactPerson',
        modelId: 'CorporateCustomer', coreModelId: 'CorporateContactPerson',
        configList: [{
            name: 'CorporateContactPerson'
        }]
    };
};


CorporateCustomerManager.getActionCodeIconMap = function () {
    var actionCodeIconMap = ServiceUtilityHelper.getMergedActionCodeIconMap(CorporateCustomerManager.getCustomActionCodeIconMap());
    return actionCodeIconMap;
};

CorporateCustomerManager.formatCustomerLevel = function (content) {
    return ServiceUtilityHelper.genTemplateFormatFunction(content.dataList);
};

/**
 * Constants method: Generate the array for mapping 'status' and its icon
 * @returns {*[]}
 */
CorporateCustomerManager.getStatusIconArray = function () {
    "use strict";
    return [{
        id: DocumentConstants.CorporateCustomer.status.INITIAL, iconClass: DocumentContentProp.statusIcon.INITIAL
    }, {
        id: DocumentConstants.CorporateCustomer.status.INUSE, iconClass: DocumentContentProp.statusIcon.INPROCESS
    }, {
        id: DocumentConstants.CorporateCustomer.status.ARCHIVED, iconClass: DocumentContentProp.statusIcon.ARCHIVED
    }];
};

CorporateCustomerManager.formatStatusIconClass = function (status) {
    "use strict";
    var statusIconArray = CorporateCustomerManager.getStatusIconArray();
    var $element = ServiceCollectionsHelper.filterArray(status, 'id', statusIconArray);
    if($element){
        return $element.iconClass;
    }
};

CorporateCustomerManager.formatStatus = function (status) {
    var $element = ServiceUtilityHelper.formatSelectWithIcon(status, CorporateCustomerManager.getStatusIconArray(), true);
    return $element;
};

/**
 * @override Set Basic path for i18n function.
 * @returns {string}
 */
CorporateCustomerManager.getI18nPath = function () {
    return "coreFunction/";
};

CorporateCustomerManager.prototype.getI18nCommonMap = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(CorporateCustomerManager.label.corporateCustomer, $.i18n.prop);
};

CorporateCustomerManager.prototype.getI18nDocMap = function () {
    "use strict";
    ServiceUtilityHelper.setI18nReflective(CorporateCustomerManager.label.corporateCustomer, $.i18n.prop, true);
};

CorporateCustomerManager.prototype.getModelTitle = function(){
    return CorporateCustomerManager.label.corporateCustomer.modelTitle;
};

CorporateCustomerManager.prototype.getDefaultDocumentEditorPage = function(){
    "use strict";
    return "CorporateCustomerEditor.html";
};

CorporateCustomerManager.prototype.getDefaultDocumentItemEditorPage = function(){
    "use strict";
    return undefined;
};

CorporateCustomerManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: vm.getDefaultDocumentEditorPage(),
        url: vm.getLoadDocumentBaseURL(),
        subPath: 'corporateCustomerUIModel',
        docType : DocumentConstants.DummyDocumentType.CorporateCustomer,
        label:CorporateCustomerManager.label.corporateCustomer,
        i18nConfig: CorporateCustomerManager.getI18nRootConfig(),
    });

    var fieldMetaList = [{
        fieldName:'id',
    },{
        fieldName:'name',
    },{
        fieldName:'telephone',
    },{
        fieldName:'mobile',
    },{
        fieldName: 'address'
    },{
        fieldName: 'note'
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};

