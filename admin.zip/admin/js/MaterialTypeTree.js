var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: MaterialTypeManager.label.materialType,
        author:{
            resourceId:'MaterialType',
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        downloadExcelURL: '../materialType/downloadExcel.html',
        searchModuleURL: '../materialType/searchModuleService.html',
        searchTreeListURL: '../materialType/searchTreeListService.html'
    },

    created: function(){
        this.initAuthorResourceCheck();
        this.initSubComponents();
    },

    methods: {
        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        searchModule: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.searchTreeListURL, requestData).then(function (response) {
                var items = JSON.parse(response.data).content;
                setTimeout(function () {
                    listVar.refreshTreeView(items);
                }, 0);
            });

            this.$http.post(vm.searchModuleURL, requestData).then(function (response) {
                var items = JSON.parse(response.data).content;
                listVar.refreshTableItems(items);
            });
        },

        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "MaterialTypeEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        newModuleModal: function () {
            listVar.newModuleModal();
        },

        uploadExcel: function(){
            listVar.uploadExcel();
        },

        downloadExcel: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.downloadExcelURL, requestData).then(function (response) {
                ExcelUploadAttach.showFile(response.body, vm.label.reportTitle);
                // vm.showFile(response.body);
            }.bind(this));
        }
    }
});

var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            parentTypeUUID: "",
            name: "",
            id: "",
            rootTypeName: "",
            rootTypeId: "",
            parentTypeName: "",
            parentTypeId: "",
            rootTypeUUID: ""
        },

        label: MaterialTypeManager.label.materialType
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
        });
    },

    methods: {
        clearSearch: function () {
            clearSearchModel(this.content);
        },

        initSelectConfigure: function () {
            var vm = this;


        }
    }

});


var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: MaterialTypeManager.label.materialType,
        cache: {
            uuid: '',
            parentNodeUUID: '',
            rootNodeUUID: '',
            client: '',
            name: '',
            note: '',
            id: '',
            rootTypeUUID: '',
            rootTypeName: '',
            rootTypeNote: '',
            rootTypeId: '',
            parentTypeUUID: '',
            parentTypeName: '',
            parentTypeNote: '',
            parentTypeId: ''
        },

        configMetaUploadExcel:{
            uploadAttachmentURL: '../materialType/uploadExcel.html',
            successCallback:function(){

            }
        },
        loadModuleListURL: '../materialType/loadModuleListService.html',
        eleEditMaterialTypeModal: '#x_eleEditMaterialTypeModal',
        eleParentTypeUUID:'#x_parentTypeUUID',
        eleParentTypeUUIDCache:'#x_parentTypeUUIDCache',
        eleRootTypeUUID:'#x_rootTypeUUID',
        tableId: '#x_table_materialType',
        datatable: '',
        items: [],
        treeItems: [],
        loadModuleTreeURL: '../materialType/loadTreeListService.html',
        preLockURL: '../materialType/preLockService.html',
        saveModuleURL:'../materialType/saveModuleService.html',
        newModuleServiceURL: '../materialType/newModuleFromParentService.html',
        searchModuleTreeURL: '../materialType/searchTreeListService.html',
        loadModuleEditURL: '../materialType/loadModuleEditService.html'
    },

    created: function(){
        this.initSubComponent();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'MaterialType');
            this.datatable = new ServiceDataTable(this.tableId);
            this.setI18nProperties();
            this.loadModuleList();
            this.initSelectConfigure();
            this.loadParentTypeList(searchModel.content);
            this.loadRootTypeList(searchModel.content);
        });
    },

    methods: {
        refreshTreeView: function (items) {
            var vm = this;
            var ser = new XMLSerializer();
            var treeElement = generateBootstrapTreeContent(vm.generateMaterialTypeTreeView(items));
            var htmlContent = ser.serializeToString(treeElement);
            $("#x_tree_materialType").empty();
            $("#x_tree_materialType").prepend(htmlContent);

            $(".iconEditMaterialTypeModel").on("click", function (e) {
                var uuid = $(this).children("input").attr("value");
                vm.editModuleModal(uuid);
                e.stopPropagation();
            });
            $(".iconNewMaterialTypeModel").on("click", function (e) {
                var baseUUID = $(this).children("input").attr("value");
                vm.newModuleModal(baseUUID);
                e.stopPropagation();
            });
            vm.initTreeAction();
        },

        refreshTableItems: function (items) {
            //this.datatable = new ServiceDataTable(this.tableId);
            this.$set(this, 'items', items);
            setTimeout(function () {
                this.datatable.build();
            }.bind(this), 0);

        },

        initSubComponent: function(){
            "use strict";
            Vue.component("excel-upload-modal", ExcelUploadModal);
        },

        initTreeAction: function () {
            $('.tree li.parent_li > span').off('click');
            $('.tree li.parent_li > span').on('click', function (e) {
                var children = $(this).parent('li.parent_li').find(' > ul > li');
                if (children.is(":visible")) {
                    children.hide('fast');
                } else {
                    children.show('fast');
                }
                e.stopPropagation();
            });
        },

        _filterMaterialTypeListByParent:function(contentList, parentTypeUUID){
            if(!contentList){
                return;
            }
            if(!contentList.length || contentList.length === 0){
                return;
            }
            var i, len = contentList.length, result = [];
            for( i = 0; i < len; i++){
                if(!parentTypeUUID || parentTypeUUID == ''){
                    // In case root material type
                    if(!contentList[i].parentTypeUUID || contentList[i].parentTypeUUID == ''){
                        result.push(contentList[i]);
                    }
                }
                if(contentList[i].parentTypeUUID === parentTypeUUID){
                    result.push(contentList[i]);
                }
            }
            return result;
        },


        generateMaterialTypeTreeView: function (contentList) {
            var vm = this;
            var headerModel = {};
            headerModel.uuid = '1';
            headerModel.layer = 1;
            headerModel.iconClass = 'icon-th-list';
            headerModel.spanClass = 'badge-warning';
            headerModel.spanContent = '系统物料类别';
            headerModel.subModelList = [];
            var rootTypeList = vm._filterMaterialTypeListByParent(contentList);
            if (rootTypeList && rootTypeList.length > 0){
                var i, lenth = rootTypeList.length;
                for (i = 0; i < lenth; i++) {
                    headerModel.subModelList.push(vm.generateMaterialTypeTreeUnion(rootTypeList[i], contentList, 2));
                }
            }
            return headerModel;
        },


        generateMaterialTypeTreeUnion: function(rawMaterial, contentList, layer){
            var vm = this;
            var materialTypeUnion = {};
            materialTypeUnion.uuid = rawMaterial.uuid;
            materialTypeUnion.layer = layer;
            materialTypeUnion.rootTypeUUID = rawMaterial.rootTypeUUID;
            materialTypeUnion.parentTypeUUID = rawMaterial.parentTypeUUID;
            materialTypeUnion.iconArray = [];
            materialTypeUnion.spanContent = rawMaterial.id + "-" + rawMaterial.name;
            var editIcon = {};
            editIcon.innerUUID = materialTypeUnion.uuid;
            editIcon.class = 'glyphicon glyphicon-pencil content-green iconEditMaterialTypeModel';
            materialTypeUnion.iconArray.push(editIcon);
            var newIcon = {};
            newIcon.innerUUID = materialTypeUnion.uuid;
            newIcon.class = 'fa fa-plus iconNewMaterialTypeModel';
            materialTypeUnion.iconArray.push(newIcon);
            materialTypeUnion.subModelList = [];
            var subTypeList = vm._filterMaterialTypeListByParent(contentList, rawMaterial.uuid);
            if (subTypeList && subTypeList.length > 0){
                var i, lenth = subTypeList.length;
                for (i = 0; i < lenth; i++) {
                    materialTypeUnion.subModelList.push(vm.generateMaterialTypeTreeUnion(subTypeList[i], contentList, layer + 1));
                }
            }
            return materialTypeUnion;
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties, serviceUIMeta: processModel.serviceUIMeta,
                fnCallback: fnCallback,
                label: [vm.label, processModel.label, searchModel.label], vm: processModel, errorHandle: vm.errorHandle,
                configList: [{
                    name: 'MaterialType',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        initSelectConfigure: function () {
            var vm = this;
            ServiceUtilityHelper.defSelect2CloseHandler({
                vm: vm,
                element: '#' + vm.eleParentTypeUUID,
                postLoadUrl: vm.loadModuleEditURL,
                uuidField:'parentTypeUUID',
                fieldList:[{sourceField:'name', targetField:'parentTypeName'}, 'rootTypeId', 'rootTypeName']
            });

            ServiceUtilityHelper.defSelect2CloseHandler({
                vm: vm,
                element: '#' + vm.eleRootTypeUUID,
                postLoadUrl: vm.loadModuleEditURL,
                uuidField:'rootTypeUUID',
                fieldList:['rootTypeUUID', 'parentTypeName', 'rootTypeId', 'rootTypeName']
            });

        },

        loadParentTypeList:function(searchContent) {
            var vm = this;

            ServiceUtilityHelper.httpRequest({
                url:vm.loadModuleTreeURL,
                $http:vm.$http,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    var content = oData.content;
                    var resultList = formatSelectResult(content, 'uuid', 'id');
                    setTimeout(function () {
                        $(vm.eleParentTypeUUID).select2({
                            data: resultList
                        });
                        $(vm.eleParentTypeUUIDCache).select2({
                            data: resultList
                        });

                        // manually set initial value
                        $(vm.eleParentTypeUUID).val(searchContent.parentTypeUUID);
                        $(vm.eleParentTypeUUID).trigger("change");
                    }, 0);
                }.bind(this)
            });
        },

        loadRootTypeList:function(searchContent) {
            var vm = this;
            //TODO change into root type list later

            ServiceUtilityHelper.httpRequest({
                url:vm.loadModuleListURL,
                $http:vm.$http,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    var content = oData.content;
                    var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'id');
                    setTimeout(function () {
                        $(vm.eleRootTypeUUID).select2({
                            data: resultList
                        });
                        // manually set initial value
                        $(vm.eleRootTypeUUID).val(searchContent.rootTypeUUID);
                        $(vm.eleRootTypeUUID).trigger("change");
                    }, 0);
                }.bind(this)
            });
        },

        loadModuleList: function () {
            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:vm.loadModuleListURL,
                $http:vm.$http,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    var content = oData.content;
                    vm.$set(vm, 'items', oData.content);
                    setTimeout(function () {
                        vm.refreshTreeView(vm.items);
                    }, 0);
                    vm.refreshTableItems(vm.items);
                }.bind(this)
            });
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                $http:vm.$http,
                author:processModel.author,
                editorPage:"MaterialTypeEditor.html",
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        editModuleModal: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);


            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                $http:vm.$http,
                author:processModel.author,
                editorPage:"MaterialTypeEditor.html",
                preLockURL: vm.preLockURL,
                postHandle: function(oData){
                    this.cache = this.copyModule(oData.content, this.cache);
                    this.loadParentTypeList(this.cache);
                    this.loadRootTypeList(this.cache);
                    // manually set initial value
                    $(vm.eleParentTypeUUIDCache).val(this.cache.parentTypeUUID);
                    $(vm.eleParentTypeUUIDCache).trigger("change");
                    $(this.eleEditMaterialTypeModal).modal('toggle');
                }.bind(this),
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        copyModule: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.parentTypeUUID = origin.parentTypeUUID;
            target.note = origin.note;
            target.parentTypeId = origin.parentTypeId;
            target.parentTypeName = origin.parentTypeName;
            target.rootTypeId = origin.rootTypeId;
            target.rootTypeName = origin.rootTypeName;
            return target;

        },

        uploadExcel: function () {
            // refresh success call back
            var vm = this;
            this.$set(this.configMetaUploadExcel, 'successCallback', this.refreshListView);
            this.$refs.excelUploadModal.popup(vm.configMetaUploadExcel);
        },

        refreshListView: function () {
            window.location.href = "MaterialTypeTree.html";
        },

        saveToModule: function () {
            var vm = this;

            ServiceUtilityHelper.httpRequest({
                url:this.loadModuleListURL,
                method:'post',
                requestData: vm.cache,
                $http:vm.$http,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    $(this.eleEditMaterialTypeModal).modal('hide');
                    // Also update to current items
                    var item = vm._filterItemByUUID(this.cache.uuid);
                    if (!item) {
                        if (!this.cache.uuid) {
                            return;
                        }
                        var newItem = this.copyModule(this.cache);
                        // In case new item added.
                        this.items.push(newItem);
                    } else {
                        this.copyModule(this.cache, item);
                    }
                    this.refreshTreeView(vm.items);
                    $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                }.bind(this)
            });
        },

        newModuleModal: function (baseUUID) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);

            ServiceUtilityHelper.httpRequest({
                url:vm.newModuleServiceURL,
                method:'post',
                requestData: requestData,
                $http:vm.$http,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    this.cache = this.copyModule(oData.content, this.cache);
                    this.loadParentTypeList(this.cache);
                    this.loadRootTypeList(this.cache);
                    // manually set initial value
                    $(vm.eleParentTypeUUIDCache).val(this.cache.parentTypeUUID);
                    $(vm.eleParentTypeUUIDCache).trigger("change");
                    $(this.eleEditMaterialTypeModal).modal('toggle');
                }.bind(this)
            });
        },

        _filterItemByUUID: function (uuid) {
            if (!this.items) {
                return;
            }
            for (var i = 0; i < this.items.length; i++) {
                if (uuid === this.items[i].uuid) {
                    return this.items[i];
                }
            }

        },
        preLock: function () {
        }
    }
});
