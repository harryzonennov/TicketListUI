var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        searchModuleURL: '../individualCustomer/searchModuleService.html'
    },
    methods: {
        searchModule: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.searchModuleURL, requestData).then(function (response) {
                listVar.$set('items', JSON.parse(response.data).content);
            })
        },
        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "IndividualCustomerEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },
        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            weiboID: "",
            id: "",
            faceBookID: "",
            name: "",
            client: "",
            baseCityUUID: "",
            weiXinID: "",
            customerType: "",
            uuid: "",
            qqNumber: ""

        },

        label: {
            weiboID: '',
            id: '',
            address: '',
            name: '',
            client: '',
            mobile: '',
            weiXinID: '',
            email: '',
            note: '',
            qqNumber: '',
            clearSearch:'',
            clearSearchComment:'',
            advancedSearchCondition: ''
        }

    },
    methods:{
        clearSearch: function(){
            clearSearchModel(this.content);
        }
    }
});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: {
            weiboID: '',
            id: '',
            address: '',
            note: '',
            name: '',
            client: '',
            mobile: '',
            weiXinID: '',
            customerType: '',
            email: '',
            qqNumber: '',

            msgSystemFailure: '',
            msgUnknowSystemFailure: '',
            index: '',
            lockFailureMessage: '',
            buttonEdit: '',
            buttonView: '',
            msgSaveOK: '',
            msgSaveOKComment: '',
            commit: '',
            close: ''
        },
        cache: {
            uuid: '',
            parentNodeUUID: '',
            rootNodeUUID: '',
            client: '',
            weiboID: '',
            id: '',
            faceBookID: '',
            note: '',
            name: '',
            baseCityUUID: '',
            weiXinID: '',
            customerType: '',
            qqNumber: ''
        }
        ,
        eleEditIndividualCustomerModal: '#x_eleEditIndividualCustomerModal',
        tableId: '#x_table_individualCustomer',
        datatable: '',
        items: [],
        loadModuleListURL: '../individualCustomer/loadModuleListService.html',
        preLockURL: '../individualCustomer/preLockService.html',
        newModuleServiceURL: '../individualCustomer/newModuleService.html',
        saveModuleURL: '../individualCustomer/saveModuleService.html',
        loadModuleEditURL: '../individualCustomer/loadModuleEditService.html'

    },
    ready: function () {
        var vm = this;
        NavigationPanelIns.initNavigation('logistics', 'IndividualCustomer');
        this.datatable = new ServiceDataTable(this.tableId);
        this.setI18nProperties();
        this.loadModuleList();
    },
    methods: {
        setI18nCommonProperties: function () {
            this.label.msgSystemFailure = $.i18n.prop('msgSystemFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.buttonEdit = $.i18n.prop('edit');
            this.label.buttonView = $.i18n.prop('view');
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.commit = $.i18n.prop('commit');
            this.label.close = $.i18n.prop('close');
            processModel.label.search = $.i18n.prop('search');
            processModel.label.add = $.i18n.prop('add');
            searchModel.label.advancedSearchCondition = $.i18n.prop('advancedSearchCondition');
            searchModel.label.clearSearch = $.i18n.prop('clearSearch');
            searchModel.label.clearSearchComment = $.i18n.prop('clearSearchComment');
            BusyLoader.cleanPageBackground();
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },
        setNodeI18nPropertiesCore: function () {
            this.label.weiboID = $.i18n.prop('weiboID');
            this.label.id = $.i18n.prop('id');
            this.label.faceBookID = $.i18n.prop('faceBookID');
            this.label.note = $.i18n.prop('note');
            this.label.name = $.i18n.prop('name');
            this.label.mobile = $.i18n.prop('mobile');
            this.label.email = $.i18n.prop('email');
            this.label.address = $.i18n.prop('address');
            this.label.customerType = $.i18n.prop('customerType');
            this.label.uuid = $.i18n.prop('uuid');
            this.label.qqNumber = $.i18n.prop('qqNumber');
            searchModel.label.weiboID = $.i18n.prop('weiboID');
            searchModel.label.id = $.i18n.prop('id');
            searchModel.label.address = $.i18n.prop('address');
            searchModel.label.name = $.i18n.prop('name');
            searchModel.label.telephone = $.i18n.prop('telephone');
            searchModel.label.mobile = $.i18n.prop('mobile');
            searchModel.label.weiXinID = $.i18n.prop('weiXinID');
            searchModel.label.customerType = $.i18n.prop('customerType');
            searchModel.label.uuid = $.i18n.prop('uuid');
            searchModel.label.qqNumber = $.i18n.prop('qqNumber');
        },
        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'IndividualCustomer', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
        },
        getI18nPath: function () {
            return 'coreFunction/';
        },
        loadModuleList: function () {
            var vm = this;
            this.$http.get(vm.loadModuleListURL).then(function (response) {
                if (!JSON.parse(response.data).content) {
                    $.Notification.notify('error', 'top center', this.label.msgSystemFailure, this.label.msgUnknowSystemFailure);
                    return;
                }
                vm.$set('items', JSON.parse(response.data).content);
                setTimeout(function () {
                    vm.datatable.build();
                }, 0);
            });
        },
        editModule: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            this.$http.post(vm.preLockURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.RC) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                if (!JSON.parse(response.data).content) {
                    ServiceHttpRequestHelper.handleErrorWithBarWrap({
                        errorMessage:this.label.lockFailureMessage
                    }, {
                        container: $('.main.message-container')
                    });
                    return;
                }
                // if (oData.RC == HttpStatus.SC_OK) {
                //     window.location.href = genCommonEditURL("IndividualCustomerEditor.html", uuid);
                // } else {
                //     swal(this.label.lockFailureMessage, JSON.parse(response.data).MSG);
                // }
            });
        },
        editModuleModal: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            this.$http.post(vm.preLockURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.RC) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                if (oData.RC == HttpStatus.SC_OK) {
                    var url = this.loadModuleEditURL + "?uuid=" + uuid;
                    this.$http.get(url).then(function (response) {
                        if (!JSON.parse(response.data).content) {
                            var _errorMessage = this.label.msgUnknowSystemFailure;
                            if(JSON.parse(response.data).errorMessage){
                                _errorMessage = JSON.parse(response.data).errorMessage;
                            }
                            swal({
                                title: this.label.msgSystemFailure,
                                text: _errorMessage,
                                type: "error",
                                confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                                cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                                confirmButtonText: this.label.confirm
                            });
                            return;
                        }
                        this.cache = this.copyModule(JSON.parse(response.data).content, this.cache);
                        $(this.eleEditIndividualCustomerModal).modal('toggle');
                    });
                } else {
                    $.Notification.notify('error', 'top center', this.label.lockFailureMessage, JSON.parse(response.data).MSG);
                }
            });

        },
        copyModule: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.weiboID = origin.weiboID;

            target.faceBookID = origin.faceBookID;

            target.note = origin.note;

            target.baseCityUUID = origin.baseCityUUID;

            target.weiXinID = origin.weiXinID;

            target.customerType = origin.customerType;

            target.qqNumber = origin.qqNumber;

            return target;

        },
        saveToModule: function () {
            var vm = this;
            this.$http.post(this.saveModuleURL, vm.cache).then(function (response) {
                $(this.eleEditIndividualCustomerModal).modal('hide');// Also update to current items
                var item = vm._filterItemByUUID(this.cache.uuid);
                if (!item) {
                    if (!this.cache.uuid) {
                        return;
                    }
                    var newItem = this.copyModule(this.cache);
// In case new item added.
                    this.items.push(newItem);
                } else {
                    this.copyModule(this.cache, item);
                }
                $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
            });
        },
        newModuleModal: function () {
            var requestData = {};
            this.$http.post(this.newModuleServiceURL, requestData).then(function (response) {
                if (!JSON.parse(response.data).content) {
                    swal({
                        title: this.label.msgSystemFailure,
                        text: this.label.msgUnknowSystemFailure,
                        type: "error",
                        confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                        cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                        confirmButtonText: this.label.confirm
                    });
                    return;
                }
// In case success.
                this.cache = this.copyModule(JSON.parse(response.data).content, this.cache);
                $(this.eleEditIndividualCustomerModal).modal('toggle');
            });
        },
        _filterItemByUUID: function (uuid) {
            if (!this.items) {
                return;
            }
            for (var i = 0; i < this.items.length; i++) {
                if (uuid === this.items[i].uuid) {
                    return this.items[i];
                }
            }

        },
        preLock: function () {
        }
    }
});
