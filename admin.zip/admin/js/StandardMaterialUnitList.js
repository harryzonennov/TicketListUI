var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        processButtonMeta:[],
        author:{
            resourceId:ServiceModuleConstants.StandardMaterialUnit,
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        searchModuleURL: '../standardMaterialUnit/searchModuleService.html'
    },

    created: function(){
        this.initAuthorResourceCheck();
        this.initSubComponents();
    },

    methods: {

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        searchModule: function () {
            listVar.searchModuleList();
        },

        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "StandardMaterialUnitEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        }
    }
});

var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            id: "",
            languageCode: "",
            name: "",
            unitType: '',
            unitCategory: '',
            systemCategory:''
        },

        label: {
            id: '',
            languageCode: '',
            name: '',
            refMaterialUnitId: '',
            refMaterialUnitLanguageCode: '',
            refMaterialUnitName: '',
            unitType: '',
            unitCategory: '',
            clearSearch:'',
            clearSearchComment:'',
            systemCategory:'',
            advancedSearchCondition: ''
        },
        eleUnitCategory: '#x_unitCategory',
        eleSystemCategory: '#x_systemCategory',
        getUnitCategoryMapURL: '../standardMaterialUnit/getUnitCategoryMap.html',
        getSystemCategoryMapURL: '../standardMaterialUnit/getSystemCategoryMap.html'
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            vm.loadUnitCategorySelectList();
            vm.loadSystemCategorySelectList();
        });
    },

    methods: {
        clearSearch: function(){
            clearSearchModel(this.content);
            clearDefSearchSelectElements([this.eleUnitTypeMap, this.eleUnitCategory,
                this.eleSystemCategory]);
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleUnitTypeMap).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'unitType', $(vm.eleUnitTypeMap).val());
            });
            $(vm.eleUnitCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'unitCategory', $(vm.eleUnitCategory).val());
            });
            $(vm.eleSystemCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'systemCategory', $(vm.eleSystemCategory).val());
            });

        },

        loadUnitCategorySelectList: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getUnitCategoryMapURL,
                $http: vm.$http,
                initValue: vm.content.unitCategory,
                element: vm.eleUnitCategory,
                addEmptyFlag: true,
                formatMeta: StandardMaterialUnitManager.formatUnitCategory,
                errorHandle: vm.errorHandle
            });

        },

        loadSystemCategorySelectList: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getSystemCategoryMapURL,
                $http: vm.$http,
                initValue: vm.content.systemCategory,
                element: vm.eleSystemCategory,
                addEmptyFlag: true,
                formatMeta: StandardMaterialUnitManager.formatSystemCategory,
                errorHandle: vm.errorHandle
            });
        }
    }

});


var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: StandardMaterialUnitManager.label.standardMaterialUnit,
        cache: {
            uuid: '',
            parentNodeUUID: '',
            rootNodeUUID: '',
            client: '',
            id: '',
            languageCode: '',
            note: '',
            name: '',
            refMaterialUnitId: '',
            refMaterialUnitLanguageCode: '',
            refMaterialUnitNote: '',
            refMaterialUnitName: ''
        },
        eleEditStandardMaterialUnitModal: '#x_eleEditStandardMaterialUnitModal',

        items: [],
        loadModuleListURL: '../standardMaterialUnit/loadModuleListService.html',
        preLockURL: '../standardMaterialUnit/preLockService.html',
        newModuleServiceURL: '../standardMaterialUnit/newModuleService.html',
        saveModuleURL: '../standardMaterialUnit/saveModuleService.html',
        loadModuleEditURL: '../standardMaterialUnit/loadModuleEditService.html'

    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
        this.setI18nProperties(processModel.initProcessButtonMeta);
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'StandardMaterialUnit');
            this.loadModuleList();
        });
    },

    methods: {
        initSubComponents: function(){
            "use strict";
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: vm.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'StandardMaterialUnit',
                    callback: vm.setNodeI18nPropertiesCore
                }]
            });
        },

        buildSearchData: function (data) {
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../standardMaterialUnit/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'name',
                labelKey: 'name',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.StandardMaterialUnit,
                    uuidFieldName: 'uuid'
                }
            },{
                fieldName: 'id',
                labelKey: 'id',
                minWidth: '180px'
            }, {
                fieldName: 'unitCategoryValue',
                fieldKey: 'unitCategory',
                labelKey: 'unitCategory',
                iconArray: StandardMaterialUnitManager.getUnitCategoryIconArray()
            }, {
                fieldName: 'systemCategoryValue',
                labelKey: 'systemCategory',
                fieldKey: 'systemCategory',
                iconArray: StandardMaterialUnitManager.getSystemCategoryIconArray()
            }, {
                fieldName: 'refMaterialUnitName',
                labelKey: 'refMaterialUnitName',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.StandardMaterialUnit,
                    uuidFieldName: 'referUnitUUID'
                }
            }];
            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        },

        searchModuleList: function () {
            this.$refs.dataTableFrame.searchModuleList();
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },


        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                author:processModel.author,
                $http:vm.$http,
                editorPage:"StandardMaterialUnitEditor.html",
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },


        formatUnitCategory: function(unitCategory){
            return StandardMaterialUnitManager.formatUnitCategoryIconClass(unitCategory);
        },

        formatSystemCategory: function(systemCategory){
            return StandardMaterialUnitManager.formatSystemCategoryIconClass(systemCategory);
        },


        preLock: function () {
        }
    }
});
