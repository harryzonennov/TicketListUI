var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        author:{
            resourceId:'Organization',
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        processButtonMeta:[],
        searchModuleURL: '../organization/searchModuleService.html'
    },

    created: function(){
        this.initAuthorResourceCheck();
        this.initSubComponents();
    },

    methods: {

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        searchModule: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.searchModuleURL, requestData).then(function (response) {
                listVar.refreshTableItems(JSON.parse(response.data).content);
                listVar.refreshTreeView();
            });
        },
        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "OrganizationEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },
        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            organType: "",
            organLevel: "",
            contactTelephone: "",
            contactMobileNumber: "",
            fax: "",
            postcode: "",
            email: "",
            addressInfo: "",
            organizationFunction: "",
            accountantName: "",
            refOrganizationUUID: "",
            id: "",
            name: ""

        },

        label: OrganizationManager.label.organization,
        orgFunctionMapArray: [],
        eleOrganizationFunction: '#x_refOrganizationFunction',
        loadOrganizationSelectListURL: '../organization/loadModuleListService.html',
        getRegularTypeURL: '../organization/getRegularType.html',
        getAccountTypeURL: '../organization/getAccountType.html',
        getOrganizationFunctionMapURL: '../organization/getOrganizationFunctionMap.html',
        loadOrganizationFunctionSelectListURL: '../organizationFunction/loadLeanModuleListService.html',
        loadAccountantSelectListURL: '../employee/loadModuleListService.html',
        loadMainContactSelectListURL: '../employee/loadModuleListService.html',
        loadEmployeeSelectListURL: '../employee/loadModuleListService.html'


    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            vm.loadOrganizationSelectList();
            vm.loadOrganizationFunctionSelectList();
        });
    },

    methods: {
        clearSearch: function () {
            clearSearchModel(this.content);
        },

        initSelectConfigure: function () {
            var vm = this;

            $(vm.eleRefFinOrgUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refFinOrgUUID', $(vm.eleRefFinOrgUUID).val());
            });
            $(vm.eleParentOrganizationUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'parentOrganizationUUID', $(vm.eleParentOrganizationUUID).val());
            });

            $(vm.eleOrganizationFunction).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'organizationFunction', $(vm.eleOrganizationFunction).val());
            });
            $(vm.eleRefAccountantUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refAccountantUUID', $(vm.eleRefAccountantUUID).val());
            });
            $(vm.eleMainContactUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'mainContactUUID', $(vm.eleMainContactUUID).val());
            });
            $(vm.eleRefCashierUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'refCashierUUID', $(vm.eleRefCashierUUID).val());
            });
        },

        loadOrganizationSelectList: function () {
            var vm = this;
            this.$http.get(this.loadOrganizationSelectListURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body), 'uuid', 'id', true);
                setTimeout(function () {
                    $(vm.eleRefFinOrgUUID).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleRefFinOrgUUID).val(vm.content.refFinOrgUUID);
                    $(vm.eleRefFinOrgUUID).trigger("change");
                }, 0);
            });
        },

        loadOrganizationFunctionSelectList: function () {
            var vm = this;
            ServiceUtilityHelper.loadMetaWithCustomReq({
                url: vm.getOrganizationFunctionMapURL,
                $http: vm.$http,
                formatMeta:SystemStandrdMetadataProxy.formatLogicOperator,
                initValue: vm.content.organizationFunction,
                addEmptyFlag: true,
                idField:'id',
                textField:'name',
                element: vm.eleOrganizationFunction,
                errorHandle: vm.errorHandle
            });


        }


    }
});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: OrganizationManager.label.organization,
        tableId: '#x_table_organization',
        datatable: '',
        editorPage: 'OrganizationEditor.html',
        items: [],
        orgFunctionMapArray: [],
        loadModuleListURL: '../organization/loadModuleListService.html',
        preLockURL: '../organization/preLockService.html',
        getOrganizationFunctionMapURL: '../organization/getOrganizationFunctionMap.html'
    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'Organization');
            this.datatable = new ServiceDataTable(this.tableId);
            this.setI18nProperties(processModel.initProcessButtonMeta);
            this.loadModuleList();
        });
    },
    methods: {
        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "/foundation/common/",
                commonCallback: this.setI18nCommonProperties, serviceUIMeta: processModel.serviceUIMeta,
                fnCallback: fnCallback,
                label: [vm.label, processModel.label, searchModel.label], vm: processModel, errorHandle: vm.errorHandle,
                configList: [{
                    name: 'Organization',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },


        loadModuleList: function () {
            var vm = this;
            this.$http.get(vm.loadModuleListURL).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    vm.errorHandle(oData);
                    return;
                }
                vm.$set(vm, 'items', JSON.parse(response.data).content);
                OrganizationManager.loadOrganizationFunctionSelectList({
                    $http: vm.$http,
                    fnCallBack: function (orgFunctionMapArray) {
                        vm.$set(vm, 'orgFunctionMapArray', orgFunctionMapArray);
                        setTimeout(function () {
                            vm.datatable.build();
                            vm.refreshTreeView();
                        }, 0);
                    }.bind(this)
                });
            });
        },

        refreshTableItems: function (items) {
            this.datatable = new ServiceDataTable(this.tableId);
            this.$set(this, 'items', items);
            setTimeout(function () {
                this.datatable.build();
            }, 0);
        },

        formatOrgFunctionClass: function (organizationFunction) {
            var $element = ServiceCollectionsHelper.filterArray(organizationFunction, 'id', this.orgFunctionMapArray);
            if ($element) {
                return $element.iconClass;
            }
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        editModule: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                author:processModel.author,
                $http:vm.$http,
                editorPage:vm.editorPage,
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        newOrganizationModal: function (baseUUID) {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = baseUUID;
            var resultURL = "OrganizationEditor.html" + "?" + urlEncode(paras);
            window.open(resultURL, '_blank');
        },

        editModuleModal: function (uuid) {
            var vm = this;
            return vm.editModule(uuid);
        },

        refreshTreeView: function () {
            var vm = this;
            var ser = new XMLSerializer();
            var treeElement = generateBootstrapTreeContent(vm.generateOrganizationTreeView(vm.items));
            var htmlContent = ser.serializeToString(treeElement);
            $("#x_tree_organization").empty();
            $("#x_tree_organization").prepend(htmlContent);
            $(".iconAddOrganization").on("click", function (e) {
                var baseUUID = $(this).children("input").attr("value");
                vm.newOrganizationModal(baseUUID);
            });
            $(".iconEditOrganization").on("click", function (e) {
                var uuid = $(this).children("input").attr("value");
                vm.editModuleModal(uuid);
            });
            vm.initTreeAction();

        },

        initTreeAction: function () {
            $('.tree li.parent_li > span').off('click');
            $('.tree li.parent_li > span').on('click', function (e) {
                var children = $(this).parent('li.parent_li').find(' > ul > li');
                if (children.is(":visible")) {
                    children.hide('fast');
                } else {
                    children.show('fast');
                }
                e.stopPropagation();
            });
        },

        _filterTopOrganization: function (organizationList) {
            "use strict";
            if (ServiceCollectionsHelper.checkNullList(organizationList)) {
                return;
            }
            var result = [];
            for (var i = 0, len = organizationList.length; i < len; i++) {
                var organization = organizationList[i];
                if (!organization.parentOrganizationUUID || organization.parentOrganizationUUID == '') {
                    result.push(organization);
                    continue;
                }
                if (organization.parentOrganizationUUID == organization.uuid) {
                    result.push(organization);
                    continue;
                }
                var parentOrg = ServiceCollectionsHelper.filterArray(organization.parentOrganizationUUID, 'uuid', organizationList);
                if (!parentOrg) {
                    result.push(organization);
                    continue;
                }
            }
            return result;
        },

        _filterSubOrganization: function (parentOrganization, organizationList) {
            "use strict";
            if (ServiceCollectionsHelper.checkNullList(organizationList)) {
                return;
            }
            var result = [];
            for (var i = 0, len = organizationList.length; i < len; i++) {
                var organization = organizationList[i];
                if (parentOrganization.uuid === organization.parentOrganizationUUID && parentOrganization.uuid !== organization.uuid) {
                    result.push(organization);
                }
            }
            return result;
        },


        generateOrganizationTreeView: function (organizationList) {
            var vm = this;
            var topTreeModel = {};
            topTreeModel.layer = 1;
            topTreeModel.iconClass = 'icon-th-list';
            topTreeModel.spanClass = 'badge-lightBlue';
            topTreeModel.spanContent = '组织架构';
            topTreeModel.subModelList = [];
            var topOrganizationList = this._filterTopOrganization(organizationList);
            if (topOrganizationList && topOrganizationList.length > 0) {
                for (var i = 0, len = topOrganizationList.length; i < len; i++) {
                    var organization = topOrganizationList[i];
                    var organizationTreeModel = this.generateOrganizationTreeViewCore(organization, organizationList, 2);
                    if (organizationTreeModel) {
                        topTreeModel.subModelList.push(organizationTreeModel);
                    }
                }
            }
            return topTreeModel;
        },

        generateOrganizationTreeViewCore: function (organization, organizationList, layer) {
            var vm = this, preOrgTreeModel = {}, organizationTreeModel = {};
            var iconClass = vm.formatOrgFunctionClass(organization.organizationFunction);
            iconClass = iconClass ? iconClass : 'md md-account-balance content-orange';
            preOrgTreeModel.layer = layer;
            preOrgTreeModel.iconClass = iconClass;
            preOrgTreeModel.postModelList = [];
            preOrgTreeModel.subModelList = [];
            preOrgTreeModel.spanContent = organization.organizationFunctionValue;

            organizationTreeModel.layer = layer;
            organizationTreeModel.uuid = organization.uuid;
            organizationTreeModel.rootNodeUUID = organization.rootNodeUUID;
            organizationTreeModel.parentNodeUUID = organization.parentNodeUUID;
            organizationTreeModel.iconArray = [];
            var spanContent = organization.id + ' - ' + organization.name;
            organizationTreeModel.spanContent = spanContent;


            var addIcon = {};
            addIcon.innerUUID = organization.uuid;
            addIcon.class = 'fa fa-plus iconAddOrganization';
            organizationTreeModel.iconArray.push(addIcon);
            var editIcon = {};
            editIcon.innerUUID = organization.uuid;
            editIcon.class = 'glyphicon glyphicon-pencil content-green iconEditOrganization';
            organizationTreeModel.iconArray.push(editIcon);
            preOrgTreeModel.postModelList.push(organizationTreeModel);

            var subOrganizationList = this._filterSubOrganization(organization, organizationList);
            if (!ServiceCollectionsHelper.checkNullList(subOrganizationList)) {
                for (var i = 0, len = subOrganizationList.length; i < len; i++) {
                    var subOrganizationTreeModel = this.generateOrganizationTreeViewCore(subOrganizationList[i], organizationList, layer + 1);
                    if (subOrganizationTreeModel) {
                        preOrgTreeModel.subModelList.push(subOrganizationTreeModel);
                    }
                }
            }
            return preOrgTreeModel;
        },

        preLock: function () {
        }
    }
});
