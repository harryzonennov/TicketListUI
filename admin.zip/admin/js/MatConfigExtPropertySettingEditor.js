var dataVar = new Vue({
    el: "#x_data",
    mixins: [ServiceRightBarPanelHelper.defTimelineMinxin, ServiceItemEditorHelper.defControlMinxin],
    data: {
        label: MaterialConfigureTemplateManager.label.matConfigExtPropertySetting,
        content: {
            matConfigExtPropertySettingUIModel:MaterialConfigureTemplateManager.content.matConfigExtPropertySettingUIModel
        },
        getPageHeaderModelListURL: '../matConfigExtPropertySetting/getPageHeaderModelList.html',
        searchStandardUnitURL:'../standardMaterialUnit/searchModuleService.html',
        getQualityInspectFlagURL: '../matConfigExtPropertySetting/getQualityInspectFlag.html',
        getMeasureFlagMapURL: '../matConfigExtPropertySetting/getMeasureFlagMap.html',
        getFieldTypeURL: '../matConfigExtPropertySetting/getFieldType.html',
        exitModuleURL: '../matConfigExtPropertySetting/exitEditor.html'
    },

    mounted: function () {
        NavigationPanelIns.initNavigation('systemAdmin', 'MaterialConfigureTemplate');
    },

    methods: {

        getServiceManager: function () {
            return MaterialConfigureTemplateManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "MatConfigExtPropertySettingEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.matConfigExtPropertySettingUIModel.uuid;
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getParentUUID: function () {
            return this.content.matConfigExtPropertySettingUIModel.parentNodeUUID;
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'matConfigExtPropertySettingUIModel', content.matConfigExtPropertySettingUIModel);
            vm.postUpdateUIModel();
        },

        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'MatConfigExtPropertySettingEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: MaterialConfigureTemplateManager,
                coreModelId: 'MatConfigExtPropertySetting',
                i18nPath: 'coreFunction/',
                helpDocumentName: ['MatConfigExtPropertySettingHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: vm.displayForEdit,
                        callback: vm.saveModule
                    },
                    exit: {
                        callback: vm.exitModule
                    }
                },
                pageHeaderConfig: [{
                    nodeInstId: 'materialConfigureTemplate',
                    baseEditUrl:"MaterialConfigureTemplateEditor.html",
                    targetTab: MaterialConfigureTemplateManager.documentTab.matConfigExtPropertySettingSection,
                    pageTitlePath: 'parentPageTitle' ,
                    pageTitleVarPath: 'templateId'
                },{
                    active: true,
                    nodeInstId: 'matConfigExtPropertySetting',
                    baseEditUrl:"MatConfigExtPropertySettingEditor.html",
                    pageTitlePath: 'pageHeaderTitle' ,
                    pageTitleVarPath: 'name'
                }],
                tabMetaList: [{
                    tabId: 'matConfigExtPropertySettingSection',
                    tabTitleKey: 'matConfigExtPropertySettingSection',
                    titleLabelKey: 'matConfigExtPropertySettingSection',
                    titleHelpKey: 'materialStockKeepUnit.matConfigExtPropertySettingSection',
                    titleIcon: 'md md-straighten content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'materialUnitSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'matConfigExtPropertySettingUIModel',
                        tabTitleKey: 'materialUnitSection',
                        titleLabelKey: 'materialUnitSection',
                        titleHelpKey: 'material.materialUnitSection',
                        titleIcon: 'md md-texture content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'id',
                            newRow: true
                        }, {
                            fieldName: 'name',
                        }, {
                            fieldName: 'fieldType',
                            newRow: true,
                            helpKey: 'matConfigExtPropertySetting.fieldType',
                            settings: {
                                getMetaDataUrl: vm.getFieldTypeURL
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'measureFlag',
                            newRow: true,
                            helpKey: 'matConfigExtPropertySetting.measureFlag',
                            settings: {
                                getMetaDataUrl: vm.getFieldTypeURL
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'qualityInspectFlag',
                            newRow: true,
                            helpKey: 'matConfigExtPropertySetting.qualityInspectFlag',
                            settings: {
                                getMetaDataUrl: vm.getFieldTypeURL
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'refUnitUUID',
                            newRow: true,
                            helpKey: 'matConfigExtPropertySetting.refUnitUUID',
                            settings: {
                                getMetaDataUrl: vm.searchStandardUnitURL,
                                method: 'post',
                                textField: 'name',
                                uuidField: 'uuid',
                                requestData: {}
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        },{
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        } ]
                    }]
                }]
            };
        }

    }
});
