var dataVar = new Vue({
    el: "#x_data",
    data: {
        dayItemTableId: '#x_table_workCalendarDayItem',
        dayItemTable: {},
        label: {
            id: '',
            defaultFlag: '',
            refTemplateUUID: '',
            name: '',
            year: '',
            note: '',
            calendarTemplateId: '',
            calendarTemplateName: '',
            calendarTemplateYear: '',
            calendarTemplateNote: '',

            workCalendarSection: '',
            calendarTemplateSection: '',
            workCalendarDayItemSection: '',

            msgSaveOK: '',
            msgSaveOKComment: '',
            msgConnectFailure: '',
            msgUnknowSystemFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            save: '',
            quickEdit: '',
            buttonDelete: '',
            exit: '',
            close: '',
            deleteWarnTitle: '',
            deleteWarnText: '',
            cancel: '',
            commit: '',
            confirm: '',
            addWorkCalendar: '',
            addCalendarTemplate: '',
            addWorkCalendarDayItem: '',
            workCalendarDayItem: {
                vocationType: '',
                dayStatus: '',
                id: '',
                name: '',
                refDate: '',
                note: ''
            }
        },
        content: {
            workCalendarUIModel: {
                uuid: '',
                client: '',
                id: '',
                defaultFlag: '',
                refTemplateUUID: '',
                name: '',
                year: '',
                note: '',
                calendarTemplateId: '',
                calendarTemplateName: '',
                calendarTemplateYear: '',
                calendarTemplateNote: ''
            },
            workCalendarDayItemUIModelList: []
        },
        cache: {
            workCalendarDayItem: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                vocationType: '',
                dayStatus: '',
                id: '',
                name: '',
                refDate: '',
                note: ''
            }

        },
        eleDefaultFlag: '#x_defaultFlag',
        eleRefTemplateUUID: '#x_refTemplateUUID',
        eleVocationType: '#x_vocationType',
        eleDayStatus: '#x_dayStatus',
        loadModuleEditURL: '../workCalendar/loadModuleEditService.html',
        saveModuleURL: '../workCalendar/saveModuleService.html',
        exitModuleURL: '../workCalendar/exitEditor.html',
        newModuleServiceURL: '../workCalendar/newModuleService.html',
        newWorkCalendarDayItemServiceURL: '../workCalendarDayItem/newModuleService.html',
        eleEditWorkCalendarDayItemModal: '#x_eleEditWorkCalendarDayItemModal',
        getDefaultFlagURL: '../workCalendar/getDefaultFlag.html',
        loadCalendarTemplateSelectListURL: '../calendarTemplate/loadLeanListModuleService.html',
        getVocationTypeURL: '../workCalendarDayItem/getVocationType.html',
        getDayStatusURL: '../workCalendarDayItem/getDayStatus.html',
        loadCalendarTemplateURL: '../CalendarTemplate/loadModule.html',
        exitURL: 'WorkCalendarList.html'

    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'WorkCalendar');
            this.setI18nProperties();
            this.loadModuleEdit();
            this.dayItemTable = new ServiceDataTable(this.dayItemTableId);
            this.initSelectConfigure();
        });
    },

    methods: {
        editWorkCalendarDayItemModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.workCalendarDayItemUIModelList);
            if (!item) {
                return;
            }
            this.cache.workCalendarDayItem = this.copyWorkCalendarDayItem(item);
            $(this.eleEditWorkCalendarDayItemModal).modal('toggle');

        },

        setToWorkCalendarDayItem: function () {
            var item = this._filterItemByUUID(this.cache.workCalendarDayItem.uuid, this.content.workCalendarDayItemUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copyWorkCalendarDayItem(this.cache.workCalendarDayItem);
                this.content.workCalendarDayItemUIModelList.push(newItem);
            } else {
                this.copyWorkCalendarDayItem(this.cache.workCalendarDayItem, item);
            }
            $(this.eleEditWorkCalendarDayItemModal).modal('hide');
        },

        newWorkCalendarDayItemModal: function () {
            var baseUUID = this.content.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            this.$http.post(this.newWorkCalendarDayItemServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
// In case success.
                this.cache.workCalendarDayItem = this.copyWorkCalendarDayItem(JSON.parse(response.data).content, this.cache.workCalendarDayItem);
                $(this.eleEditWorkCalendarDayItemModal).modal('toggle');
            });

        },

        deleteWorkCalendarDayItem: function () {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.workCalendarDayItemUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, content.workCalendarDayItemUIModelList);
                    } else {
// do nothing, just return
                    }
                });
        },

        addWorkCalendarDayItem: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.workCalendarUIModel.uuid;
            var resultURL = "WorkCalendarDayItemEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },

        editWorkCalendarDayItem: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            window.location.href = genCommonEditURL("WorkCalendarDayItemEditor.html", uuid);

        },

        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.quickEdit = $.i18n.prop('quickEdit');
            this.label.delete = $.i18n.prop('delete');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.deleteWarnTitle = $.i18n.prop('deleteWarnTitle');
            this.label.deleteWarnText = $.i18n.prop('deleteWarnText');
            this.label.cancel = $.i18n.prop('cancel');
            this.label.commit = $.i18n.prop('commit');
            this.label.confirm = $.i18n.prop('confirm');
            this.label.addWorkCalendar = $.i18n.prop('addWorkCalendar');
            this.label.addCalendarTemplate = $.i18n.prop('addCalendarTemplate');
            this.label.addWorkCalendarDayItem = $.i18n.prop('addWorkCalendarDayItem');
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            this.label.id = $.i18n.prop('id');
            this.label.defaultFlag = $.i18n.prop('defaultFlag');
            this.label.refTemplateUUID = $.i18n.prop('refTemplateUUID');
            this.label.name = $.i18n.prop('name');
            this.label.year = $.i18n.prop('year');
            this.label.note = $.i18n.prop('note');
            this.label.calendarTemplateId = $.i18n.prop('calendarTemplateId');
            this.label.calendarTemplateName = $.i18n.prop('calendarTemplateName');
            this.label.workCalendarSection = $.i18n.prop('workCalendarSection');
            this.label.calendarTemplateSection = $.i18n.prop('calendarTemplateSection');
            this.label.workCalendarDayItemSection = $.i18n.prop('workCalendarDayItemSection');

        },

        setI18nDayItemProperties: function () {
            this.label.workCalendarDayItem.vocationType = $.i18n.prop('vocationType');
            this.label.workCalendarDayItem.dayStatus = $.i18n.prop('dayStatus');
            this.label.workCalendarDayItem.id = $.i18n.prop('id');
            this.label.workCalendarDayItem.name = $.i18n.prop('name');
            this.label.workCalendarDayItem.refDate = $.i18n.prop('refDate');
            this.label.workCalendarDayItem.note = $.i18n.prop('note');

        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'WorkCalendar', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
            jQuery.i18n.properties({
                name: 'WorkCalendarDayItem', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setI18nDayItemProperties
            });

        },

        getI18nPath: function () {
            return 'foundation/common/';
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleRefTemplateUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.workCalendarUIModel, 'refTemplateUUID', $(vm.eleRefTemplateUUID).val());
                var url = vm.loadCalendarTemplateURL + "?uuid=" + $(vm.eleRefTemplateUUID).val();
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.content, 'calendarTemplateId', content.id);
                    vm.$set(vm.content, 'calendarTemplateName', content.name);
                }.bind(this));
            });

        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if (processMode == PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                var url = this.newModuleServiceURL;
                baseUUID = getUrlVar("baseUUID");
                var content = getUrlVar("content");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID, "content", content);
                this.$http.post(url, requestData).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }
            if (processMode == PROCESSMODE_EDIT) {
// In case [Edit mode]
                var url = this.loadModuleEditURL + "?uuid=" + baseUUID;
                this.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }


        },

        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }

        },

        copyWorkCalendarDayItem: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.vocationType = origin.vocationType;
            target.dayStatus = origin.dayStatus;
            target.refDate = origin.refDate;
            target.note = origin.note;
            return target;

        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            this.$http.post(vm.saveModuleURL, vm.content).then(function (response) {
                $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                this.setModuleToUI(JSON.parse(response.data).content);
                var processMode = getUrlVar(LABEL_PROCESSMODE);
                if (processMode && processMode == PROCESSMODE_NEW) {
                    var baseUUID = vm.content.workCalendarUIModel.uuid;
                    if (baseUUID) {
                        window.location.href = genCommonEditURL("WorkCalendarEditor.html", baseUUID);
                    }
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.workCalendarUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);

        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.workCalendarUIModel.uuid;
            window.location.href = genCommonEditURL("WorkCalendarEditor.html", baseUUID, tabKey);

        },

        getDefaultFlag: function (content) {
            var vm = this;
            this.$http.get(this.getDefaultFlagURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleDefaultFlag).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleDefaultFlag).val(content.workCalendarUIModel.defaultFlag);
                    $(vm.eleDefaultFlag).trigger("change");
                }, 0);
            });

        },

        loadCalendarTemplateSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadCalendarTemplateSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleRefTemplateUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefTemplateUUID).val(content.workCalendarUIModel.refTemplateUUID);
                    $(vm.eleRefTemplateUUID).trigger("change");
                }, 0);
            });

        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'workCalendarUIModel', content.workCalendarUIModel);
            vm.$set(vm.content, 'workCalendarDayItemUIModelList', content.workCalendarDayItemUIModelList);
            vm.getDefaultFlag(content);
            vm.loadCalendarTemplateSelectList(content);
            setTimeout(function () {
                vm.dayItemTable.build();
            }, 0);
        }

    }
});
