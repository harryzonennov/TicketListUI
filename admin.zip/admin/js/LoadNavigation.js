/**
 * Created by Zhang,hang on 4/24/2017.
 */

var RightSideMenuCls = Vue.extend({
    name:'rightside-systemmenu',
    props:{
        /* using enable-right-bar in DOM */
        enableRightBar:[String, Boolean]
    },
    data: function () {
        "use strict";
        return {
            label: {
                common: {
                    settingTitle: "",
                    logoutWarnTitle: "",
                    closeRightBarTitle:"",
                    openRightBarTitle:"",
                    logoutWarnComment: "",
                    toggleNavBar: "",
                    confirm: "",
                    cancel: "",
                    logoutTitle: "",
                    unlock: "",
                    unlockTitle: "",
                    unlockAll: "",
                    unlockAllTitle: "",
                    unlockSuccessTitle: "",
                    unlockUserSuccessComment: "",
                    unlockSystemSuccessComment: ""
                }
            },
            meta:{
                sideBarOpen:false
            },
            $body: '',
            $openLeftBtn: '',
            $menuItem: ''
        };
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            getCommonI18n(jQuery.i18n, vm.setI18nCommonProperties);
            this.initSideMenu();
            this.meta.sideBarOpen = $('#wrapper').hasClass('right-bar-enabled');
        }.bind(this));
    },

    ready: function () {
        var vm = this;
        getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
        this.initSideMenu();
    },

    computed: {
        rightBar:function(){
            "use strict";
            return this.enableRightBar;
        }

    },

    methods: {

        initSideMenu: function () {
            this.$body = $("body");
            this.$openLeftBtn = $(".open-left");
            this.$menuItem = $("#sidebar-menu a");
        },

        setI18nCommonProperties: function () {
            "use strict";
            this.label.common.settingTitle = $.i18n.prop('settingTitle');
            this.label.common.logoutTitle = $.i18n.prop('logoutTitle');
            this.label.common.openRightBarTitle = $.i18n.prop('openRightBarTitle');
            this.label.common.closeRightBarTitle = $.i18n.prop('closeRightBarTitle');
            this.label.common.unlock = $.i18n.prop('unlock');
            this.label.common.cancel = $.i18n.prop('cancel');
            this.label.common.confirm = $.i18n.prop('confirm');
            this.label.common.unlockTitle = $.i18n.prop('unlockTitle');
            this.label.common.unlockAll = $.i18n.prop('unlockAll');
            this.label.common.unlockAllTitle = $.i18n.prop('unlockAllTitle');
            this.label.common.logoutWarnTitle = $.i18n.prop('logoutWarnTitle');
            this.label.common.logoutWarnComment = $.i18n.prop('logoutWarnComment');
            this.label.common.unlockSuccessTitle = $.i18n.prop('unlockSuccessTitle');
            this.label.common.unlockUserSuccessComment = $.i18n.prop('unlockUserSuccessComment');
            this.label.common.unlockSystemSuccessComment = $.i18n.prop('unlockSystemSuccessComment');

            this.label.common.enterSysConfigure = $.i18n.prop('enterSysConfigure');
            this.label.common.enterSysConfigureTitle = $.i18n.prop('enterSysConfigureTitle');
            this.label.common.enterSysApplication = $.i18n.prop('enterSysApplication');
            this.label.common.enterSysApplicationTitle = $.i18n.prop('enterSysApplicationTitle');


            $(".cs-open-right-bar").tooltip({title: this.label.common.openRightBarTitle, placement:'bottom'});
            $(".cs-close-right-bar").tooltip({title: this.label.common.closeRightBarTitle, placement:'bottom'});
            $(".cs-system-setting").tooltip({title: this.label.common.settingTitle, placement:'bottom'});
            $(".cs-logout").tooltip({title: this.label.common.logoutTitle, placement:'bottom'});
        },

        showRightBar:function(){
            "use strict";
            return this.enableRightBar;
        },

        logoutService: function () {
            var vm = this;
            swal({
                    title: vm.label.common.logoutWarnTitle,
                    text: vm.label.common.logoutWarnComment,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.common.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.common.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var requestData = {};
                        var url = '../common/logoutService.html';
                        vm.$http.post(url, requestData).then(function (response) {
                            window.location.href = "index.html";
                        });
                    } else {
                        // do nothing, just return
                    }
                });
        },

        openRightSideBar: function(tab, key, event, argus){
            if(event && event.stopPropagation){
                event.stopPropagation();
            }
            this.meta.sideBarOpen = true;
            var openTab = tab;
            // 'rightBar' is hard-code top level right bar vue component instance name
            if(!openTab && rightBar && rightBar.getDefaultTab){
                openTab = rightBar.getDefaultTab();
            }
            if(key && rightBar && rightBar.setActiveKey){
                rightBar.setActiveKey(key);
            }
            if(rightBar && rightBar.initTasks){
                // manually trigger some init tasks before open
                rightBar.initTasks();
            }
            if(RightBarTemplate){
                RightBarTemplate.openSideBar(openTab, key);
            }else{
                $('#wrapper').toggleClass('right-bar-enabled', true);
            }

        },


        closeRightSideBar: function(event){
            if(event && event.stopPropagation){
                event.stopPropagation();
            }
            this.meta.sideBarOpen = false;
            $('#wrapper').toggleClass('right-bar-enabled', false);
        },

        rightBarEnabled: function(){
            return this.meta.sideBarOpen;
        },

        enterSysConfigure: function () {
            window.location.href = "ServiceDocConfigureList.html";
        },

        enterSysApplication: function () {
            window.location.href = "LogonUserList.html";
        },

        unlock: function () {
            var unlockURL = '../common/unLock.html';
            this.$http.post(unlockURL, {}).then(function (response) {
                $.Notification.notify('success', 'top center', this.label.common.unlockSuccessTitle, this.label.common.unlockUserSuccessComment);
            });
        },

        unlockAll: function () {
            var unLockAllURL = '../common/unLockAll.html';
            this.$http.post(unLockAllURL, {}).then(function (response) {
                $.Notification.notify('success', 'top center', this.label.common.unlockSuccessTitle, this.label.common.unlockSystemSuccessComment);
            });
        }
    },


    template: '<ul class="nav navbar-nav navbar-right pull-right">\n' +
    '    <li class="hidden-xs" v-show="showRightBar()">\n' +
    '        <a id="cs-open-right-bar" class="right-bar-toggle cs-open-right-bar" v-show="rightBarEnabled() === false" :title="label.common.openRightBarTitle"><i\n' +
    '                class="ion-arrow-left-a content-darkblue1"  v-on:click="openRightSideBar(undefined, undefined, $event)"></i></a>\n' +
    '        <a class="right-bar-toggle waves-effect  cs-close-right-bar" v-show="rightBarEnabled() === true" :title="label.common.closeRightBarTitle"><i\n' +
    '                class="ion-arrow-right-a content-darkblue1"  v-on:click="closeRightSideBar($event)"></i></a>\n' +
    '    </li>\n' +
    '\n' +
    '    <li class="dropdown hidden-xs">\n' +

    '        <a :title="label.common.settingTitle" class="dropdown-toggle waves-effect waves-light cs-system-setting" data-toggle="dropdown" aria-expanded="true">\n' +
    '            <i class="ion-settings content-darkblue1"></i>\n' +
    '        </a>\n' +
    '        <ul class="dropdown-menu dropdown-menu-lg">\n' +
    '            <li class="list-group nicescroll notifi-title">' +
    '                    <div class="media"  >\n' +
    '                        <div class="pull-left p-r-10">\n' +
    '                             <em class="fa fa-cogs noti-action content-darkblue1"></em>\n' +
    '                        </div>\n' +
    '                        <div class="media-body">\n' +
    '                            <h5 class="media-heading">{{label.common.settingTitle}}</h5>\n' +
    '                        </div>\n' +
    '                    </div>\n' +
    '            </li>\n' +
    '            <li class="list-group nicescroll notification-list">\n' +
    '                <a class="list-group-item">\n' +
    '                    <div class="media" v-on:click="unlock()" >\n' +
    '                        <div class="pull-left p-r-10">\n' +
    '                            <em class="fa fa-unlock-alt noti-action content-pink"></em>\n' +
    '                        </div>\n' +
    '                        <div class="media-body">\n' +
    '                            <h5 class="media-heading">{{label.common.unlock}}</h5>\n' +
    '                            <p class="m-0">\n' +
    '                                <small>{{label.common.unlockTitle}}</small>\n' +
    '                            </p>\n' +
    '                        </div>\n' +
    '                    </div>\n' +
    '                </a>\n' +
    '\n' +
    '\n' +
    '                <a  class="list-group-item">\n' +
    '                    <div class="media" v-on:click="unlockAll()">\n' +
    '                        <div class="pull-left p-r-10">\n' +
    '                            <em class="fa fa-unlock noti-action content-red"></em>\n' +
    '                        </div>\n' +
    '                        <div class="media-body">\n' +
    '                            <h5 class="media-heading">{{label.common.unlockAll}}</h5>\n' +
    '                            <p class="m-0">\n' +
    '                                <small>{{label.common.unlockAllTitle}}</small>\n' +
    '                            </p>\n' +
    '                        </div>\n' +
    '                    </div>\n' +
    '                </a>\n' +
    '\n' +
    '\n' +
    '                <a  class="list-group-item">\n' +
    '                    <div class="media" v-on:click="enterSysConfigure()">\n' +
    '                        <div class="pull-left p-r-10">\n' +
    '                            <em class="ion-wrench noti-action"></em>\n' +
    '                        </div>\n' +
    '                        <div class="media-body">\n' +
    '                            <h5 class="media-heading">{{label.common.enterSysConfigure}}</h5>\n' +
    '                            <p class="m-0">\n' +
    '                                <small>{{label.common.enterSysConfigureTitle}}</small>\n' +
    '                            </p>\n' +
    '                        </div>\n' +
    '                    </div>\n' +
    '                </a>\n' +
    '\n' +
    '\n' +
    '                <a  class="list-group-item">\n' +
    '                    <div class="media" v-on:click="enterSysApplication()">\n' +
    '                        <div class="pull-left p-r-10">\n' +
    '                            <em class="md md-apps noti-action content-lightblue"></em>\n' +
    '                        </div>\n' +
    '                        <div class="media-body">\n' +
    '                            <h5 class="media-heading">{{label.common.enterSysApplication}}</h5>\n' +
    '                            <p class="m-0">\n' +
    '                                <small>{{label.common.enterSysApplicationTitle}}</small>\n' +
    '                            </p>\n' +
    '                        </div>\n' +
    '                    </div>\n' +
    '                </a>\n' +
    '            </li>\n' +
    '\n' +
    '        </ul>\n' +
    '    </li>\n' +
    '    <li class="hidden-xs">\n' +
    '        <a class="right-bar-toggle waves-effect cs-logout" :title="label.common.logoutTitle"><i\n' +
    '                class="fa fa-sign-out content-peach-red" v-on:click="logoutService()"></i></a>\n' +
    '    </li>\n' +
    '\n' +
    '</ul>'
});

Vue.component('rightside-systemmenu', RightSideMenuCls);

var MessageConstant = function(){

};

MessageConstant.getMessageLevelCodeIconArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.StandardPropety.MessageLevelCode.INFO, iconClass: 'nmd nmd-alarm content-lightblue'},
        {id: DocumentConstants.StandardPropety.MessageLevelCode.WARN, iconClass: 'nmd nmd-remove-circle content-orange'},
        {id: DocumentConstants.StandardPropety.MessageLevelCode.ERROR, iconClass: 'nmd nmd-cancel content-peach-red'}
    ];
};

MessageConstant.getTreeNodeSpanClassArray = function () {
    "use strict";
    return [
        {id: DocumentConstants.StandardPropety.MessageLevelCode.INFO, iconClass: 'focus-info'},
        {id: DocumentConstants.StandardPropety.MessageLevelCode.WARN, iconClass: 'focus-warning'},
        {id: DocumentConstants.StandardPropety.MessageLevelCode.ERROR, iconClass: 'focus-error'}
    ];
};


MessageConstant.filterArray = function(key, keyName, rawList){
    if(!rawList || rawList.length === 0){
        return;
    }
    if(!key){
        return null;
    }
    if(!keyName){
        return null;
    }
    var i, tempModel, _len = rawList.length;
    for( i = 0; i < _len; i++){
        tempModel = rawList[i];
        if(typeof key === 'number'){
            if(key === tempModel[keyName]){
                return rawList[i];
            }
        }else{
            if(key == tempModel[keyName]){
                return rawList[i];
            }
        }

    }
};


MessageConstant.formatMessageLevelCodeIconClass = function (messageLevelCode) {
    "use strict";
    var messageLevelIconArray = MessageConstant.getMessageLevelCodeIconArray();
    var $element = MessageConstant.filterArray(messageLevelCode, 'id', messageLevelIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

MessageConstant.formatMessageLevelTreeeNodeSpanClass = function (messageLevelCode) {
    "use strict";
    var messageLevelIconArray = MessageConstant.getTreeNodeSpanClassArray();
    var $element = MessageConstant.filterArray(messageLevelCode, 'id', messageLevelIconArray);
    if ($element) {
        return $element.iconClass;
    }
};

var MessageMenu = Vue.extend({
    name:'message-menu',

    data: function () {
        "use strict";
        return {
            label: {
                searchPlaceHolder: '',
                errorMessageTitle: '',
                warnMessageTitle: '',
                notifyMessageTitle: ''
            },
            navigationItemList:[],
            messageList:
                [{
                    messageLevelCode:DocumentConstants.StandardPropety.MessageLevelCode.INFO,
                    iconHeader:'',
                    num:0,
                    displayflag: undefined,
                    messageResponseList:[]
                },{
                    messageLevelCode:DocumentConstants.StandardPropety.MessageLevelCode.WARN,
                    iconHeader:'',
                    num:0,
                    displayflag: undefined,
                    messageResponseList:[]
                },{
                    messageLevelCode:DocumentConstants.StandardPropety.MessageLevelCode.ERROR,
                    iconHeader:'',
                    num:0,
                    displayflag: undefined,
                    messageResponseList:[]
                }],
            loadUserMessageURL:'../logonUser/loadUserMessageService.html'

        };
    },

    created: function(){
        this.initMeta();
        this.getCommonI18n();
        this.initLoadMessage();
    },

    mounted: function () {
        this.$nextTick(function () {

        }.bind(this));
    },
    methods:{

        initLoadMessage: function(){
            "use strict";
            var vm = this;
            var messageListPromise = vm.getMessageListPromise(vm.$http);
            var navigationItemListPromise = vm.getNavigationListPromise();
            Promise.all([messageListPromise, navigationItemListPromise]).then(function(values){
                var messageList = values[0];
                var navigationItemList = values[1];
                vm.fillMessageResponse(messageList, navigationItemList);
            });
        },

        getNavigationListPromise: function () {
            var vm = this;
            return new Promise(function (resolve, reject) {
                if(vm.navigationItemList && vm.navigationItemList.length > 0){
                    resolve(vm.navigationItemList);
                }else{
                    var navigationItemListPromise = ServiceApplicationFactory.getNavigationListPromise(vm.$http);
                    navigationItemListPromise.then(function (values) {
                        vm.$set(vm, 'navigationItemList', values);
                        resolve(values);
                    });
                }
            }.bind(this));
        },

        getMessageListPromise: function () {
            "use strict";
            var vm = this;
            return new Promise(function (resolve, reject) {
                vm.$http.get(vm.loadUserMessageURL).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        reject(oData);
                    }
                    resolve(oData.content);
                }).catch(function(){
                    resolve();
                });
            }.bind(this));
        },

        initMeta: function(){
            "use strict";
            var vm = this;
            vm.getNavigationListPromise();
            if( !vm.messageList || vm.messageList.length === 0){
                return;
            }
            for(var i = 0; i < vm.messageList.length; i++){
                var iconHeader = MessageConstant.formatMessageLevelCodeIconClass(vm.messageList[i].messageLevelCode);
                if(iconHeader){
                    vm.messageList[i].iconHeader = iconHeader;
                    vm.$set(vm.messageList, i, vm.messageList[i]);
                }
            }
        },

        setI18nCommonProperties: function(){
            "use strict";
            this.label.errorMessageTitle = $.i18n.prop('errorMessageTitle');
            this.label.warnMessageTitle = $.i18n.prop('warnMessageTitle');
            this.label.notifyMessageTitle = $.i18n.prop('notifyMessageTitle');
        },

        getCommonI18n: function(){
            var promise1 = jQuery.i18n.properties({
                name: 'ComElements', //properties file name
                path: getI18nRootPath() + getCommonI18nPath(),
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache: true,
                callback: this.setI18nCommonProperties
            });
            return promise1;
        },

        fillMessageResponse: function( messageResponseList, navigationItemList){
            "use strict";
            var vm = this;
            if( !messageResponseList || messageResponseList.length === 0){
                return;
            }
            for(var i = 0; i < messageResponseList.length; i++){
                vm.insertIntoMessageList(messageResponseList[i], navigationItemList);
            }
            vm.fillTooltip();
        },

        fillTooltip: function(){
            var vm = this;
            var _infoClass = vm.formatMessageLevelClass(DocumentConstants.StandardPropety.MessageLevelCode.INFO);
            $('.' + _infoClass).tooltip({title: this.label.notifyMessageTitle, placement:'bottom'});
            var _warnClass = vm.formatMessageLevelClass(DocumentConstants.StandardPropety.MessageLevelCode.WARN);
            $('.' + _warnClass).tooltip({title: this.label.warnMessageTitle, placement:'bottom'});
            var _errorClass = vm.formatMessageLevelClass(DocumentConstants.StandardPropety.MessageLevelCode.ERROR);
            $('.' + _errorClass).tooltip({title: this.label.errorMessageTitle, placement:'bottom'});
        },

        getNavigationUrl: function(messageResponse, navigationSourceId, navigationItemList){
            var navUnion = ServiceCollectionsHelper.filterArray(navigationSourceId, 'id', navigationItemList);
            if(navUnion){
                var url = navUnion.targetUrl;
                if(url && messageResponse.actionCode){
                    url = url + "?actionCode=" + messageResponse.actionCode;
                }
                return url;
            }
        },

        navigateToTarget: function(messageResponse){
            "use strict";
            var url = messageResponse.navigationUrl;
            if(messageResponse.rawSEList && messageResponse.rawSEList.length > 0){
                var uuidArray = "";
                messageResponse.rawSEList.forEach(function(se){
                    uuidArray = uuidArray + se.uuid + " ";
                });
                url = changeURLPar(url, LABEL_UUIDARRAY, uuidArray);
            }
            window.open(url, '_blank');
        },

        formatMessageLevelClass: function(messageLevelCode){
            return "message-level-" + messageLevelCode;
        },

        insertIntoMessageList: function(messageResponse, navigationItemList){
            "use strict";
            var vm = this;
            var index = -1;
            var result = ServiceCollectionsHelper.filterWithIndex(vm.messageList, function(tempMessage){
                return tempMessage.messageLevelCode * 1 === messageResponse.messageLevelCode * 1;
            });
            if(!result){
                return;
            }
            index = result.index;
            var messageInContent = result.model;
            if( messageResponse.rawSEList && messageResponse.rawSEList.length > 0 ){
                messageInContent.displayflag = true;
            } else{
                return;
            }
            messageResponse.navigationUrl = vm.getNavigationUrl(messageResponse, messageResponse.navigationSourceId, navigationItemList);
            messageResponse.iconMessage = messageInContent.iconHeader;
            messageInContent.num = messageInContent.num? (messageInContent.num + 1): 1;
            messageInContent.messageResponseList = messageInContent.messageResponseList? messageInContent.messageResponseList: [];
            messageInContent.messageResponseList.push(messageResponse);
            vm.$set(vm.messageList, index, messageInContent);
        }

    },

    template:
        '<div>' +
        '<ul v-for="(message, index) in messageList" class="nav navbar-nav navbar-right pull-right">\n' +
        '    <li v-show="message.displayflag" class="dropdown hidden-xs">\n' +
        '        <a  class="dropdown-toggle waves-effect waves-light cs-message-setting " ' +
        '          :class="formatMessageLevelClass(message.messageLevelCode)" data-toggle="dropdown" aria-expanded="true">\n' +
        '            <i :class="message.iconHeader"></i>\n' +
        '            <span className="badge badge-xs badge-pink content-lightblue">{{message.num}}</span>\n' +
        '        </a>\n' +
        '        <ul  class="dropdown-menu dropdown-menu-lg">\n' +
        '            <li v-for="(messageResponse, inj) in message.messageResponseList" class="list-group nicescroll notifi-message">' +
        '                 <div class="media"  @click="navigateToTarget(messageResponse)">\n' +
        '                        <div class="pull-left p-r-10">\n' +
        '                             <em :class="messageResponse.iconMessage" ></em>\n' +
        '                        </div>\n' +
        '                        <div class="media-body">\n' +
        '                            <h5 class="media-heading">{{messageResponse.messageTitle}}</h5>\n' +
        '                        </div>\n' +
        '                        <span class="label label-success pull-right">{{messageResponse.dataNum}}</span>\n' +
        '                  </div>\n' +
        '            </li>\n' +
        '        </ul>\n' +
        '    </li>\n' +
        '</ul>'+
        '</div>'
});
Vue.component('message-menu', MessageMenu);

var SearchNavigation = Vue.extend({
    name:'search-navigation',
    props:{
        /* using enable-right-bar in DOM */
        keywords:[String]
    },
    data: function () {
        "use strict";
        return {
            label: {
                searchPlaceHolder: ''
            },
            content:{
                keyWords:''
            },
            meta:{
                switch:0,
            }
        };
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
        }.bind(this));
    },

    methods:{

        setI18nCommonProperties: function(){
            "use strict";
            this.label.searchPlaceHolder = $.i18n.prop('searchPlaceHolder');
        },

        searchNavByKeywords: function(){
            var paras = {};
            paras.keyWords = encodeURI(this.content.keyWords);
            var resultURL = "NavigationWelcome.html?keyWords=" + paras.keyWords;
            window.open(resultURL, '_blank');
        },

        switchOn: function(){
            var vm = this;
            vm.$set(vm.meta, 'switch', 1);
        },

        checkSwitchOn: function(){
            var vm = this;
            if(vm.meta.switch === 1){
                return true;
            }
        },

        checkSwitchOff: function(){
            var vm = this;
            if(vm.meta.switch === 0){
                return true;
            }
        }

    },

    template:
    '<span>' +
        '<form v-show="checkSwitchOn()" role="search" class="navbar-left app-search pull-left hidden-xs">\n' +
    '      <input type="text" :placeholder="label.searchPlaceHolder" v-model="content.keyWords" class="form-control app-search-input m-l-20">\n' +
    '      <em><a><i class="fa fa-search" @click="searchNavByKeywords"></i></a></em>\n' +
    '    </form>' +
    '    <span class="app-avatar pull-left p-l-50 " v-show="checkSwitchOff()"><em><a >' +
        '     <i class="fa fa-search content-lightblue" @click="switchOn"></i></a></em></span>' +
    '</span>'
});
Vue.component('search-navigation', SearchNavigation);

var UserDetailBlock = Vue.extend({
    name:'user-detail-block',
    data: function () {
        "use strict";
        return {
            label: {
                logonUserHeaderTitle:'',
                searchPlaceHolder: ''
            },
            content:{
                logonUserUUID:'',
                logonUserName:'',
                logonUserId:'',
                status:'',
                statusValue:''
            },
            getLoginInfoServiceURL: '../common/getLoginInfoService.html'
        };
    },
    computed: {
        computedPupFunction: function(){
            "use strict";
            var logonUserManager = new LogonUserManager();
            if(logonUserManager) {
                return logonUserManager.getDocumentPopoverContent.bind(logonUserManager);
            }
        }
    },
    created: function(){
        this.getLoginInfoService();
        this.initSubComponents();
    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            this.initSubComponents();
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
        }.bind(this));
    },
    methods:{
        setI18nCommonProperties: function(){
            "use strict";
            this.label.searchPlaceHolder = $.i18n.prop('searchPlaceHolder');
            this.label.logonUserHeaderTitle = $.i18n.prop('logonUserHeaderTitle');
        },

        initSubComponents:function(){
            Vue.component("popup-core", PopupCore);
        },

        resultPopTrigger: function(){
            "use strict";
            return '.dropdown-toggle.profile';
        },

        logonUserHeaderIconClass: function(){
            "use strict";
            return 'md md-perm-contact-cal';
        },

        getLoginInfoService: function(){
            "use strict";
            var vm = this;
            this.$http.get(vm.getLoginInfoServiceURL).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    return;
                }
                vm.$set(vm, 'content', oData.content);
            });
        },
        
        popup: function () {
            window.alert("poup");
        }
    },
    template:
    '<div class="user-detail">\n' +
    '   <popup-core :target-uid="content.logonUserUUID" :pop-trigger="resultPopTrigger()" :header-title="label.logonUserHeaderTitle"' +
    '    :header-icon-class="logonUserHeaderIconClass()" :popup-content-function = "computedPupFunction"></popup-core>\n' +
    '    <div class="dropup" >\n' +
    '            <a class="dropdown-toggle profile" data-toggle="dropdown" aria-expanded="true">\n' +
    '                            <img src="assets/images/users/avatar-2.jpg" alt="user-img" class="img-circle">\n' +
    '                            <span class="user-info-span">\n' +
    '                                <h5 class="m-t-0 m-b-0">{{content.logonUserId}}-{{content.logonUserName}}</h5>\n' +
    '                                <p class="text-muted m-b-0">\n' +
    '                                    <small><i class="fa fa-circle text-success"></i> <span>{{content.statusValue}}</span></small>\n' +
    '                                </p>\n' +
    '              </span>\n' +
    '          </a>\n' +
    '     </div>\n' +
    '</div>'

});
Vue.component('user-detail-block', UserDetailBlock);


var LoadingCls = Vue.extend({
    data: function () {
        "use strict";
        return {

        };
    },

    mounted: function () {
        this.$nextTick(function () {

        }.bind(this));
    },

    methods:{
        showBusyLoading: function(){
            $("#busyLoadingDialog").modal('toggle');
            $("#x_data .container").css({opacity:0.1});
            $('.circliful-chart').circliful({
                animationstep: 0.3
            });
        },

        hideBusyLoading: function(){
            $("#busyLoadingDialog").modal('hide');
            $("#busyLoadingDialog .circliful-chart").empty();
            $("#x_data .container").css({opacity:1});
        }
    },

    template:
    '<div class="modal fade" id="busyLoadingDialog" data-backdrop="static" data-keyboard="false">\n' +
    '<div class="modal-dialog" style="width:65%;">\n' +
    '<div class="circliful-chart" data-dimension="150" data-width="10" data-fontsize="16" data-percent="100" data-fgcolor="#0A6ED1" data-bgcolor="#ebeff2">\n' +
    ' </div>\n' +
    '</div>\n' +
    ' </div>'
});

Vue.component('loadingComponent', LoadingCls);

/**
 * BusyLoader:
 *    --{String} parentElement: parent element dom, target element to be hidden.
 */
var BusyLoader = Vue.extend({
    name:'busy-loader',
    props: {
        /* using parent-element */
        parentElement:String,
        /* using model */
        model: [String, Number],
        /* using embedded */
        embedded: [Boolean, String]
    },
    data: function () {
        "use strict";
        return {
            corePostfix: undefined
        };
    },

    computed:{
        coreLoaderId: function(){
            return 'x-busy-loader-' + this.corePostfix;
        },

        comLoading:function(){
            return 'busyLoading' + this.model;
        }
    },

    created:function(){
        "use strict";
        this.initCorePost();
    },

    mounted: function () {
    },

    methods:{

        initCorePost: function(){
            "use strict";
            this.corePostfix = genRamdomPostIndex();
        },

        showBusyLoading: function(){
            $('#' + this.coreLoaderId).removeClass('hide-display');
            $('#' + this.coreLoaderId).addClass('hold-display');
            if(this.embedded){
                if(this.embedded === true || this.embedded === 'true'){
                    $('#' + this.coreLoaderId).removeClass('window');
                }
            }
            if(this.parentElement){
                $(this.parentElement).css({opacity:0.3});
                // $('#' + this.coreLoaderId).css({opacity:1});
            }
        },

        hideBusyLoading: function(timeout){
            var localTimeOut = timeout ? timeout: 0;
            var vm = this;
            setTimeout(function(){
                $('#' + vm.coreLoaderId).removeClass('hold-display');
                $('#' + vm.coreLoaderId).addClass('hide-display');
                if(vm.parentElement){
                    $(vm.parentElement).css({opacity:1});
                }
            }, localTimeOut);
        }
    },

    template:
        '<div :class="comLoading" :id="coreLoaderId" style="z-index:100;" class="busy-loader-core window hide-display"></div>'
});

Vue.component('busy-loader', BusyLoader);



var Navigator = new Vue({
    el: "#x_navigation",
    data: {
        lanCode: '',
        rightSideSystemMenuHoc: "rightSideSystemMenuHoc",
        label: {
            common: {
                logoutWarnTitle: "",
                logoutWarnComment: "",
                confirm: "",
                cancel: "",
                logoutTitle: "",
                unlock: "",
                unlockTitle: "",
                unlockAll: "",
                unlockAllTitle: "",
                enterSysConfigure: "",
                enterSysConfigureTitle: "",
                enterSysApplication: "",
                enterSysApplicationTitle: ""
            },

            group: {
                office: "",
                salesDistribution: "",
                finance: "",
                warehouse: "",
                logistics: "",
                InternalConfigure:""
            },

            admin: {
                ServiceDocumentSetting: "",
                PricingSetting: "",
                Role: "",
                LogonUser: "",
                Organization: "",
                Employee: "",
                MapConfigureModel: "",
                ServiceFlowModel: "",
                FlowRouter: "",
                FlowableTask:"",
                HtmlPageConfigure: "",
                ServiceExtensionSetting: "",
                SerialNumberSetting: "",
                ServiceSpinner: "",
                ServiceDocConsumerUnion: "",
                MaterialConfigureTemplate:"",
                ServiceMobileMessageResource: "",
                FinanceResource: "",
                reportTemplate: "",
                StandardMaterialUnit: "",
                SystemCodeValueCollection: "",
                MessageTemplate: "",
                NavigationElementResource: "",
                NavigationSystemSetting:"",
                AuthorizationGroup: "",
                AuthorizationObject: "",
                FinanceSetting: "",
                FinAccount: "",
                FinAccountTitle: "",
                FinPayReceiveList: "",
                ResFinSystemResource: "",
                ServiceEntityLogModel: "",
                BidInvitationLogModel: "",
                InboundDeliveryLogModel: "",
                OutboundDeliveryLogModel: "",
                SystemExecutorSetting: "",
                FinReceipt: "",
                FinVoucher: "",
                CalendarTemplate:"",
                WorkCalendar:"",
                ServiceDocConfigure:"",
                SearchProxyConfig:"",
                ServiceDocConsumer:""

            },
            logistics: {
                SupplyChainCockpit:"",
                Material: "",
                MaterialType: "",
                MaterialStockKeepUnit: "",
                RegisteredProduct:"",
                CorporateSupplier: "",
                CorporateCustomer: "",
                IndividualCustomer: "",
                systemAdmin: "",
                role: "",
                PurchaseContract: "",
                Inquiry: "",
                InquiryMaterialItem: "",
                PurchaseContractMaterialItem: "",
                SalesContract: "",
                SalesContractMaterialItem:"",
                SalesReturnOrder:"",
                SalesReturnMaterialItem:"",
                SalesForcast:"",
                SalesForcastMaterialItem:"",
                PurchaseRequest:"",
                PurchaseRequestMaterialItem:"",
                PurchaseReturnOrder:"",
                PurchaseReturnMaterialItem:"",
                WasteProcessOrder:"",
                SalesSettleOrder: "",
                BidInvitationOrderManage: "",
                BidInvitationOrder: "",
                BidMaterialItem: "",
                InboundDelivery: "",
                QualityInspectOrderInbound:"",
                Warehouse: "",
                OutboundDelivery: "",
                WarehouseStore: "",
                WarehouseStoreItem: "",
                WarehouseManagement:"",
                InboundOutbound:"",
                HostCompany: "",
                InventoryCheckOrder: "",
                SystemConfigureResource: "",
                InboundItem: "",
                OutboundItem: '',
                InventoryTransferOrder:'',
                InventoryTransferItem:''
            },

            production: {
                ProductionCockpit:"",
                ProductionPlan: "",
                ProductionConfigure: "",
                ProductionPlanManage: "",
                BillOfMaterialOrder: "",
                BillOfMaterialTemplate: "",
                ProductionOrder: "",
                RepairProdOrder: "",
                ProductionOrderSwimChart: "",
                ProdPickingOrder: "",
                ProdOrderReport: "",
                ProdOrderTargetMatItem: "",
                ProcessBOMOrder: "",
                ProdProcess: "",
                ProcessRouteOrder: "",
                WorkingCenter: "",
                ProductionProcess:"",
                ProductionResourceUnion: "",
                ProdWorkCenter: "",
                ProdBasicData: "",
                ProdReturnOrder: "",
                QualityInspectOrderProd: "",
                ProdPickingOrderManage: "",
                ProdPickingRefMaterialItem: "",
                ProdReturnRefMaterialItem: ""
            }
        },
        serviceExtensionSettingHelper: {},
        uid: "",
        messageList: undefined,
        authorizationACUnionList: undefined,
        resourceCache: undefined

    },

    ready: function () {
        var vm = this;
        if (!this.lanCode || this.lanCode === '') {
            this.lanCode = getLan();
        }
        sessionStorage.setItem('lanCode', this.lanCode);
        Vue.component('rightside-systemmenu', RightSideMenuCls);
        Vue.component('loadingComponent', LoadingCls);
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            if (!this.lanCode || this.lanCode === '') {
                this.lanCode = getLan();
            }
            sessionStorage.setItem('lanCode', this.lanCode);
            vm.setLanCode(this.lanCode);
            Vue.component('rightside-systemmenu', RightSideMenuCls);
            Vue.component('loadingComponent', LoadingCls);
        }.bind(this));
    },

    methods: {

        openLeftBar: function () {
            $("#wrapper").toggleClass("enlarged");
            $("#wrapper").addClass("forced");

            if ($("#wrapper").hasClass("enlarged") && $("body").hasClass("fixed-left")) {
                $("body").removeClass("fixed-left").addClass("fixed-left-void");
            } else if (!$("#wrapper").hasClass("enlarged") && $("body").hasClass("fixed-left-void")) {
                $("body").removeClass("fixed-left-void").addClass("fixed-left");
            }

            if ($("#wrapper").hasClass("enlarged")) {
                $(".left ul").removeAttr("style");
            } else {
                $(".subdrop").siblings("ul:first").show();
            }

            toggle_slimscroll(".slimscrollleft");
            $("body").trigger("resize");
        },

        openRightSideBar: function(tab, key, event, argus){
            "use strict";
            var rightMenu = this.$refs.rightmenu;
            if(rightMenu && rightMenu.openRightSideBar){
                rightMenu.openRightSideBar(tab, key, event, argus);
            }
        },


        closeRightSideBar: function(event){
            var rightMenu = this.$refs.rightmenu;
            if(rightMenu && rightMenu.closeRightSideBar){
                rightMenu.closeRightSideBar(event);
            }
        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'NavigationElementResource', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setI18nNavigation
            });
        },


        getI18nPath: function () {
            return "foundation/";
        },

        getLanCode: function () {
            return this.lanCode;
        },

        setLanCode: function (lanCode) {
            this.lanCode = lanCode;
        },

        unlock: function () {
            var unlockURL = '../common/unLock.html';
            this.$http.post(unlockURL, {}).then(function (response) {
                // $.Notification.notify('success', 'top center', '解锁成功', '已经解锁当前用户锁住的所有单据');
            });
        },

        unlockAll: function () {
            var unLockAllURL = '../common/unLockAll.html';
            this.$http.post(unLockAllURL, {}).then(function (response) {
                // $.Notification.notify('success', 'top center', '解锁成功', '已经解锁当前系统所有被锁住的单据');
            });
        },

        enterSysConfigure: function () {
            window.location.href = "LogonUserList.html";
        },

        enterSysApplication: function () {
            window.location.href = "ServiceDocConfigureList.html";
        },

        logoutService: function () {
            var vm = this;
            swal({
                    title: vm.label.common.logoutWarnTitle,
                    text: vm.label.common.logoutWarnComment,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.common.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.common.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var requestData = {};
                        var url = '../common/logoutService.html';
                        vm.$http.post(url, requestData).then(function (response) {
                            window.location.href = "index.html";
                        });
                    } else {
                        // do nothing, just return
                    }
                });
        },


        setI18nNavigation: function () {
            if (ServiceExtensionSettingHelper) {
                this.serviceExtensionSettingHelper = new ServiceExtensionSettingHelper();
            }
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            this.setI18nNavGroup();
            this.setI18nNavAdm();
            this.setI18nLogistics();
            this.setI18nProduction();
        },

        setI18nNavGroup: function () {
            "use strict";
            this.label.group.system = $.i18n.prop('system');
            this.label.group.InternalConfigure = $.i18n.prop('InternalConfigure');
            this.label.group.production = $.i18n.prop('production');
            this.label.group.finance = $.i18n.prop('finance');
            this.label.group.office = $.i18n.prop('office');
            this.label.group.salesDistribution = $.i18n.prop('salesDistribution');
            this.label.group.logistics = $.i18n.prop('logistics');
            this.label.group.warehouse = $.i18n.prop('warehouse');
            if (this.serviceExtensionSettingHelper) {
                this.serviceExtensionSettingHelper.setCustomI18n(this.$http, "NavigationElementResource", this.label.group);
            }
        },

        setI18nCommonProperties: function () {
            "use strict";
            this.label.common.logoutTitle = $.i18n.prop('logoutTitle');
            this.label.common.unlock = $.i18n.prop('unlock');
            this.label.common.cancel = $.i18n.prop('cancel');
            this.label.common.confirm = $.i18n.prop('confirm');
            this.label.common.unlockTitle = $.i18n.prop('unlockTitle');
            this.label.common.unlockAll = $.i18n.prop('unlockAll');
            this.label.common.unlockAllTitle = $.i18n.prop('unlockAllTitle');
            this.label.common.enterSysConfigure = $.i18n.prop('enterSysConfigure');
            this.label.common.enterSysConfigureTitle = $.i18n.prop('enterSysConfigureTitle');
            this.label.common.enterSysApplication = $.i18n.prop('enterSysApplication');
            this.label.common.enterSysApplicationTitle = $.i18n.prop('enterSysApplicationTitle');
            this.label.common.logoutWarnTitle = $.i18n.prop('logoutWarnTitle');
            this.label.common.logoutWarnComment = $.i18n.prop('logoutWarnComment');
            this.label.common.toggleNavBar = $.i18n.prop('toggleNavBar');
            if (this.serviceExtensionSettingHelper) {
                this.serviceExtensionSettingHelper.setCustomI18n(this.$http, "NavigationElementResource", this.label.common);
            }
            $(".button-menu-mobile").tooltip({title: this.label.common.toggleNavBar, placement:'bottom'});

        },

        setI18nNavAdm: function () {
            this.label.admin.SystemConfigureResource = $.i18n.prop('SystemConfigureResource');
            this.label.admin.UserRole = $.i18n.prop('UserRole');
            this.label.admin.Role = $.i18n.prop('Role');
            this.label.admin.ServiceDocumentSetting = $.i18n.prop('ServiceDocumentSetting');
            this.label.admin.PricingSetting = $.i18n.prop('PricingSetting');
            this.label.admin.LogonUser = $.i18n.prop('LogonUser');
            this.label.admin.MapConfigureModel = $.i18n.prop('MapConfigureModel');
            this.label.admin.ServiceFlowModel = $.i18n.prop('ServiceFlowModel');
            this.label.admin.FlowRouter = $.i18n.prop('FlowRouter');
            this.label.admin.FlowableTask = $.i18n.prop('FlowableTask');
            this.label.admin.HtmlPageConfigure = $.i18n.prop('HtmlPageConfigure');
            this.label.admin.ServiceSpinner = $.i18n.prop('ServiceSpinner');
            this.label.admin.ServiceDocConfigure = $.i18n.prop('ServiceDocConfigure');
            this.label.admin.SearchProxyConfig = $.i18n.prop('SearchProxyConfig');
            this.label.admin.ServiceDocConsumerUnion = $.i18n.prop('ServiceDocConsumerUnion');
            this.label.admin.ServiceMobileMessageResource = $.i18n.prop('ServiceMobileMessageResource');
            this.label.admin.FinanceResource = $.i18n.prop('FinanceResource');
            this.label.admin.reportTemplate = $.i18n.prop('reportTemplate');
            this.label.admin.ServiceExtensionSetting = $.i18n.prop('ServiceExtensionSetting');
            this.label.admin.SerialNumberSetting = $.i18n.prop('SerialNumberSetting');
            this.label.admin.Organization = $.i18n.prop('Organization');
            this.label.admin.Employee = $.i18n.prop('Employee');
            this.label.admin.StandardMaterialUnit = $.i18n.prop('StandardMaterialUnit');
            this.label.admin.SystemCodeValueCollection = $.i18n.prop('SystemCodeValueCollection');
            this.label.admin.MessageTemplate = $.i18n.prop('MessageTemplate');
            this.label.admin.NavigationSystemSetting = $.i18n.prop('NavigationSystemSetting');
            this.label.admin.NavigationElementResource = $.i18n.prop('NavigationElementResource');
            this.label.admin.AuthorizationObject = $.i18n.prop('AuthorizationObject');
            this.label.admin.AuthorizationGroup = $.i18n.prop('AuthorizationGroup');
            this.label.admin.ServiceEntityLogModel = $.i18n.prop('ServiceEntityLogModel');
            this.label.admin.BidInvitationLogModel = $.i18n.prop('BidInvitationLogModel');
            this.label.admin.InboundDeliveryLogModel = $.i18n.prop('InboundDeliveryLogModel');
            this.label.admin.OutboundDeliveryLogModel = $.i18n.prop('OutboundDeliveryLogModel');
            this.label.admin.MaterialConfigureTemplate = $.i18n.prop('MaterialConfigureTemplate');
            this.label.admin.SystemExecutorSetting = $.i18n.prop('SystemExecutorSetting');
            this.label.admin.FinanceSetting = $.i18n.prop('FinanceSetting');
            this.label.admin.FinAccount = $.i18n.prop('FinAccount');
            this.label.admin.FinAccountTitle = $.i18n.prop('FinAccountTitle');
            this.label.admin.FinVoucher = $.i18n.prop('FinVoucher');
            this.label.admin.FinReceipt = $.i18n.prop('FinReceipt');
            this.label.admin.FinPayReceiveList = $.i18n.prop('FinPayReceiveList');
            this.label.admin.ResFinSystemResource = $.i18n.prop('ResFinSystemResource');
            this.label.admin.CalendarTemplate = $.i18n.prop('CalendarTemplate');
            this.label.admin.WorkCalendar = $.i18n.prop('WorkCalendar');
            if (this.serviceExtensionSettingHelper) {
                this.serviceExtensionSettingHelper.setCustomI18n(this.$http, "NavigationElementResource", this.label.admin);
            }
        },

        setI18nLogistics: function () {
            this.label.logistics.SupplyChainCockpit = $.i18n.prop('SupplyChainCockpit');
            this.label.logistics.Material = $.i18n.prop('Material');
            this.label.logistics.MaterialType = $.i18n.prop('MaterialType');
            this.label.logistics.MaterialStockKeepUnit = $.i18n.prop('MaterialStockKeepUnit');
            this.label.logistics.RegisteredProduct = $.i18n.prop('RegisteredProduct');
            this.label.logistics.CorporateSupplier = $.i18n.prop('CorporateSupplier');
            this.label.logistics.CorporateCustomer = $.i18n.prop('CorporateCustomer');
            this.label.logistics.IndividualCustomer = $.i18n.prop('IndividualCustomer');
            this.label.logistics.role = $.i18n.prop('Role');
            this.label.logistics.logonUser = $.i18n.prop('LogonUser');
            this.label.logistics.systemAdmin = $.i18n.prop('systemAdmin');
            this.label.logistics.SalesContract = $.i18n.prop("SalesContract");
            this.label.logistics.SalesContractMaterialItem = $.i18n.prop("SalesContractMaterialItem");
            this.label.logistics.SalesReturnOrder = $.i18n.prop("SalesReturnOrder");
            this.label.logistics.SalesReturnMaterialItem = $.i18n.prop("SalesReturnMaterialItem");
            this.label.logistics.SalesForcast = $.i18n.prop("SalesForcast");
            this.label.logistics.SalesForcastMaterialItem = $.i18n.prop("SalesForcastMaterialItem");
            this.label.logistics.SalesSettleOrder = $.i18n.prop("SalesSettleOrder");
            this.label.logistics.PurchaseContract = $.i18n.prop("PurchaseContract");
            this.label.logistics.PurchaseRequest = $.i18n.prop("PurchaseRequest");
            this.label.logistics.PurchaseRequestMaterialItem = $.i18n.prop("PurchaseRequestMaterialItem");
            this.label.logistics.PurchaseReturnOrder = $.i18n.prop("PurchaseReturnOrder");
            this.label.logistics.PurchaseReturnMaterialItem = $.i18n.prop("PurchaseReturnMaterialItem");
            this.label.logistics.WasteProcessOrder = $.i18n.prop("WasteProcessOrder");
            this.label.logistics.Inquiry = $.i18n.prop("Inquiry");
            this.label.logistics.InquiryMaterialItem = $.i18n.prop("InquiryMaterialItem");
            this.label.logistics.PurchaseContractMaterialItem = $.i18n.prop("PurchaseContractMaterialItem");
            this.label.logistics.BidInvitationOrder = $.i18n.prop('BidInvitationOrder');
            this.label.logistics.BidInvitationOrderManage = $.i18n.prop('BidInvitationOrderManage');
            this.label.logistics.BidMaterialItem = $.i18n.prop('BidMaterialItem');
            this.label.logistics.InboundDelivery = $.i18n.prop('InboundDelivery');
            this.label.logistics.QualityInspectOrderInbound = $.i18n.prop('QualityInspectOrderInbound');
            this.label.logistics.InboundItem = $.i18n.prop('InboundItem');
            this.label.logistics.OutboundItem = $.i18n.prop('OutboundItem');
            this.label.logistics.Warehouse = $.i18n.prop('Warehouse');
            this.label.logistics.OutboundDelivery = $.i18n.prop('OutboundDelivery');
            this.label.logistics.WarehouseManagement = $.i18n.prop('WarehouseManagement');
            this.label.logistics.WarehouseStore = $.i18n.prop('WarehouseStore');
            this.label.logistics.WarehouseStoreItem = $.i18n.prop('WarehouseStoreItem');
            this.label.logistics.HostCompany = $.i18n.prop('HostCompany');
            this.label.logistics.SystemConfigureResource = $.i18n.prop('SystemConfigureResource');
            this.label.logistics.InboundOutbound = $.i18n.prop('InboundOutbound');
            this.label.logistics.InventoryCheckOrder = $.i18n.prop('InventoryCheckOrder');
            this.label.logistics.InventoryTransferOrder = $.i18n.prop('InventoryTransferOrder');
            this.label.logistics.InventoryTransferItem = $.i18n.prop('InventoryTransferItem');
            if (this.serviceExtensionSettingHelper) {
                this.serviceExtensionSettingHelper.setCustomI18n(this.$http, "NavigationElementResource", this.label.logistics);
            }
        },

        setI18nProduction: function () {
            this.label.production.BillOfMaterialOrder = $.i18n.prop('BillOfMaterialOrder');
            this.label.production.BillOfMaterialTemplate = $.i18n.prop('BillOfMaterialTemplate');
            this.label.production.ProductionCockpit = $.i18n.prop('ProductionCockpit');
            this.label.production.ProductionPlan = $.i18n.prop('ProductionPlan');
            this.label.production.ProductionPlanManage = $.i18n.prop('ProductionPlanManage');
            this.label.production.ProductionConfigure = $.i18n.prop('ProductionConfigure');
            this.label.production.ProductionOrder = $.i18n.prop('ProductionOrder');
            this.label.production.RepairProdOrder = $.i18n.prop('RepairProdOrder');
            this.label.production.ProductionOrderSwimChart = $.i18n.prop('ProductionOrderSwimChart');
            this.label.production.ProcessBOMOrder = $.i18n.prop('ProcessBOMOrder');
            this.label.production.WorkingCenter = $.i18n.prop('WorkingCenter');
            this.label.production.ProductionResourceUnion = $.i18n.prop('ProductionResourceUnion');
            this.label.production.ProdProcess = $.i18n.prop('ProdProcess');
            this.label.production.ProcessRouteOrder = $.i18n.prop('ProcessRouteOrder');
            this.label.production.ProdWorkCenter = $.i18n.prop('ProdWorkCenter');
            this.label.production.ProdBasicData = $.i18n.prop('ProdBasicData');
            this.label.production.ProductionConfigure = $.i18n.prop('ProductionConfigure');
            this.label.production.ProductionProcess = $.i18n.prop('ProductionProcess');
            this.label.production.ProdOrderReport = $.i18n.prop('ProdOrderReport');
            this.label.production.ProdOrderTargetMatItem = $.i18n.prop('ProdOrderTargetMatItem');
            this.label.production.ProdPickingOrder = $.i18n.prop('ProdPickingOrder');
            this.label.production.ProdReturnOrder = $.i18n.prop('ProdReturnOrder');
            this.label.production.QualityInspectOrderProd = $.i18n.prop('QualityInspectOrderProd');
            this.label.production.ProdPickingOrderManage = $.i18n.prop('ProdPickingOrderManage');
            this.label.production.ProdPickingRefMaterialItem = $.i18n.prop('ProdPickingRefMaterialItem');
            this.label.production.ProdReturnRefMaterialItem = $.i18n.prop('ProdReturnRefMaterialItem');
            if (this.serviceExtensionSettingHelper) {
                this.serviceExtensionSettingHelper.setCustomI18n(this.$http, "NavigationElementResource", this.label.production);
            }
        },

        getLabelById: function (id) {
            if (this.label.common[id]) {
                return this.label.common[id];
            }
            if (this.label.group[id]) {
                return this.label.group[id];
            }
            if (this.label.admin[id]) {
                return this.label.admin[id];
            }
            if (this.label.logistics[id]) {
                return this.label.logistics[id];
            }
            if (this.label.production[id]) {
                return this.label.production[id];
            }
            return id;
        },


        refineNavaigationGroupList: function (navaigationGroupList, authorizationACUnionList) {
            var refinedNavigationGroupList = [];
            for (var i = 0, len = navaigationGroupList.length; i < len; i++) {

                var navigationGroup = navaigationGroupList[i];
                if (navigationGroup.resourceId) {
                    // In case need to check group navigation's resource
                    var resourceModel = ServiceApplicationFactory.filterAuthorizationACUninon(navigationGroup.resourceId, authorizationACUnionList);
                    if (!resourceModel) {
                        continue;
                    } else {
                        refinedNavigationGroupList.push(navigationGroup);
                    }
                } else {
                    // In case don't need to check group navigation resource
                    refinedNavigationGroupList.push(navigationGroup);
                }
            }
            return refinedNavigationGroupList;
        },

        refineNavaigationDataList: function (data, authorizationACUnionList) {
            var refinedNavigationList = [];
            for (var i = 0, len = data.navigationList.length; i < len; i++) {

                var navigation = data.navigationList[i];
                if (navigation.resourceId) {
                    // In case need to check group navigation's resource
                    var resourceModel = ServiceApplicationFactory.filterAuthorizationACUninon(navigation.resourceId, authorizationACUnionList);
                    if (!resourceModel) {
                        continue;
                    }
                }


                var subNavigationList = navigation.subNavigationList;
                var refinedSubNavigationList = [];
                if (subNavigationList && subNavigationList.length > 0) {
                    for (var j = 0, lenJ = subNavigationList.length; j < lenJ; j++) {
                        if (!subNavigationList[j].resourceId) {
                            refinedSubNavigationList.push(subNavigationList[j]);
                            continue;
                        }
                        var subResourceModel = ServiceApplicationFactory.filterAuthorizationACUninon(subNavigationList[j].resourceId, authorizationACUnionList);
                        if (subResourceModel) {
                            refinedSubNavigationList.push(subNavigationList[j]);
                        }
                    }
                }

                // In case there is sub Navigation
                if (refinedSubNavigationList && refinedSubNavigationList.length > 0) {
                    refinedNavigationList.push({
                        "id": navigation.id,
                        "icon": navigation.icon,
                        "url": navigation.url,
                        subNavigationList: refinedSubNavigationList
                    });
                } else {
                    if (navigation.resourceId) {
                        refinedNavigationList.push({
                            "id": navigation.id,
                            "icon": navigation.icon,
                            "url": navigation.url
                        });
                    }
                }
            }
            return {navigationList: refinedNavigationList};

        },

        /**
         * @private Generate Navigation side panel Html content.
         * @param data
         * @param groupId
         * @param navigationId
         * @returns {Element}
         */
        _generateNavigationHtml: function (xmlDoc, data, navigationId, authorizationACUnionList) {
            var vm = this;
            var navigationList = data.navigationList;
            var ulElement = xmlDoc.createElement("ul");
            for (var i = 0; i < navigationList.length; i++) {
                var navigation = navigationList[i];
                var liElement = xmlDoc.createElement("li");
                liElement.setAttribute("class", "has_sub");
                ulElement.appendChild(liElement);
                var ahrefElement = xmlDoc.createElement("a");
                if (navigation.url) {
                    // In case there is url on top item
                    ahrefElement.setAttribute("href", navigation.url);
                } else {
                    ahrefElement.setAttribute("href", "javascript:void(0);");
                }
                var activeFlag = vm._checkNavigationResourceActive(navigation, navigationId);
                if (i == 0) {
                    if (activeFlag) {
                        ahrefElement.setAttribute("class", "topItem waves-effect waves-primary active");
                    } else {
                        ahrefElement.setAttribute("class", "topItem waves-effect waves-primary ");
                    }
                } else {
                    if (activeFlag) {
                        ahrefElement.setAttribute("class", "waves-effect waves-primary active");
                    } else {
                        ahrefElement.setAttribute("class", "waves-effect waves-primary");
                    }
                }

                // var spanWrapperElement = ServiceDOMUtilityHelper.createDefElement({
                //     element: 'span',
                //     class:'ahref-wrapper',
                //     parentElement: liElement
                // });
                liElement.appendChild(ahrefElement);
                if (navigation.icon) {
                    var iconElement = xmlDoc.createElement("i");
                    iconElement.setAttribute("class", navigation.icon + " content-darkblue1");
                    var emWrapperElement = ServiceDOMUtilityHelper.createDefElement({
                        element: 'em',
                        class:'m-r-10',
                        parentElement: ahrefElement
                    });
                    emWrapperElement.appendChild(iconElement);
                }
                var spanElement = xmlDoc.createElement("span");
                var textNode = xmlDoc.createTextNode(' ' + vm.getLabelById(navigation.id));
                spanElement.appendChild(textNode);
                ahrefElement.appendChild(spanElement);

                var numberFlag = false;
                if (navigation.msgNumSuccess) {
                    numberFlag = true;
                    var spanNumberElement = xmlDoc.createElement("span");
                    spanNumberElement.setAttribute("class", "label label-success pull-right");
                    var textNumberNode = xmlDoc.createTextNode(' ' + navigation.msgNumSuccess + ' ');
                    spanNumberElement.appendChild(textNumberNode);
                    ahrefElement.appendChild(spanNumberElement);
                }

                var subNavigationList = navigation.subNavigationList;
                if (subNavigationList && subNavigationList.length > 0) {
                    if (numberFlag === false) {
                        var spanArrowElement = xmlDoc.createElement("span");
                        spanArrowElement.setAttribute("class", "menu-arrow");
                        ahrefElement.appendChild(spanArrowElement);
                    }
                    vm._generateSubNaviHtmlWrapper(liElement, xmlDoc, subNavigationList, navigationId, authorizationACUnionList);
                }
            }
            return ulElement;
        },

        /**
         * @private Check if current navigation resource should be active
         * @param navigation
         * @param navigationId
         * @returns {boolean}
         *
         */
        _checkNavigationResourceActive: function (navigation, navigationId) {
            if (navigationId === navigation.id) {
                return true;
            }
            if (!navigation.subNavigationList) {
                return false;
            }
            for (var i = 0; i < navigation.subNavigationList.length; i++) {
                if (navigationId === navigation.subNavigationList[i].id) {
                    return true;
                }
            }
            return false;
        },


        _generateSubNaviHtmlWrapper: function (parentElement, xmlDoc, subNavigationList, navigationId, authorizationACUnionList) {
            var vm = this;
            var ulElement = xmlDoc.createElement("ul");
            ulElement.setAttribute("class", "list-unstyled");
            parentElement.appendChild(ulElement);
            for (var i = 0; i < subNavigationList.length; i++) {
                var navigation = subNavigationList[i];
                var resourceId = navigation.resourceId;
                var resourceModel = ServiceApplicationFactory.filterAuthorizationACUninon(resourceId, authorizationACUnionList);
                if (!resourceModel) {
                    continue;
                }
                var activeFlag = false;
                activeFlag = navigationId === navigation.id;
                var liElement = xmlDoc.createElement("li");
                ulElement.appendChild(liElement);
                if (activeFlag) {
                    liElement.setAttribute("class", "active");
                }
                var ahrefElement = xmlDoc.createElement("a");
                if (navigation.url) {
                    ahrefElement.setAttribute("href", navigation.url);
                }
                // var spanWrapperElement = ServiceDOMUtilityHelper.createDefElement({
                //     element: 'span',
                //     class:'ahref-wrapper',
                //     parentElement: liElement
                // });
                liElement.appendChild(ahrefElement);
                var textNode = xmlDoc.createTextNode(vm.getLabelById(navigation.id));
                ahrefElement.appendChild(textNode);
                var nextSubNavigationList = navigation.subNavigationList;
                if (nextSubNavigationList && nextSubNavigationList.length > 0) {
                    vm._generateSubNaviHtmlWrapper(liElement, xmlDoc, nextSubNavigationList, navigationId, authorizationACUnionList);
                }
            }
        },

        /**
         * @private filter navigation union from navigation list parsing from configure file.
         * @param navigationList
         * @param groupId
         * @returns {*}
         * @private
         */
        _filterNavGroupUnion: function (navigationList, groupId) {
            if (!navigationList) {
                return;
            }
            for (var i = 0; i < navigationList.length; i++) {
                if (navigationList[i].id === groupId) {
                    return navigationList[i];
                }
            }
        },


        /**
         * @private generate navigation group html content.
         * @param xmlDoc
         * @param groupId
         * @param navGroupList
         *
         */
        _generateNavigationGroupHtml: function (xmlDoc, groupId, navGroupList) {
            var vm = this;
            var navElement = xmlDoc.createElement("ul");
            navElement.setAttribute("class", "nav navbar-nav hidden-xs");
            if (navGroupList) {
                for (var i = 0; i < navGroupList.length; i++) {
                    var navGroup = navGroupList[i];
                    var liElement = xmlDoc.createElement("li");
                    navElement.appendChild(liElement);
                    var ahrefElement = xmlDoc.createElement("a");
                    if (navGroup.defaultUrl) {
                        ahrefElement.setAttribute("href", navGroup.defaultUrl);
                    } else {
                        ahrefElement.setAttribute("href", "#");
                    }

                    if (groupId === navGroup.id) {
                        liElement.setAttribute("class", "active");
                    }
                    ahrefElement.setAttribute("class", "waves-effect");
                    //liElement.appendChild(ahrefElement);

                    var emIconElement = ServiceDOMUtilityHelper.createDefElement({
                        class: 'nav navbar-nav ',
                        element: 'em',
                        parentElement: liElement
                    });
                    var emHrefElement = ServiceDOMUtilityHelper.createDefElement({
                        class: navGroup.backgroundClass,
                        element: 'a',
                        parentElement: emIconElement
                    });
                    if (navGroup.defaultUrl) {
                        emHrefElement.setAttribute("href", navGroup.defaultUrl);
                    } else {
                        emHrefElement.setAttribute("href", "#");
                    }
                    var iconEmbedElement = ServiceDOMUtilityHelper.createDefElement({
                        class: navGroup.iconClass,
                        element: 'icon',
                        parentElement: emHrefElement
                    });
                    var textNode = xmlDoc.createTextNode(vm.getLabelById(navGroupList[i].id));
                    ahrefElement.appendChild(textNode);
                }
            }
            return navElement;
        },


        getAuthorizationACUnionListPromise: function () {
            var vm = this;
            return new Promise(function (resolve, reject) {
                if (this.authorizationACUnionList && this.authorizationACUnionList.length > 0) {
                    resolve(this.authorizationACUnionList);
                } else {
                    var authorizationACUnionListPromise = ServiceApplicationFactory.getAuthorizationACUnionListPromise(vm.$http);
                    authorizationACUnionListPromise.then(function (values) {
                        this.authorizationACUnionList = values;
                        resolve(this.authorizationACUnionList);
                    });
                }
            }.bind(this));
        },


        /**
         * @public LoadNavigation entrance method, generate navigation dom.
         * @param $groupElement: Parent DOM element to locate navigation group html content.
         * @param $naviElement: Parent DOM element to locate navigation resource html content.
         * @param groupId: current active navigation group id.
         * @param navigationId: current active navigation resource id.
         */
        loadNavigation: function ($groupElement, $naviElement, groupId, navigationId) {
            // var rightSideMenu = new RightSideMenuCls({
            //     el: '#rightSideSystemMenuHoc'
            // });
            var vm = this;
            vm.loadNavigationCore({
                $groupElement: $groupElement,
                $naviElement:$naviElement,
                groupId: groupId,
                navigationId: navigationId,
                groupConfigPath: 'js/navigation.json'
            });

        },

        initNavigation: function (groupId, navigationId) {
            var vm = this;
            vm.initNavigationCore({
                groupId: groupId,
                navigationId: navigationId,
                label: vm.label
            });

        },

        /**
         * @public LoadNavigation entrance method, generate navigation dom.
         * @param $groupElement: Parent DOM element to locate navigation group html content.
         * @param $naviElement: Parent DOM element to locate navigation resource html content.
         * @param groupId: current active navigation group id.
         * @param navigationId: current active navigation resource id.
         */
        loadNavigationInternalConfig: function ($groupElement, $naviElement, groupId, navigationId) {
            // var rightSideMenu = new RightSideMenuCls({
            //     el: '#rightSideSystemMenuHoc'
            // });
            var vm = this;
            vm.loadNavigationCore({
                $groupElement: $groupElement,
                $naviElement: $naviElement,
                groupId: groupId,
                navigationId: navigationId,
                groupConfigPath: 'js/navigationSysConfig.json'
            });
        },

        /**
         * Core Logic to render navigation panel
         * @param {object} oSettings
         *       --{string} groupId
         *       --{string} navigationId
         */
        initNavigationCore: function (oSettings) {
            var vm = this;
            var label = oSettings.label;
            var navGroupListPromise = NavigationGroupIns.getNavigationGroupListPromise();
            var authorizationACUnionListPromise = vm.getAuthorizationACUnionListPromise(vm.$http);
            NavigationGroupIns.initGroupConfigure({
                navGroupListPromise:navGroupListPromise,
                authorizationPromise: authorizationACUnionListPromise,
                label: label,
                groupId: oSettings.groupId
            });
            navGroupListPromise.then(function(data){
                var navigationGroupList = data.navigationList;
                var navElementListPromise = SideBarNavigator.getNavigationListPromise(oSettings.groupId, navigationGroupList);
                SideBarNavigator.initNaviConfigure({
                    navElementListPromise:navElementListPromise,
                    authorizationPromise: authorizationACUnionListPromise,
                    label: label,
                    groupId: oSettings.navigationId
                });
            });
        },

        /**
         * Core Logic to render navigation panel
         * @param {object} oSettings
         *       --{dom} $groupElement:
         *       --{dom} $naviElement:
         *       --{string} groupId
         *       --{string} navigationId
         *       --{path} groupConfigPath
         */
        loadNavigationCore: function (oSettings) {
            // var rightSideMenu = new RightSideMenuCls({
            //     el: '#rightSideSystemMenuHoc'
            // });
            var vm = this;
            var ser = new XMLSerializer();
            window.jQuery.Sidemenu.$menuItem = $("#sidebar-menu a");
            window.jQuery.Sidemenu.init();
            var groupResponse = $.getJSON(oSettings.groupConfigPath, function (data) {
                jQuery.i18n.properties({
                    name: 'NavigationElementResource', //properties file name
                    path: getI18nRootPath() + vm.getI18nPath(), //path for properties files
                    mode: 'map', //Using map mode to consume properties files
                    cache:true,
                    language: vm.getLanCode(),
                    callback: vm.setI18nNavigation
                });
            });
            var authorizationACUnionListPromise = vm.getAuthorizationACUnionListPromise(vm.$http);
            // UN lock current locking
            vm.unlock();
            Promise.all([authorizationACUnionListPromise, groupResponse]).then(function (values) {
                var authorizationACUnionList = values[0];
                var navigationGroupList = values[1].navigationList;
                var xmlDoc = document.implementation.createDocument("", "", null);
                navigationGroupList = vm.refineNavaigationGroupList(navigationGroupList, authorizationACUnionList);
                var navGroupHtmlContent = vm._generateNavigationGroupHtml(xmlDoc, oSettings.groupId, navigationGroupList);
                var htmlContentGroup = ser.serializeToString(navGroupHtmlContent);
                oSettings.$groupElement.empty();
                oSettings.$groupElement.prepend(htmlContentGroup);
                var navigationUnion = vm._filterNavGroupUnion(navigationGroupList, oSettings.groupId);
                if (navigationUnion) {
                    var navigationResponse = $.getJSON("js/" + navigationUnion.url).then(function (data) {
                        var refinedData = vm.refineNavaigationDataList(data, authorizationACUnionList);
                        var ulElement = vm._generateNavigationHtml(xmlDoc, refinedData, oSettings.navigationId, authorizationACUnionList);
                        var htmlContent = ser.serializeToString(ulElement);
                        oSettings.$naviElement.empty();
                        oSettings.$naviElement.prepend(htmlContent);
                        window.jQuery.Sidemenu.$menuItem = $("#sidebar-menu a");
                        window.jQuery.Sidemenu.init();
                    });
                }
            });
        }

    }
});
