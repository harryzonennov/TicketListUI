var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        processButtonMeta:[],
        searchModuleURL: '../pricingSetting/searchModuleService.html'
    },


    created: function(){
        var vm = this;
        vm.initSubComponents();
    },

    methods: {

        searchModule: function () {
            listVar.searchModuleList();
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    formatClass: vm.displayForEdit,
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "PricingSettingEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            name: "",
            multiCurrencyFlag: "",
            uuid: "",
            defCurrencyCode: "",
            id: ""
        },

        label: PricingSettingManager.label.pricingSetting
    },
    methods:{
        clearSearch: function(){
            clearSearchModel(this.content);
        }
    }
});

var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: PricingSettingManager.label.pricingSetting,
        author:{
            resourceId:'PricingSetting',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        tableId: '#x_table_pricingSetting',
        datatable: '',
        items: [],
        loadModuleListURL: '../pricingSetting/loadModuleListService.html',
        preLockURL: '../pricingSetting/preLockService.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
        this.setI18nProperties(processModel.initProcessButtonMeta);
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'PricingSetting');
            //this.datatable = new ServiceDataTable(this.tableId);
            // this.initAuthorResourceCheck();
            this.loadModuleList();
        });
    },

    methods: {

        initSubComponents: function(){
            "use strict";
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },
        //
        // initAuthorResourceCheck: function(){
        //     "use strict";
        //     var vm = this;
        //     ServiceAuthorHelper.initDefaultAuthorObject({
        //         vm:vm,
        //         errorHandle:ServiceUtilityHelper.handleErrorUIDefault
        //     });
        // },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop);
        },

        setI18nProperties: function (fnCallback) {
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'PricingSetting',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        searchModuleList: function () {
            this.$refs.dataTableFrame.searchModuleList();
        },

        buildSearchData: function (data) {
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../pricingSetting/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'id',
                labelKey: 'id',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.PricingSetting,
                    uuidFieldName: 'uuid'
                }
            }, {
                fieldName: 'name',
                minWidth: '180px'
            },{
                fieldName: 'defCurrencyCode',
                minWidth: '180px'
            },{
                fieldName: 'multiCurrencyFlag',
                minWidth: '180px'
            }];
            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        },


        loadModuleList2: function () {
            var vm = this;
            this.$http.get(vm.loadModuleListURL).then(function (response) {
                if (!JSON.parse(response.data).content) {
                    $.Notification.notify('error', 'top center', this.label.msgConnectFailure, this.label.msgLoadDataFailure);
                    return;
                }
                vm.$set('items', JSON.parse(response.data).content);
                setTimeout(function () {
                    vm.datatable.build();
                }, 0);
            });
        },

        refreshTableItems: function (items) {
            this.datatable = new ServiceDataTable(this.tableId);
            this.$set('items', items);
            setTimeout(function () {
                this.datatable.build();
            }.bind(this), 0);
        },


        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                $http:vm.$http,
                author:processModel.author,
                editorPage:"PricingSettingEditor.html",
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        }

    }
});
