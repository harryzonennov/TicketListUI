var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        processButtonMeta:[],
        author:{
            resourceId:'CorporateSupplier',
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        serviceUIMeta: {},
        downloadExcelURL: '../corporateSupplier/downloadExcel.html',
        searchModuleURL: '../corporateSupplier/searchModuleService.html'
    },

    created: function(){
        this.initAuthorResourceCheck();
        this.initSubComponents();
    },

    methods: {
        searchModule: function () {
            listVar.searchModuleList();
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    formatClass: vm.displayForEdit,
                    callback: vm.newModule
                },
                downloadExcel: {
                    formatClass: vm.displayForExcel,
                    callback: vm.downloadExcel
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        downloadExcel: function () {
            var vm = this;
            var excelType = ServiceUIMetaProxy.filterKeyValue(vm.serviceUIMeta, 'excelType');
            ServiceExcelHelper.downloadExcel({
                url: vm.downloadExcelURL,
                $http: vm.$http,
                excelType: excelType,
                busyLoader: vm.$refs.refBusyLoader,
                requestData: searchModel.content,
                reportTitle: listVar.label.modelTitle,
                errorHandle: listVar.errorHandle
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "CorporateSupplierEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },
        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});
var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            weiXinID: "",
            status: "",
            uuid: "",
            id: "",
            tags: "",
            countryName: "",
            supplierLevel:'',
            stateName: "",
            cityName:'',
            client: "",
            name: "",
            weiboID: ""
        },

        label: {
            weiXinID: '',
            status: '',
            retireDate: '',
            supplierLevel:'',
            uuid: '',
            id: '',
            name: '',
            tags: '',
            tagsSearchComment: '',
            clearSearch:'',
            clearSearchComment:'',
            cityName:'',
            countryName: "",
            stateName: "",
            weiboID: '',
            customerType: '',
            mobile: '',
            telephone: '',
            address: '',
            contactPersonName:'',
            note: '',
            faceBookID: ''
        },
        eleTags:'#x_tags',
        supplierLevelArray:[],
        eleSupplierLevel: '#x_supplierLevel',
        getSupplierLevelMapURL:'../corporateSupplier/loadSupplierLevelMap.html'

    },

    mounted: function () {
        this.$nextTick(function () {
            this.initTagsInput();
            this.getSupplierLevel();
            this.initSelectConfig();
        }.bind(this));
    },
    methods: {
        clearSearch: function(){
            clearSearchModel(this.content);
            $(this.eleTags).tagsinput('removeAll');
        },

        initTagsInput: function () {
            "use strict";
            $(this.eleTags).tagsinput();
        },

        initSelectConfig: function(){
            var vm = this;
            $(vm.eleSupplierLevel).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'supplierLevel', $(vm.eleSupplierLevel).val());
            });
        },

        getSupplierLevel: function () {
            var vm = this;
            this.$http.get(this.getSupplierLevelMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                    return;
                }
                var supplierLevelArray = JSON.parse(response.body).content;
                vm.$set(vm, 'supplierLevelArray', supplierLevelArray);
                var _formatSupplierLevel = ServiceUtilityHelper.genTemplateFormatFunction(supplierLevelArray);
                var resultList = formatSelectResult(supplierLevelArray, 'id', 'name');
                if( !resultList ){
                    return;
                }
                resultList.splice(0, 0, {'id':'0', 'text':' '});

                setTimeout(function () {
                    $(vm.eleSupplierLevel).select2({
                        data: resultList,
                        templateResult: _formatSupplierLevel,
                        templateSelection: _formatSupplierLevel
                    });
                }, 0);
            });
        }
    }

});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: CorporateSupplierManager.label.corporateSupplier,
        author: {
            resourceId: 'CorporateCustomer',
            actionCode: {
                List: false,
                Edit: false,
                View: false,
                PriceInfo: false,
                Delete: false
            }
        },
        tableId: '#x_table_corporateCustomer',
        datatable: '',
        items: [],
        coporateList: [],
        loadModuleListURL: '../corporateSupplier/loadModuleListService.html',
        preLockURL: '../corporateSupplier/preLockService.html',
        deleteModuleURL: '../corporateCustomer/deleteModule.html'
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            this.datatable = new ServiceDataTable(this.tableId);
            NavigationPanelIns.initNavigation('logistics', 'CorporateSupplier');
            this.initAuthorResourceCheck();
            this.setI18nProperties(processModel.initProcessButtonMeta());
            this.loadModuleList();
        }.bind(this));
    },
    methods: {


        initAuthorResourceCheck: function () {
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm: vm,
                errorHandle: ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        refreshTableList: function(newItems){
            // this.datatable = new ServiceDataTable(this.tableId);
            this.$set(this, 'items', newItems);
            this.refreshFlag = true;
            //this.datatable.datatable.draw(false);
            setTimeout(function () {
                this.datatable.build();
            }.bind(this), 0);
        },


        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop);
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,serviceUIMeta: processModel.serviceUIMeta,
                fnCallback: fnCallback, modelId: 'CorporateSupplier', coreModelId: 'CorporateSupplier',
                label: [vm.label, searchModel.label, processModel.label], vm:processModel, errorHandle: vm.errorHandle,
                configList: [{
                    name: 'CorporateSupplier',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        searchModuleList: function(){
            this.datatable.datatable.ajax.reload();
        },

        buildSearchData: function(data){
            searchModel.content.tags = getMultSearchTags(searchModel.eleTags);
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleList: function () {
            var vm = this;

            var fnDeleteModule;
            if(vm.author.actionCode.Delete === true){
                fnDeleteModule = vm.deleteModule;
            }

            var _oInitSettings = {
                items: vm.items,
                url:'../corporateSupplier/searchTableService.html',
                fnAjaxData:vm.buildSearchData,
                fnEditModule:vm.editModule,
                fnEditModuleModal:vm.editModule,
                fnDeleteModule:fnDeleteModule
                //fnDrawCallback: vm.initBidOrderPopOverFrame
            };

            var settings = ServiceDataTable.genDefServerSettingsTemplate(_oInitSettings);

            $.extend(true, settings, {
                'errorHandle' : vm.errorHandle,
                "columnDefs": [
                    {
                        "targets": 0,
                        "createdCell": function (td, cellData, rowData, row, col) {
                            ServiceDataTable.genDefFirstColumnContent(_oInitSettings, td,cellData, rowData, row, col);
                        }
                    },
                    {
                        "targets": 5,
                        "createdCell": function (td, cellData, rowData, row, col) {
                            iconClassMapArray = ServiceUtilityHelper.convCodeValueIconMap(searchModel.supplierLevelArray);
                            ServiceDataTable.buildDefValueStyleTd(document, td, rowData['supplierLevel'],
                                iconClassMapArray);
                        }
                    },
                    {
                        "targets": 6,
                        "createdCell": function (td, cellData, rowData, row, col) {

                            var tagsList = ServiceDataTable.getTagListBySeperator(cellData);
                            if (tagsList && tagsList.length > 0) {
                                ServiceDataTable.fnDrawTagsTd(td, tagsList);
                            }
                        }
                    }
                ],
                "columns": [
                    { "data": "id", "orderable" : true },
                    { "data": "id", "orderable" : true },
                    { "data": "name", "orderable" : true },
                    { "data": "telephone", "orderable": true },
                    { "data": "cityName", "orderable": true },
                    { "data": "supplierLevelValue", "orderable": true },
                    { "data": "tags", "orderable": true }
                ]
            });

            vm.datatable.buildWithServer(settings);
        },

        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                author:processModel.author,
                $http:vm.$http,
                editorPage:"CorporateSupplierEditor.html",
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        _getTagsList: function(row, cellData, refreshFlag){
            var tagsList;
            if(refreshFlag){
                if(!this.items[row]){
                    return;
                }
                tagsList = this._getTagBySeperator(this.items[row]["tags"]);
            }else{
                tagsList = this._getTagBySeperator(cellData) ;
            }
            return tagsList;
        },

        deleteModule: function (uuid) {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        // execution deletion
                        var item = ServiceCollectionsHelper.filterArray(uuid, 'uuid', vm.items);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, vm.items);
                        var requestData = {uuid: uuid};
                        vm.$http.post(vm.deleteModuleURL, requestData).then(function (response) {
                            var oData = JSON.parse(response.data);
                            if (!oData.errorCode || oData.errorCode * 1 > 299) {
                                vm.errorHandle(oData);
                                return;
                            }
                            $.Notification.notify('success', 'top center', this.label.msgDeleteOK, this.label.msgDeleteOKComment);
                            // remove the data from list
                            vm.searchModuleList();
                        });
                    } else {
                        // do nothing, just return
                    }
                });

        },

        _getTagBySeperator: function(cellData){
            return cellData? cellData.split(','):null;
        },


        _fnGenInnerHtml: function(tagsList){
            var i = 0, len = tagsList.length, codeUUID, codeUnion, ulElement;
            var maxLength = 4;
            ulElement = document.createElement('div');
            // ulElement.setAttribute('class', 'select2-selection__rendered');
            for (i = 0; i < len; i++) {
                if (i < maxLength) {
                    var liElement = document.createElement('div');
                    liElement.setAttribute('class', 'selection_choice');
                    liElement.setAttribute('title', tagsList[i]);
                    var textElement = document.createTextNode(tagsList[i] + ' ');
                    liElement.appendChild(textElement);
                    ulElement.appendChild(liElement);
                } else {
                    var subElement = document.createElement('div');
                    subElement.setAttribute('class', 'selection_element');
                    var textNode = document.createTextNode(" ... ");
                    subElement.appendChild(textNode);
                    ulElement.appendChild(subElement);
                    break;
                }
            }
            return ulElement;
        },

        _fnDrawTagsTd: function (td, tagsList) {
            if (tagsList && tagsList.length > 0) {
                td.innerHTML = '';
                var ulElement = this._fnGenInnerHtml(tagsList);
                td.appendChild(ulElement);
            }
        },

        preLock: function () {
        }
    }
});
