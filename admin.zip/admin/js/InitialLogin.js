/**
 * Created by Zhang,Hang on 8/23/2016.
 */

var searchModel = new Vue({
    el: "#x_data",
    data: {
        content: {
            uuid: "",
            name: "",
            id: "",
            userId: "",
            client: "",
            password: "",
            newPassword: "",
            confirmPassword: "",
            errorMessage: ""
        },
        label: {
            msgSystemFailure: '',
            msgUnknowSystemFailure: '',
            noneAuthorizedFailure: '',
            noneLogonUser: '',
            reloginSessionTimeout: ''
        },
        initialLoginURL: '../common/initialLoginService.html',
        loadLogonUserURL: '../logonUser/loadModule.html',
    },

    mounted: function () {
        this.$nextTick(function () {
            this.initLoginSetting();
        });
    },

    methods: {

        initLoginSetting: function () {
            "use strict";
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var kennwort = getUrlVar("kennwort");
            vm.content.password = Base64.decode(kennwort);
            var url = this.loadLogonUserURL + "?uuid=" + baseUUID;
            this.$http.get(url).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                this.setModuleToUI(oData.content);
            }.bind(this));

            vm.getI18nWrap(function () {
                vm.getI18nCommonMap();
                var errorCode = getUrlVar("errorCode");
                var subErrorCode = getUrlVar("subErrorCode");
                var pathname = getUrlVar("pathName");
                vm.$set(vm.content, 'subErrorCode', subErrorCode);
                vm.$set(vm.content, 'errorCode', errorCode);
                vm.$set(vm.content, 'pathname', pathname);
                if (errorCode + "" === HttpStatus.SC_UNAUTHORIZED + "") {
                    if (subErrorCode + "" === HttpSubStatus.SC_SUBERROR_LOGONFAILED + "") {
                        vm.$set(vm.content, 'errorMessage', vm.label.reloginSessionTimeout);
                    }
                }
            });
        },

        setModuleToUI: function (logonUser) {
            this.content.uuid = logonUser.uuid;
            this.content.name = logonUser.name;
            this.content.id = logonUser.id;
            this.content.userId = logonUser.id;
            this.content.client = logonUser.client;
        },

        initialLogin: function () {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("userId", this.content.userId, "password", this.content.password,
                "newPassword", this.content.newPassword, "confirmPassword", this.content.confirmPassword, "client", "001");
            this.$http.post(vm.initialLoginURL, requestData).then(function (response) {
                if (JSON.parse(response.data).errorCode == HttpStatus.SC_OK) {
                    vm.forwardToTarget();
                } else {
                    ServiceHttpRequestHelper.handleErrorCodeWrap({
                        errorMessage: JSON.parse(response.data).errorMessage,
                        errorTitle: "登陆失败"
                    });
                }
            }, function (response) {
                alert(response.statusText);
            });
        },

        checkPasswordConfirm: function () {
            if (!this.content.newPassword) {
                return false;
            }
            if (this.content.newPassword !== this.content.confirmPassword) {
                return false;
            }
            return true;
        },

        forwardToTarget: function () {
            "use strict";
            var vm = this;
            var resultPara = getUrlVars();
            // call to get logon user's role list
            var promise = ServiceApplicationFactory.getRoleListPromise(this.$http);
            promise.then(function (roleList) {
                if (resultPara.pathname) {
                    resultPara.errorCode = undefined;
                    resultPara.subErrorCode = undefined;
                    var pathname = resultPara.pathname;
                    resultPara.pathname = undefined;
                    var resultURL = pathname + "?" + urlEncode(resultPara);
                    window.location.href = resultURL;
                } else {
                    window.location.href = "BidInvitationOrderList.html";
                }
            }, function (oError) {

            });

        },

        getI18nWrap: function (fnCallback) {
            "use strict";
            var vm = this;
            jQuery.i18n.properties({
                name: 'ComElements', //properties file name
                path: getI18nRootPath() + vm.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: fnCallback
            });
        },

        getI18nCommonMap: function () {
            "use strict";
            this.label.msgSystemFailure = $.i18n.prop('msgSystemFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.noneAuthorizedFailure = $.i18n.prop('noneAuthorizedFailure');
            this.label.noneLogonUser = $.i18n.prop('noneLogonUser');
            this.label.reloginSessionTimeout = $.i18n.prop('reloginSessionTimeout');
        },

        getI18nPath: function () {
            "use strict";
            return "foundation/";
        }
    }
});

