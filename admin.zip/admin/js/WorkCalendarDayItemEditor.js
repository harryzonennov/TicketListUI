var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: {
            vocationType: '',
            dayStatus: '',
            id: '',
            name: '',
            refDate: '',
            note: '',

            workCalendarDayItemSection: '',

            msgSaveOK: '',
            msgSaveOKComment: '',
            msgConnectFailure: '',
            msgUnknowSystemFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            save: '',
            exit: '',
            quickEdit: '',
            buttonDelete: '',
            close: '',
            deleteWarnTitle: '',
            deleteWarnText: '',
            cancel: '',
            commit: '',
            confirm: '',
            addWorkCalendarDayItem: ''
        },
        content: {
            uuid: '',
            client: '',
            vocationType: '',
            dayStatus: '',
            id: '',
            name: '',
            refDate: '',
            note: ''
        },
        eleVocationType: '#x_vocationType',
        eleDayStatus: '#x_dayStatus',
        loadModuleEditURL: '../workCalendarDayItem/loadModuleEditService.html',
        saveModuleURL: '../workCalendarDayItem/saveModuleService.html',
        exitModuleURL: '../workCalendarDayItem/exitEditor.html',
        newModuleServiceURL: '../workCalendarDayItem/newModuleService.html',
        getVocationTypeURL: '../workCalendarDayItem/getVocationType.html',
        getDayStatusURL: '../workCalendarDayItem/getDayStatus.html'

    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'WorkCalendarDayItem');
            this.setI18nProperties();
            this.loadModuleEdit();
            this.initSelectConfigure();
        });
    },

    methods: {
        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.quickEdit = $.i18n.prop('quickEdit');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.deleteWarnTitle = $.i18n.prop('deleteWarnTitle');
            this.label.deleteWarnText = $.i18n.prop('deleteWarnText');
            this.label.cancel = $.i18n.prop('cancel');
            this.label.commit = $.i18n.prop('commit');
            this.label.confirm = $.i18n.prop('confirm');
            this.label.addWorkCalendarDayItem = $.i18n.prop('addWorkCalendarDayItem');
            BusyLoader.cleanPageBackground();

        },

        setNodeI18nPropertiesCore: function () {
            this.label.vocationType = $.i18n.prop('vocationType');
            this.label.dayStatus = $.i18n.prop('dayStatus');
            this.label.id = $.i18n.prop('id');
            this.label.name = $.i18n.prop('name');
            this.label.refDate = $.i18n.prop('refDate');
            this.label.note = $.i18n.prop('note');
            this.label.workCalendarDayItemSection = $.i18n.prop('workCalendarDayItemSection');

        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'WorkCalendarDayItem', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });

        },

        getI18nPath: function () {
            return "production/";
        },

        initSelectConfigure: function () {
            var vm = this;

        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if (processMode == PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                var url = this.newModuleServiceURL;
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                this.$http.post(url, requestData).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }
            if (processMode == PROCESSMODE_EDIT) {
// In case [Edit mode]
                var url = this.loadModuleEditURL + "?uuid=" + baseUUID;
                this.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }


        },

        setPageHeaderLink: function () {
            var vm = this;
            var baseUUID = vm.content.parentNodeUUID;
            var baseDocURL = genCommonEditURL("WorkCalendarEditor.html", baseUUID);
            var ser = new XMLSerializer();
            var xmlDoc = document.implementation.createDocument("", "", null);
            $("#x_linkToDoc").empty();
            var docText = vm.label.parentPageTitle + ":" + vm.content.parentNodeId;
            var linkToRootDocElement = DocumentOrderMatPopInfo.createPageHeaderLinkToRootDoc(xmlDoc, docText, baseDocURL);
            var htmlContent = ser.serializeToString(linkToRootDocElement);
            $("#x_linkToDoc").prepend(htmlContent);

        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            this.$http.post(vm.saveModuleURL, vm.content).then(function (response) {
                $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                this.setModuleToUI(JSON.parse(response.data).content);
                var processMode = getUrlVar(LABEL_PROCESSMODE);
                if (processMode && processMode == PROCESSMODE_NEW) {
                    var baseUUID = vm.content.uuid;
                    if (baseUUID) {
                        window.location.href = genCommonEditURL("WorkCalendarDayItemEditor.html", baseUUID);
                    }
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.parentNodeUUID;
            window.location.href = genCommonEditURL("WorkCalendarEditor.html", baseUUID);

        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.uuid;
            window.location.href = genCommonEditURL("WorkCalendarDayItemEditor.html", baseUUID, tabKey);

        },

        getVocationType: function (content) {
            var vm = this;
            this.$http.get(this.getVocationTypeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleVocationType).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleVocationType).val(content.vocationType);
                    $(vm.eleVocationType).trigger("change");
                }, 0);
            });

        },

        getDayStatus: function (content) {
            var vm = this;
            this.$http.get(this.getDayStatusURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleDayStatus).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleDayStatus).val(content.dayStatus);
                    $(vm.eleDayStatus).trigger("change");
                }, 0);
            });

        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'workCalendarDayItemUIModel', content);
            vm.getVocationType(content);
            vm.getDayStatus(content);
            this.setPageHeaderLink();

        }

    }
});
