var dataVar = new Vue({
    el: "#x_data",
    mixins: [CorporateCustomerManager.labelTemplate],
    data: {
        contactpersonTableId: '#x_table_corporateContactPerson',
        contactpersonTable: {},
        label: CorporateCustomerManager.label.corporateCustomer,
        content: {
            corporateCustomerUIModel: CorporateCustomerManager.content.corporateCustomerUIModel,
            corporateContactPersonUIModelList: [],
            corporateCustomerAttachmentUIModelList: []
        },
        cache: {
            corporateContactPerson: {
                id:'',
                name:'',
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refNodeName: '',
                refUUID: '',
                weixinId:'',
                email:'',
                telephone: '',
                contactRole: '',
                contactPosition: '',
                address: '',
                contactRoleNote: '',
                note: ''
            }
        },
        attachmentMeta:{
            loadAttachmentURL: '../corporateCustomer/loadAttachment.html',
            deleteAttachmentURL: '../corporateCustomer/deleteAttachment.html',
            uploadAttachmentURL: '../corporateCustomer/uploadAttachment.html',
            uploadAttachmentTextURL: '../corporateCustomer/uploadAttachmentText.html'
        },
        attachmentLabel:{
            attachmentSection:''
        },
        author:{
            resourceId:ServiceModuleConstants.CorporateCustomer,
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        processButtonMeta: [],
        embedProcessButtonMeta:[],
        addressInfoInit: false, // Indicator whethear 'AddressInfo' has initial value.
        eleCustomerLevel:'#x_customerLevel',
        loadModuleEditURL: '../corporateCustomer/loadModuleEditService.html',
        loadModuleViewURL: '../corporateCustomer/loadModuleViewService.html',
        saveModuleURL: '../corporateCustomer/saveModuleService.html',
        checkDuplicateURL: '../corporateCustomer/checkDuplicate.html',
        newModuleServiceURL: '../corporateCustomer/newModuleService.html',
        getCustomerLevelMapURL:'../corporateCustomer/loadCustomerLevelMap.html',
        newCorporateContactPersonServiceURL: '../individualCustomer/newContactCustomerService.html',
        eleEditCorporateContactPersonModal: '#x_eleEditCorporateContactPersonModal',
        eleCityName: '#x_cityName',
        loadCitySelectListURL: '../city/loadLeanModuleListService.html',
        exitURL: 'CorporateCustomerList.html',
        exitModuleURL: '../corporateCustomer/exitEditor.html'
    },

    created: function(){
        "use strict";
        var vm = this;
        vm.initSubComponents();
        vm.initAuthorResourceCheck();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('logistics', 'CorporateCustomer');
            this.setI18nProperties(vm.initProcessButtonMeta());
            this.loadModuleEdit();
            this.initTagsInput();
            this.initSelectConfig();
            this.initParsleyConfigure();
            this.contactpersonTable = new ServiceDataTable(this.contactpersonTableId);
        }.bind(this));
    },

    watch: {
        'content.corporateCustomerUIModel.stateName': function (stateName) {
            this.updateAddressInfo({
                stateName: stateName,
                cityName:  this.content.corporateCustomerUIModel.cityName,
                townZone: this.content.corporateCustomerUIModel.townZone,
                streetName: this.content.corporateCustomerUIModel.streetName,
                telephone:this.content.corporateCustomerUIModel.contactTelephone
            });
        },
        'content.corporateCustomerUIModel.cityName': function (cityName) {
            this.updateAddressInfo({
                stateName: this.content.corporateCustomerUIModel.stateName,
                cityName: cityName,
                townZone: this.content.corporateCustomerUIModel.townZone,
                streetName: this.content.corporateCustomerUIModel.streetName,
                telephone:this.content.corporateCustomerUIModel.telephone
            });
        },
        'content.corporateCustomerUIModel.townZone': function (townZone) {
            this.updateAddressInfo({
                stateName: this.content.corporateCustomerUIModel.stateName,
                cityName: this.content.corporateCustomerUIModel.cityName,
                townZone: townZone,
                streetName: this.content.corporateCustomerUIModel.streetName,
                telephone:this.content.corporateCustomerUIModel.telephone
            });
        },
        'content.corporateCustomerUIModel.streetName': function (streetName) {
            this.updateAddressInfo({
                stateName: this.content.corporateCustomerUIModel.stateName,
                cityName: this.content.corporateCustomerUIModel.cityName,
                townZone: this.content.corporateCustomerUIModel.townZone,
                streetName: streetName,
                telephone:this.content.corporateCustomerUIModel.telephone
            });
        },
        'content.corporateCustomerUIModel.contactTelephone': function (telephone) {
            this.updateAddressInfo({
                stateName: this.content.corporateCustomerUIModel.stateName,
                cityName: this.content.corporateCustomerUIModel.cityName,
                townZone: this.content.corporateCustomerUIModel.townZone,
                streetName: this.content.corporateCustomerUIModel.streetName,
                telephone:telephone
            });
        }
    },

    methods: {

        initSubComponents: function() {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("popup-label", PopupLabel);
            Vue.component("attachment-union", AttachmentUnion);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        /**
         * @Overwrite: Get document type for each edit controller
         */
        getDocumentType: function () {
            return DocumentConstants.DummyDocumentType.CorporateCustomer;
        },

        getServiceManager: function () {
            return CorporateCustomerManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "CorporateCustomerEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.corporateCustomerUIModel.uuid;
        },

        /**
         * @Overwrite: get document status from content
         */
        getStatus: function () {
            return this.content.corporateCustomerUIModel.status;
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        initParsleyConfigure: function() {
            var vm = this;
            ServiceParselyMessageHelper.initParsleyConfigureWrapper({
                labelObj: vm.label
            });
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        updateAddressInfo: function (oSettings) {
            var vm = this;
            var address = ServiceUtilityHelper.buildAddressInfo(oSettings);
            if(!vm.addressInfoInit){
                vm.$set(vm.content.corporateCustomerUIModel, 'address', address);
            }
        },

        initTagsInput: function(){
            "use strict";
            $('#x_tags').tagsinput({
                width:'120px'
            });
        },

        initSelectConfig: function(){
            var vm = this;
            $(vm.eleCityName).on('typeahead:selected', function(evt, item) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.corporateCustomerUIModel, 'refCityUUID', item.id);
                vm.$set(vm.content.corporateCustomerUIModel, 'cityName', item.text);
            });
            $(vm.eleCustomerLevel).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.corporateCustomerUIModel, 'customerLevel', $(vm.eleCustomerLevel).val());
            });
        },

        getCustomerLevel: function (content) {
            var vm = this;
            this.$http.get(this.getCustomerLevelMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                    return;
                }
                var customerLevelArray = JSON.parse(response.body).content;
                var _formatCustomerLevel = ServiceUtilityHelper.genTemplateFormatFunction(customerLevelArray);
                var resultList = formatSelectResult(customerLevelArray, 'id', 'name');

                setTimeout(function () {
                    $(vm.eleCustomerLevel).select2({
                        data: resultList,
                        templateResult: _formatCustomerLevel,
                        templateSelection: _formatCustomerLevel
                    });
                    // manually set initial value
                    $(vm.eleCustomerLevel).val(content.corporateCustomerUIModel.customerLevel);
                    $(vm.eleCustomerLevel).trigger("change");
                }, 0);
            });
        },

        loadCitySelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadCitySelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleCityName).typeahead({
                        hint: true,
                        highlight: true,
                        minLength: 0
                    }, {
                        name: 'contacters',
                        displayKey: 'text',
                        source: subModelMatcher(resultList, 'text'),
                        limit: 10 /* Specify max number of suggestions to be displayed */
                    });
                }, 0);
            });

        },

        editCorporateContactPersonModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.corporateContactPersonUIModelList);
            if (!item) {
                return;
            }
            $("#x_contatctPosition").tagsinput("add",item.contactPosition);
            this.cache.corporateContactPerson = this.copyCorporateContactPerson(item);
            $(this.eleEditCorporateContactPersonModal).modal('toggle');
        },

        editIndividualCustomer:function(uuid){
            var vm = this;
            window.location.href = genCommonEditURL("IndividualCustomerEditor.html", uuid);
        },

        setToCorporateContactPerson: function () {
            var item = this._filterItemByUUID(this.cache.corporateContactPerson.uuid, this.content.corporateContactPersonUIModelList);
            if (!item) {
                var newItem = this.copyCorporateContactPerson(this.cache.corporateContactPerson);
                this.content.corporateContactPersonUIModelList.push(newItem);
            } else {
                this.copyCorporateContactPerson(this.cache.corporateContactPerson, item);
            }
            $(this.eleEditCorporateContactPersonModal).modal('hide');
        },

        newCorporateContactPersonModal: function () {
            var baseUUID = this.content.corporateCustomerUIModel.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);

            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:vm.newCorporateContactPersonServiceURL,
                $http:vm.$http,
                method:'post',
                requestData: requestData,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    vm.cache.corporateContactPerson = vm.copyCorporateContactPerson(oData.content, vm.cache.corporateContactPerson);
                    $(vm.eleEditCorporateContactPersonModal).modal('toggle');
                }.bind(this)
            });

        },

        addCorporateContactPerson: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "CorporateContactPersonEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        editCorporateContactPerson: function () {
            var vm = this;
            window.location.href = genCommonEditURL("CorporateContactPersonEditor.html", uuid);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nCommonReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nContactPersonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.corporateContactPerson, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'CorporateCustomer',
                    callback: this.setNodeI18nPropertiesCore
                },{
                    name: 'CorporateContactPerson',
                    callback: this.setI18nContactPersonProperties
                }]
            });
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if (processMode * 1 === PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                baseUUID = getUrlVar("uuid");
                var requestData = generateServiceSimpleContentUnion(baseUUID);

                ServiceUtilityHelper.httpRequest({
                    url:vm.newModuleServiceURL,
                    $http:vm.$http,
                    method:'post',
                    requestData: requestData,
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        vm.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if (processMode * 1 === PROCESSMODE_EDIT) {
                // In case [Edit mode]
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    initAuthor: function(author){vm.$set(vm, 'author', author);},
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }

        },

        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }
        },

        deleteCoporateContact: function (uuid) {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.corporateContactPersonUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, vm.content.corporateContactPersonUIModelList);
                    } else {
                        // do nothing, just return
                    }
                });
        },

        copyCorporateContactPerson: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refUUID = origin.refUUID;
            target.mobile = origin.mobile;
            target.weixinId = origin.weixinId;
            target.email = origin.email;
            target.contactRole = origin.contactRole;
            target.contactPosition = origin.contactPosition;
            target.contactPositionNote = origin.contactPositionNote;
            target.contactRoleNote = origin.contactRoleNote;
            target.note = origin.note;
            target.address = origin.address;
            return target;

        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            vm.content.corporateCustomerUIModel.tags = $('#x_tags').val();
            this.saveModuleCore();
        },

        saveModuleCore: function(){
            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:vm.saveModuleURL,
                $http:vm.$http,
                method:'post',
                requestData: vm.content,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    $.Notification.notify('success', 'top center', vm.label.msgSaveOK, vm.label.msgSaveOKComment);
                    vm.setModuleToUI(oData.content);
                    var processMode = getUrlVar(LABEL_PROCESSMODE);
                    if (processMode && processMode * 1 === PROCESSMODE_NEW) {
                        var baseUUID = vm.content.corporateCustomerUIModel.uuid;
                        if (baseUUID) {
                            window.location.href = genCommonEditURL("CorporateCustomerEditor.html", baseUUID);
                        }
                    }
                }.bind(this)
            });
        },


        refreshEditView: function (tabKey) {
            var baseUUID = this.content.corporateCustomerUIModel.uuid;
            window.location.href = genCommonEditURL("CorporateCustomerEditor.html", baseUUID, tabKey);
        },



        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.corporateCustomerUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);

        },

        setModuleToUI: function (content) {
            var vm = this;
            if(content.corporateCustomerUIModel.address){
                vm.$set(vm, 'addressInfoInit', true);
            }
            ServiceUtilityHelper.switchToTab();
            vm.$set(vm.content, 'corporateCustomerUIModel', content.corporateCustomerUIModel);
            vm.$set(vm.content, 'corporateContactPersonUIModelList', content.corporateContactPersonUIModelList);
            vm.$set(vm.content, 'corporateCustomerAttachmentUIModelList', content.corporateCustomerAttachmentUIModelList);
            setTimeout(function () {
                vm.contactpersonTable.build();
            }, 0);
            vm.getCustomerLevel(content);
            bindingTagsInput($('#x_tags'), content.corporateCustomerUIModel.tags);
            vm.loadCitySelectList(content);
        }

    }
});
