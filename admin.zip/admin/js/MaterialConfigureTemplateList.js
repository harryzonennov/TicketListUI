var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        processButtonMeta:[],
        author:{
            resourceId:ServiceModuleConstants.MaterialConfigureTemplate,
            actionCode:{
                Edit:false,
                View:false,
                Excel: false,
                Delete: false
            }
        },
        searchModuleURL: '../materialConfigureTemplate/searchModuleService.html'
    },

    created: function(){
        this.initAuthorResourceCheck();
        this.initSubComponents();
    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    formatClass: vm.displayForEdit,
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },


        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        searchModule: function () {
            listVar.searchModuleList();
        },

        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "MaterialConfigureTemplateEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});

var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            id: "",
            name: "",
        },

        label: MaterialConfigureTemplateManager.label.materialConfigureTemplate,
        getValueUsageURL: '../matDecisionValueSetting/getValueUsage.html',
        getFieldNameURL: '../matConfigHeaderCondition/getFieldName.html',
        getRefNodeInstIdURL: '../matConfigHeaderCondition/getRefNodeInstId.html',
        getLogicOperatorURL: '../matConfigHeaderCondition/getLogicOperator.html',
        getFieldTypeURL: '../matConfigExtPropertySetting/getFieldType.html'

    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
        });
    },

    methods: {}
});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: MaterialConfigureTemplateManager.label.materialConfigureTemplate,
        items: [],
        loadModuleListURL: '../materialConfigureTemplate/loadModuleListService.html',
        preLockURL: '../materialConfigureTemplate/preLockService.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
        this.setI18nProperties(processModel.initProcessButtonMeta);
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'MaterialConfigureTemplate');
            this.loadModuleList();
        });
    },
    methods: {

        initSubComponents: function(){
            "use strict";
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'MaterialConfigureTemplate',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        searchModuleList: function () {
            this.$refs.dataTableFrame.searchModuleList();
        },

        buildSearchData: function (data) {
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../materialConfigureTemplate/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'id',
                labelKey: 'id',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.MaterialConfigureTemplate,
                    uuidFieldName: 'uuid'
                }
            }, {
                fieldName: 'name',
                labelKey: 'name',
                minWidth: '180px'
            }];
            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        },

        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid: uuid,
                $http: vm.$http,
                author: processModel.author,
                editorPage: "MaterialConfigureTemplateEditor.html",
                preLockURL: vm.preLockURL,
                errorHandle: vm.errorHandle,
                lockFailureHandle: function (oData) {
                    swal(this.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        preLock: function () {
        }
    }
});
