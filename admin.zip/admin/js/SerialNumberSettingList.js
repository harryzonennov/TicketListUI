var processModel = new Vue({
    el: "#x_process_model",
    data: {
        label: {
            add: '',
            search: ''
        },
        processButtonMeta:[],
        author: {
            resourceId: ServiceModuleConstants.SerialNumberSetting,
            actionCode: {
                Edit: false,
                View: false,
                PriceInfo: false,
                Delete: false,
                Excel: false
            }
        },
        searchModuleURL: '../serialNumberSetting/searchModuleService.html'
    },


    created: function(){
        var vm = this;
        vm.initAuthorResourceCheck();
        vm.initSubComponents();
    },

    methods: {

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                search: {
                    callback: vm.searchModule
                },
                newModule: {
                    callback: vm.newModule
                }
            };
            vm.$set(vm, 'processButtonMeta', processButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        searchModule: function () {
            var vm = this;
            var requestData = searchModel.content;
            this.$http.post(vm.searchModuleURL, requestData).then(function (response) {
                listVar.refreshTableItems(JSON.parse(response.data).content);
            });
        },
        newModule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            var resultURL = "SerialNumberSettingEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },
        newModuleModal: function () {
            listVar.newModuleModal();
        }
    }
});

var searchModel = new Vue({
    el: "#x_data_search",
    data: {
        content: {
            category: "",
            name: "",
            id: "",
            systemStandardCategory: "",
            switchFlag: ""
        },

        label: SerialNumberSettingManager.label.serialNumberSetting,
        eleCategory: '#x_category',
        eleSystemStandardCategory: '#x_systemStandardCategory',
        eleSwitchFlag: '#x_switchFlag',
        getCategoryURL: '../serialNumberSetting/getCategoryMap.html',
        getSystemStandardCategoryURL: '../serialNumberSetting/getSystemStandardCategory.html',
        getSwitchFlagURL: '../serialNumberSetting/getSwitchFlagMap.html'

    },
    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.initSelectConfigure();
            vm.getCategoryMap();
            vm.getSystemStandardCategory();
            vm.getSwitchFlagMap();
        });
    },
    methods: {
        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'category', $(vm.eleCategory).val());
            });

            $(vm.eleSwitchFlag).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'switchFlag', $(vm.eleSwitchFlag).val());
            });

            $(vm.eleSystemStandardCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'systemStandardCategory', $(vm.eleSystemStandardCategory).val());
            });
        },


        getCategoryMap: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getCategoryURL,
                $http: vm.$http,
                formatMeta:SystemStandrdMetadataProxy.formatDefaultSystemCategory,
                addEmptyFlag: true,
                initValue: vm.content.category,
                element: vm.eleCategory,
                errorHandle: listVar.errorHandle
            });
        },


        getSystemStandardCategory: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getSystemStandardCategoryURL,
                $http: vm.$http,
                formatMeta:SystemStandrdMetadataProxy.formatDefaultSystemCategory,
                addEmptyFlag: true,
                initValue: vm.content.systemStandardCategory,
                element: vm.eleSystemStandardCategory,
                errorHandle: listVar.errorHandle
            });
        },


        getSwitchFlagMap: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getSwitchFlagURL,
                $http: vm.$http,
                formatMeta:SystemStandrdMetadataProxy.formatDefaultSwitchCode,
                addEmptyFlag: true,
                initValue: vm.content.switchFlag,
                element: vm.eleSwitchFlag,
                errorHandle: listVar.errorHandle
            });
        }
    }
});
var listVar = new Vue({
    el: "#x_data_List",
    data: {
        label: SerialNumberSettingManager.label.serialNumberSetting,
        cache: {
            uuid: '',
            parentNodeUUID: '',
            rootNodeUUID: '',
            client: '',
            category: '',
            name: '',
            id: '',
            systemStandardCategory: '',
            switchFlag: ''
        },
        tableId: '#x_table_serialNumberSetting',
        datatable: '',
        items: [],
        loadModuleListURL: '../serialNumberSetting/loadModuleListService.html',
        preLockURL: '../serialNumberSetting/preLockService.html',
        newModuleServiceURL: '../serialNumberSetting/newModuleService.html',
        saveModuleURL: '../serialNumberSetting/saveModuleService.html',
        loadModuleEditURL: '../serialNumberSetting/loadModuleEditService.html'

    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
        this.setI18nProperties(processModel.initProcessButtonMeta);
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'SerialNumberSetting');
            // this.datatable = new ServiceDataTable(this.tableId);
            // this.setI18nProperties();
            this.loadModuleList();
        });
    },

    methods: {

        initSubComponents: function(){
            "use strict";
            Vue.component("service-data-table-frame", ServiceDataTableFrame);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
            $("#x_clearSearch").tooltip({title: searchModel.label.clearSearchComment});
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(processModel.label, $.i18n.prop, true);
            ServiceUtilityHelper.setI18nReflective(searchModel.label, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "foundation/systemResource/",
                commonCallback: vm.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'SerialNumberSetting',
                    callback: vm.setNodeI18nPropertiesCore
                }]
            });
        },

        searchModuleList: function () {
            this.$refs.dataTableFrame.searchModuleList();
        },

        buildSearchData: function (data) {
            data.content = searchModel.content;
            return JSON.stringify(data);
        },

        loadModuleList: function () {
            var vm = this;
            var oSettings = {
                editModule: vm.editModule,
                buildSearchData: vm.buildSearchData,
                scrollX: true,
                label: vm.label,
                busyLoader: vm.$refs.refBusyLoader,
                errorHandle: vm.errorHandle,
                url: '../serialNumberSetting/searchTableService.html'
            };

            var fieldMetaList = [{
                fieldName: 'uuid',
            }, {
                fieldName: 'id',
                labelKey: 'id',
                minWidth: '180px',
                docPopConfig: {
                    documentType: DocumentConstants.DummyDocumentType.SerialNumberSetting,
                    uuidFieldName: 'uuid'
                }
            }, {
                fieldName: 'name',
                labelKey: 'name',
                minWidth: '180px'
            },{
                fieldName: 'categoryValue',
                labelKey: 'category',
                minWidth: '180px'
            },{
                fieldName: 'systemStandardCategoryValue',
                labelKey: 'systemStandardCategory',
                iconArray: SystemStandrdMetadataProxy.getDefaultSystemCategoryIconArray(),
                minWidth: '180px'
            },{
                fieldName: 'systemStandardCategoryValue',
                labelKey: 'systemStandardCategory',
                iconArray: SystemStandrdMetadataProxy.getDefaultSwitchIconArray(),
                minWidth: '180px'
            }];
            oSettings['fieldMetaList'] = fieldMetaList;
            vm.$refs.dataTableFrame.loadModuleList(oSettings);
        },

        formatSwitchClass: function(itemSwitch){
            return SystemStandrdMetadataProxy.formatSwitchClass(itemSwitch);
        },

        editModule: function (uuid) {
            var vm = this;
            ServiceUtilityHelper.navigateToEditModule({
                uuid:uuid,
                $http:vm.$http,
                author:processModel.author,
                editorPage:"SerialNumberSettingEditor.html",
                errorHandle: vm.errorHandle,
                lockFailureHandle: function(oData){
                    swal(vm.label.lockFailureMessage, oData.MSG);
                }
            });
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        formatSystemCategoryClass: function(systemCategory){
            return SystemStandrdMetadataProxy.formatSystemCategoryClass(systemCategory);
        },


        preLock: function () {
        }
    }
});
