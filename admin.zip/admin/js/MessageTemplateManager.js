/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var MessageTemplateManager = function () {

};

MessageTemplateManager.label = {
    messageTemplate:{
        id: '',
        name: '',
        searchDataUrl: '',
        processIndex: '',
        handlerClass: '',
        searchModelName:'',
        searchModelLabel:'',
        searchModelClass: '',
        note: '',
        modelTitle:'',
        addMessageTemplate: '',
        searchProxyName:'',
        searchProxyLabel:'',
        addMessageTempSearchCondition: '',
        addMessageTempPrioritySetting: '',
        messageTempPrioritySection: '',
        messageTemplateSection: '',
        messageTempSearchConditionSection: '',
        systemCodeValueCollectionSection: '',
        messageTitle:'',
        messageContent:'',
        msgSaveOK: '',
        navigationSourceId:'',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        quickEdit: '',
        buttonDelete: '',
        exit: '',
        close: '',
        tab1Title:'',
        tab2Title:'',
        deleteWarnTitle: '',
        deleteWarnText: '',
        cancel: '',
        commit: '',
        confirm: '',
        fieldName: '',
        logicOperator: '',
        searchOperator: '',
        fieldValue: '',
        iconStyle: '',
        colorStyle: '',
        priorityCode: '',
        collectionCategory: '',
        advancedSearchCondition: '',
        buttonEdit: '',
        buttonView: ''
    },
    messageTempPrioritySetting: {
        refPrioritySettingUUID: '',
        messageLevelCode:'',
        messageTitle:'',
        messageContent:'',
        fieldName:'',
        fieldValue:'',
        dataSourceProviderId:'',
        iconStyle: '',
        endValue: '',
        colorStyle: '',
        startValue: '',
        priorityCode: '',
        actionCode:'',
        logicOperator: '',
        searchOperator: '',
        note: '',
        tab1Title:'',
        tab2Title:'',
        addMessageTempPrioritySetting: '',
        addSystemCodeValueCollection: '',
        parentPageTitle:'',
        dataOffsetUnit:'',
        dataOffsetValue:'',
        dataOffsetDirection:'',
        pageTitle:'',
        messageTempPrioritySettingSection: '',
        systemCodeValueCollectionSection: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        quickEdit: '',
        buttonDelete: '',
        exit: '',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        cancel: '',
        commit: '',
        confirm: ''
    },
    messageTempSearchCondition: {
        dataSourceProviderId:'',
        dataOffsetValue:'',
        dataOffsetDirection:'',
        addMessageTempSearchCondition: '',
        parentPageTitle:'',
        pageTitle:'',
        messageTempSearchConditionSection: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        exit: '',
        quickEdit: '',
        buttonDelete: '',
        tab1Title:'',
        tab2Title:'',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        cancel: '',
        commit: '',
        confirm: '',
        fieldName: '',
        logicOperator: '',
        searchOperator: '',
        fieldValue: '',
        note: ''
    }
};


MessageTemplateManager.labelTemplate = {
    data: function() {
        return {
            label: {
                "messageTempSearchCondition": MessageTemplateManager.label.messageTempSearchCondition,
                "messageTempPrioritySetting":MessageTemplateManager.label.messageTempPrioritySetting,
            }
        };
    }
};


MessageTemplateManager.prototype.getModelTitle = function(){
    return MessageTemplateManager.label.messageTemplate.modelTitle;
};

/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
MessageTemplateManager.prototype.getI18nWrap = function (fnCallback) {
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "coreFunction/",
        fnCallback: fnCallback,
        commonCallback: MessageTemplateManager.setI18nCommonProperties,
        configList: [{
            name: 'MessageTemplate',
            callback: MessageTemplateManager.setNodeI18nPropertiesCore
        },{
            name: 'MessageTempPrioritySetting',
            callback: MessageTemplateManager.setI18nPrioritySettingProperties
        },{
            name: 'MessageTempSearchCondition',
            callback: MessageTemplateManager.setI18nSearchConditionProperties
        }]
    });
};


MessageTemplateManager.setI18nCommonProperties = function () {
    ServiceUtilityHelper.setI18nCommonReflective(MessageTemplateManager.label.messageTemplate, $.i18n.prop);
};

MessageTemplateManager.setNodeI18nPropertiesCore = function () {
    ServiceUtilityHelper.setI18nReflective(MessageTemplateManager.label.messageTemplate, $.i18n.prop, true);
};

MessageTemplateManager.setI18nPrioritySettingProperties = function () {
    ServiceUtilityHelper.setI18nReflective(MessageTemplateManager.label.messageTempPrioritySetting, $.i18n.prop, true);
};

MessageTemplateManager.setI18nSearchConditionProperties = function () {
    ServiceUtilityHelper.setI18nReflective(MessageTemplateManager.label.messageTempSearchCondition, $.i18n.prop, true);
};


/**
 * Definition of Tab on UI
 * @type {{}}
 */
MessageTemplateManager.documentTab = {
    materialSection:'tabMaterialSection',
    materialUnitSection: 'tabMaterialUnitSection'
};


/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
MessageTemplateManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../messageTemplate/loadModuleViewService.html';
};

/**
 * @override Get Basic URL for load document list.
 * @returns {string}
 */
MessageTemplateManager.prototype.getLoadSelectListURL = function () {
    "use strict";
    return '../messageTemplate/loadModuleListService.html';
};


MessageTemplateManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: "MessageTemplateEditor.html",
        url: "../messageTemplate/loadModuleViewService.html",
        label:MessageTemplateManager.label,
        getI18nWrap:this.getI18nWrap.bind(vm)
    });

    var fieldMetaList = [{
        fieldName:'messageTemplateUIModel.id',
        labelKey:'messageTemplate.id'
    },{
        fieldName:'messageTemplateUIModel.name',
        labelKey:'messageTemplate.name'
    },{
        fieldName:'messageTemplateUIModel.messageTitle',
        labelKey:'messageTemplate.messageTitle'
    },{
        fieldName: 'messageTemplateUIModel.messageContent',
        labelKey:'messageTemplate.messageContent'
    },{
        listSubPath:'messageTempPrioritySettingUIModelList',
        fieldName:'messageLevelCodeValue',
        labelKey:'messageTempPrioritySetting.messageLevelCode',
        fieldKey: 'messageLevelCode',
        listValueStragety:DocumentOrderMatPopInfo.ListItemStragegy.FIRST_MULTI_ITEM,
        listFirstNum:3,
        iconArray: MessageTempPriorityManager.getMessageLevelCodeIconArray()
    },{
        listSubPath:'messageTempPrioritySettingUIModelList',
        fieldName:'messageTitle',
        labelKey:'messageTempPrioritySetting.messageTitle'
    },{
        fieldName: 'messageTemplateUIModel.searchModelName',
        labelKey:'messageTemplate.searchModelName'
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};


