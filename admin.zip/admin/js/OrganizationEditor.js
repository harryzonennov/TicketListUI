var dataVar = new Vue({
    el: "#x_data",
    mixins: [OrganizationManager.labelTemplate],
    data: {
        basicsettingTableId: '#x_table_basicsetting',
        basicsettingTable: {},
        logonUserOrgTableId: '#x_table_logonUserOrg',
        logonUserOrgTable: {},
        label: OrganizationManager.label.organization,
        content: {
            organizationUIModel: {
                uuid: '',
                client: '',
                organType: '',
                organLevel: '',
                refFinOrgUUID: '',
                id: '',
                regularType: '',
                name: '',
                contactTelephone: '',
                contactPerson: '',
                contactMobileNumber: '',
                fax: '',
                addressInfo: '',
                organizationFunction: '',
                note: '',
                cityName: '',
                streetName: '',
                townZone: '',
                refOrganizationFunction: '',
                organizationFunctionName: '',
                refAccountantUUID: '',
                accountantName: '',
                mainContactUUID: '',
                mainContactName: '',
                refCashierUUID: ''
            },
            logonUserOrganizationUIModelList: []
        },
        cache: {
            organizationBarcodeBasicSetting: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refOrganizationUUID: '',
                id: '',
                name: '',
                ean13CompanyCode: '',
                ean13CountryHead: '',
                note: ''
            }
        },
        author:{
            resourceId:'Organization',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        processButtonMeta:[],
        eleOrganType: '#x_organType',
        eleOrganLevel: '#x_organLevel',
        eleRefFinOrgUUID: '#x_refFinOrgUUID',
        eleParentOrganizationUUID: '#x_parentOrganizationUUID',
        eleRegularType: '#x_regularType',
        eleAccountType: '#x_accountType',
        eleRefOrganizationFunction: '#x_refOrganizationFunction',
        eleRefAccountantUUID: '#x_refAccountantUUID',
        eleMainContactUUID: '#x_mainContactUUID',
        eleRefCashierUUID: '#x_refCashierUUID',
        eleOrganizationFunction:'#x_organizationFunction',
        loadModuleEditURL: '../organization/loadModuleEditService.html',
        loadModuleViewURL: '../organization/loadModuleViewService.html',
        saveModuleURL: '../organization/saveModuleService.html',
        newModuleServiceURL: '../organization/newModuleFromParentService.html',
        newOrganizationBarcodeBasicSettingServiceURL: '../organizationBarcodeBasicSetting/newModuleService.html',
        eleEditOrganizationBarcodeBasicSettingModal: '#x_eleEditOrganizationBarcodeBasicSettingModal',
        getOrganTypeURL: '../organization/getOrganType.html',
        getOrganLevelURL: '../organization/getOrganLevel.html',
        getOrganizationFunctionMapURL: '../organization/getOrganizationFunctionMap.html',
        loadOrganizationSelectListURL: '../organization/loadModuleListService.html',
        getRegularTypeURL: '../organization/getRegularType.html',
        getAccountTypeURL: '../organization/getAccountType.html',
        loadEmployeeSelectListURL: '../employee/loadLeanModuleListService.html',
        loadOrganizationURL: '../Organization/loadModule.html',
        loadOrganizationFunctionURL: '../organizationFunction/loadModule.html',
        loadEmployeeURL: '../employee/loadModule.html',
        exitURL: 'OrganizationList.html',
        exitModuleURL: '../organization/exitEditor.html'
    },

    created: function(){
        "use strict";
        var vm = this;
        vm.initAuthorResourceCheck();
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'Organization');
            this.logonUserOrgTable = new ServiceDataTable(this.logonUserOrgTableId);
            this.setI18nProperties(vm.initProcessButtonMeta);
            this.loadModuleEdit();
            this.basicsettingTable = new ServiceDataTable(this.basicsettingTableId);
            this.initSelectConfigure();
        });
    },

    watch: {
        'content.organizationUIModel.cityName': function (cityName) {
            this.updateAddressInfo({
                cityName: cityName,
                townZone: this.content.organizationUIModel.townZone,
                streetName: this.content.organizationUIModel.streetName,
                telephone:this.content.organizationUIModel.contactTelephone
            });
        },
        'content.organizationUIModel.townZone': function (townZone) {
            this.updateAddressInfo({
                cityName: this.content.organizationUIModel.cityName,
                townZone: townZone,
                streetName: this.content.organizationUIModel.streetName,
                telephone:this.content.organizationUIModel.contactTelephone
            });
        },
        'content.organizationUIModel.streetName': function (streetName) {
            this.updateAddressInfo({
                cityName: this.content.organizationUIModel.cityName,
                townZone: this.content.organizationUIModel.townZone,
                streetName: streetName,
                telephone:this.content.organizationUIModel.contactTelephone
            });
        },
        'content.organizationUIModel.contactTelephone': function (streetName) {
            this.updateAddressInfo({
                cityName: this.content.organizationUIModel.cityName,
                townZone: this.content.organizationUIModel.townZone,
                streetName: streetName,
                telephone:this.content.organizationUIModel.contactTelephone
            });
        }
    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function (){
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray:processButtonMeta
            });
        },

        displayForExcel: function(){
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Excel === true ? true: undefined);
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        updateAddressInfo: function (oSettings) {
            var vm = this;
            var addressInfo = ServiceUtilityHelper.buildAddressInfo(oSettings);
            vm.$set(vm.content.organizationUIModel, 'addressInfo', addressInfo);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nBasicSettingProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.organizationBarcodeBasicSetting, $.i18n.prop, true);
        },

        setI18nLogonOrgProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.logonUserOrg, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: '/foundation/common/',
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'Organization',
                    callback: this.setNodeI18nPropertiesCore
                }, {
                    name: 'LogonUserOrg',
                    callback: this.setI18nLogonOrgProperties
                }]
            });
        },


        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleRefFinOrgUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.organizationUIModel, 'refFinOrgUUID', $(vm.eleRefFinOrgUUID).val());
                var url = vm.loadOrganizationURL + "?uuid=" + $(vm.eleRefFinOrgUUID).val();

                ServiceUtilityHelper.httpRequest({
                    url:vm.loadOrganizationURL,
                    $http:vm.$http,
                    uuid:$(vm.eleRefFinOrgUUID).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                        vm.$set(vm.content.organizationUIModel, 'refFinOrgName', content.name);
                        vm.$set(vm.content.organizationUIModel, 'refFinOrgId', content.id);
                    }.bind(this)
                });
            });
            $(vm.eleParentOrganizationUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.organizationUIModel, 'parentOrganizationUUID', $(vm.eleParentOrganizationUUID).val());
                var url = vm.loadOrganizationURL + "?uuid=" + $(vm.eleParentOrganizationUUID).val();

                ServiceUtilityHelper.httpRequest({
                    url:vm.loadOrganizationURL,
                    $http:vm.$http,
                    uuid:$(vm.eleParentOrganizationUUID).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                        vm.$set(vm.content.organizationUIModel, 'parentOrganizationName', content.name);
                        vm.$set(vm.content.organizationUIModel, 'parentOrganizationId', content.id);
                    }.bind(this)
                });
            });
            $(vm.eleRefOrganizationFunction).on("select2:close", function (e) {
                ServiceUtilityHelper.httpRequest({
                    url:vm.loadOrganizationFunctionURL,
                    $http:vm.$http,
                    uuid:$(vm.eleRefOrganizationFunction).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                        vm.$set(vm.content, 'organizationFunctionName', content.name);
                        vm.$set(vm.content, 'organizationFunctionNote', content.note);
                    }.bind(this)
                });
            });
            $(vm.eleRefAccountantUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.organizationUIModel, 'refAccountantUUID', $(vm.eleRefAccountantUUID).val());
                var url = vm.loadEmployeeURL + "?uuid=" + $(vm.eleRefAccountantUUID).val();
                ServiceUtilityHelper.httpRequest({
                    url:vm.loadEmployeeURL,
                    $http:vm.$http,
                    uuid:$(vm.eleRefAccountantUUID).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                        // vm.$set(vm.content, 'organizationFunctionName', content.name);
                        // vm.$set(vm.content, 'organizationFunctionNote', content.note);
                    }.bind(this)
                });
            });
            $(vm.eleMainContactUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.organizationUIModel, 'mainContactUUID', $(vm.eleMainContactUUID).val());
                var url = vm.loadEmployeeURL + "?uuid=" + $(vm.eleMainContactUUID).val();
                ServiceUtilityHelper.httpRequest({
                    url:vm.loadEmployeeURL,
                    $http:vm.$http,
                    uuid:$(vm.eleMainContactUUID).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                    }.bind(this)
                });
            });
            $(vm.eleRefCashierUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.organizationUIModel, 'refCashierUUID', $(vm.eleRefCashierUUID).val());
                var url = vm.loadEmployeeURL + "?uuid=" + $(vm.eleRefCashierUUID).val();
                ServiceUtilityHelper.httpRequest({
                    url:vm.loadEmployeeURL,
                    $http:vm.$http,
                    uuid:$(vm.eleRefCashierUUID).val(),
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        var content = oData.content;
                    }.bind(this)
                });
            });

            $(vm.eleOrganizationFunction).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.organizationUIModel, 'organizationFunction', $(vm.eleOrganizationFunction).val());
            });

        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if (processMode * 1 === PROCESSMODE_NEW) {
                ServiceUtilityHelper.newModuleDefault({
                    newModuleServiceURL: vm.newModuleServiceURL,
                    vm:vm,
                    errorHandle:vm.errorHandle,
                    postSet:vm.setModuleToUI
                });
            }
            if (processMode * 1 === PROCESSMODE_EDIT) {
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    initAuthor: function(author){vm.$set(vm, 'author', author);},
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }


        },

        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }

        },

        copyOrganizationBarcodeBasicSetting: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refOrganizationUUID = origin.refOrganizationUUID;
            target.ean13CompanyCode = origin.ean13CompanyCode;
            target.ean13CountryHead = origin.ean13CountryHead;
            target.note = origin.note;
            return target;

        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }

            ServiceUtilityHelper.httpRequest({
                url:this.saveModuleURL,
                $http:vm.$http,
                method:'post',
                requestData: vm.content,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                    this.setModuleToUI(oData.content);
                    var processMode = getUrlVar(LABEL_PROCESSMODE);
                    if (processMode && processMode * 1 === PROCESSMODE_NEW) {
                        var baseUUID = vm.content.organizationUIModel.uuid;
                        if (baseUUID) {
                            window.location.href = genCommonEditURL("OrganizationEditor.html", baseUUID);
                        }
                    }
                }.bind(this)
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.organizationUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);

        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.organizationUIModel.uuid;
            window.location.href = genCommonEditURL("OrganizationEditor.html", baseUUID, tabKey);

        },

        getOrganType: function (content) {
            var vm = this;
            this.$http.get(this.getOrganTypeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleOrganType).select2({
                        data: JSON.parse(response.body)
                    });
                    // manually set initial value
                    $(vm.eleOrganType).val(content.organizationUIModel.organType);
                    $(vm.eleOrganType).trigger("change");
                }, 0);
            });
        },

        getOrganizationFunction: function (content) {
            var vm = this;
            ServiceUtilityHelper.loadMetaWithCustomReq({
                url: OrganizationManager.Constants.getOrganizationFunctionMapURL,
                $http: vm.$http,
                formatMeta:SystemStandrdMetadataProxy.formatLogicOperator,
                initValue: vm.content.organizationUIModel.organizationFunction,
                idField:'id',
                textField:'name',
                element: vm.eleOrganizationFunction,
                errorHandle: vm.errorHandle
            });
        },

        editLogonUserOrgModal: function(){
            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:'../organization/submitFlow.html',
                $http:vm.$http,
                method:'post',
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                    this.setModuleToUI(oData.content);
                    var processMode = getUrlVar(LABEL_PROCESSMODE);
                    if (processMode && processMode * 1 === PROCESSMODE_NEW) {
                        var baseUUID = vm.content.organizationUIModel.uuid;
                        if (baseUUID) {
                            window.location.href = genCommonEditURL("OrganizationEditor.html", baseUUID);
                        }
                    }
                }.bind(this)
            });
        },

        getOrganLevel: function (content) {
            var vm = this;
            this.$http.get(this.getOrganLevelURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleOrganLevel).select2({
                        data: JSON.parse(response.body)
                    })
                    // manually set initial value
                    $(vm.eleOrganLevel).val(content.organizationUIModel.organLevel);
                    $(vm.eleOrganLevel).trigger("change");
                }, 0);
            });

        },

        loadRefFinSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadOrganizationSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleRefFinOrgUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefFinOrgUUID).val(content.organizationUIModel.refFinOrgUUID);
                    $(vm.eleRefFinOrgUUID).trigger("change");
                }, 0);
            });
        },

        loadParentOrgSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadOrganizationSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleParentOrganizationUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleParentOrganizationUUID).val(content.organizationUIModel.parentOrganizationUUID);
                    $(vm.eleParentOrganizationUUID).trigger("change");
                }, 0);
            });
        },

        getRegularType: function (content) {
            var vm = this;
            this.$http.get(this.getRegularTypeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleRegularType).select2({
                        data: JSON.parse(response.body)
                    })
                    // manually set initial value
                    $(vm.eleRegularType).val(content.organizationUIModel.regularType);
                    $(vm.eleRegularType).trigger("change");
                }, 0);
            });

        },

        getAccountType: function (content) {
            var vm = this;
            this.$http.get(this.getAccountTypeURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                setTimeout(function () {
                    $(vm.eleAccountType).select2({
                        data: JSON.parse(response.body)
                    })
                    // manually set initial value
                    $(vm.eleAccountType).val(content.organizationUIModel.accountType);
                    $(vm.eleAccountType).trigger("change");
                }, 0);
            });

        },

        loadOrganizationFunctionSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadOrganizationFunctionSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleRefOrganizationFunction).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefOrganizationFunction).val(content.organizationUIModel.refOrganizationFunction);
                    $(vm.eleRefOrganizationFunction).trigger("change");
                }, 0);
            });

        },

        loadAccountantSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadEmployeeSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleRefAccountantUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefAccountantUUID).val(content.organizationUIModel.refAccountantUUID);
                    $(vm.eleRefAccountantUUID).trigger("change");
                }, 0);
            });

        },

        loadMainContactSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadEmployeeSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleMainContactUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleMainContactUUID).val(content.organizationUIModel.mainContactUUID);
                    $(vm.eleMainContactUUID).trigger("change");
                }, 0);
            });

        },

        loadCashierSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadEmployeeSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleRefCashierUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefCashierUUID).val(content.organizationUIModel.refCashierUUID);
                    $(vm.eleRefCashierUUID).trigger("change");
                }, 0);
            });

        },

        refreshTableItem: function(){
            var vm = this;
            setTimeout(function () {
                vm.logonUserOrgTable.buildWithCache({
                    "pageLength": 10
                });
            }, 0);
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'organizationUIModel', content.organizationUIModel);
            vm.$set(vm.content, 'logonUserOrganizationUIModelList', content.logonUserOrganizationUIModelList);
            vm.refreshTableItem();
            vm.loadParentOrgSelectList(content);
            vm.loadRefFinSelectList(content);
            vm.loadAccountantSelectList(content);
            vm.loadMainContactSelectList(content);
            vm.loadCashierSelectList(content);
            vm.getOrganizationFunction(content);
        },

        editOrganizationBarcodeBasicSettingModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.organizationBarcodeBasicSettingUIModelList);
            if (!item) {
                return;
            }
            this.cache.organizationBarcodeBasicSetting = this.copyOrganizationBarcodeBasicSetting(item);
            $(this.eleEditOrganizationBarcodeBasicSettingModal).modal('toggle');

        },

        setToOrganizationBarcodeBasicSetting: function () {
            var item = this._filterItemByUUID(this.cache.organizationBarcodeBasicSetting.uuid, this.content.organizationBarcodeBasicSettingUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copyOrganizationBarcodeBasicSetting(this.cache.organizationBarcodeBasicSetting);
                this.content.organizationBarcodeBasicSettingUIModelList.push(newItem);
            } else {
                this.copyOrganizationBarcodeBasicSetting(this.cache.organizationBarcodeBasicSetting, item);
            }
            $(this.eleEditOrganizationBarcodeBasicSettingModal).modal('hide');
        },

        newOrganizationBarcodeBasicSettingModal: function () {
            var baseUUID = this.content.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);

            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:vm.newOrganizationBarcodeBasicSettingServiceURL,
                $http:vm.$http,
                method:'post',
                requestData: requestData,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    vm.cache.organizationBarcodeBasicSetting = vm.copyOrganizationBarcodeBasicSetting(oData.content, vm.cache.organizationBarcodeBasicSetting);
                    $(vm.eleEditOrganizationBarcodeBasicSettingModal).modal('toggle');
                }.bind(this)
            });

        },

        deleteOrganizationBarcodeBasicSetting: function () {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.organizationBarcodeBasicSettingUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, content.organizationBarcodeBasicSettingUIModelList);
                    } else {
// do nothing, just return
                    }
                });
        },

        addOrganizationBarcodeBasicSetting: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.organizationUIModel.uuid;
            var resultURL = "OrganizationBarcodeBasicSettingEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },

        editOrganizationBarcodeBasicSetting: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            window.location.href = genCommonEditURL("OrganizationBarcodeBasicSettingEditor.html", uuid);

        }

    }
});
