function SystemConfigureManager(){
    this.init();
};

SystemConfigureManager.prototype.init = function(){
    this.systemConfigure = {
        globalSystemSwitches:undefined,
        resources:undefined
    };

    this.URLs = {
        loadModuleListURL: '../systemConfigureCategory/loadModuleListService.html',
        loadModuleEditURL: '../systemConfigureCategory/loadModuleEditService.html'
    };
};

SystemConfigureManager.prototype.getSystemConfigureResource = function(oSettings){
    var sourceId = oSettings.sourceId;
    var categoryId = oSettings.categoryId;
    var systemResources;
    var configureResponse = this.getSystemConfigureResourceCorePromise();
    return new Promise(function(resolve, reject){
        configureResponse.then(function (data) {
            oSettings.resources = data;
            var configureResource =  this.filterResource(oSettings);
            if(configureResource){
                resolve(configureResource);
            }else{
                resolve(undefined);
            }
        }.bind(this));
    }.bind(this));

};

SystemConfigureManager.prototype.getSystemConfigureResourceCorePromise = function(){
    return new Promise(function(resolve, reject){
        if(this.systemConfigure && this.systemConfigure.resources){
            resolve(this.systemConfigure.resources);
        }else{
            $.ajax({
                url: this.URLs.loadModuleListURL,
                type: 'GET',
                beforeSend: function (request) {
                    request.setRequestHeader("Type", "application/json");
                },
                dataType: 'json',
                success: function (response) {
                    if (response.content) {
                        this.buildResourcesFromBackend(response.content, function (result) {
                            resolve(result);
                        });
                    }
                }.bind(this),
                error: function (jqXHR) {
                    reject(jqXHR);
                }
            });
        }
    }.bind(this));
};

SystemConfigureManager.prototype.buildResourcesFromBackend = function(systemCategoryList, fnCallback){
    var i = 0, len = 0, uuid;
    if(systemCategoryList && systemCategoryList.length > 0){
        len = systemCategoryList.length;
        var promises = [];
        for(i = 0; i < len; i++){
           uuid = systemCategoryList[i].uuid;
           if(uuid){
               var coreResourcePromise = new Promise(function(resolve, reject){
                   $.ajax({
                       url: this.URLs.loadModuleEditURL + '?uuid=' + uuid,
                       type: 'GET',
                       beforeSend: function (request) {
                           request.setRequestHeader("Type", "application/json");
                       },
                       dataType: 'json',
                       success: function (response) {
                           if (response.content) {
                               this._pushToArray(response.content);
                               resolve(response.content);
                           }else{
                               reject();
                           }
                       }.bind(this),
                       error: function (jqXHR) {
                           // do nothing
                           reject();
                       }
                   });
               }.bind(this));
               promises.push(coreResourcePromise);
           }
        }
        Promise.all(promises).then(function(results) {
            if(fnCallback){
                fnCallback(this.systemConfigure.resources);
            }
        }.bind(this));
    }
};

SystemConfigureManager.prototype._pushToArray = function(systemConfigureCategoryUIModelServiceUIModel){
    "use strict";
    var existed = ServiceCollectionsHelper.filterArray(systemConfigureCategoryUIModelServiceUIModel.systemConfigureCategoryUIModel.uuid,
      'uuid', this.systemConfigure.resources, 'systemConfigureCategoryUIModel');
    if(!existed){
        if(!this.systemConfigure.resources){
            this.systemConfigure.resources = [];
        }
        this.systemConfigure.resources.push(systemConfigureCategoryUIModelServiceUIModel);
    }
};


SystemConfigureManager.prototype.filterResource = function(oSettings){
    "use strict";
    var systemResources = oSettings.resources, sourceId = oSettings.sourceId, categoryId = oSettings.categoryId, i = 0;
    if(categoryId){
        var systemCategory = this.filterCategory(oSettings);
        if(systemCategory ){
            return this.filterResourceInCategoryCore(systemCategory, sourceId);
        }else{
            // In case categoryId is not correct to find system category

        }
    }else{
        if(systemResources && systemResources.length > 0){
            for(var key in systemResources){
                var tempResult = this.filterResourceInCategoryCore(systemResources[i], sourceId);
                if(tempResult){
                    return tempResult;
                }
            }
        }
    }
};

SystemConfigureManager.prototype.filterResourceInCategoryCore = function(systemCategory, resourceId){
    "use strict";
    if(systemCategory){
        for(var key in systemCategory){
            if(key === resourceId){
                return systemCategory[key];
            }
        }
    }
};

SystemConfigureManager.prototype.filterCategory = function(oSettings){
    "use strict";
    var systemResources = oSettings.resources, categoryId = oSettings.categoryId;
    if(systemResources && systemResources.length > 0){
        var resultCategory = ServiceCollectionsHelper.filterArray(categoryId, 'id', systemResources, 'systemConfigureCategoryUIModel');
        return resultCategory;
    }
};