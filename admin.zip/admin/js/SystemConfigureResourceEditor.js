var dataVar = new Vue({
    el: "#x_data",
    data: {
        extensionunionTableId: '#x_table_extensionunion',
        extensionunionTable: {},
        configureelementTableId: '#x_table_configureelement',
        configureelementTable: {},
        label: {
            id: '',
            scenarioMode: '',
            standardSystemCategory: '',
            name: '',
            note: '',
            parentPageTitle: '',
            pageTitle: '',
            systemConfigureResourceSection: '',
            systemConfigureExtensionUnionSection: '',
            systemConfigureElementSection: '',
            systemConfigureResourceTreeSection: '',

            msgSaveOK: '',
            msgSaveOKComment: '',
            msgConnectFailure: '',
            msgUnknowSystemFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            save: '',
            quickEdit: '',
            buttonDelete: '',
            exit: '',
            close: '',
            deleteWarnTitle: '',
            deleteWarnText: '',
            cancel: '',
            commit: '',
            confirm: '',
            addSystemConfigureResource: '',
            addSystemConfigureExtensionUnion: '',
            addSystemConfigureElement: '',
            systemConfigureCategoryPageTitle:'',
            systemConfigureResourcePageTitle:'',
            systemConfigureElement: {
                id: '',
                name: '',
                standardSystemCategory: '',
                scenarioMode: '',
                elementType: ''
            },
            systemConfigureExtensionUnion: {
                id: '',
                name: '',
                configureValueName: '',
                configureValueId:'',
                configureSwitchProxy: '',
                configureValue: '',
                refCodeValue: ''
            },
            subSystemConfigureExtensionUnion: {
                id: '',
                name: '',
                configureValueName: '',
                configureValueId:'',
                configureSwitchProxy: '',
                configureValue: ''
            }
        },
        content: {
            systemConfigureResourceUIModel: {
                id: '',
                scenarioMode: '',
                standardSystemCategory: '',
                name: '',
                note: ''
            },
            systemConfigureExtensionUnionUIModelList: [],
            systemConfigureElementUIModelList: []
        },
        cache: {
            systemConfigureExtensionUnion: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refUUID: '',
                refCodeValueUUID: '',
                configureValueName: '',
                configureValueId:'',
                name: '',
                configureSwitchProxy: '',
                configureValue: ''
            },
            systemCodeValueUnionUIModelList:[],
            systemConfigureElement: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                id: '',
                name: '',
                client: '',
                refNodeName: '',
                refUUID: '',
                scenarioMode: '',
                elementType: ''
            },
            subSystemConfigureExtensionUnion: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refCodeValueUUID: '',
                refUUID: '',
                refNodeName: '',
                configureValueName: '',
                configureValueId:'',
                configureSwitchProxy: '',
                configureValue: ''
            },
            pageHeaderModelList:[]
        },
        author: {
            resourceId: ServiceModuleConstants.SystemConfigureResource,
            actionCode: {
                Edit: false,
                View: false,
                PriceInfo: false,
                Delete: false,
                Excel: false
            }
        },
        eleScenarioMode: '#x_scenarioMode',
        eleStandardSystemCategory: '#x_standardSystemCategory',
        eleSubScenarioMode: '#x_subScenarioMode',
        eleRefCodeValue: '#x_refCodeValue',
        eleConfigureValue: '#x_configureValue',
        loadModuleEditURL: '../systemConfigureResource/loadModuleEditService.html',
        loadModuleViewURL: '../systemConfigureResource/loadModuleViewService.html',
        saveModuleURL: '../systemConfigureResource/saveModuleService.html',
        exitModuleURL: '../systemConfigureResource/exitEditor.html',
        newModuleServiceURL: '../systemConfigureResource/newModuleService.html',
        newSystemConfigureExtensionUnionServiceURL: '../systemConfigureExtensionUnion/newModuleService.html',
        eleEditSystemConfigureExtensionUnionModal: '#x_eleEditSystemConfigureExtensionUnionModal',
        newSystemConfigureElementServiceURL: '../systemConfigureElement/newModuleService.html',
        eleEditSystemConfigureElementModal: '#x_eleEditSystemConfigureElementModal',
        getPageHeaderModelListURL: '../systemConfigureResource/getPageHeaderModelList.html',
        newSubSystemConfigureExtensionUnionServiceURL: '../subSystemConfigureExtensionUnion/newModuleService.html',
        eleEditSubSystemConfigureExtensionUnionModal: '#x_eleEditSubSystemConfigureExtensionUnionModal',
        getSystemCodeValueCollectionListURL: '../systemCodeValueCollection/loadModuleListService.html',
        getSystemCodeValueCollectionURL: '../systemCodeValueCollection/loadModuleEditService.html',
        getScenarioModeMapURL: '../systemConfigureCategory/getScenarioModeMap.html',
        getSubScenarioModeMapURL: '../systemConfigureCategory/getSubScenarioModeMap.html',
        getSystemStandardCategoryMapURL: '../systemConfigureCategory/getSystemStandardCategoryMap.html'
    },

    created: function () {
        this.initSubComponents();
        this.initAuthorResourceCheck();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'SystemConfigureResource');
            this.setI18nProperties();
            this.loadModuleEdit();
            this.extensionunionTable = new ServiceDataTable(this.extensionunionTableId);
            this.configureelementTable = new ServiceDataTable(this.configureelementTableId);
            this.initSelectConfigure();
        });
    },

    methods: {

        /**
         * Initial register sub component
         */
        initSubComponents: function(){
            "use strict";
            Vue.component("page-header-union", PageHeaderUnion);
        },

        initAuthorResourceCheck: function () {
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm: vm,
                errorHandle: ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        setToSubSystemConfigureExtensionUnion: function () {
            var item = this._filterItemByUUID(this.cache.subSystemConfigureExtensionUnion.uuid, this.content.systemConfigureExtensionUnionUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copySubSystemConfigureExtensionUnion(this.cache.subSystemConfigureExtensionUnion);
                this.content.systemConfigureExtensionUnionUIModelList.push(newItem);
            } else {
                this.copySubSystemConfigureExtensionUnion(this.cache.subSystemConfigureExtensionUnion, item);
            }
            $(this.eleEditSubSystemConfigureExtensionUnionModal).modal('hide');
        },

        newSubSystemConfigureExtensionUnionModal: function () {
            var baseUUID = this.content.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);

            ServiceUtilityHelper.httpRequest({
                url: vm.newSubSystemConfigureExtensionUnionServiceURL,
                $http: vm.$http,
                method: 'post',
                requestData: requestData,
                errorHandle: vm.errorHandle,
                postHandle: function (oData) {
                    vm.cache.subSystemConfigureExtensionUnion = vm.copySubSystemConfigureExtensionUnion(oData.content, vm.cache.subSystemConfigureExtensionUnion);
                    $(vm.eleEditSubSystemConfigureExtensionUnionModal).modal('toggle');
                }.bind(this)
            });

        },

        deleteSubSystemConfigureExtensionUnion: function () {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.systemConfigureExtensionUnionUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, content.systemConfigureExtensionUnionUIModelList);
                    } else {
// do nothing, just return
                    }
                });
        },

        generateSystemConfigureResourceTreeView: function (content) {
            var vm = this;
            var systemConfigureResourceTreeModel = {};
            systemConfigureResourceTreeModel.uuid = content.systemConfigureResourceUIModel.uuid;
            systemConfigureResourceTreeModel.rootNodeUUID = content.systemConfigureResourceUIModel.rootNodeUUID;
            systemConfigureResourceTreeModel.parentNodeUUID = content.systemConfigureResourceUIModel.parentNodeUUID;
            systemConfigureResourceTreeModel.layer = 1;
            systemConfigureResourceTreeModel.iconClass = 'icon-th-list';
            systemConfigureResourceTreeModel.spanClass = 'badge-warning';
            systemConfigureResourceTreeModel.spanContent = content.systemConfigureResourceUIModel.id;
            systemConfigureResourceTreeModel.subModelList = [];
            systemConfigureResourceTreeModel.postModelList = [];

            var postModel1 = {};
            postModel1.iconClass = 'fa fa-code-fork content-orange';
            postModel1.spanContent = '';
            postModel1.spanContent = ' 所属配置属性';
            postModel1.spanClass = 'badge-lightGrey';
            postModel1.iconArray = [];
            postModel1.iconArray.push({
                class : 'ion-android-remove content-lightGrey'
            });
            var addConnectionIcon = {};
            addConnectionIcon.innerUUID = systemConfigureResourceTreeModel.uuid;
            addConnectionIcon.class = 'fa fa-plus iconNewSystemConfigureExtensionUnionInterface';
            postModel1.iconArray.push(addConnectionIcon);
            systemConfigureResourceTreeModel.postModelList.push(postModel1);


            var postModel2 = {};
            postModel2.iconClass = 'fa fa-cogs content-orange';
            postModel2.spanContent = '';
            postModel2.spanContent = ' 所属配置元素';
            postModel2.iconArray = [];
            var seperateIcon2 = {};
            seperateIcon2.class = 'ion-android-remove content-lightGrey';
            postModel2.iconArray.push(seperateIcon2);
            var addElementIcon = {};
            addElementIcon.innerUUID = systemConfigureResourceTreeModel.uuid;
            addElementIcon.class = 'fa fa-plus iconNewSystemConfigureExtensionUnionInterface';
            postModel2.iconArray.push(addElementIcon);
            systemConfigureResourceTreeModel.postModelList.push(postModel2);
            // var systemConfigureExtensionUnionHeader = vm.generateSystemConfigureExtensionUnionHeader(2, systemConfigureResourceTreeModel.uuid);

            // systemConfigureResourceTreeModel.subModelList.push(systemConfigureExtensionUnionHeader);
            if (content.systemConfigureExtensionUnionUIModelList) {
                for (var i = 0; i < content.systemConfigureExtensionUnionUIModelList.length; i++) {
                    systemConfigureResourceTreeModel.subModelList.push(vm.generateSystemConfigureExtensionUnionTreeView(content.systemConfigureExtensionUnionUIModelList[i], 3));
                }
            }
            // var systemConfigureElementHeader = vm.generateSystemConfigureElementHeader(2, systemConfigureResourceTreeModel.uuid);
            // systemConfigureResourceTreeModel.subModelList.push(systemConfigureElementHeader);
            if (content.systemConfigureElementUIModelList) {
                for (var i = 0; i < content.systemConfigureElementUIModelList.length; i++) {
                    systemConfigureResourceTreeModel.subModelList.push(vm.generateSystemConfigureElementTreeView(content.systemConfigureElementUIModelList[i], 3));
                }
            }
            return systemConfigureResourceTreeModel;
        },



        generateSystemConfigureExtensionUnionTreeView: function (content, layer) {
            var vm = this;
            var systemConfigureExtensionUnionTreeModel = {};
            systemConfigureExtensionUnionTreeModel.uuid = content.uuid;
            systemConfigureExtensionUnionTreeModel.rootNodeUUID = content.rootNodeUUID;
            systemConfigureExtensionUnionTreeModel.parentNodeUUID = content.parentNodeUUID;
            systemConfigureExtensionUnionTreeModel.iconArray = [];
            systemConfigureExtensionUnionTreeModel.subModelList = [];
            systemConfigureExtensionUnionTreeModel.spanContent = '   ' + content.name + '-' + content.configureValueName;
            systemConfigureExtensionUnionTreeModel.spanClass = 'badge-lightBlue';

            var postModel1 = {};
            systemConfigureExtensionUnionTreeModel.iconClass = 'fa fa-code-fork content-orange';
            var seperateIcon = {};
            seperateIcon.class = 'ion-android-remove content-lightGrey';
            systemConfigureExtensionUnionTreeModel.iconArray.push(seperateIcon);

            var editIcon = {};
            editIcon.innerUUID = systemConfigureExtensionUnionTreeModel.uuid;
            editIcon.class = 'glyphicon glyphicon-pencil content-green iconEditSystemConfigureExtensionUnion'
            systemConfigureExtensionUnionTreeModel.iconArray.push(editIcon);

            return systemConfigureExtensionUnionTreeModel;

        },

        generateSystemConfigureElementTreeView: function (content, layer) {
            var vm = this;
            var systemConfigureElementTreeModel = {};
            systemConfigureElementTreeModel.uuid = content.systemConfigureElementUIModel.uuid;
            systemConfigureElementTreeModel.rootNodeUUID = content.systemConfigureElementUIModel.rootNodeUUID;
            systemConfigureElementTreeModel.parentNodeUUID = content.systemConfigureElementUIModel.parentNodeUUID;
            systemConfigureElementTreeModel.iconArray = [];
            systemConfigureElementTreeModel.subModelList = [];
            systemConfigureElementTreeModel.postModelList = [];
            systemConfigureElementTreeModel.spanContent = content.systemConfigureElementUIModel.id;


            systemConfigureElementTreeModel.iconClass = 'fa fa-cogs content-orange';
            systemConfigureElementTreeModel.iconArray.push({
                class: 'ion-android-remove content-lightGrey'
            });

            var postModel1 = {};
            postModel1.iconClass = 'fa fa-code-fork content-orange';
            postModel1.spanContent = '';
            postModel1.spanContent = ' 所属配置属性';
            postModel1.spanClass = 'badge-lightBlue';
            postModel1.iconArray = [];
            var seperateIcon = {};
            seperateIcon.class = 'ion-android-remove content-lightGrey';
            postModel1.iconArray.push(seperateIcon);
            var addConnectionIcon = {};
            addConnectionIcon.innerUUID = content.systemConfigureElementUIModel.uuid;
            addConnectionIcon.class = 'fa fa-plus iconNewSystemConfigureExtensionUnionInterface';
            postModel1.iconArray.push(addConnectionIcon);
            systemConfigureElementTreeModel.postModelList.push(postModel1);

            var editIcon = {};
            editIcon.innerUUID = systemConfigureElementTreeModel.uuid;
            editIcon.class = 'glyphicon glyphicon-pencil content-green iconEditSystemConfigureElement'
            systemConfigureElementTreeModel.iconArray.push(editIcon);

            if (content.systemConfigureExtensionUnionUIModelList) {
                for (var i = 0; i < content.systemConfigureExtensionUnionUIModelList.length; i++) {
                    systemConfigureElementTreeModel.subModelList.push(vm.generateSystemConfigureExtensionUnionTreeView(content.systemConfigureExtensionUnionUIModelList[i], 5));
                }
            }
            return systemConfigureElementTreeModel;
        },

        errorHandle: function (oData) {
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true : undefined);
        },

        refreshTreeView: function () {
            var vm = this;
            var ser = new XMLSerializer();
            var treeElement = generateBootstrapTreeContent(vm.generateSystemConfigureResourceTreeView(vm.content));
            var htmlContent = ser.serializeToString(treeElement);
            $("#x_tree_systemConfigureResource").empty();
            $("#x_tree_systemConfigureResource").prepend(htmlContent);
            $(".iconNewSystemConfigureExtensionUnionInterface").on("click", function (e) {
                var baseUUID = $(this).children("input").attr("value");
                vm.newSystemConfigureExtensionUnionModal(baseUUID);
            });
            $(".iconEditSystemConfigureExtensionUnion").on("click", function (e) {
                var uuid = $(this).children("input").attr("value");
                vm.editSystemConfigureExtensionUnionModal(uuid);
            });
            $(".iconNewSystemConfigureElementInterface").on("click", function (e) {
                var baseUUID = $(this).children("input").attr("value");
                vm.newSystemConfigureElementModal(baseUUID);
            });
            $(".iconEditSystemConfigureElement").on("click", function (e) {
                var uuid = $(this).children("input").attr("value");
                vm.editSystemConfigureElementModal(uuid);
            });
            $(".iconNewSubSystemConfigureExtensionUnionInterface").on("click", function (e) {
                var baseUUID = $(this).children("input").attr("value");
                vm.newSubSystemConfigureExtensionUnionModal(baseUUID);
            });
            $(".iconEditSubSystemConfigureExtensionUnion").on("click", function (e) {
                var uuid = $(this).children("input").attr("value");
                vm.editSubSystemConfigureExtensionUnionModal(uuid);
            });
            vm.initTreeAction();

        },

        initTreeAction: function () {
            $('.tree li.parent_li > span').off('click');
            $('.tree li.parent_li > span').on('click', function (e) {
                var children = $(this).parent('li.parent_li').find(' > ul > li');
                if (children.is(":visible")) {
                    children.hide('fast');
                } else {
                    children.show('fast');
                }
                e.stopPropagation();
            });

        },

        editSubSystemConfigureExtensionUnionModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.systemConfigureExtensionUnionUIModelList);
            if (!item) {
                return;
            }
            this.cache.subSystemConfigureExtensionUnion = this.copySubSystemConfigureExtensionUnion(item);
            $(this.eleEditSubSystemConfigureExtensionUnionModal).modal('toggle');

        },

        editSystemConfigureExtensionUnionModal: function (uuid) {
            var vm = this;
            var item = this._filterItemByUUID(uuid, this.content.systemConfigureExtensionUnionUIModelList);
            if (!item) {
                return;
            }
            this.cache.systemConfigureExtensionUnion = this.copySystemConfigureExtensionUnion(item);
            // manually set initial value
            $(vm.eleRefCodeValue).val(this.cache.systemConfigureExtensionUnion.refCodeValueUUID);
            $(vm.eleRefCodeValue).trigger("change");

            vm.getSystemCodeValueUnionSelect(this.cache.systemConfigureExtensionUnion.refCodeValueUUID);
            $(this.eleEditSystemConfigureExtensionUnionModal).modal('toggle');

        },


        setToSystemConfigureExtensionUnion: function () {
            var item = this._filterItemByUUID(this.cache.systemConfigureExtensionUnion.uuid, this.content.systemConfigureExtensionUnionUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copySystemConfigureExtensionUnion(this.cache.systemConfigureExtensionUnion);
                this.content.systemConfigureExtensionUnionUIModelList.push(newItem);
            } else {
                this.copySystemConfigureExtensionUnion(this.cache.systemConfigureExtensionUnion, item);
            }
            $(this.eleEditSystemConfigureExtensionUnionModal).modal('hide');
        },

        newSystemConfigureExtensionUnionModal: function () {
            var vm = this;
            var baseUUID = this.content.systemConfigureResourceUIModel.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            ServiceUtilityHelper.httpRequest({
                url: vm.newSystemConfigureExtensionUnionServiceURL,
                $http: vm.$http,
                method: 'post',
                requestData: requestData,
                errorHandle: vm.errorHandle,
                postHandle: function (oData) {
                    $(vm.eleRefCodeValue).val(vm.cache.systemConfigureExtensionUnion.refCodeValueUUID);
                    $(vm.eleRefCodeValue).trigger("change");
                    vm.cache.systemConfigureExtensionUnion = vm.copySystemConfigureExtensionUnion(oData.content, vm.cache.systemConfigureExtensionUnion);
                    $(vm.eleEditSystemConfigureExtensionUnionModal).modal('toggle');
                }.bind(this)
            });

        },

        deleteSystemConfigureExtensionUnion: function () {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.systemConfigureExtensionUnionUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, content.systemConfigureExtensionUnionUIModelList);
                    } else {
// do nothing, just return
                    }
                });
        },

        addSystemConfigureExtensionUnion: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.systemConfigureResourceUIModel.uuid;
            var resultURL = "SystemConfigureExtensionUnionEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },

        editSystemConfigureExtensionUnion: function (uuid) {
            var vm = this;
            window.location.href = genCommonEditURL("SystemConfigureExtensionUnionEditor.html", uuid);
        },

        editSystemConfigureElementModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.systemConfigureElementUIModelList);
            if (!item) {
                return;
            }
            this.cache.systemConfigureElement = this.copySystemConfigureElement(item);
            $(this.eleEditSystemConfigureElementModal).modal('toggle');

        },

        setToSystemConfigureElement: function () {
            var item = this._filterItemByUUID(this.cache.systemConfigureElement.uuid, this.content.systemConfigureElementUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copySystemConfigureElement(this.cache.systemConfigureElement);
                this.content.systemConfigureElementUIModelList.push(newItem);
            } else {
                this.copySystemConfigureElement(this.cache.systemConfigureElement, item);
            }
            $(this.eleEditSystemConfigureElementModal).modal('hide');
        },

        newSystemConfigureElementModal: function () {
            var baseUUID = this.content.systemConfigureResourceUIModel.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            ServiceUtilityHelper.httpRequest({
                url: vm.newSystemConfigureElementServiceURL,
                $http: vm.$http,
                method: 'post',
                requestData: requestData,
                errorHandle: vm.errorHandle,
                postHandle: function (oData) {
                    vm.cache.systemConfigureElement = vm.copySystemConfigureElement(oData.content, vm.cache.systemConfigureElement);
                    $(vm.eleEditSystemConfigureElementModal).modal('toggle');
                }.bind(this)
            });


        },

        deleteSystemConfigureElement: function () {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.systemConfigureElementUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, content.systemConfigureElementUIModelList);
                    } else {
// do nothing, just return
                    }
                });
        },

        addSystemConfigureElement: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.systemConfigureResourceUIModel.uuid;
            var resultURL = "SystemConfigureElementEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },

        editSystemConfigureElement: function (uuid) {
            var vm = this;
            window.location.href = genCommonEditURL("SystemConfigureElementEditor.html", uuid);

        },

        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.quickEdit = $.i18n.prop('quickEdit');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.deleteWarnTitle = $.i18n.prop('deleteWarnTitle');
            this.label.deleteWarnText = $.i18n.prop('deleteWarnText');
            this.label.cancel = $.i18n.prop('cancel');
            this.label.commit = $.i18n.prop('commit');
            this.label.confirm = $.i18n.prop('confirm');
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            this.label.id = $.i18n.prop('id');
            this.label.scenarioMode = $.i18n.prop('scenarioMode');
            this.label.standardSystemCategory = $.i18n.prop('standardSystemCategory');
            this.label.name = $.i18n.prop('name');
            this.label.note = $.i18n.prop('note');
            this.label.systemConfigureResourceSection = $.i18n.prop('systemConfigureResourceSection');
            this.label.systemConfigureExtensionUnionSection = $.i18n.prop('systemConfigureExtensionUnionSection');
            this.label.systemConfigureElementSection = $.i18n.prop('systemConfigureElementSection');
            this.label.systemConfigureResourceTreeSection = $.i18n.prop('systemConfigureResourceTreeSection');
            this.label.systemConfigureElementSection = $.i18n.prop('systemConfigureElementSection');
            this.label.systemConfigureResourceTreeSection = $.i18n.prop('systemConfigureResourceTreeSection');
            this.label.addSystemConfigureResource = $.i18n.prop('addSystemConfigureResource');
            this.label.addSystemConfigureExtensionUnion = $.i18n.prop('addSystemConfigureExtensionUnion');
            this.label.addSystemConfigureElement = $.i18n.prop('addSystemConfigureElement');
            this.label.addSystemConfigureResource = $.i18n.prop('addSystemConfigureResource');
            this.label.parentPageTitle = $.i18n.prop('parentPageTitle');
            this.label.pageTitle = $.i18n.prop('pageTitle');
            this.label.systemConfigureCategoryPageTitle = $.i18n.prop('systemConfigureCategoryPageTitle');
            this.label.systemConfigureResourcePageTitle = $.i18n.prop('systemConfigureResourcePageTitle');
            this.label.systemConfigureElementPageTitle = $.i18n.prop('systemConfigureElementPageTitle');

        },

        setI18nConfigureElementProperties: function () {
            this.label.systemConfigureElement.scenarioMode = $.i18n.prop('scenarioMode');
            this.label.systemConfigureElement.elementType = $.i18n.prop('elementType');
            this.label.systemConfigureElement.standardSystemCategory = $.i18n.prop('standardSystemCategory');
            this.label.systemConfigureElement.id = $.i18n.prop('id');
            this.label.systemConfigureElement.name = $.i18n.prop('name');
        },

        setI18nExtensionUnionProperties: function () {
            this.label.systemConfigureExtensionUnion.configureValueName = $.i18n.prop('configureValueName');
            this.label.systemConfigureExtensionUnion.configureValueId = $.i18n.prop('configureValueId');
            this.label.systemConfigureExtensionUnion.configureSwitchProxy = $.i18n.prop('configureSwitchProxy');
            this.label.systemConfigureExtensionUnion.configureValue = $.i18n.prop('configureValue');
            this.label.systemConfigureExtensionUnion.name = $.i18n.prop('name');
            this.label.systemConfigureExtensionUnion.id = $.i18n.prop('id');
            this.label.systemConfigureExtensionUnion.refCodeValue = $.i18n.prop('refCodeValue');
        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'SystemConfigureResource', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
            jQuery.i18n.properties({
                name: 'SystemConfigureElement', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setI18nConfigureElementProperties
            });
            jQuery.i18n.properties({
                name: 'SystemConfigureExtensionUnion', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setI18nExtensionUnionProperties
            });

        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleStandardSystemCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.systemConfigureResourceUIModel, 'standardSystemCategory', $(vm.eleStandardSystemCategory).val());
            });
            $(vm.eleScenarioMode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.systemConfigureResourceUIModel, 'scenarioMode', $(vm.eleScenarioMode).val());
            });
            $(vm.eleSubScenarioMode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.systemConfigureResourceUIModel, 'subScenarioMode', $(vm.eleSubScenarioMode).val());
            });
            $(vm.eleRefCodeValue).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.systemConfigureExtensionUnion, 'refCodeValueUUID', $(vm.eleRefCodeValue).val());
                // Logic to set configure value
                vm.getSystemCodeValueUnionSelect($(vm.eleRefCodeValue).val());

            });
            $(vm.eleConfigureValue).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                var refCodeValueUUID = $(vm.eleConfigureValue).val();
                vm.$set(vm.cache.systemConfigureExtensionUnion, 'configureValue', refCodeValueUUID);
                var refCodeValue = ServiceCollectionsHelper.filterArray(refCodeValueUUID, 'uuid', vm.cache.systemCodeValueUnionUIModelList);
                if(refCodeValue){
                    vm.$set(vm.cache.systemConfigureExtensionUnion, 'configureValueName', refCodeValue.name);
                    vm.$set(vm.cache.systemConfigureExtensionUnion, 'configureValueId', refCodeValue.id);
                }
            });

        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            if (processMode === PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                ServiceUtilityHelper.httpRequest({
                    url: vm.newModuleServiceURL,
                    $http: vm.$http,
                    method: 'post',
                    requestData: requestData,
                    errorHandle: vm.errorHandle,
                    postHandle: function (oData) {
                        vm.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if (processMode == PROCESSMODE_EDIT) {
                // In case [Edit mode]
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl: this.loadModuleEditURL,
                    viewUrl: this.loadModuleViewURL,
                    uuid: baseUUID,
                    author: vm.author,
                    $http: vm.$http,
                    errorHandle: vm.errorHandle,
                    postSet: vm.setModuleToUI
                });
            }


        },

        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }

        },

        copySystemConfigureExtensionUnion: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refNodeName = origin.refNodeName;
            target.refUUID = origin.refUUID;
            target.refCodeValueUUID = origin.refCodeValueUUID;
            target.configureValueName = origin.configureValueName;
            target.configureValueId = origin.configureValueId;
            target.configureSwitchProxy = origin.configureSwitchProxy;
            target.configureValue = origin.configureValue;
            return target;

        },

        copySystemConfigureElement: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refNodeName = origin.refNodeName;
            target.refUUID = origin.refUUID;
            target.scenarioMode = origin.scenarioMode;
            target.elementType = origin.elementType;
            return target;

        },

        copySubSystemConfigureExtensionUnion: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refCodeValueUUID = origin.refCodeValueUUID;
            target.refUUID = origin.refUUID;
            target.refNodeName = origin.refNodeName;
            target.configureValueName = origin.configureValueName;
            target.configureValueId = origin.configureValueId;
            target.configureSwitchProxy = origin.configureSwitchProxy;
            target.configureValue = origin.configureValue;
            return target;

        },

        getPageHeaderModelList: function(uuid, baseUUID){
            var vm = this;
            vm.$refs.pageHeader.initPageHeader({
                uuid:uuid,
                baseUUID:baseUUID,
                pageHeaderListUrl:vm.getPageHeaderModelListURL,
                fnPageHeaderModel:vm.fnPageHeaderModel
            });
        },

        fnPageHeaderModel:function(pageHeaderModel){
            if (pageHeaderModel.nodeInstId === 'systemConfigureCategory'){
                baseDocURL = genCommonEditURL("SystemConfigureCategoryEditor.html", pageHeaderModel.uuid);
                pageHeaderModel.pageLink = baseDocURL;
                pageHeaderModel.pageTitle = this.label.systemConfigureCategoryPageTitle + ":" + this.content.systemConfigureResourceUIModel.parentNodeId;
                return pageHeaderModel;
            }
            if (pageHeaderModel.nodeInstId === 'systemConfigureResource'){
                baseDocURL = genCommonEditURL("SystemConfigureResourceEditor.html", pageHeaderModel.uuid);
                pageHeaderModel.pageLink = baseDocURL;
                pageHeaderModel.pageTitle = this.label.systemConfigureResourcePageTitle;
                return pageHeaderModel;
            }
        },

        saveModule: function () {
            var vm = this;
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            ServiceUtilityHelper.httpRequest({
                url: vm.saveModuleURL,
                $http: vm.$http,
                method: 'post',
                requestData: vm.content,
                errorHandle: vm.errorHandle,
                postHandle: function (oData) {
                    $.Notification.notify('success', 'top center', vm.label.msgSaveOK, vm.label.msgSaveOKComment);
                    vm.setModuleToUI(oData.content);
                    var processMode = getUrlVar(LABEL_PROCESSMODE);
                    if (processMode && processMode === PROCESSMODE_NEW) {
                        var baseUUID = vm.content.systemConfigureResourceUIModel.uuid;
                        if (baseUUID) {
                            window.location.href = genCommonEditURL("SystemConfigureResourceEditor.html", baseUUID);
                        }
                    }
                }.bind(this)
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.systemConfigureResourceUIModel.parentNodeUUID;
            window.location.href = genCommonEditURL("SystemConfigureCategoryEditor.html", baseUUID);

        },

        refreshEditView: function () {
            var baseUUID = this.content.systemConfigureResourceUIModel.uuid;
            window.location.href = genCommonEditURL("SystemConfigureResourceEditor.html", baseUUID);

        },

        getScenarioMode: function (content) {
            var vm = this;
            ServiceUtilityHelper.loadMetaRequest({
                url: vm.getScenarioModeMapURL,
                $http: vm.$http,
                initValue: vm.content.systemConfigureResourceUIModel.scenarioMode,
                element: vm.eleScenarioMode,
                errorHandle: vm.errorHandle
            });
        },

        getStandardSystemCategory: function (content) {
            var vm = this;
            ServiceUtilityHelper.loadMetaRequest({
                url: vm.getSystemStandardCategoryMapURL,
                $http: vm.$http,
                initValue: vm.content.systemConfigureResourceUIModel.standardSystemCategory,
                element: vm.eleStandardSystemCategory,
                errorHandle: vm.errorHandle
            });
        },

        getSystemCodeValueCollection: function () {
            var vm = this;
            this.$http.get(this.getSystemCodeValueCollectionListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'id');
                setTimeout(function () {
                    $(vm.eleRefCodeValue).select2({
                        data: resultList
                    });

                }, 0);
            });
        },

        getSystemCodeValueUnionSelect: function (baseUUID) {
            var vm = this;
            var url = this.getSystemCodeValueCollectionURL + "?&uuid=" + baseUUID;
            if(!baseUUID){
                return;
            }
            this.$http.get(url).then(function (response) {
                var content = JSON.parse(response.body).content;
                if (!content) {
                    // pop up error message
                }
                vm.$set(vm.cache.systemConfigureExtensionUnion, 'name', content.systemCodeValueCollectionUIModel.name);
                vm.$set(vm.cache.systemConfigureExtensionUnion, 'id', content.systemCodeValueCollectionUIModel.id);
                this.cache.systemCodeValueUnionUIModelList = content.systemCodeValueUnionUIModelList;
                var resultList = vm.formatCodeValueSelectResult(this.cache.systemCodeValueUnionUIModelList);
                // Clear select options
                $(vm.eleConfigureValue).empty();
                setTimeout(function () {
                    $(vm.eleConfigureValue).select2({
                        data: resultList
                    });
                    $(vm.eleConfigureValue).val(vm.cache.systemConfigureExtensionUnion.configureValue);
                    $(vm.eleConfigureValue).trigger("change");
                }, 0);
            });
        },

        formatCodeValueSelectResult: function (rawList) {
            if (!rawList || rawList.length == 0) {
                return null;
            }
            var i = 0, len = rawList.length, resultList = [];
            for (var i = 0; i < len; i++) {
                var element = {'id': rawList[i]['uuid'], 'text': rawList[i]['id'] + '-' + rawList[i]['name']}
                resultList.push(element);
            }
            return resultList;
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'systemConfigureResourceUIModel', content.systemConfigureResourceUIModel);
            vm.$set(vm.content, 'systemConfigureExtensionUnionUIModelList', content.systemConfigureExtensionUnionUIModelList);
            vm.$set(vm.content, 'systemConfigureElementUIModelList', content.systemConfigureElementUIModelList);
            vm.getPageHeaderModelList(vm.content.systemConfigureResourceUIModel.uuid, vm.content.systemConfigureResourceUIModel.parentNodeUUID);
            vm.getStandardSystemCategory(content);
            vm.getScenarioMode(content);
            vm.getSystemCodeValueCollection();
            setTimeout(function () {
                vm.refreshTreeView();
            }, 0);
        }

    }
});
