var MaterialUtility = function () {

};

MaterialUtility.formatDefaultPrirityCode = function(){
    "use strict";
    var $element = ServiceUtilityHelper.formatSelectWithIcon(priorityCode, SystemStandrdMetadataProxy.getDefaultPrirityCodeIconArray());
    return $element;
};

/**
 * Constants method: Generate the array for mapping 'TraceMode' and 'iconClass'
 * @returns {*[]}
 */
MaterialUtility.getTraceModeArray = function(traceMode) {
    "use strict";
    return [{
        id: DocumentConstants.MaterialStockKeepUnit.traceMode.NONE,  iconClass: 'md md-location-disabled content-grey'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceMode.SINGE, iconClass: 'md md-gps-fixed content-lightblue'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceMode.BATCH, iconClass: 'md md-gps-not-fixed content-lightblue'
    }];
};

/**
 * Constants method: Generate the array for mapping 'traceLevel' and 'iconClass'
 * @returns {*[]}
 */
MaterialUtility.getTraceLevelArray = function(traceLevel) {
    "use strict";
    return [{
        id: DocumentConstants.MaterialStockKeepUnit.traceLevel.TEMPLATE,  iconClass: 'md md-filter-none content-grey'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceLevel.INSTANCE, iconClass: 'md md-filter-center-focus content-lightblue'
    }];
};

/**
 * Constants method: Generate the array for mapping 'traceStatus' and 'iconClass'
 * @returns {*[]}
 */
MaterialUtility.getTraceStatusArray = function(traceStatus) {
    "use strict";
    return [{
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.INIT, iconClass: 'md md-restore content-orange'
    },{
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.ACTIVE, iconClass: 'glyphicon glyphicon-ok content-green'
    }, {
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.INUSE, iconClass: 'glyphicon glyphicon-ok content-green'
    },{
        id: DocumentConstants.MaterialStockKeepUnit.traceStatus.ARCHIVE, iconClass: 'md md-sd-card content-grey'
    }];
};

/**
 * Constants method: Generate the array for mapping 'operationMode' and 'iconClass'
 * @returns {*[]}
 */
MaterialUtility.getOperationMode = function(traceStatus) {
    "use strict";
    return [{
        id: DocumentConstants.Material.operationMode.SIMPLE, iconClass: 'fa fa-gear content-orange'
    },{
        id: DocumentConstants.Material.operationMode.COMPOUND, iconClass: 'fa fa-gears content-red'
    }];
};

/**
 * @override: Generate Document Basic Info Popover.
 * @param {object} oSettings
 *         ----{string} uuid: target UUID to retrieve the Inquiry instance.
 *         ----{DOM element}$http.
 *         ----{DOM element}$popCoreElement.
 *         ----{string}targetPage: target editor page destination name.
 *         ----{function} fnCallBack: call back method, after all data is loaded.
 */
MaterialUtility.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var uuid = oSettings.uuid;
    var $http = oSettings.$http;
    var targetPage = oSettings.targetPage ? oSettings.targetPage: "MaterialEditor.html";
    var $popCoreElement = oSettings.$popCoreElement;
    var fnCallBack = oSettings.fnCallBack;
    var url = "../material/loadModuleViewService.html" + "?uuid=" + uuid;
    $http.get(url).then(function (response) {
        var oData = JSON.parse(response.data);
        if (!oData.content) {
            ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
            return;
        }
        // Set to cache
        var _materialUIModel = oData.content.materialUIModel;
        var labelObject = {};
        var material = {};

        var paras = {};
        paras.processMode = PROCESSMODE_EDIT;
        paras.uuid = _materialUIModel.uuid;
        var resultURL = targetPage + "?" + urlEncode(paras);

        var serializer = new XMLSerializer();

        var xmlDoc = document.implementation.createDocument("", "", null);
        $popCoreElement.empty();
        var oSetting = {};
        oSetting.editUrl = resultURL;
        material.id = _materialUIModel.id;
        material.name = _materialUIModel.name;
        material.supplyType = _materialUIModel.supplyTypeValue;
        var iconSupplyType = MaterialManager.formatSupplyTypeIconClass(_materialUIModel.supplyType);
        if (iconSupplyType) {
            material.supplyType = {
                value: _materialUIModel.supplyTypeValue,
                iconClass: iconSupplyType
            };
        }
        material.materialCategory = _materialUIModel.materialCategoryValue;
        material.materialTypeName = _materialUIModel.materialTypeName;
        labelObject.id = oSettings.label.id;
        labelObject.name = oSettings.label.name;
        labelObject.supplyType = oSettings.label.supplyType;
        labelObject.materialCategory = oSettings.label.materialCategory;
        labelObject.materialTypeName = oSettings.label.materialTypeName;
        labelObject.materialType = oSettings.label.materialType;
        var topElement = DocumentOrderMatPopInfo.genSimpleDocPopCore(xmlDoc, labelObject, material, oSetting);
        var htmlContent = serializer.serializeToString(topElement);
        $popCoreElement.prepend(htmlContent);
        if (fnCallBack) {
            fnCallBack();
        }
    }.bind(this));
};




