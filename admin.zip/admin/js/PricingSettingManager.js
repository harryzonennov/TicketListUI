/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var PricingSettingManager = function () {

};


PricingSettingManager.label={
    pricingSetting:{
        id: '',
        name: '',
        defaultTaxRate: '',
        multiCurrencyFlag: '',
        defCurrencyCode: '',
        note: '',
        addPricingCurrencyConfigure:'',
        modelTitle:'',
        pricingSettingSection: '',
        pricingCurrencyConfigureSection: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgLoadDataFailure: '',
        quickEdit: '',
        buttonDelete: '',
        exit: '',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        cancel: '',
        commit: '',
        confirm: '',
        index: '',
        lockFailureMessage: '',
        addPricingSetting: '',
        clearSearch:'',
        clearSearchComment:'',
        buttonEdit: '',
        buttonView: '',
        uuid: '',
        currencyCode: '',
        advancedSearchCondition: ''
    },

    pricingCurrencyConfigure:{
        id: '',
        name: '',
        currencyCode: '',
        exchangeRate: '',
        note: '',
        defaultCurrency: '',
        activeFlag: '',
        pricingCurrencyConfigureSection: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        exit: '',
        close: '',
        commit: ''
    }
};


PricingSettingManager.labelTemplate = {
    data: function() {
        return {
            label: {
                "pricingCurrencyConfigure":PricingSettingManager.label.pricingCurrencyConfigure,
            }
        };
    }
};


/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
PricingSettingManager.prototype.getI18nWrap = function (fnCallback) {
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "coreFunction/",
        fnCallback: fnCallback,
        commonCallback: PricingSettingManager.setI18nCommonProperties,
        configList: [{
            name: 'PricingSetting',
            callback: PricingSettingManager.setNodeI18nPropertiesCore
        }]
    });
};


PricingSettingManager.setI18nCommonProperties = function () {
    ServiceUtilityHelper.setI18nCommonReflective(PricingSettingManager.label.pricingSetting, $.i18n.prop);
};



/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
PricingSettingManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../pricingSetting/loadModuleViewService.html';
};

/**
 * @override Get Basic URL for load document list.
 * @returns {string}
 */
PricingSettingManager.prototype.getLoadSelectListURL = function () {
    "use strict";
    return '../pricingSetting/loadModuleListService.html';
};


PricingSettingManager.prototype.getModelTitle = function(){
    return PricingSettingManager.label.pricingSetting.modelTitle;
};


PricingSettingManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: "PricingSettingEditor.html",
        url: "../pricingSetting/loadModuleViewService.html",
        label:PricingSettingManager.label.pricingSetting,
        subPath:'pricingSettingUIModel',
        getI18nWrap:this.getI18nWrap.bind(vm),
        docType:DocumentConstants.DummyDocumentType.PricingSetting
    });

    var fieldMetaList = [{
        fieldName:'id'
    },{
        fieldName:'name'
    },{
        fieldName:'multiCurrencyFlag'
    },{
        fieldName:'defCurrencyCode'
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};
