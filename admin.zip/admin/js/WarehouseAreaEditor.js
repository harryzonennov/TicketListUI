var dataVar = new Vue({
    el: "#x_data",
    data: {
        storeitemTableId: '#x_table_storeitem',
        storeitemTable: {},
        label: WarehouseManager.label.warehouse,
        author:{
            resourceId:'Warehouse',
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        content: {
            warehouseAreaUIModel: WarehouseManager.content.warehouseAreaUIModel
        },
        cache: {
            warehouseAreaStoreItem: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refUUID: '',
                refNodeName: ''
            }

        },
        areaInit: undefined,
        volumeInit: undefined,
        loadModuleEditURL: '../warehouseArea/loadModuleEditService.html',
        saveModuleURL: '../warehouseArea/saveModuleService.html',
        exitModuleURL: '../warehouseArea/exitEditor.html',
        newModuleServiceURL: '../warehouseArea/newModuleService.html',
        newWarehouseAreaStoreItemServiceURL: '../warehouseAreaStoreItem/newModuleService.html',
        eleEditWarehouseAreaStoreItemModal: '#x_eleEditWarehouseAreaStoreItemModal'
    },

    watch: {
        'content.warehouseAreaUIModel.length': function (length) {
            var vm = this;
            this.updateArea({
                length: length,
                width: vm.content.warehouseAreaUIModel.width
            });
            this.updateVolume({
                length: length,
                width: vm.content.warehouseAreaUIModel.width,
                height: vm.content.warehouseAreaUIModel.height
            });
        },
        'content.warehouseAreaUIModel.width': function (width) {
            var vm = this;
            this.updateArea({
                length: vm.content.warehouseAreaUIModel.length,
                width: width
            });
            this.updateVolume({
                length: vm.content.warehouseAreaUIModel.length,
                width: width,
                height: vm.content.warehouseAreaUIModel.height
            });
        },
        'content.warehouseAreaUIModel.height': function (height) {
            var vm = this;
            this.updateVolume({
                length: vm.content.warehouseAreaUIModel.length,
                width: vm.content.warehouseAreaUIModel.width,
                height: height
            });
        }
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'Warehouse');
            this.setI18nProperties();
            this.loadModuleEdit();
            this.initAuthorResourceCheck();
            this.storeitemTable = new ServiceDataTable(this.storeitemTableId);
        });
    },

    methods: {

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.warehouseAreaUIModel.uuid;
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getParentUUID: function () {
            return this.content.warehouseAreaUIModel.parentNodeUUID;
        },

        /**
         * @Overwrite get service manager class
         * @return {*}
         */
        getServiceManager: function (){
            return WarehouseManager;
        },

        updateArea: function (oSettings) {
            var vm = this;
            if( !vm.areaInit ){
                var area = ServiceUtilityHelper.directCalculateArea(oSettings);
                vm.$set(vm.content.warehouseAreaUIModel, 'area', area);
            }
        },

        updateVolume: function (oSettings) {
            var vm = this;
            if( !vm.volumeInit ){
                var volume = ServiceUtilityHelper.directCalculateVolume(oSettings);
                vm.$set(vm.content.warehouseAreaUIModel, 'volume', volume);
            }
        },

        initAuthorResourceCheck: function(){
            var vm = this;
            var authorPromise = ServiceApplicationFactory.getAuthorizationObject(this.$http, this.author.resourceId, this.author.actionCode);
            authorPromise.then(function(oResult){
                vm.author = oResult;
            }, function (reason) {
                // don't do anything
            });
        },


        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.commit = $.i18n.prop('commit');
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            this.label.id = $.i18n.prop('id');
            this.label.name = $.i18n.prop('name');
            this.label.storeType = $.i18n.prop('storeType');
            this.label.note = $.i18n.prop('note');
            this.label.warehouseAreaSection = $.i18n.prop('warehouseAreaSection');
            this.label.warehouseAreaStoreItemSection = $.i18n.prop('warehouseAreaStoreItemSection');
            this.label.itemPageTitle = $.i18n.prop('itemPageTitle');
            this.label.warehousePageTitle = $.i18n.prop('warehousePageTitle');
            this.label.length = $.i18n.prop('length');
            this.label.width = $.i18n.prop('width');
            this.label.area = $.i18n.prop('area');
            this.label.volume = $.i18n.prop('volume');
            this.label.refTechSection = $.i18n.prop('refTechSection');

        },

        setI18nStoreItemProperties: function () {

        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'WarehouseArea', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
            jQuery.i18n.properties({
                name: 'WarehouseAreaStoreItem', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setI18nStoreItemProperties
            });

        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if (processMode == PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                var url = this.newModuleServiceURL;
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                this.$http.post(url, requestData).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }
            if (processMode == PROCESSMODE_EDIT) {
// In case [Edit mode]
                var url = this.loadModuleEditURL + "?uuid=" + baseUUID;
                this.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }


        },

        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }

        },

        copyWarehouseAreaStoreItem: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refUUID = origin.refUUID;
            target.refNodeName = origin.refNodeName;
            return target;

        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            this.$http.post(vm.saveModuleURL, vm.content).then(function (response) {
                $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                this.setModuleToUI(JSON.parse(response.data).content);
                var processMode = getUrlVar(LABEL_PROCESSMODE);
                if (processMode && processMode == PROCESSMODE_NEW) {
                    var baseUUID = vm.content.warehouseAreaUIModel.uuid;
                    if (baseUUID) {
                        window.location.href = genCommonEditURL("WarehouseAreaEditor.html", baseUUID);
                    }
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.warehouseAreaUIModel.parentNodeUUID;
            window.location.href = genCommonEditURL("WarehouseEditor.html", baseUUID);

        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.warehouseAreaUIModel.uuid;
            window.location.href = genCommonEditURL("WarehouseAreaEditor.html", baseUUID, tabKey);

        },

        setPageHeaderLink:function(){
            var vm = this;
            var baseUUID = vm.content.warehouseAreaUIModel.parentNodeUUID;
            var baseDocURL = genCommonEditURL("WarehouseEditor.html", baseUUID);
            var ser = new XMLSerializer();
            var xmlDoc = document.implementation.createDocument("", "", null);
            $("#x_linkToDoc").empty();
            var docText = vm.label.warehousePageTitle + ":" + vm.content.warehouseAreaUIModel.warehouseId;
            var linkToRootDocElement = DocumentOrderMatPopInfo.createPageHeaderLinkToRootDoc(xmlDoc, docText, baseDocURL) ;
            var htmlContent = ser.serializeToString(linkToRootDocElement);
            $("#x_linkToDoc").prepend(htmlContent);
        },

        setModuleToUI: function (content) {
            var vm = this;
            if(content.warehouseAreaUIModel.area && content.warehouseAreaUIModel.area > 0){
                vm.$set(vm, 'areaInit', true);
            }
            if(content.warehouseAreaUIModel.volume && content.warehouseAreaUIModel.volume > 0){
                vm.$set(vm, 'volumeInit', true);
            }
            vm.$set(vm.content, 'warehouseAreaUIModel', content.warehouseAreaUIModel);
            vm.setPageHeaderLink();
        },



        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'WarehouseAreaEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: WarehouseManager,
                coreModelId: 'WarehouseArea',
                i18nPath: 'coreFunction/',
                helpDocumentName: ['WarehouseAreaHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: 'displayForEdit',
                        callback: 'saveModule'
                    },
                    exit: {
                        callback: 'exitModule'
                    }
                },
                pageHeaderConfig: [{
                    nodeInstId: 'warehouse',
                    baseEditUrl:"WarehouseEditor.html",
                    targetTab: WarehouseManager.documentTab.warehouseUnitSection,
                    pageTitlePath: 'warehousePageTitle' ,
                    pageTitleVarPath: 'warehouseId'
                },{
                    active: true,
                    nodeInstId: 'warehouseArea',
                    baseEditUrl:"WarehouseAreaEditor.html",
                    pageTitlePath: 'pageHeaderTitle' ,
                    pageTitleVarPath: 'id'
                }],
                tabMetaList: [{
                    tabId: 'warehouseAreaSection',
                    tabTitleKey: 'warehouseAreaSection',
                    titleLabelKey: 'warehouseAreaSection',
                    titleHelpKey: 'warehouse.warehouseAreaSection',
                    titleIcon: 'md md-texture content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'warehouseAreaSection',
                        updatedByUidPath: 'updatedByUUID',
                        updatedByNamePath: 'updatedByName',
                        updatedDatePath: 'updatedDate',
                        messageResponsePath: 'meta.messageResponse',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'warehouseUIModel',
                        tabTitleKey: 'warehouseAreaSection',
                        titleLabelKey: 'warehouseAreaSection',
                        titleHelpKey: 'warehouse.warehouseAreaSection',
                        titleIcon: 'md md-content-paste content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'id',
                            required: true,
                            newRow: true
                        }, {
                            required: true,
                            fieldName: 'name',
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        }]
                    }, {
                        sectionId: 'refTechSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'warehouseUIModel',
                        tabTitleKey: 'warehouseContactSection',
                        titleLabelKey: 'warehouseContactSection',
                        titleHelpKey: 'warehouse.warehouseContactSection',
                        titleIcon: 'md md-quick-contacts-dialer content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'length',
                            newRow: true,
                        }, {
                            fieldName: 'width'
                        }, {
                            fieldName: 'height',
                        }, {
                            newRow: true,
                            fieldName: 'area'
                        }, {
                            fieldName: 'volume'
                        }]
                    }]
                }]
            };
        }

    }
});
