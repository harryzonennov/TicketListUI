var dataVar = new Vue({
    el: "#x_data",
    mixins:[CalendarTemplateManager.labelTemplate],
    data: {
        workscheduleTableId: '#x_table_workschedule',
        workscheduleTable: {},
        templateitemTableId: '#x_table_templateitem',
        templateitemTable: {},
        label: CalendarTemplateManager.label.calendarTemplate,
        content: {
            calendarTemplateUIModel: {
                client: '',
                uuid: '',
                id: '',
                name: '',
                year: '',
                note: ''
            },
            calendarTempWorkScheduleUIModelList: [],
            calendarTemplateItemUIModelList: []
        },
        cache: {
            calendarTempWorkSchedule: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                id: '',
                name: '',
                endTime: '',
                startTime: '',
                note: ''
            },
            calendarTemplateItem: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                id: '',
                periodType: '',
                vocationType: '',
                dayStatus: '',
                name: '',
                startMonth: '',
                lastDays: '',
                startDay: '',
                note: ''
            }
        },

        author:{
            resourceId:ServiceModuleConstants.CalendarTemplate,
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        processButtonMeta: [],
        embedProcessButtonMeta:[],
        elePeriodType: '#x_periodType',
        eleVocationType: '#x_vocationType',
        eleDayStatus: '#x_dayStatus',
        eleLastDays: '#x_lastDays',
        eleStartDay: '#x_startDay',
        eleStartMonth: '#x_startMonth',
        loadModuleEditURL: '../calendarTemplate/loadModuleEditService.html',
        saveModuleURL: '../calendarTemplate/saveModuleService.html',
        newModuleServiceURL: '../calendarTemplate/newModuleService.html',
        newCalendarTempWorkScheduleServiceURL: '../calendarTempWorkSchedule/newModuleService.html',
        eleEditCalendarTempWorkScheduleModal: '#x_eleEditCalendarTempWorkScheduleModal',
        newCalendarTemplateItemServiceURL: '../calendarTemplateItem/newModuleService.html',
        eleEditCalendarTemplateItemModal: '#x_eleEditCalendarTemplateItemModal',
        getPeriodTypeURL: '../calendarTemplateItem/getPeriodType.html',
        getVocationTypeURL: '../calendarTemplateItem/getVocationType.html',
        getDayStatusURL: '../calendarTemplateItem/getDayStatus.html',
        exitURL: 'CalendarTemplateList.html',
        exitModuleURL: '../calendarTemplate/exitEditor.html'
    },

    created: function(){
        "use strict";
        var vm = this;
        this.setI18nProperties(vm.initProcessButtonMeta);
        vm.initAuthorResourceCheck();
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'CalendarTemplate');
            this.loadModuleEdit();
            this.workscheduleTable = new ServiceDataTable(this.workscheduleTableId);
            this.templateitemTable = new ServiceDataTable(this.templateitemTableId);
            this.initSelectConfigure();
        });
    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function() {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("popup-label", PopupLabel);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleVocationType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.calendarTemplateItem, 'vocationType', $(vm.eleVocationType).val());
            });

            $(vm.elePeriodType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.calendarTemplateItem, 'periodType', $(vm.elePeriodType).val());
                vm.setSelectStartDay(vm.cache.calendarTemplateItem);
                vm.setSelectStartMonth(vm.cache.calendarTemplateItem);
                vm.setSelectLastDays(vm.cache.calendarTemplateItem);
            });

            $(vm.eleDayStatus).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.calendarTemplateItem, 'dayStatus', $(vm.eleDayStatus).val());
            });

            $(vm.eleLastDays).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.calendarTemplateItem, 'lastDays', $(vm.eleLastDays).val());
            });

            $(vm.eleStartDay).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.calendarTemplateItem, 'startDay', $(vm.eleStartDay).val());
                vm.setSelectLastDays(vm.cache.calendarTemplateItem);
            });

            $(vm.eleStartMonth).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.calendarTemplateItem, 'startMonth', $(vm.eleStartMonth).val());
                vm.setSelectStartDay(vm.cache.calendarTemplateItem);
                vm.setSelectLastDays(vm.cache.calendarTemplateItem);
            });
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nWorkScheduleProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.calendarTempWorkSchedule, $.i18n.prop, true);
        },

        setI18nTemplateItemProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.calendarTemplateItem, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "foundation/common/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'CalendarTemplate',
                    callback: this.setNodeI18nPropertiesCore
                },{
                    name: 'CalendarTempWorkSchedule',
                    callback: this.setI18nWorkScheduleProperties
                },{
                    name: 'CalendarTemplateItem',
                    callback: this.setI18nTemplateItemProperties
                }]
            });
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            if (processMode === PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                var url = this.newModuleServiceURL;
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                this.$http.post(url, requestData).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }
            if (processMode === PROCESSMODE_EDIT) {
// In case [Edit mode]
                var url = this.loadModuleEditURL + "?uuid=" + baseUUID;
                this.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    this.setModuleToUI(oData.content);
                });
            }
        },

        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }
        },

        copyCalendarTempWorkSchedule: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.endTime = origin.endTime;
            target.startTime = origin.startTime;
            target.note = origin.note;
            return target;

        },

        copyCalendarTemplateItem: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.periodType = origin.periodType;
            target.vocationType = origin.vocationType;
            target.dayStatus = origin.dayStatus;
            target.startMonth = origin.startMonth;
            target.lastDays = origin.lastDays;
            target.startDay = origin.startDay;
            target.note = origin.note;
            return target;

        },

        saveModule: function () {
            var vm = this;
            ServiceUtilityHelper.defSaveModuleWrapper({
                vm: vm,
                editorPage: "CalendarTemplateEditor.html",
                fnGetBaseUUID: function (){
                    return vm.content.calendarTemplateUIModel.uuid;
                }
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.calendarTemplateUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);

        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.calendarTemplateUIModel.uuid;
            window.location.href = genCommonEditURL("CalendarTemplateEditor.html", baseUUID, tabKey);
        },

        getPeriodType: function (calendarTemplateItem) {
            this.loadPropertyCore({
                url: this.getPeriodTypeURL,
                element: this.elePeriodType,
                initValue: calendarTemplateItem.periodType
            });
        },

        getVocationType: function (calendarTemplateItem) {
            this.loadPropertyCore({
                url: this.getVocationTypeURL,
                element: this.eleVocationType,
                initValue: calendarTemplateItem.vocationType
            });
        },

        getDayStatus: function (calendarTemplateItem) {
            this.loadPropertyCore({
                url: this.getDayStatusURL,
                element: this.eleDayStatus,
                initValue: calendarTemplateItem.dayStatus,
                templateResult: this.formatDayStatus,
                templateSelection: this.formatDayStatus
            });
        },

        /**
         * Get all possible last days values in format of selection
         * @param startDay: startDay
         * @param periodType
         * @returns {*|Array}
         */
        getPossibleStartDays: function (periodType) {
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.WEEK) {
                return this.genIntNumberList(-1, 7);
            }
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.MONTH) {
                return this.genIntNumberList(-1, 31);
            }
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.QUARTER) {
                return this.genIntNumberList(-1, 31);
            }
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.YEAR) {
                return this.genIntNumberList(-1, 31);
            }
        },

        /**
         * Get all possible start months values in format of selection
         * @param startDay: startDay
         * @param periodType
         * @returns {*|Array}
         */
        getPossibleStartMonths: function (periodType) {
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.WEEK) {
                return this.genIntNumberList(0, 1);
            }
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.MONTH) {
                return this.genIntNumberList(0, 1);
            }
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.QUARTER) {
                return this.genIntNumberList(-1, 3);
            }
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.YEAR) {
                return this.genIntNumberList(-1, 12);
            }
        },

        /**
         * Get all possible last days values in format of selection
         * @param startDay: startDay
         * @param periodType
         * @returns {*|Array}
         */
        getPossibleLastDays: function (startDay, periodType) {
            var realStartDay = (startDay && !isNaN(startDay)) ? startDay: 1;
            if(startDay === -1){
                // In case last day, only 1 day last
                return this.genIntNumberList(1, 1);
            }
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.WEEK) {
                return this.genIntNumberList(1, 7 - realStartDay + 1);
            }
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.MONTH) {
                return this.genIntNumberList(1, 31 - realStartDay + 1);
            }
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.QUARTER) {
                return this.genIntNumberList(1, 31 - realStartDay + 1);
            }
            if (periodType * 1 === DocumentConstants.CalendarTemplateItem.periodType.YEAR) {
                return this.genIntNumberList(1, 31 - realStartDay + 1);
            }
        },

        genIntNumberList: function (start, length) {
            var result = [];
            for (i = start; i <= length; i++) {
                result.push({id: i, text: i});
            }
            return result;
        },

        formatDayStatus: function (status) {
            var $element = ServiceUtilityHelper.formatSelectWithIcon(status, [{
                id: DocumentConstants.WorkCalendarDayItem.dayStatus.VOCATION, iconClass: 'md md md-landscape content-green'
            }, {
                id: DocumentConstants.WorkCalendarDayItem.dayStatus.WORK, iconClass: 'md md-computer content-red'
            }], true);
            return $element;
        },

        loadPropertyCore: function (oSettings) {
            var vm = this;
            this.$http.get(oSettings.url).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                $(oSettings.element).empty();
                setTimeout(function () {
                    $(oSettings.element).select2({
                        data: resultList,
                        templateResult: oSettings.templateResult,
                        templateSelection: oSettings.templateSelection
                    });
                    // manually set initial value
                    if (oSettings.initValue) {
                        $(oSettings.element).val(oSettings.initValue);
                        $(oSettings.element).trigger("change");
                    } else {
                        if (resultList && resultList.length > 0) {
                            $(oSettings.element).val(resultList[0].id);
                            $(oSettings.element).trigger("change");
                        }
                    }
                }, 0);
            });
        },

        setOnlineSelectionCore: function(oSettings){
            $(oSettings.element).empty();
            $(oSettings.element).select2({
                data: oSettings.resultList,
                templateResult: oSettings.templateResult,
                templateSelection: oSettings.templateSelection
            });
        },

        setSelectLastDays: function(calendarTemplateItem){
            var vm = this;
            var resultList = this.getPossibleLastDays(calendarTemplateItem.startDay, calendarTemplateItem.periodType);
            this.setOnlineSelectionCore({
                element: vm.eleLastDays,
                resultList: resultList
            });
        },

        setSelectStartDay: function(calendarTemplateItem){
            var vm = this;
            var resultList = this.getPossibleStartDays(calendarTemplateItem.periodType);
            this.setOnlineSelectionCore({
                element: vm.eleStartDay,
                resultList: resultList
            });
        },

        setSelectStartMonth: function(calendarTemplateItem){
            var vm = this;
            var resultList = this.getPossibleStartMonths(calendarTemplateItem.periodType);
            this.setOnlineSelectionCore({
                element: vm.eleStartMonth,
                resultList: resultList
            });
        },


        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'calendarTemplateUIModel', content.calendarTemplateUIModel);
            vm.$set(vm.content, 'calendarTempWorkScheduleUIModelList', content.calendarTempWorkScheduleUIModelList);
            vm.$set(vm.content, 'calendarTemplateItemUIModelList', content.calendarTemplateItemUIModelList);
            vm.getPeriodType(vm.cache.calendarTemplateItem);
            vm.getVocationType(vm.cache.calendarTemplateItem);
            vm.getDayStatus(vm.cache.calendarTemplateItem);
            vm.setSelectStartMonth(vm.cache.calendarTemplateItem);
            vm.setSelectStartDay(vm.cache.calendarTemplateItem);
            vm.setSelectLastDays(vm.cache.calendarTemplateItem);

        },

        editCalendarTempWorkScheduleModal: function (uuid) {
            var item = this._filterItemByUUID(uuid, this.content.calendarTempWorkScheduleUIModelList);
            if (!item) {
                return;
            }
            this.cache.calendarTempWorkSchedule = this.copyCalendarTempWorkSchedule(item);
            $(this.eleEditCalendarTempWorkScheduleModal).modal('toggle');
        },

        setToCalendarTempWorkSchedule: function () {
            var item = this._filterItemByUUID(this.cache.calendarTempWorkSchedule.uuid, this.content.calendarTempWorkScheduleUIModelList);
            if (!item) {
                //In case new Item added
                var newItem = this.copyCalendarTempWorkSchedule(this.cache.calendarTempWorkSchedule);
                this.content.calendarTempWorkScheduleUIModelList.push(newItem);
            } else {
                this.copyCalendarTempWorkSchedule(this.cache.calendarTempWorkSchedule, item);
            }
            $(this.eleEditCalendarTempWorkScheduleModal).modal('hide');
        },

        newCalendarTempWorkScheduleModal: function () {
            var baseUUID = this.content.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            this.$http.post(this.newCalendarTempWorkScheduleServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                // In case success.
                this.cache.calendarTempWorkSchedule = this.copyCalendarTempWorkSchedule(JSON.parse(response.data).content, this.cache.calendarTempWorkSchedule);
                $(this.eleEditCalendarTempWorkScheduleModal).modal('toggle');
            });

        },

        deleteCalendarTempWorkSchedule: function () {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.calendarTempWorkScheduleUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, content.calendarTempWorkScheduleUIModelList);
                    } else {
                        // do nothing, just return
                    }
                });
        },

        addCalendarTempWorkSchedule: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.calendarTemplateUIModel.uuid;
            var resultURL = "CalendarTempWorkScheduleEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },

        editCalendarTempWorkSchedule: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            window.location.href = genCommonEditURL("CalendarTempWorkScheduleEditor.html", uuid);

        },

        editCalendarTemplateItemModal: function (uuid) {
            var vm = this;
            var item = this._filterItemByUUID(uuid, this.content.calendarTemplateItemUIModelList);
            if (!item) {
                return;
            }
            this.cache.calendarTemplateItem = this.copyCalendarTemplateItem(item);
            vm.getPeriodType(vm.cache.calendarTemplateItem);
            vm.getVocationType(vm.cache.calendarTemplateItem);
            vm.getDayStatus(vm.cache.calendarTemplateItem);
            vm.setSelectStartMonth(vm.cache.calendarTemplateItem);
            vm.setSelectStartDay(vm.cache.calendarTemplateItem);
            vm.setSelectLastDays(vm.cache.calendarTemplateItem);
            $(this.eleEditCalendarTemplateItemModal).modal('toggle');
        },

        setToCalendarTemplateItem: function () {
            var item = this._filterItemByUUID(this.cache.calendarTemplateItem.uuid, this.content.calendarTemplateItemUIModelList);
            if (!item) {
//In case new Item added
                var newItem = this.copyCalendarTemplateItem(this.cache.calendarTemplateItem);
                this.content.calendarTemplateItemUIModelList.push(newItem);
            } else {
                this.copyCalendarTemplateItem(this.cache.calendarTemplateItem, item);
            }
            $(this.eleEditCalendarTemplateItemModal).modal('hide');
        },

        newCalendarTemplateItemModal: function () {
            var vm = this;
            var baseUUID = this.content.calendarTemplateUIModel.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            this.$http.post(this.newCalendarTemplateItemServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
// In case success.
                this.cache.calendarTemplateItem = this.copyCalendarTemplateItem(JSON.parse(response.data).content, this.cache.calendarTemplateItem);
                vm.getPeriodType(vm.cache.calendarTemplateItem);
                vm.getVocationType(vm.cache.calendarTemplateItem);
                vm.getDayStatus(vm.cache.calendarTemplateItem);
                vm.setSelectStartMonth(vm.cache.calendarTemplateItem);
                vm.setSelectStartDay(vm.cache.calendarTemplateItem);
                vm.setSelectLastDays(vm.cache.calendarTemplateItem);
                $(this.eleEditCalendarTemplateItemModal).modal('toggle');
            });

        },

        deleteCalendarTemplateItem: function () {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = vm._filterItemByUUID(uuid, vm.content.calendarTemplateItemUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, content.calendarTemplateItemUIModelList);
                    } else {
// do nothing, just return
                    }
                });
        },

        addCalendarTemplateItem: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.calendarTemplateUIModel.uuid;
            var resultURL = "CalendarTemplateItemEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;

        },

        editCalendarTemplateItem: function (uuid) {
            var vm = this;
            var requestData = generateServiceSimpleContentUnion("uuid", uuid);
            window.location.href = genCommonEditURL("CalendarTemplateItemEditor.html", uuid);

        }

    }
});
