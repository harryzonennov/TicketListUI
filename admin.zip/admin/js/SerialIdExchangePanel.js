/**
 * Embedded Panel for Doc Mat Item to maintain multiple serial ids for multiple registered instance
 * Dependency: PopBottomPanel
 */
var SerialIdExchangePanel = Vue.extend({
    name: "serial-id-exchange-panel",
    data: function () {
        "use strict";
        return {
            label: {
                confirm:'',
                confirmTitle:'',
                refMaterialSKUId:'',
                refMaterialSKUName:'',
                grossAmount:'',
                serialIdList:'',
                serialIdListComment:'',
            },
            valueContent: {
                refTemplateMaterialSKUUUID:'',
                serialIdList:[]
            },
            meta:{
                initLoadUrl:'',
                updateUrl:'',
                selectSerialIdListUrl:'',
                errorHandle:'',
                initCheckEmpty:'',
                postUpdatee:''
            },
            serialIdInputBatchModel:{},
            cache:{
                serialIdList:'',
                refMaterialSKU:{
                    id:'',
                    name:'',
                    uuid:''
                },
                nonEmptyAmount:0,
                leftAmount:0,
                grossAmount:0,
                grossAmountLabel:''
            }
        };
    },
    created: function(){
        var vm = this;
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            vm.setI18nProperties();
            vm.initSelectConfigure();
        });
    },

    computed: {
        warnMessageTitle: function(){
            return '该物料有空序列号 已经输入[' + this.cache.nonEmptyAmount + "], 还剩余[" + this.cache.leftAmount +  "]";
        },

        eleSerialIdList: function(){
            return 'x_serialIdList' + this.postfix;
        }
    },

    watch: {
        'cache.serialIdList': function (serialIdList) {
            "use strict";
            var vm = this;
            if( !serialIdList ){
                return;
            }
            vm.$set(vm.valueContent, 'serialIdList', serialIdList);
            vm.updateLeftAmount(serialIdList);
            // re-render
            vm.$refs.popBottomPanel.refreshPanel();
        }
    },

    methods: {

        initSubComponents: function () {
            "use strict";
            Vue.component("pop-bottom-panel", PopBottomPanel);
            Vue.component("material-stock-pop-label", MaterialStockPopLabel);
        },

        initSelectConfigure: function() {
            var vm = this;
            $('#' + vm.eleSerialIdList).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache, 'serialIdList', $('#' + vm.eleSerialIdList).val());
                vm.$refs.popBottomPanel.refreshPanel();
            });
        },

        /**
         * Initialize configure
         * @param {object} oSettings
         *          --{string} initLoadUrl
         *          --{string} updateUrl
         *          --{function} errorHandle
         *          --{function} initCheckEmpty
         *          --{function} postUpdate
         */
        initConfigure: function(oSettings){
            "use strict";
            var vm = this;
            // initial load process

            vm.$set(vm.meta, 'initLoadUrl', oSettings.initLoadUrl);
            vm.$set(vm.meta, 'updateUrl', oSettings.updateUrl);
            vm.$set(vm.meta, 'errorHandle', oSettings.errorHandle);
            vm.$set(vm.meta, 'initCheckEmpty', oSettings.initCheckEmpty);
            vm.$set(vm.meta, 'postUpdate', oSettings.postUpdate);
            vm.$set(vm.meta, 'selectSerialIdListUrl', oSettings.selectSerialIdListUrl);
            ServiceUtilityHelper.httpRequest({
                url:oSettings.initLoadUrl,
                $http:vm.$http,
                errorHandle:oSettings.errorHandle,
                postHandle:function(oData){
                    vm.$set(vm, 'serialIdInputBatchModel', oData.content);
                    if(oSettings.initCheckEmpty){
                        oSettings.initCheckEmpty();
                        vm.initCheckEmptySerialIdScheme(vm.serialIdInputBatchModel);
                    }
                }.bind(this)
            });
        },

        setI18nCommonProperties: function () {
            this.label.close = $.i18n.prop('close');
            this.label.cancel = $.i18n.prop('cancel');
            this.label.commit = $.i18n.prop('commit');
            this.label.confirm = $.i18n.prop('confirm');
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {

            this.label.refMaterialSKUId = $.i18n.prop('refMaterialSKUId');
            this.label.refMaterialSKUName = $.i18n.prop('refMaterialSKUName');
            this.label.grossAmount = $.i18n.prop('grossAmount');
            this.label.serialIdArray = $.i18n.prop('serialIdArray');
            this.label.serialIdArrayComment = $.i18n.prop('serialIdArrayComment');
            this.label.serialIdList = $.i18n.prop('serialIdList');
            this.label.serialIdListComment = $.i18n.prop('serialIdListComment');
            $(".save-button").tooltip({title: this.label.saveTitle, placement:'bottom'});

        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'SerialIdInput', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        loadPanel: function (oSettings) {
            var vm = this;
            var serialIdInputModel = oSettings.serialIdInputModel;
            var refMaterialSKU = oSettings.refMaterialSKU;
            var grossAmountLabel = oSettings.grossAmountLabel;
            var grossAmount = oSettings.grossAmount;
            vm.$set(vm, 'valueContent', serialIdInputModel);

            vm.$set(vm.cache, 'refMaterialSKU', refMaterialSKU);
            vm.$set(vm.cache, 'grossAmountLabel', grossAmountLabel);
            vm.$set(vm.cache, 'grossAmount', grossAmount);
            vm.updateLeftAmount(serialIdInputModel.serialIdList);
            vm.$refs.popBottomPanel.showPanel();
        },

        updateLeftAmount: function(serialIdList){
            var vm = this;
            var nonEmptyAmount = RegisteredProductManager.getNonEmptySerialAmount(serialIdList);
            var leftAmount = vm.cache.grossAmount - nonEmptyAmount;
            vm.$set(vm.cache, 'nonEmptyAmount', nonEmptyAmount);
            vm.$set(vm.cache, 'leftAmount', leftAmount);
        },

        checkWhenUpdate: function(){
            var vm = this;
            var disableConfirm = vm.disableConfirm();
            if(disableConfirm === true){
                return undefined;
            }
            return true;
        },

        disableConfirm: function(){
            var vm = this;
            vm.updateLeftAmount(vm.valueContent.serialIdList);
            if(vm.cache.leftAmount > 0){
                return true;
            }
            return undefined;
        },

        displayFocus: function(){
            var vm = this;
            var disableConfirm = vm.disableConfirm();
            if(disableConfirm === true){
                return undefined;
            }
            return 'focus-info';
        },


        saveModule: function(){
            var vm = this;
            var checkResult = vm.checkWhenUpdate();
            if(!checkResult){
                return;
            }
            // this.$emit('update', vm.valueContent);
            vm.updateSerialInputModelScheme(vm.valueContent,{
                serialIdInputTopModel:vm.serialIdInputBatchModel,
                postUrl:vm.meta.updateUrl,
                errorHandle: vm.meta.errorHandle,
                postHandle: function(){
                    if(vm.meta.postUpdate){
                        vm.meta.postUpdate();
                    }
                }.bind(this)
            });
            vm.$refs.popBottomPanel.hidePanel();
        },

        /**
         * Utility method array
         */
        initCheckEmptySerialIdScheme: function(serialIdInputTopModel){
            var vm = this;
            var emptyInputModel = vm.filterEmptySerialIdInput(serialIdInputTopModel);
            if(emptyInputModel){
                emptyInputModel = emptyInputModel.model;
                vm.loadPanel({
                    serialIdInputModel:emptyInputModel,
                    refMaterialSKU: emptyInputModel.refTemplateMaterialSKU,
                    grossAmountLabel: emptyInputModel.grossAmountLabel,
                    grossAmount: emptyInputModel.grossAmount
                });
            }
        },

        editSerialIdScheme: function (docMatItemUIModel){
            "use strict";
            var vm = this;
            var refTemplateSKUUUID = docMatItemUIModel.refMaterialTemplateUUID;
            var serialIdInputModel = vm.filterSerialInputModelByTemplateSKUUUID(refTemplateSKUUUID, vm.serialIdInputBatchModel);
            if(serialIdInputModel){
                serialIdInputModel = serialIdInputModel.model;
                vm.loadSerialIdSelectArray(serialIdInputModel, docMatItemUIModel.uuid);
                vm.loadPanel({
                    serialIdInputModel:serialIdInputModel,
                    refMaterialSKU: serialIdInputModel.refTemplateMaterialSKU,
                    grossAmountLabel: serialIdInputModel.grossAmountLabel,
                    grossAmount: serialIdInputModel.grossAmount
                });
            }
        },

        getSerialIdArrayPromise: function (uuid) {
            "use strict";
            var vm = this;
            return new Promise(function (resolve, reject) {
                ServiceUtilityHelper.httpRequest({
                    url: vm.meta.selectSerialIdListUrl,
                    $http: vm.$http,
                    uuid: uuid,
                    errorHandle: function(error){
                        reject({'msg': error});
                        vm.errorHandle(error);
                    },
                    postHandle: function (oData) {
                        if(oData.content && oData.content.length > 0){
                            var serialIdSelectList = [];
                            oData.content.forEach(function(serialId){
                                serialIdSelectList.push({id:serialId, text: serialId});
                            });
                            resolve(serialIdSelectList);
                        }else{
                            resolve([]);
                        }

                    }.bind(this)
                });
            }.bind(this));
        },

        loadSerialIdSelectArray: function (serialIdInputModel, uuid) {
            var vm = this;
            var serialIdSelectListPromise = vm.getSerialIdArrayPromise(uuid);
            serialIdSelectListPromise.then(function (serialIdSelectList) {
                setTimeout(function () {
                    vm._setSerialIdList(serialIdInputModel, serialIdSelectList);
                }, 0);
            });
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.message-container.serialIdExchange')
            });
        },

        _setSerialIdList: function (serialIdInputModel, serialIdSelectList) {
            var vm = this;
            $('#' + vm.eleSerialIdList).select2({
                multiple: true,
                data: serialIdSelectList
            });
            if (serialIdInputModel && serialIdInputModel.serialIdList) {
                $('#' + vm.eleSerialIdList).val(serialIdInputModel.serialIdList);
                $('#' + vm.eleSerialIdList).trigger("change");
            }
        },


        updateSerialInputModelScheme: function(serialInputModel, oSettings){
            var vm = this;
            var serialIdInputTopModel = oSettings.serialIdInputTopModel;
            var postUrl = oSettings.postUrl;
            var refTemplateMaterialSKUUUID = serialInputModel.refTemplateMaterialSKUUUID;
            var oldSerialInputModel = vm.filterSerialInputModelByTemplateSKUUUID(refTemplateMaterialSKUUUID, serialIdInputTopModel);
            var index = -1;
            if(oldSerialInputModel){
                index = oldSerialInputModel.index;
                serialInputModel = oldSerialInputModel.model;
                if(index >= 0){
                    vm.$set(serialIdInputTopModel.serialIdInputModelList[index], 'serialIdList', serialInputModel.serialIdList);
                    ServiceUtilityHelper.httpRequest({
                        url: postUrl,
                        method:'post',
                        requestData: serialIdInputTopModel,
                        $http: vm.$http,
                        errorHandle:oSettings.errorHandle,
                        postHandle:oSettings.postHandle
                    });
                }
            }
        },

        filterEmptySerialIdInput: function(serialIdInputTopModel){
            "use strict";
            if(!serialIdInputTopModel || !serialIdInputTopModel.serialIdInputModelList){
                return;
            }
            return ServiceCollectionsHelper.filterWithIndex(serialIdInputTopModel.serialIdInputModelList, function (serialIdInputModel){
                var nonEmptyAmount = RegisteredProductManager.getNonEmptySerialAmount(serialIdInputModel.serialIdList);
                return nonEmptyAmount < serialIdInputModel.grossAmount;
            });
        },


        filterSerialInputModelByTemplateSKUUUID: function(refTemplateSKUUUID, serialIdInputTopModel){
            "use strict";
            if(!serialIdInputTopModel || !serialIdInputTopModel.serialIdInputModelList){
                return;
            }
            return ServiceCollectionsHelper.filterWithIndex(serialIdInputTopModel.serialIdInputModelList, function (serialIdInputModel){
                return refTemplateSKUUUID === serialIdInputModel.refTemplateMaterialSKUUUID;
            });
        },

    },

    template:
        '<div>'+
        '    <pop-bottom-panel ref="popBottomPanel">' +
        '        <template v-slot:content>' +
        '            <div class="row">\n' +
        '                   <div class="col-lg-12">\n' +
        '                                 <div class="portlet">\n' +
        '                                        <div class="portlet-heading bg-lightgrey">\n' +
        '                                                    <h3 class="portlet-title "><i class="nmd nmd-filter-9 content-lightblue"></i> ' +
        '                                                           批量设置序列号</h3>&nbsp; \n' +
        '                                                    <button :disabled="disableConfirm()" type="button" :class="displayFocus()" class="btn btn-action btn-rounded-embed-search btn-success-reverse embed-secHeaderLeft ' +
        '                                                       embed-sectHeader save-button"  @click="saveModule" data-original-title="" title="">' +
        '                                                       <i class="md md-check embedIcon"></i>  {{label.confirm}}</span> '+
        '                                                    </button>'+
        '                                                    <div class="portlet-widgets">\n' +
        '                                                    </div>\n' +
        '                                                    <div class="clearfix"></div>\n' +
        '                                        </div>\n' +
        '                                         <div class="portlet-body">\n' +
        '                                                      <div class="message-container serialIdExchange ">' +
        '                                                      </div>\n' +
        '                                                      <div class="message-container2 serialIdExchange " v-show="cache.leftAmount > 0">' +
        '                                                           <div class="row message-title">' +
        '                                                                <div class="col-sm-12">' +
        '                                                                   <div class="message-title-box background-messageError">' +
        '                                                                         <i class="md md-close content-red"></i>' +
        '                                                                          <span class="page-title" v-text="warnMessageTitle"></span>' +
        '                                                                   </div>\n' +
        '                                                                </div>\n' +
        '                                                           </div>\n' +
        '                                                      </div>\n' +
        '                                                      <div class="row">\n' +
        '                                                            <div class="col-md-4">\n' +
        '                                                                <form action="#" class="form-horizontal" role="form">\n' +
        '                                                                    <div class="form-group">\n' +
        '                                                                         <material-stock-pop-label :label-value="label.refMaterialSKUName" \n' +
        '                                                                                                      label-class="col-md-4 control-label"\n' +
        '                                                                                                      :target-uid="cache.refMaterialSKU.uuid"\n' +
        '                                                                                                      :header-title="label.refMaterialSKUName"></material-stock-pop-label>\n' +
        '                                                                        <div class="col-md-7">' +
        '                                                                            <input type="text" disabled="true" class="form-control" v-model="cache.refMaterialSKU.name"/>\n' +
        '                                                                        </div>\n' +
        '                                                                    </div>\n' +
        '                                                                </form>\n' +
        '                                                            </div>\n' +
        '                                                            <div class="col-md-4">\n' +
        '                                                                <form action="#" class="form-horizontal" role="form">\n' +
        '                                                                    <div class="form-group">\n' +
        '                                                                        <label class=" col-md-4 control-label">{{label.refMaterialSKUId}}</label>\n' +
        '                                                                        <div class="col-md-7">' +
        '                                                                            <input type="text" disabled="true" class="form-control" v-model="cache.refMaterialSKU.id"/>\n' +
        '                                                                        </div>\n' +
        '                                                                    </div>\n' +
        '                                                                </form>\n' +
        '                                                            </div>\n' +
        '                                                            <div class="col-md-4">\n' +
        '                                                                <form action="#" class="form-horizontal" role="form">\n' +
        '                                                                    <div class="form-group">\n' +
        '                                                                        <label class=" col-md-4 control-label">{{label.grossAmount}}</label>\n' +
        '                                                                        <div class="col-md-4">' +
        '                                                                            <input type="text" disabled="true" class="form-control" v-model="cache.grossAmountLabel"/>\n' +
        '                                                                        </div>\n' +
        '                                                                    </div>\n' +
        '                                                                </form>\n' +
        '                                                            </div>\n' +
        '                                                        </div>' +
        '                                                        <div class="lean-hr-seperate header-offset border-darkblue"></div>\n' +
        '                                                        <div class="row">\n' +
        '                                                            <div class="col-md-4">\n' +
        '                                                                <form action="#" class="form-horizontal" role="form">\n' +
        '                                                                    <div class="form-group">\n' +
        '                                                                        <label class=" col-md-4 control-label">{{label.serialIdList}}</label>\n' +
        '                                                                        <div class="col-md-8">\n' +
        '                                                                             <select :id="eleSerialIdList" class="form-control" v-model="cache.serialIdList"></select>\n' +
 '                                                                                   <span className="help-block"><small>{{label.serialIdListComment}}</small></span>\n' +
        '                                                                        </div>\n' +
        '                                                                    </div>\n' +
        '                                                                </form>\n' +
        '                                                            </div>\n' +
        '                                                          </div>' +
        '                                                    </div>' +
        '                                      </div>' +
        '                                 </div>' +
        '                       </div>' +
        '         </template>' +
        '    </pop-bottom-panel>' +
        '</div>'

});
