/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var MaterialTypeManager = function () {

};

MaterialTypeManager.label = {
    materialType:{
        id: '',
        name: '',
        note: '',
        rootTypeId: '',
        rootTypeName: '',
        rootTypeNote: '',
        parentTypeId: '',
        parentTypeName: '',
        parentTypeNote: '',
        cancel:'',
        confirm:'',
        materialTypeSection: '',
        rootTypeSection: '',
        parentTypeSection: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgSystemFailure: '',
        msgUnknowSystemFailure: '',
        parentTypeUUID: '',
        clearSearch:'',
        clearSearchComment:'',
        advancedSearchCondition: '',
        buttonEdit: '',
        buttonView: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        exit: '',
        close: '',
        commit: '',
        modelTitle:''
    }
};

MaterialTypeManager.content = {
    materialTypeUIModel: {
        parentTypeUUID: '',
        id: '',
        name: '',
        note: '',
        rootTypeUUID: '',
        rootTypeId: '',
        rootTypeName: '',
        rootTypeNote: '',
        parentTypeId: '',
        parentTypeName: ''
    }
};

MaterialTypeManager.prototype.getModelTitle = function(){
    return MaterialTypeManager.label.materialType.modelTitle;
};

/**
 * [API] Get root node inst id
 */
MaterialTypeManager.getRootNodeInstId = function(){
    return "materialType";
};

/**
 * [API] Get resource id for checking authorization
 */
MaterialTypeManager.getResourceId = function(){
    return ServiceModuleConstants.MaterialType;
};

/**
 * [API] Get document type
 */
MaterialTypeManager.getDocumentType = function(){
    return DocumentConstants.DummyDocumentType.MaterialType;
};

/**
 * [API]Get root 18n config
 */
MaterialTypeManager.getI18nRootConfig = function () {
    return {
        i18nPath: 'coreFunction/',
        mainName: 'MaterialType',
        modelId: 'MaterialType', coreModelId: 'MaterialType'
    };
};


/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
MaterialTypeManager.prototype.getI18nWrap = function (fnCallback) {
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "coreFunction/",
        fnCallback: fnCallback,
        commonCallback: MaterialTypeManager.setI18nCommonProperties,
        configList: [{
            name: 'MaterialType',
            callback: MaterialTypeManager.setNodeI18nPropertiesCore
        }]
    });
};



MaterialTypeManager.setI18nCommonProperties = function () {
    ServiceUtilityHelper.setI18nCommonReflective(MaterialTypeManager.label.materialType, $.i18n.prop);
};

MaterialTypeManager.setNodeI18nPropertiesCore = function () {
    ServiceUtilityHelper.setI18nReflective(MaterialTypeManager.label.materialType, $.i18n.prop, true);
};



/**
 * Definition of Tab on UI
 * @type {{}}
 */
MaterialTypeManager.documentTab = {
    materialSection:'tabMaterialSection',
    materialUnitSection: 'tabMaterialUnitSection'
};


/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
MaterialTypeManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../materialType/loadModuleViewService.html';
};

/**
 * @override Get Basic URL for load document list.
 * @returns {string}
 */
MaterialTypeManager.prototype.getLoadSelectListURL = function () {
    "use strict";
    return '../materialType/loadModuleListService.html';
};


MaterialTypeManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: "MaterialTypeEditor.html",
        url: "../materialType/loadModuleViewService.html",
        label:MaterialTypeManager.label.materialType,
        getI18nWrap:this.getI18nWrap.bind(vm)
    });

    var fieldMetaList = [{
        fieldName:'materialTypeUIModel.id',
    },{
        fieldName:'materialTypeUIModel.name',
    },{
        fieldName:'materialTypeUIModel.parentTypeId',
    },{
        fieldName: 'materialTypeUIModel.parentTypeName'
    },{
        fieldName: 'materialTypeUIModel.rootTypeId'
    },{
        fieldName: 'materialTypeUIModel.rootTypeName'
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};


