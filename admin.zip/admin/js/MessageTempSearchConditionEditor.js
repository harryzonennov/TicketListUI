var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: {
            fieldName: '',
            logicOperator: '',
            searchOperator: '',
            fieldValue: '',
            note: '',
            dataSourceProviderId:'',
            dataOffsetValue:'',
            dataOffsetDirection:'',
            addMessageTempSearchCondition: '',
            parentPageTitle:'',
            pageTitle:'',
            messageTempSearchConditionSection: '',
            msgSaveOK: '',
            msgSaveOKComment: '',
            msgConnectFailure: '',
            msgUnknowSystemFailure: '',
            msgLoadDataFailure: '',
            index: '',
            lockFailureMessage: '',
            save: '',
            exit: '',
            quickEdit: '',
            buttonDelete: '',
            close: '',
            deleteWarnTitle: '',
            deleteWarnText: '',
            cancel: '',
            commit: '',
            confirm: ''
        },
        content: {
            parentNodeUUID:'',
            uuid: '',
            client: '',
            dataSourceProviderId:'',
            dataOffsetValue:'',
            dataOffsetDirection:'',
            fieldName: '',
            logicOperator: '',
            parentNodeId: '',
            searchOperator: '',
            fieldValue: '',
            note: ''
        },
        author: {
            resourceId: ServiceModuleConstants.MessageTemplate,
            actionCode: {
                Edit: false,
                View: false,
                PriceInfo: false,
                Delete: false,
                Excel: false
            }
        },
        meta:{
            providerOffsetUnitVisible: false,
            providerOffsetValueVisible: false,
            providerOffsetDirection:false
        },
        eleLogicOperator: '#x_logicOperator',
        eleFieldName: '#x_fieldName',
        eleProviderOffsetUnit: '#x_providerOffsetUnit',
        eleProviderDirection: '#x_providerOffsetDirection',
        eleDataProvider: '#x_dataProvider',
        getPageHeaderModelListURL: '../messageTempPrioritySetting/getPageHeaderModelList.html',
        loadModuleEditURL: '../messageTempSearchCondition/loadModuleEditService.html',
        saveModuleURL: '../messageTempSearchCondition/saveModuleService.html',
        exitModuleURL: '../messageTempSearchCondition/exitEditor.html',
        getLogicOperatorURL: '../messageTempSearchCondition/getLogicOperator.html',
        getSearchFieldNameListURL: '../messageTempSearchCondition/getSearchFieldNameList.html',
        getDataProviderMapURL: '../messageTemplate/getDataProviderMap.html',
        getProviderOffsetUnitURL: '../messageTemplate/getProviderOffsetUnit.html',
        getProviderOffsetDirectionURL: '../messageTemplate/getProviderOffsetDirection.html',
        getProviderOffsetDirectionTemplateURL: '../messageTemplate/getProviderOffsetDirectionTemplate.html',
        getProviderOffsetUnitTemplateURL:'../messageTemplate/getProviderOffsetUnitTemplate.html',
        newModuleServiceURL: '../messageTempSearchCondition/newModuleService.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
        vm.initAuthorResourceCheck();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            Navigator.loadNavigation($('#x_navigationGroup'), $('#sidebar-menu'), 'systemAdmin', 'MessageTemplate');
            this.setI18nProperties();
            this.initSelectConfigure();
            this.loadModuleEdit();
        });
    },

    methods: {

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function () {
            "use strict";
            Vue.component("page-header-union", PageHeaderUnion);
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleLogicOperator).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'logicOperator', $(vm.eleLogicOperator).val());
            });
            $(vm.eleFieldName).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'fieldName', $(vm.eleFieldName).val());
            });
            $(vm.eleDataProvider).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                var providerId = $(vm.eleDataProvider).val();
                vm.$set(vm.content, 'dataSourceProviderId', providerId);
                vm.getProviderOffsetUnit(providerId);
                vm.getProviderOffsetDirection(providerId);
            });
            $(vm.eleProviderDirection).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'dataOffsetDirection', $(vm.eleProviderDirection).val());
            });
            $(vm.eleProviderOffsetUnit).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content, 'dataOffsetUnit', $(vm.eleProviderOffsetUnit).val());
            });

        },

        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgConnectFailure = $.i18n.prop('msgConnectFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.msgLoadDataFailure = $.i18n.prop('msgLoadDataFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.quickEdit = $.i18n.prop('quickEdit');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.deleteWarnTitle = $.i18n.prop('deleteWarnTitle');
            this.label.deleteWarnText = $.i18n.prop('deleteWarnText');
            this.label.cancel = $.i18n.prop('cancel');
            this.label.commit = $.i18n.prop('commit');
            this.label.confirm = $.i18n.prop('confirm');
            BusyLoader.cleanPageBackground();

        },

        setNodeI18nPropertiesCore: function () {
            this.label.fieldName = $.i18n.prop('fieldName');
            this.label.logicOperator = $.i18n.prop('logicOperator');
            this.label.searchOperator = $.i18n.prop('searchOperator');
            this.label.fieldValue = $.i18n.prop('fieldValue');
            this.label.note = $.i18n.prop('note');
            this.label.parentPageTitle = $.i18n.prop('parentPageTitle');
            this.label.pageTitle = $.i18n.prop('pageTitle');
            this.label.dataSourceProviderId = $.i18n.prop('dataSourceProviderId');
            this.label.addMessageTempSearchCondition = $.i18n.prop('addMessageTempSearchCondition');
            this.label.messageTempSearchConditionSection = $.i18n.prop('messageTempSearchConditionSection');
            this.label.dataOffsetValue = $.i18n.prop('dataOffsetValue');
            this.label.dataOffsetDirection = $.i18n.prop('dataOffsetDirection');

        },

        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'MessageTempSearchCondition', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });

        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            if (processMode === PROCESSMODE_NEW) {
// in case [Create mode]
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                ServiceUtilityHelper.httpRequest({
                    url:this.newModuleServiceURL,
                    $http:vm.$http,
                    method:'post',
                    requestData: requestData,
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        this.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }

            if (processMode === PROCESSMODE_EDIT) {
// In case [Edit mode]

                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    errorHandle:vm.errorHandle,
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }
        },


        getPageHeaderModelList: function(uuid, baseUUID){
            var vm = this;
            vm.$refs.pageHeader.initPageHeader({
                uuid:uuid,
                baseUUID: baseUUID,
                pageHeaderListUrl:vm.getPageHeaderModelListURL,
                fnPageHeaderModel:vm.fnPageHeaderModel
            });
        },

        fnPageHeaderModel:function(pageHeaderModel){
            var vm = this;
            if (pageHeaderModel.nodeInstId === 'messageTemplate'){
                var targetTab = MessageTempPriorityManager.documentTab.messageTemplateSection;
                baseDocURL = genCommonEditURL("MessageTemplateEditor.html", pageHeaderModel.uuid, targetTab);
                pageHeaderModel.pageLink = baseDocURL;
                pageHeaderModel.pageTitle = vm.label.parentPageTitle + ":" + vm.content.parentNodeId;
                return pageHeaderModel;
            }
        },

        saveModule: function () {
            var vm = this;
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            ServiceUtilityHelper.httpRequest({
                url:this.saveModuleURL,
                $http:vm.$http,
                method:'post',
                requestData: vm.content,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    $.Notification.notify('success', 'top center', vm.label.msgSaveOK, vm.label.msgSaveOKComment);
                    vm.setModuleToUI(oData.content);
                    var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
                    if (processMode && processMode === PROCESSMODE_NEW) {
                        var baseUUID = vm.content.uuid;
                        if (baseUUID) {
                            window.location.href = genCommonEditURL("MessageTempSearchConditionEditor.html", baseUUID);
                        }
                    }
                }.bind(this)
            });
        },


        getLogicOperator: function () {
            var vm = this;
            ServiceUtilityHelper.loadMetaRequest({
                url: vm.getLogicOperatorURL,
                $http: vm.$http,
                formatMeta:SystemStandrdMetadataProxy.formatLogicOperator,
                initValue: vm.content.logicOperator,
                element: vm.eleLogicOperator,
                errorHandle: vm.errorHandle
            });
        },

        getSearchFieldNameList: function (content) {
            var vm = this;
            var baseUUID = vm.content.parentNodeUUID;
            this.$http.get(this.getSearchFieldNameListURL + "?baseUUID=" + baseUUID).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    return;
                }
                var resultList = formatSelectResult(oData.content, 'fieldName', 'fieldName');
                setTimeout(function () {
                    $(vm.eleFieldName).select2({
                        data: resultList,
                    });
                    // manually set initial value
                    $(vm.eleFieldName).val(content.fieldName);
                    $(vm.eleFieldName).trigger("change");
                }, 0);
            });

        },

        getDataProvider: function (content) {
            var vm = this;
            this.$http.get(this.getDataProviderMapURL).then(function (response) {
                var oData = JSON.parse(response.data);
                setTimeout(function () {
                    $(vm.eleDataProvider).select2({
                        data: oData
                    });
                    // manually set initial value
                    $(vm.eleDataProvider).val(content.dataSourceProviderId);
                    $(vm.eleDataProvider).trigger("change");
                    // Also trigger
                    vm.getProviderOffsetUnit(content.dataSourceProviderId);
                    vm.getProviderOffsetDirection(content.dataSourceProviderId);
                }, 0);
            });

        },

        getProviderOffsetDirection: function (providerId) {
            var vm = this;
            var metaSettings = {metaUrl:this.getProviderOffsetDirectionTemplateURL, $http:vm.$http};
            var directionTemplatePromise = MessageTempPriorityManager.getProviderMetaTemplate(providerId, metaSettings);
            this.$http.get(this.getProviderOffsetDirectionURL + "?providerId=" + providerId).then(function (response) {
                var oData = JSON.parse(response.data);
                if(oData && oData.length > 0){
                    vm.$set(vm.meta, 'providerOffsetValueVisible', true);
                    vm.$set(vm.meta, 'providerOffsetDirectionVisible', true);
                }
                directionTemplatePromise.then(function(metaTemplate){
                    setTimeout(function () {
                        $(vm.eleProviderDirection).select2({
                            data: oData,
                            templateResult:metaTemplate,
                            templateSelection:metaTemplate
                        });
                        // manually set initial value
                        $(vm.eleProviderDirection).val(vm.content.dataOffsetDirection);
                        $(vm.eleProviderDirection).trigger("change");
                    }, 0);
                });
            });
        },


        getProviderOffsetUnit: function (providerId) {
            var vm = this;
            var metaSettings = {metaUrl:this.getProviderOffsetUnitTemplateURL, $http:vm.$http};
            var offsetUnitTemplatePromise = MessageTempPriorityManager.getProviderMetaTemplate(providerId, metaSettings);
            this.$http.get(this.getProviderOffsetUnitURL + "?providerId=" + providerId).then(function (response) {
                var oData = JSON.parse(response.data);
                offsetUnitTemplatePromise.then(function(metaTemplate){
                    setTimeout(function () {
                        $(vm.eleProviderOffsetUnit).select2({
                            data: oData,
                            templateResult:metaTemplate,
                            templateSelection:metaTemplate
                        });
                        if(oData && oData.length > 0){
                            vm.$set(vm.meta, 'providerOffsetUnitVisible', true);
                        }
                        // manually set initial value
                        $(vm.eleProviderOffsetUnit).val(vm.content.dataOffsetUnit);
                        $(vm.eleProviderOffsetUnit).trigger("change");
                    }, 0);
                });

            }.bind(this));
        },


        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.parentNodeUUID;
            window.location.href = genCommonEditURL("MessageTemplateEditor.html", baseUUID);

        },

        refreshEditView: function () {
            var baseUUID = this.content.uuid;
            window.location.href = genCommonEditURL("MessageTempSearchConditionEditor.html", baseUUID);

        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm, 'content', content);
            // this.setPageHeaderLink();
            vm.getPageHeaderModelList(content.uuid, content.parentNodeUUID);
            this.getLogicOperator(content);
            this.getSearchFieldNameList(content);
            vm.getDataProvider(content);

        }

    }
});
