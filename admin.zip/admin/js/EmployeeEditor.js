var rightBar = new Vue({
    el: "#rightBarHoc",
    mixins: [ServiceRightBarPanelHelper.defTimelineMinxin, EmployeeManager.labelTemplate],
    data: function () {
        return {
            label: EmployeeManager.label.employee,
            selectMeta: {
                iconClassMap: {
                    "employee.status": EmployeeManager.getStatusIconArray()
                },
                data: {
                    "employee.status": ""
                }
            }
        };
    },

    methods: {
        setI18nProperties: function (fnCallback) {
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'Employee',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        getActionMeta: function(){
            return {"actionCodeMap": EmployeeManager.getActionCodeIconMap()};
        },

        initHelpDocumentList: function (uuid) {
            "use strict";
            var vm = this;
            ServiceRightBarPanelHelper.initHelpDocumentWithAction({
                uuid: uuid,
                vm: vm,
                getDocActionNodeListURL: '../employee/getDocActionNodeList.html',
                errorHandle: dataVar.errorHandle,
                helpDocumentName: ['EmployeeHelpDocument']
            });
        }
    }
});

var dataVar = new Vue({
    el: "#x_data",
    mixins: [EmployeeManager.labelTemplate],
    data: {
        employeeOrgTableId: '#x_table_employeeOrg',
        employeeOrgTable: {},
        label: EmployeeManager.label.employee,
        content: {
            employeeUIModel: EmployeeManager.content.employeeUIModel,
            employeeOrgUIModelList: [],
            employeeAttachmentUIModelList: []
        },
        cache: {
            employeeOrg: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                employeeRole: '',
                organizationId: '',
                organizationName: '',
                organizationFunction: '',
                refUUID: ''
            }
        },

        author:{
            resourceId:ServiceModuleConstants.Employee,
            actionCode:{
                Edit:false,
                View:false,
                PriceInfo: false,
                Delete: false,
                Excel:false
            }
        },
        attachmentMeta:{
            loadAttachmentURL: '../employee/loadAttachment.html',
            deleteAttachmentURL: '../employee/deleteAttachment.html',
            uploadAttachmentURL: '../employee/uploadAttachment.html',
            uploadAttachmentTextURL: '../employee/uploadAttachmentText.html'
        },
        attachmentLabel:{
            attachmentSection:'产品图片'
        },
        docActionConfigureList:[],
        processButtonMeta: [],
        embedProcessButtonMeta:[],
        eleGender: '#x_gender',
        eleStatus: '#x_status',
        eleWorkRole: '#x_workRole',
        eleBirthDay: '#x_birthDate',
        eleBoardDate: '#x_boardDate',
        eleOperateType: '#x_operateType',
        eleJobLevel: '#x_jobLevel',
        eleOrganizationFunction: '#x_organizationFunction',
        loadOrganizationListURL: '../organization/loadModuleListService.html',
        eleEditEmployeeOrgModal: '#x_eleEditEmployeeOrgModal',
        eleRefOrganization: '#x_refRefOrganization',
        getDocActionConfigureListURL: '../employee/getDocActionConfigureList.html',
        loadOrganizationURL: '../organization/loadModule.html',
        eleEmployeeAttachmentModal: '#x_employeeAttachmentModal',
        loadModuleEditURL: '../employee/loadModuleEditService.html',
        loadModuleViewURL: '../employee/loadModuleViewService.html',
        saveModuleURL: '../employee/saveModuleService.html',
        newModuleServiceURL: '../employee/newModuleService.html',
        activeServiceURL: '../employee/activeService.html',
        archiveServiceURL: '../employee/archiveService.html',
        reInitServiceURL: '../employee/reInitService.html',
        getGenderURL: '../employee/getGender.html',
        getStatusURL: '../employee/getStatus.html',
        getWorkRoleURL: '../employee/getWorkRole.html',
        getJobLevelURL: '../employee/getJobLevel.html',
        executeDocActionURL:'../employee/executeDocAction.html',
        getOrganizationFunctionMapURL: '../organization/getOrganizationFunctionMap.html',
        getOperateTypeURL: '../employee/getOperateType.html',
        newEmployeeOrgServiceURL: '../employeeOrg/newModuleService.html',
        removeEmployeeOrgServiceURL: '../employee/removeEmployeeFromOrgService.html',
        assignEmployeeToOrgServiceURL: '../employee/assignEmployeeToOrgService.html',
        exitURL: 'EmployeeList.html',
        exitModuleURL: '../employee/exitEditor.html'
    },

    created: function(){
        "use strict";
        var vm = this;
        vm.initAuthorResourceCheck();
        vm.initDocActionConfigureList();
        vm.initSubComponents();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'Employee');
            this.setI18nProperties(vm.initProcessButtonMeta);
            this.loadModuleEdit();
            this.initSelectConfigure();
            this.employeeOrgTable = new ServiceDataTable(this.employeeOrgTableId);
            this.initDatePickerConfigure();
        });
    },

    watch: {
        'content.employeeUIModel.stateName': function (stateName) {
            this.updateAddressInfo({
                stateName: stateName,
                cityName: this.content.employeeUIModel.cityName,
                townZone: this.content.employeeUIModel.townZone,
                streetName: this.content.employeeUIModel.streetName,
                telephone: this.content.employeeUIModel.mobile
            });
        },
        'content.employeeUIModel.cityName': function (cityName) {
            this.updateAddressInfo({
                stateName: this.content.employeeUIModel.stateName,
                cityName: cityName,
                townZone: this.content.employeeUIModel.townZone,
                streetName: this.content.employeeUIModel.streetName,
                telephone: this.content.employeeUIModel.telephone
            });
        },
        'content.employeeUIModel.townZone': function (townZone) {
            this.updateAddressInfo({
                stateName: this.content.employeeUIModel.stateName,
                cityName: this.content.employeeUIModel.cityName,
                townZone: townZone,
                streetName: this.content.employeeUIModel.streetName,
                telephone: this.content.employeeUIModel.mobile
            });
        },
        'content.employeeUIModel.streetName': function (streetName) {
            this.updateAddressInfo({
                stateName: this.content.employeeUIModel.stateName,
                cityName: this.content.employeeUIModel.cityName,
                townZone: this.content.employeeUIModel.townZone,
                streetName: streetName,
                telephone: this.content.employeeUIModel.mobile
            });
        },
        'content.employeeUIModel.mobile': function (telephone) {
            this.updateAddressInfo({
                stateName: this.content.employeeUIModel.stateName,
                cityName: this.content.employeeUIModel.cityName,
                townZone: this.content.employeeUIModel.townZone,
                streetName: this.content.employeeUIModel.streetName,
                telephone: this.content.employeeUIModel.mobile
            });
        }
    },

    methods: {
        updateAddressInfo: function (oSettings) {
            var vm = this;
            var address = ServiceUtilityHelper.buildAddressInfo(oSettings);
            if (!vm.addressInfoInit) {
                vm.$set(vm.content, 'address', address);
            }
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSubComponents: function() {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("attachment-union", AttachmentUnion);
            Vue.component("popup-label", PopupLabel);
            Vue.component("doc-action-modal", DocActionModal);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        /**
         * @Overwrite: Get document type for each edit controller
         */
        getDocumentType: function () {
            return DocumentConstants.DummyDocumentType.Employee;
        },

        getServiceManager: function () {
            return EmployeeManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "EmployeeEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.employeeUIModel.uuid;
        },

        /**
         * @Overwrite: get document status from content
         */
        getStatus: function () {
            return this.content.employeeUIModel.status;
        },

        /**
         * @Overwrite provide doc action code matrix
         * @return {*}
         */
        getActionCodeMatrix: function () {
            return {
                submit: {actionCode: EmployeeManager.DOC_ACTION_CODE.SUBMIT},
                revokeSubmit: {actionCode: EmployeeManager.DOC_ACTION_CODE.REVOKE_SUBMIT},
                approve: {actionCode: EmployeeManager.DOC_ACTION_CODE.APPROVE},
                reInit: {actionCode: EmployeeManager.DOC_ACTION_CODE.REINIT},
                rejectApprove: {actionCode: EmployeeManager.DOC_ACTION_CODE.REJECT_APPROVE},
                countApprove: {actionCode: EmployeeManager.DOC_ACTION_CODE.COUNTAPPROVE},
                active: {actionCode: EmployeeManager.DOC_ACTION_CODE.ACTIVE},
                archive: {actionCode: EmployeeManager.DOC_ACTION_CODE.ARCHIVE}
            };
        },

        initDocActionConfigureList: function (){
            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:vm.getDocActionConfigureListURL,
                $http:vm.$http,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    vm.$set(vm, 'docActionConfigureList', oData.content);
                }.bind(this)
            });
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nCommonReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
            $("#x_btn_active").tooltip({title: this.label.activeTitle});
            $("#x_btn_archive").tooltip({title: this.label.archiveTitle});
            $("#x_btn_reInit").tooltip({title: this.label.reInitTitle});
        },

        setNodeI18nEmployeeOrgProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.employeeOrg, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'Employee',
                    callback: this.setNodeI18nPropertiesCore
                }, {
                    name: 'EmployeeOrg',
                    callback: this.setNodeI18nEmployeeOrgProperties
                },{
                    actionNode: vm.label.actionNode
                }]
            });
        },


        getI18nPath: function () {
            return "coreFunction/";
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleGender).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.employeeUIModel, 'gender', $(vm.eleGender).val());
            });
            $(vm.eleStatus).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.employeeUIModel, 'status', $(vm.eleStatus).val());
            });
            $(vm.eleOperateType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.employeeUIModel, 'operateType', $(vm.eleOperateType).val());
            });
            $(vm.eleWorkRole).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.employeeUIModel, 'workRole', $(vm.eleWorkRole).val());
            });
            $(vm.eleJobLevel).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.employeeUIModel, 'jobLevel', $(vm.eleJobLevel).val());
            });
            $(vm.eleRefOrganization).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.employeeOrg, 'refUUID', $(vm.eleRefOrganization).val());
                var url = vm.loadOrganizationURL + "?uuid=" + $(vm.eleRefOrganization).val();
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        return;
                    }
                    vm.$set(vm.cache.employeeOrg, 'organizationId', oData.content.id);
                    vm.$set(vm.cache.employeeOrg, 'organizationFunction', oData.content.organizationFunction);
                    vm.getOrganizationFunction(vm.cache);
                });
            });
            $(vm.eleOrganizationFunction).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.employeeOrg, 'organizationFunction', $(vm.eleOrganizationFunction).val());
            });

        },

        initDatePickerConfigure: function () {
            var vm = this;
            ServiceDataPickerHelper.initDatePicker({
                element:vm.eleBirthDay,
                callBack: function(val){
                    vm.content.employeeUIModel.birthDate = val;
                }
            });

            ServiceDataPickerHelper.initDatePicker({
                element:vm.eleBoardDate,
                callBack: function(val){
                    vm.content.employeeUIModel.boardDate = val;
                }
            });
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },


        displayForActionCodeConfig: function(oSettings){
            return ServiceUtilityHelper.displayForActionCodeConfig({
                currentStatus:this.content.employeeUIModel.status * 1,
                docActionConfigureList:this.docActionConfigureList,
                targetActionCode:oSettings.targetActionCode,
                accessActionCodeModel:this.author.actionCode,
                renderModel: oSettings.renderModel,
                involveTaskStatus:oSettings.involveTaskStatus,
            });
        },

        displayForApprove: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.APPROVE,
                renderModel:{approve:{}},
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForRejectApprove: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.REJECT_APPROVE,
                renderModel:{approve:{}},
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForSubmit: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.SUBMIT,
                renderModel:{approve:{}},
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForRevokeSubmit: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.REVOKE_SUBMIT,
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForActive: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.ACTIVE,
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForReInit: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.REINIT,
                involveTaskStatus: this.involveTaskStatus
            });
        },

        genActionNodeInitConfigure: function(oSettings){
            var vm = this;
            if(!oSettings.targetUrl){
                oSettings.targetUrl = vm.executeDocActionURL;
            }
            if(!oSettings.serviceUIModel){
                oSettings.serviceUIModel = vm.content;
            }
            if(!oSettings.postHandle){
                oSettings.postHandle = vm.refreshEditView;
            }
            if(!oSettings.getActionCodeURL){
                oSettings.getActionCodeURL = vm.getActionCodeMapURL;
            }
            if(!oSettings.actionIconMap){
                oSettings.actionIconMap = LogonUserManager.getActionCodeIconMap();
            }
            return oSettings;
        },


        loadOrganizationSelectList: function (cache) {
            var vm = this;
            this.$http.get(this.loadOrganizationListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                setTimeout(function () {
                    $(vm.eleRefOrganization).select2({
                        data: resultList
                    });
                    if (cache && cache.employeeOrg && cache.employeeOrg.refUUID) {
                        // manually set initial value
                        $(vm.eleRefOrganization).val(cache.employeeOrg.refUUID);
                        $(vm.eleRefOrganization).trigger("change");
                    } else {
                        if (resultList && resultList.length > 0) {
                            $(vm.eleRefOrganization).val(resultList[0].id);
                            $(vm.eleRefOrganization).trigger("change");
                        }
                    }
                }, 0);
            });
        },


        setToOrganization: function () {
            "use strict";

            var vm = this;
            var requestData = {
                uuid: this.cache.employeeOrg.uuid,
                parentNodeUUID: this.cache.employeeOrg.parentNodeUUID,
                rootNodeUUID: this.cache.employeeOrg.rootNodeUUID,
                employeeRole: this.cache.employeeOrg.employeeRole,
                refUUID: this.cache.employeeOrg.refUUID
            };
            this.$http.post(this.assignEmployeeToOrgServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                        container: $('.main.message-container')
                    });
                    return;
                }

                // In case success.
                this.cache.employeeOrg = this.copyEmployeeOrgUIModel(JSON.parse(response.data).content, this.cache.employeeOrg);
                var item = ServiceCollectionsHelper.filterArray(this.cache.employeeOrg.uuid, 'uuid', this.content.employeeOrgUIModelList);
                if (!item) {
                    //In case new Item added
                    var newItem = this.copyEmployeeOrgUIModel(this.cache.employeeOrg);
                    if (!this.content.employeeOrgUIModelList) {
                        this.content.employeeOrgUIModelList = [];
                    }
                    this.content.employeeOrgUIModelList.push(newItem);
                } else {
                    this.copyEmployeeOrgUIModel(this.cache.employeeOrg, item);
                }
                $(this.eleEditEmployeeOrgModal).modal('hide');
                setTimeout(function () {
                    vm.refreshEditView(EmployeeManager.documentTab.organizationSection);
                }, 200);
            }.bind(this)).catch(function(error){
                ServiceHttpRequestHelper.handleErrorWithBarWrap(error, {
                    container: $('.main.message-container')
                });
                return;
            }.bind(this));

        },


        /**
         * Deprecate
         */
        copyEmployeeOrgUIModel: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refUUID = origin.refUUID;
            target.organizationId = origin.organizationId;
            target.organizationName = origin.organizationName;
            target.organizationFunction = origin.organizationFunction;
            return target;
        },


        newOrganizationModal: function () {
            var vm = this;
            var rootNodeUUID = this.content.employeeUIModel.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", rootNodeUUID);
            this.loadOrganizationSelectList(vm.cache);
            this.$http.post(this.newEmployeeOrgServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                        container: $('.main.message-container')
                    });
                    return;
                }
                // In case success.
                this.cache.employeeOrg = this.copyEmployeeOrgUIModel(JSON.parse(response.data).content, this.cache.employeeOrg);
                $(this.eleEditEmployeeOrgModal).modal('toggle');
            }).catch(function(error){
                ServiceHttpRequestHelper.handleErrorWithBarWrap(error, {
                    container: $('.main.message-container')
                });
            });

        },

        deleteEmployeeOrg: function (uuid) {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var url = vm.removeEmployeeOrgServiceURL + '?uuid=' + uuid;
                        vm.$http.get(url).then(function (response) {
                            var oData = JSON.parse(response.data);
                            var _index = ServiceCollectionsHelper.removeItemByUUID(uuid, vm.content.employeeOrgUIModelList);
                        });
                    } else {
                        // do nothing, just return
                    }
                });
        },


        editEmployeeOrgModal: function (uuid) {
            var vm = this;
            var item = filterListItemByUUIDReflective(this.content, uuid);
            if (!item) {
                return;
            }
            this.cache.employeeOrg = this.copyEmployeeOrgUIModel(item);
            this.loadOrganizationSelectList(vm.cache);
            this.getOrganizationFunction(vm.cache);
            $(this.eleEditEmployeeOrgModal).modal('toggle');
        },


        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if (processMode * 1 === PROCESSMODE_NEW) {
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                ServiceUtilityHelper.httpRequest({
                    url:vm.newModuleServiceURL,
                    $http:vm.$http,
                    method:'post',
                    requestData: requestData,
                    errorHandle:vm.errorHandle,
                    postHandle:function(oData){
                        vm.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if (processMode * 1 === PROCESSMODE_EDIT) {
                // In case [Edit mode]
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl:this.loadModuleEditURL,
                    viewUrl:this.loadModuleViewURL,
                    uuid:baseUUID,
                    author:vm.author,
                    initAuthor: function(author){vm.$set(vm, 'author', author);},
                    $http:vm.$http,
                    messageContainer: $('.main.message-container'),
                    postSet:vm.setModuleToUI
                });
            }
        },


        errorHandle: function(oData){
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        saveModule: function () {
            var vm = this;
            ServiceUtilityHelper.defSaveModuleWrapper({
                vm: vm,
                editorPage: "EmployeeEditor.html",
                fnGetBaseUUID: function (){
                    return vm.content.employeeUIModel.uuid;
                }
            });
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var embedProcessButtonMeta = [{
                button: {
                    id: 'batchAddMatList',
                    label: vm.label.batchAddMatList,
                    title: vm.label.batchAddMatList,
                    disableFlag: vm.disableNotInInit,
                    icon: 'md md-more-vert',
                    formatClass: '',
                    callback: '',
                }
            }];
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                active: {
                    label: vm.label.active,
                    formatClass: vm.displayForActive,
                    iconClass: 'ion-wand content-pink',
                    callback: vm.activeService
                },
                reInit: {
                    label: vm.label.reInit,
                    formatClass: vm.displayForReInit,
                    iconClass: 'glyphicon glyphicon-pencil content-green',
                    callback: vm.reInitService
                },
                submit: {
                    formatClass: vm.displayForSubmit,
                    callback: vm.submitService
                },
                revokeSubmit: {
                    formatClass: vm.displayForRevokeSubmit,
                    callback: vm.revokeSubmitService
                },
                approve: {
                    formatClass: vm.displayForApprove,
                    callback: vm.approveOrder
                },
                rejectApprove: {
                    formatClass: vm.displayForApprove,
                    callback: vm.rejectApproveService
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$set(vm, 'embedProcessButtonMeta', embedProcessButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },


        revokeSubmitService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.revokeSubmitWarnTitle,
                warnText:vm.label.actionNode.revokeSubmitWarnText,
                actionCode:LogonUserManager.DOC_ACTION_CODE.REVOKE_SUBMIT
            }));
        },

        submitService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.submitWarnTitle,
                warnText:vm.label.actionNode.submitWarnText,
                preValidate:vm.validateSave,
                actionCode:LogonUserManager.DOC_ACTION_CODE.SUBMIT
            }));
        },


        rejectApproveService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.rejectApproveWarnTitle,
                warnText:vm.label.actionNode.rejectApproveWarnText,
                preValidate:vm.validateSave,
                actionCode:LogonUserManager.DOC_ACTION_CODE.REJECT_APPROVE
            }));
        },

        approveService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.approveWarnTitle,
                warnText:vm.label.actionNode.approveWarnText,
                preValidate:vm.validateSave,
                actionCode:LogonUserManager.DOC_ACTION_CODE.APPROVE
            }));
        },

        activeService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.activeWarnTitle,
                warnText:vm.label.activeWarnMessage,
                preValidate:vm.validateSave,
                actionCode:LogonUserManager.DOC_ACTION_CODE.ACTIVE
            }));
        },

        reInitService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.approveWarnTitle,
                warnText:vm.label.actionNode.approveWarnText,
                preValidate:vm.validateSave,
                actionCode:LogonUserManager.DOC_ACTION_CODE.REINIT
            }));
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.employeeUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitModuleURL, this.exitURL, UIFLAG_STANDARD);
        },

        refreshEditView: function (tabKey) {
            var baseUUID = this.content.employeeUIModel.uuid;
            window.location.href = genCommonEditURL("EmployeeEditor.html", baseUUID, tabKey);
        },

        getGender: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getGenderURL,
                $http: vm.$http,
                formatMeta:EmployeeManager.formatGender,
                initValue: vm.content.employeeUIModel.gender,
                element: vm.eleGender,
                errorHandle: vm.errorHandle
            });
        },

        getStatus: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getStatusURL,
                $http: vm.$http,
                formatMeta:EmployeeManager.formatStatus,
                postHandle:function(resultList){
                    if(rightBar){
                        rightBar.updateSelectMetaData('employee.status', resultList);
                    }
                },
                initValue: vm.content.employeeUIModel.status,
                element: vm.eleStatus,
                errorHandle: vm.errorHandle
            });
        },

        getOperateType: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getOperateTypeURL,
                $http: vm.$http,
                postHandle:function(resultList){
                    if(rightBar){
                        rightBar.updateSelectMetaData('employee.operateType', resultList);
                    }
                },
                initValue: vm.content.employeeUIModel.operateType,
                element: vm.eleOperateType,
                errorHandle: vm.errorHandle
            });
        },

        getWorkRole: function () {
            var vm = this;
            ServiceUtilityHelper.loadMetaWithCustomReq({
                url: vm.getWorkRoleURL,
                $http: vm.$http,
                initValue: vm.content.employeeUIModel.workRole,
                idField:'id',
                textField:'name',
                element: vm.eleWorkRole,
                errorHandle: vm.errorHandle
            });
        },

        getJobLevel: function () {
            var vm = this;
            ServiceUtilityHelper.loadMetaWithCustomReq({
                url: vm.getJobLevelURL,
                $http: vm.$http,
                initValue: vm.content.employeeUIModel.jobLevel,
                idField:'id',
                textField:'name',
                element: vm.eleJobLevel,
                errorHandle: vm.errorHandle
            });
        },


        getOrganizationFunction: function (cache) {
            var vm = this;
            ServiceUtilityHelper.loadMetaWithCustomReq({
                url: vm.getOrganizationFunctionMapURL,
                $http: vm.$http,
                initValue: vm.content.employeeUIModel.organizationFunction,
                idField:'id',
                textField:'name',
                element: vm.eleOrganizationFunction,
                errorHandle: vm.errorHandle
            });
            // this.$http.get(this.getOrganizationFunctionMapURL).then(function (response) {
            //     if (!JSON.parse(response.body)) {
            //         // pop up error message
            //     }
            //     var orgFunctionMapArray = JSON.parse(response.body).content;
            //     var _formatOrgFunction = ServiceUtilityHelper.genTemplateFormatFunction(orgFunctionMapArray);
            //     var resultList = formatSelectResult(orgFunctionMapArray, 'id', 'name');
            //     setTimeout(function () {
            //         $(vm.eleOrganizationFunction).select2({
            //             data: resultList,
            //             templateResult: _formatOrgFunction,
            //             templateSelection: _formatOrgFunction
            //         });
            //         // manually set initial value
            //         $(vm.eleOrganizationFunction).val(cache.employeeOrg.organizationFunction);
            //         $(vm.eleOrganizationFunction).trigger("change");
            //     }, 0);
            // });
        },

        openRightSideBar: function(key){
            NavigationPanelIns.openRightSideBar(RightBarTemplate.TABS.tab2, key);
        },

        loadOrganizationFunction: function () {
            var vm = this;
            OrganizationManager.loadOrganizationFunctionSelectList({
                $http: vm.$http,
                fnCallBack: function (orgFunctionMapArray) {
                    vm.$set(vm, 'orgFunctionMapArray', orgFunctionMapArray);
                    setTimeout(function () {
                        vm.employeeOrgTable.buildWithCache({
                            "pageLength": 5
                        });
                    }, 0);
                }.bind(this)
            });
        },

        formatOrgFunctionClass: function (organizationFunction) {
            var $element = ServiceCollectionsHelper.filterArray(organizationFunction, 'id', this.orgFunctionMapArray);
            if ($element) {
                return $element.iconClass;
            }
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'employeeUIModel', content.employeeUIModel);
            vm.$set(vm.content, 'employeeOrgUIModelList', content.employeeOrgUIModelList);
            vm.$set(vm.content, 'employeeAttachmentUIModelList', content.employeeAttachmentUIModelList);
            if (content.employeeUIModel.address) {
                vm.$set(vm, 'addressInfoInit', true);
            }
            vm.loadOrganizationFunction();
            vm.getGender();
            vm.getStatus();
            vm.getWorkRole();
            vm.getJobLevel();
            vm.getOperateType();
            rightBar.initHelpDocumentList(vm.content.employeeUIModel.uuid);
        },

        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'EmployeeEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: EmployeeManager,
                coreModelId: 'Employee',
                i18nPath: 'coreFunction/',
                getDocActionNodeListURL: '../employee/getDocActionNodeList.html',
                helpDocumentName: ['EmployeeHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: 'displayForEdit',
                        callback: 'saveModule'
                    },
                    placeholder: {
                        category: ProcessButtonConstants.placeholderCategory.DOC_ACTION_BTN
                    },
                    exit: {
                        callback: 'exitModule'
                    }
                },
                tabMetaList: [{
                    tabId: 'employeeSection',
                    tabTitleKey: 'employeeSection',
                    titleLabelKey: 'employeeSection',
                    titleHelpKey: 'employee.employeeSection',
                    titleIcon: 'md md-texture content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'employeeSection',
                        updatedByUidPath: 'updatedByUUID',
                        updatedByNamePath: 'updatedByName',
                        updatedDatePath: 'updatedDate',
                        messageResponsePath: 'meta.messageResponse',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'employeeUIModel',
                        tabTitleKey: 'employeeSection',
                        titleLabelKey: 'employeeSection',
                        titleHelpKey: 'employee.employeeSection',
                        titleIcon: 'md md-content-paste content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'id',
                            required: true,
                            newRow: true
                        }, {
                            required: true,
                            fieldName: 'name',
                        }, {
                            fieldName: 'status',
                            disabled: true,
                            helpKey: 'employee.status',
                            settings: {
                                getMetaDataUrl: vm.getStatusURL,
                                formatMeta: 'formatStatus'
                            },
                            iconArray: 'getStatusIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'gender',
                            settings: {
                                getMetaDataUrl: vm.getGenderURL,
                                formatMeta: 'formatGender'
                            },
                            iconArray: 'getGenderIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'identification',
                            newRow: true
                        }, {
                            fieldName: 'birthDate',
                        }, {
                            fieldName: 'age',
                        }, {
                            refControl: {
                                id: RefControl.Ids.Separator
                            }
                        },{
                            fieldName: 'boardDate',
                            newRow: true
                        }, {
                            fieldName: 'workRole',
                            disabled: true,
                            helpKey: 'employee.workRole',
                            settings: {
                                getMetaDataUrl: vm.getWorkRoleURL,
                                idField:'id',
                                textField:'name'
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2,
                            newRow: true
                        }, {
                            fieldName: 'jobLevel',
                            disabled: true,
                            helpKey: 'employee.jobLevel',
                            settings: {
                                getMetaDataUrl: vm.getJobLevelURL,
                                idField:'id',
                                textField:'name'
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'operateType',
                            settings: {
                                getMetaDataUrl: vm.getOperateTypeURL,
                                formatMeta: 'formatGender'
                            },
                            iconArray: 'getGenderIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        }]
                    }, {
                        sectionId: 'employeeContactSection',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'employeeUIModel',
                        tabTitleKey: 'employeeContactSection',
                        titleLabelKey: 'employeeContactSection',
                        titleHelpKey: 'employee.employeeContactSection',
                        titleIcon: 'md md-quick-contacts-dialer content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            newRow: true,
                            fieldName: 'logonUserId'
                        }, {
                            fieldName: 'logonUserName',
                        }, {
                            fieldName: 'mobile',
                            newRow: true,
                        }, {
                            fieldName: 'telephone'
                        }, {
                            fieldName: 'fax',
                        }, {
                            fieldName: 'weiXinID'
                        }, {
                            fieldName: 'email'
                        }, {
                            refControl: {
                                id: RefControl.Ids.Separator
                            }
                        }, {
                            newRow: true,
                            fieldName: 'stateName'
                        }, {
                            fieldName: 'cityName'
                        }, {
                            fieldName: 'townZone'
                        }, {
                            fieldName: 'streetName'
                        }, {
                            fieldName: 'address',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea,
                            setAutoValue: {
                                callbackTemplateId:"updateAddressInfo"
                            },
                        }]
                    }, ]
                },{
                    tabId: 'organizationSection',
                    tabTitleKey: 'organizationSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'organizationSection',
                        parentContentPath: 'employeeOrgUIModelList',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        detailedPageUrl: 'EmployeeOrgEditor.html',
                        refItemName: 'employeeOrgPanel',
                        editModuleFlag: true,
                        editModuleModalFlag: true,
                        tabTitleKey: 'employeeOrgSection',
                        titleLabelKey: 'employeeOrgSection',
                        titleHelpKey: 'employee.employeeOrgSection',
                        titleIcon: 'md md-nature-people content-portlet-title',
                        scrollX: true,
                        embedProcessButtonMeta: {
                            addTitle: 'newOrganization',
                            addLabel: 'newOrganization',
                            newModuleModalFlag: true
                        },
                        fieldMetaList: [{
                            fieldName: 'employeeOrgUIModel.uuid'
                        }, {
                            fieldName: 'employeeOrgUIModel.organizationId',
                            labelKey: 'employeeOrg.organizationId',
                            minWidth: '180px'
                        }, {
                            fieldName: 'employeeOrgUIModel.organizationName',
                            labelKey: 'employeeOrg.organizationName',
                            minWidth: '180px'
                        }, {
                            fieldName: 'employeeOrgUIModel.organizationFunctionValue',
                            labelKey: 'employeeOrg.organizationFunction',
                        }, {
                            fieldName: 'employeeOrgUIModel.addressInfo',
                            labelKey: 'employeeOrg.addressInfo',
                        }]
                    }]
                },{
                    tabId: 'employeeAttachmentSection',
                    tabTitleKey: 'employeeAttachmentSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'employeeAttachment',
                        sectionCategory: AsyncSection.sectionCategory.ATTACHMENT,
                        parentContentPath: 'employeeAttachmentUIModelList',
                        errorHandle: 'errorHandle',
                        settings: {
                            configMetaPath: 'attachmentMeta'
                        }
                    }]
                }]
            };
        }

    }
});
