var rightBar = new Vue({
    el: "#rightBarHoc",
    mixins: [ServiceRightBarPanelHelper.defTimelineMinxin, LogonUserManager.labelTemplate],
    data: function () {
        return {
            label: LogonUserManager.label.logonUser,
            selectMeta: {
                iconClassMap: {
                    "logonUser.status": LogonUserManager.getStatusIconArray()
                },
                data: {
                    "logonUser.status": ""
                }
            }
        };
    },

    methods: {

        setI18nProperties: function (fnCallback) {
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "foundation/common/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'LogonUser',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        getI18nPath: function () {
            return "foundation/common/";
        },

        getActionMeta: function(){
            return {"actionCodeMap": LogonUserManager.getActionCodeIconMap()};
        },

        initHelpDocumentList: function (uuid) {
            "use strict";
            var vm = this;
            ServiceRightBarPanelHelper.initHelpDocumentWithAction({
                uuid: uuid,
                vm: vm,
                getDocActionNodeListURL: '../logonUser/getDocActionNodeList.html',
                errorHandle: dataVar.errorHandle,
                helpDocumentName: ['LogonUserHelpDocument']
            });
        }
    }
});

var dataVar = new Vue({
    el: "#x_data",
    mixins: [LogonUserManager.labelTemplate],
    data: {
        userroleTableId: '#x_table_role',
        userroleTable: {},
        organizationTableId: '#x_table_organization',
        organizationTable: {},
        equipmentreferenceTableId: '#x_table_equipmentreference',
        equipmentreferenceTable: {},
        label: LogonUserManager.label.logonUser,
        content: {
            logonUserUIModel:LogonUserManager.content.logonUserUIModel,
            userRoleUIModelList: [],
            logonUserOrganizationUIModelList: []
        },
        author: {
            resourceId: 'LogonUser',
            actionCode: {
                Edit: false,
                View: false,
                PriceInfo: false,
                Delete: false,
                Excel: false
            }
        },
        cache: {
            newPassword: '',
            resetPassword: '',
            extensionPromise: '',
            userRole: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refSEName: '',
                refNodeName: '',
                refUUID: '',
                roleName: '',
                roleId: '',
                roleNote: ''
            },
            logonUserOrganization: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                workRole:'',
                client: '',
                refSEName: '',
                refNodeName: '',
                refUUID: '',
                organizationId: '',
                organizationName: ''
            }
        },
        systemConfigureResource: {
            systemConfigureResourceUIModel: {
                id: '',
                scenarioMode: '',
                standardSystemCategory: '',
                name: '',
                note: ''
            },
            systemConfigureExtensionUnionUIModelList: [],
            systemConfigureElementUIModelList: []
        },
        docActionConfigureList:[],
        processButtonMeta: [],
        embedProcessButtonMeta:[],
        orgFunctionMapArray:[],
        serviceExtensionSettingHelper: {},
        serviceResourseHelper: {},
        passwordSetType: {},
        eleRefOrgUUID: '#x_refOrgUUID',
        eleRefRoleUUID: '#x_refRoleUUID',
        eleUserType: '#x_userType',
        eleStatus: '#x_status',
        eleResetPasswordModal: '#x_resetPasswordModal',
        eleAddRoleModal: '#x_addRoleModal',
        eleEditLogonUserOrg: '#x_editLogonUserOrg',
        eleOrganizationFunction: '#x_organizationFunction',
        eleWorkRole: '#x_workRole',
        loadModuleEditURL: '../logonUser/loadModuleEditService.html',
        resetPasswordURL: '../logonUser/setPasswordService.html',
        saveModuleURL: '../logonUser/saveModuleService.html',
        checkDuplicateIDURL: '../logonUser/checkDuplicateID.html',
        exitModuleURL: '../logonUser/exitEditor.html',
        newModuleServiceURL: '../logonUser/newModuleService.html',
        newModuleWithTemplateService: '../logonUser/newModuleWithTemplateService.html',
        newUserRoleServiceURL: '../userRole/newModuleService.html',
        newLogonUserOrgURL: '../logonUserOrg/newModuleService.html',
        executeDocActionURL: '../logonUser/executeDocAction.html',
        getDocActionConfigureListURL: '../logonUser/getDocActionConfigureList.html',
        assignUserToOrgServiceURL: '../logonUserOrg/saveModuleService.html',
        removeUserFromOrgServiceURL: '../logonUser/removeUserFromOrgService.html',
        activeServiceURL: '../logonUser/activeService.html',
        archiveServiceURL: '../logonUser/archiveService.html',
        loadRoleSelectListURL: '../role/loadModuleListService.html',
        eleEditOrganizationModal: '#x_eleEditOrganizationModal',
        loadOrganizationSelectListURL: '../organization/loadModuleListService.html',
        getOrganizationFunctionMapURL: '../organization/getOrganizationFunctionMap.html',
        getWorkRoleMapURL: '../logonUser/getWorkRoleMap.html',
        loadRoleURL: '../role/loadModuleService.html',
        getUserTypeMapURL: '../logonUser/getUserTypeMap.html',
        getStatusURL: '../logonUser/getStatus.html',
        loadOrganURL: '../organization/loadModuleService.html',
        exitURL: '../logonUser/exitEditor.html',
        postExitURL: 'LogonUserList.html'
    },

    created: function(){
        "use strict";
        var vm = this;
        vm.initSubComponents();
        vm.initDocActionConfigureList();
        vm.initAuthorResourceCheck();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'LogonUser');
            this.setI18nProperties(vm.initProcessButtonMeta);
            this.loadModuleEdit();
            this.initResouceMetaData();
            this.userroleTable = new ServiceDataTable(this.userroleTableId);
            this.organizationTable = new ServiceDataTable(this.organizationTableId);
            this.equipmentreferenceTable = new ServiceDataTable(this.equipmentreferenceTableId);
            window.addEventListener('beforeunload', this.exitHandler);
            this.initSelectConfigure();
            this.initSwitchery();
        });
    },

    methods: {

        initResouceMetaData: function () {
            var vm = this;
            this.serviceResourseHelper = new ServiceResourseHelper();
            var oFilterSetting = {
                $http: vm.$http,
                resourceLevel: ServiceResourseHelper.ResourceLevel.ConfigureResource,
                id: 'LogonUser'
            };
            var resultPromise = this.serviceResourseHelper.getExtensionValue(oFilterSetting);
            resultPromise.then(function (result) {
                vm.$set(vm, 'systemConfigureResource', result);
                var oSetting = {
                    resourceLevel: ServiceResourseHelper.ResourceLevel.ConfigureResource,
                    id: 'LogonUser',
                    filterExtendKeyName: 'id',
                    filterExtendKeyValue: 'PlatformPasswordSetType'
                };
                this.passwordSetType = this.serviceResourseHelper.filterExtensionUnion(oSetting, this.systemConfigureResource);
                console.log(this.passwordSetType);
            }.bind(this));
        },

        initExtenstionMetaData: function (id) {
            var vm = this;
            if (ServiceExtensionSettingHelper) {
                this.serviceExtensionSettingHelper = new ServiceExtensionSettingHelper();
            }
            return new Promise(function (resolve, reject) {
                var resultPromise = this.serviceExtensionSettingHelper.getExtensionById(id, vm.$http);
                resultPromise.then(function (result) {
                    if (result) {
                        var fieldList = result.serviceExtendFieldSettingUIModelList;
                        resolve(fieldList);
                    } else {
                        resolve();
                    }
                }.bind(this));
            }.bind(this));
        },

        initAuthorResourceCheck: function () {
            var vm = this;
            var authorPromise = ServiceApplicationFactory.getAuthorizationObject(this.$http, this.author.resourceId, this.author.actionCode);
            authorPromise.then(function (oResult) {
                vm.author = oResult;
            }, function (reason) {
                // don't do anything
            });
        },

        initDocActionConfigureList: function (){
            var vm = this;
            ServiceUtilityHelper.httpRequest({
                url:vm.getDocActionConfigureListURL,
                $http:vm.$http,
                errorHandle:vm.errorHandle,
                postHandle:function(oData){
                    vm.$set(vm, 'docActionConfigureList', oData.content);
                }.bind(this)
            });
        },

        /**
         * @Overwrite: Get document type for each edit controller
         */
        getDocumentType: function () {
            return DocumentConstants.DummyDocumentType.LogonUser;
        },

        getServiceManager: function () {
            return LogonUserManager;
        },

        /**
         * @Overwrite: Get Current Edit page URL
         */
        getEditPageURL: function () {
            return "LogonUserEditor.html";
        },

        /**
         * @Overwrite: Get Base UUID value from controller data content
         */
        getBaseUUID: function () {
            return this.content.logonUserUIModel.uuid;
        },

        /**
         * @Overwrite: get document status from content
         */
        getStatus: function () {
            return this.content.logonUserUIModel.status;
        },

        /**
         * @Overwrite provide doc action code matrix
         * @return {*}
         */
        getActionCodeMatrix: function () {
            return {
                submit: {actionCode: LogonUserManager.DOC_ACTION_CODE.SUBMIT},
                revokeSubmit: {actionCode: LogonUserManager.DOC_ACTION_CODE.REVOKE_SUBMIT},
                approve: {actionCode: LogonUserManager.DOC_ACTION_CODE.APPROVE},
                reInit: {actionCode: LogonUserManager.DOC_ACTION_CODE.REINIT},
                rejectApprove: {actionCode: LogonUserManager.DOC_ACTION_CODE.REJECT_APPROVE},
                countApprove: {actionCode: LogonUserManager.DOC_ACTION_CODE.COUNTAPPROVE},
                active: {actionCode: LogonUserManager.DOC_ACTION_CODE.ACTIVE},
                archive: {actionCode: LogonUserManager.DOC_ACTION_CODE.ARCHIVE}
            };
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nCommonReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },

        setI18nLogonUserOrgProperties: function () {
            ServiceUtilityHelper.setI18nReflective(this.label.logonUserOrg, $.i18n.prop, true);
        },

        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "foundation/common/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'LogonUser',
                    callback: this.setNodeI18nPropertiesCore
                }, {
                    name: 'LogonUserOrg',
                    callback: this.setI18nLogonUserOrgProperties
                },{
                    actionNode: vm.label.actionNode
                }]
            });
        },

        displayForActionCodeConfig: function(oSettings){
            return ServiceUtilityHelper.displayForActionCodeConfig({
                currentStatus:this.content.logonUserUIModel.status * 1,
                docActionConfigureList:this.docActionConfigureList,
                targetActionCode:oSettings.targetActionCode,
                accessActionCodeModel:this.author.actionCode,
                renderModel: oSettings.renderModel,
                involveTaskStatus:oSettings.involveTaskStatus,
            });
        },

        displayForApprove: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.APPROVE,
                renderModel:{approve:{}},
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForRejectApprove: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.REJECT_APPROVE,
                renderModel:{approve:{}},
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForSubmit: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.SUBMIT,
                renderModel:{approve:{}},
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForRevokeSubmit: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.REVOKE_SUBMIT,
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForActive: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.ACTIVE,
                involveTaskStatus: this.involveTaskStatus
            });
        },

        displayForReInit: function () {
            return this.displayForActionCodeConfig({
                targetActionCode: LogonUserManager.DOC_ACTION_CODE.REINIT,
                involveTaskStatus: this.involveTaskStatus
            });
        },

        genActionNodeInitConfigure: function(oSettings){
            var vm = this;
            if(!oSettings.targetUrl){
                oSettings.targetUrl = vm.executeDocActionURL;
            }
            if(!oSettings.serviceUIModel){
                oSettings.serviceUIModel = vm.content;
            }
            if(!oSettings.postHandle){
                oSettings.postHandle = vm.refreshEditView;
            }
            if(!oSettings.getActionCodeURL){
                oSettings.getActionCodeURL = vm.getActionCodeMapURL;
            }
            if(!oSettings.actionIconMap){
                oSettings.actionIconMap = LogonUserManager.getActionCodeIconMap();
            }
            return oSettings;
        },

        exitHandler: function () {
            defaultExitEditor(baseUUID, this.exitURL,
                null, UIFLAG_STANDARD);
        },

        getI18nPath: function () {
            return "foundation/common/";
        },

        changePassword: function () {
            $(this.eleResetPasswordModal).modal('toggle');
        },

        initSubComponents: function() {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("attachment-union", AttachmentUnion);
            Vue.component("doc-action-modal", DocActionModal);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        /**
         * Deprecate
         */
        copyLogonUserOrg: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.workRole = origin.workRole;
            target.refSEName = origin.refSEName;
            target.refNodeName = origin.refNodeName;
            target.organizationId = origin.organizationId;
            target.organizationFunction = origin.organizationFunction;
            target.refUUID = origin.refUUID;
            target.organizationName = origin.organizationName;
            return target;
        },

        deleteUserOrg: function (uuid) {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var url = vm.removeUserFromOrgServiceURL + '?uuid=' + uuid;
                        vm.$http.get(url).then(function (response) {
                            var oData = JSON.parse(response.data);
                            var _index = ServiceCollectionsHelper.removeItemByUUID(uuid, vm.content.logonUserOrganizationUIModelList);
                        });
                    } else {
                        // do nothing, just return
                    }
                });
        },
        /**
         * Deprecate
         */
        addLogonUserOrg: function () {
            var vm = this;
            var baseUUID = this.content.logonUserUIModel.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            vm.getOrganizationFunction(vm.cache);
            vm.getWorkRole();
            this.$http.post(this.newLogonUserOrgURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                this.cache.logonUserOrganization = this.copyLogonUserOrg(JSON.parse(response.data).content, this.cache.logonUserOrganization);
                this.loadOrganizationSelectList(vm.cache);
                $(this.eleEditLogonUserOrg).modal('toggle');
            });
        },
        /**
         * Deprecate
         */
        editLogonUserOrgModal: function (uuid) {
            var vm = this;
            var item = filterListItemByUUIDReflective(this.content, uuid);
            if (!item) {
                return;
            }
            this.cache.logonUserOrganization = this.copyLogonUserOrg(item);
            this.loadOrganizationSelectList(vm.cache);
            this.getOrganizationFunction(vm.cache);
            vm.getWorkRole();
            $(this.eleEditLogonUserOrg).modal('toggle');
        },

        /**
         * Deprecate
         */
        setToLogonUserOrg: function () {
            "use strict";
            var requestData = {
                uuid:this.cache.logonUserOrganization.uuid,
                parentNodeUUID:this.cache.logonUserOrganization.parentNodeUUID,
                rootNodeUUID:this.cache.logonUserOrganization.rootNodeUUID,
                refUUID:this.cache.logonUserOrganization.refUUID,
                workRole: this.cache.logonUserOrganization.workRole
            };
            this.$http.post(this.assignUserToOrgServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                // In case success.
                var item = this._filterItemByUUID(this.cache.logonUserOrganization.uuid, this.content.logonUserOrganizationUIModelList);
                if (!item) {
                    //In case new Item added
                    var newItem = this.copyLogonUserOrg(this.cache.logonUserOrganization);
                    this.content.logonUserOrganizationUIModelList.push(newItem);
                } else {
                    this.copyLogonUserOrg(this.cache.logonUserOrganization, item);
                }
                $(this.eleEditLogonUserOrg).modal('hide');
                setTimeout(function () {
                    this.refreshEditView();
                }, 200);
            }.bind(this));
        },


        refreshEditView: function (tabKey) {
            var baseUUID = this.content.logonUserUIModel.uuid;
            window.location.href = genCommonEditURL("LogonUserEditor.html", baseUUID, tabKey);
        },

        deleteUserRole: function (uuid) {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var _index = ServiceCollectionsHelper.removeItemByUUID(uuid, vm.content.userRoleUIModelList);
                    }
                });
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var embedProcessButtonMeta = [{
                button: {
                    id: 'batchAddMatList',
                    label: vm.label.batchAddMatList,
                    title: vm.label.batchAddMatList,
                    disableFlag: vm.disableNotInInit,
                    icon: 'md md-more-vert',
                    formatClass: '',
                    callback: '',
                }
            }];
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                active: {
                    label: vm.label.active,
                    formatClass: vm.displayForActive,
                    iconClass: 'ion-wand content-pink',
                    callback: vm.activeService
                },
                reInit: {
                    label: vm.label.reInit,
                    formatClass: vm.displayForReInit,
                    iconClass: 'glyphicon glyphicon-pencil content-green',
                    callback: vm.reInitService
                },
                submit: {
                    formatClass: vm.displayForSubmit,
                    callback: vm.submitService
                },
                revokeSubmit: {
                    formatClass: vm.displayForRevokeSubmit,
                    callback: vm.revokeSubmitService
                },
                approve: {
                    formatClass: vm.displayForApprove,
                    callback: vm.approveOrder
                },
                rejectApprove: {
                    formatClass: vm.displayForApprove,
                    callback: vm.rejectApproveService
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$set(vm, 'embedProcessButtonMeta', embedProcessButtonMeta);
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        revokeSubmitService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.revokeSubmitWarnTitle,
                warnText:vm.label.actionNode.revokeSubmitWarnText,
                actionCode:LogonUserManager.DOC_ACTION_CODE.REVOKE_SUBMIT
            }));
        },

        submitService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.submitWarnTitle,
                warnText:vm.label.actionNode.submitWarnText,
                preValidate:vm.validateSave,
                actionCode:LogonUserManager.DOC_ACTION_CODE.SUBMIT
            }));
        },


        rejectApproveService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.rejectApproveWarnTitle,
                warnText:vm.label.actionNode.rejectApproveWarnText,
                preValidate:vm.validateSave,
                actionCode:LogonUserManager.DOC_ACTION_CODE.REJECT_APPROVE
            }));
        },

        approveService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.approveWarnTitle,
                warnText:vm.label.actionNode.approveWarnText,
                preValidate:vm.validateSave,
                actionCode:LogonUserManager.DOC_ACTION_CODE.APPROVE
            }));
        },

        activeService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.activeWarnTitle,
                warnText:vm.label.activeWarnMessage,
                preValidate:vm.validateSave,
                actionCode:LogonUserManager.DOC_ACTION_CODE.ACTIVE
            }));
        },

        reInitService: function () {
            var vm = this;
            vm.$refs.docActionModal.initLoad(vm.genActionNodeInitConfigure({
                warnTitle:vm.label.actionNode.approveWarnTitle,
                warnText:vm.label.actionNode.approveWarnText,
                preValidate:vm.validateSave,
                actionCode:LogonUserManager.DOC_ACTION_CODE.REINIT
            }));
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true: undefined);
        },

        displayInInit: function () {
            var status = this.content.logonUserUIModel.status * 1 ;
            if(!this.author.actionCode.Edit){
                return DocumentManagerFactory.formatDisplayClass(undefined);
            }
            if (status === DocumentConstants.LogonUser.status.INIT) {
                return DocumentManagerFactory.formatDisplayClass(true);
            }
            return DocumentManagerFactory.formatDisplayClass(undefined);
        },

        displayInActive: function () {
            var status = this.content.logonUserUIModel.status * 1 ;
            if(!this.author.actionCode.Edit){
                return DocumentManagerFactory.formatDisplayClass(undefined);
            }
            if (status === DocumentConstants.LogonUser.status.ACTIVE) {
                return DocumentManagerFactory.formatDisplayClass(true);
            }
            return DocumentManagerFactory.formatDisplayClass(undefined);
        },

        displayInArchive: function () {
            var status = this.content.logonUserUIModel.status * 1 ;
            if(!this.author.actionCode.Edit){
                return DocumentManagerFactory.formatDisplayClass(undefined);
            }
            if (status === DocumentConstants.LogonUser.status.ARCHIVE) {
                return DocumentManagerFactory.formatDisplayClass(true);
            }
            return DocumentManagerFactory.formatDisplayClass();
        },


        addRole: function () {
            var baseUUID = this.content.logonUserUIModel.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            this.$http.post(this.newUserRoleServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
// In case success.
                this.cache.userRole = this.copyUserRole(JSON.parse(response.data).content, this.cache.userRole);
                $(this.eleAddRoleModal).modal('toggle');
            });
        },

        copyUserRole: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.roleId = origin.roleId;
            target.refUUID = origin.refUUID;
            target.roleName = origin.roleName;
            target.roleNote = origin.roleNote;
            return target;
        },

        setToUserRole: function () {
            var item = this._filterItemByUUID(this.cache.userRole.uuid, this.content.userRoleUIModelList);
            if (!item) {
                var newItem = this.copyUserRole(this.cache.userRole);
                this.content.userRoleUIModelList.push(newItem);
            } else {
                this.copyUserRole(this.cache.userRole, item);
            }
            $(this.eleAddRoleModal).modal('hide');
        },

        confirmToChangePassword: function () {
            var vm = this;
            if (vm.cache.newPassword !== vm.cache.confirmPassword) {
                $("#xgroup_confirmPassword").toggleClass("has-error has-feedback");
                return;
            }
            var request = {
                baseUUID: vm.content.logonUserUIModel.uuid,
                newPassword: vm.cache.newPassword,
                confirmPassword: vm.cache.newPassword
            };
            $(this.eleResetPasswordModal).modal('toggle');
            this.$http.post(vm.resetPasswordURL, request).then(function (response) {
                var oData = JSON.parse(response.data);
                if (oData.errorCode * 1 === HttpStatus.SC_OK) {
                    $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgPasswordSuccess);
                }
            });
        },


        _filterItemByUUID: function (uuid, items) {
            if (!items) {
                return;
            }
            for (var i = 0; i < items.length; i++) {
                if (uuid === items[i].uuid) {
                    return items[i];
                }
            }
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleRefRoleUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.userRole, 'refUUID', $(vm.eleRefRoleUUID).val());
                var url = vm.loadRoleURL + "?uuid=" + $(vm.eleRefRoleUUID).val();
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        return;
                    }
                    var content = JSON.parse(response.data).content;
                    vm.$set(vm.cache.userRole, 'roleId', content.id);
                    vm.$set(vm.cache.userRole, 'roleName', content.name);
                    vm.$set(vm.cache.userRole, 'roleNote', content.note);
                });
            });

            $(vm.eleRefOrgUUID).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.logonUserOrganization, 'refUUID', $(vm.eleRefOrgUUID).val());
                var url = vm.loadOrganURL + "?uuid=" + $(vm.eleRefOrgUUID).val();
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        return;
                    }
                    var content = oData.content;
                    vm.$set(vm.cache.logonUserOrganization, 'refSEName', content.serviceEntityName);
                    vm.$set(vm.cache.logonUserOrganization, 'refNodeName', content.nodeName);
                    vm.$set(vm.cache.logonUserOrganization, 'organizationName', content.name);
                    vm.$set(vm.cache.logonUserOrganization, 'organizationId', content.id);
                    vm.$set(vm.cache.logonUserOrganization, 'organizationFunction', content.organizationFunction);
                    vm.$set(vm.cache.logonUserOrganization, 'refUUID', content.uuid);

                    $(vm.eleOrganizationFunction).val(content.organizationFunction);
                    $(vm.eleOrganizationFunction).trigger("change");

                    $(vm.eleWorkRole).val(content.workRole);
                    $(vm.eleWorkRole).trigger("change");

                });
            });

            $(vm.eleUserType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.logonUserUIModel, 'userType', $(vm.eleUserType).val());
            });

            $(vm.eleStatus).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.logonUserUIModel, 'status', $(vm.eleStatus).val());
            });

            $(vm.eleOrganizationFunction).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.logonUserOrganization, 'organizationFunction', $(vm.eleOrganizationFunction).val());
            });

            $(vm.eleWorkRole).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.logonUserOrganization, 'workRole', $(vm.eleWorkRole).val());
            });
        },


        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE);
            if (processMode * 1 === PROCESSMODE_NEW) {
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                var url, roleId, organizationId;
                this.initExtenstionMetaData('LogonUser').then(function (fieldList) {
                    if (fieldList && fieldList.length > 0) {
                        url = this.newModuleWithTemplateService;
                        var defRole = ServiceCollectionsHelper.filterArray('roleId', 'fieldName', fieldList, 'serviceExtendFieldSettingUIModel');
                        var defOrganization = ServiceCollectionsHelper.filterArray('organizationId', 'fieldName', fieldList, 'serviceExtendFieldSettingUIModel');
                        if (defRole && defRole.serviceExtendFieldSettingUIModel) {
                            roleId = defRole.serviceExtendFieldSettingUIModel.initialValue;
                        }
                        if (defOrganization && defOrganization.serviceExtendFieldSettingUIModel) {
                            organizationId = defOrganization.serviceExtendFieldSettingUIModel.initialValue;
                        }
                        var requestData = {
                            roleId: roleId,
                            organizationId: organizationId
                        };
                        vm.$http.post(url, requestData).then(function (response) {
                            var oData = JSON.parse(response.data);
                            if (!oData.content) {
                                ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                                return;
                            }
                            var content = oData.content;
                            this.setModuleToUI(content);
                        });

                    } else {
                        url = this.newModuleServiceURL;
                        vm.$http.post(url).then(function (response) {
                            var oData = JSON.parse(response.data);
                            if (!oData.content) {
                                ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                                return;
                            }
                            var content = oData.content;
                            this.setModuleToUI(content);
                        });
                    }
                }.bind(this));

            }
            if (processMode == PROCESSMODE_EDIT) {
// In case [Edit mode]
                var url = this.loadModuleEditURL + "?uuid=" + baseUUID;
                vm.$http.get(url).then(function (response) {
                    var oData = JSON.parse(response.data);
                    if (!oData.content) {
                        ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                        return;
                    }
                    var content = oData.content;
                    this.setModuleToUI(content);
                });
            }


        },

        saveModule: function () {
            var vm = this;
            var formArray = $('#x_form_data');
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }

            var baseUUID = vm.content.logonUserUIModel.uuid;
            var requestData = {
                id: vm.content.logonUserUIModel.id,
                uuid: baseUUID
            };
            this.$http.post(vm.checkDuplicateIDURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (oData.errorCode * 1 === HttpStatus.SC_OK) {
                    this.$http.post(vm.saveModuleURL, vm.content).then(function (response) {
                        $.Notification.notify('success', 'top center', this.label.msgSaveOK, this.label.msgSaveOKComment);
                        this.setModuleToUI(JSON.parse(response.data).content);
                        var processMode = getUrlVar(LABEL_PROCESSMODE);
                        if (processMode && processMode == PROCESSMODE_NEW) {
                            if (baseUUID) {
                                window.location.href = genCommonEditURL("LogonUserEditor.html", baseUUID);
                            }
                        }
                    }.bind(this));
                } else if (oData.errorCode * 1 === HttpStatus.SC_CONFLICT) {
                    swal({
                        title: this.label.warnDuplicateIDTitle,
                        text: this.label.warnDuplicateIDComment.formatString(vm.content.logonUserUIModel.id),
                        type: "error",
                        confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                        cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                        confirmButtonText: this.label.confirm
                    });

                } else {

                }

            }.bind(this));

        },

        exitModule: function () {
            var vm = this;
            //var baseUUID = vm.content.logonUserUIModel.parentNodeUUID;
            //window.location.href = genCommonEditURL("LogonUserList.html", baseUUID);
            var baseUUID = vm.content.logonUserUIModel.uuid;
            defaultExitEditor(baseUUID, this.exitURL,
                this.postExitURL, UIFLAG_STANDARD);

        },

        loadOrganizationSelectList: function (cache) {
            var vm = this;
            this.$http.get(this.loadOrganizationSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                resultList = vm._filterOutListForOrganizationSelection(resultList);
                setTimeout(function () {
                    $(vm.eleRefOrgUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefOrgUUID).val(cache.logonUserOrganization.refUUID);
                    $(vm.eleRefOrgUUID).trigger("change");
                }, 0);
            });
        },


        getOrganizationFunction: function (cache) {
            var vm = this;
            this.$http.get(this.getOrganizationFunctionMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var orgFunctionMapArray = JSON.parse(response.body).content;
                var _formatOrgFunction= ServiceUtilityHelper.genTemplateFormatFunction(orgFunctionMapArray);
                var resultList = formatSelectResult(orgFunctionMapArray, 'id', 'name');
                setTimeout(function () {
                    $(vm.eleOrganizationFunction).select2({
                        data: resultList,
                        templateResult:_formatOrgFunction,
                        templateSelection:_formatOrgFunction
                    });
                    // manually set initial value
                    $(vm.eleOrganizationFunction).val(cache.logonUserOrganization.organizationFunction);
                    $(vm.eleOrganizationFunction).trigger("change");
                }, 0);
            });
        },



        errorHandle: function (oData) {
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        getWorkRole: function (cache) {
            var vm = this;
            ServiceUtilityHelper.loadMetaWithCustomReq({
                url: vm.getWorkRoleMapURL,
                $http: vm.$http,
                initValue: vm.cache.logonUserOrganization.workRole,
                idField:'id',
                textField:'name',
                element: vm.eleWorkRole,
                errorHandle: vm.errorHandle
            });
        },

        loadRoleSelectList: function (content) {
            var vm = this;
            this.$http.get(this.loadRoleSelectListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'name');
                resultList = vm._filterOutListForRoleSelection(resultList);
                setTimeout(function () {
                    $(vm.eleRefRoleUUID).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleRefRoleUUID).val(content.logonUserUIModel.roleUUID);
                    $(vm.eleRefRoleUUID).trigger("change");
                }, 0);
            });
        },

        _filterOutListForRoleSelection: function (rawList) {
            var vm = this;
            if (ServiceCollectionsHelper.checkNullList(rawList)) {
                return;
            }
            var result = [], checkIndex = -1;
            rawList.forEach(function (union) {
                checkIndex = ServiceCollectionsHelper.filterArrayIndex(union.uuid, 'refUUID', vm.content.userRoleUIModelList);
                result.push(union);
            });
            return result;
        },

        _filterOutListForOrganizationSelection: function (rawList) {
            var vm = this;
            if (ServiceCollectionsHelper.checkNullList(rawList)) {
                return;
            }
            var result = [], checkIndex = -1;
            rawList.forEach(function (union) {
                checkIndex = ServiceCollectionsHelper.filterArrayIndex(union.uuid, 'refUUID', vm.content.logonUserOrganizationUIModelList);
                result.push(union);
            });
            return result;
        },

        loadUserTypeList: function (content) {
            var vm = this;
            this.$http.get(this.getUserTypeMapURL).then(function (response) {
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleUserType).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleUserType).val(content.logonUserUIModel.userType);
                    $(vm.eleUserType).trigger("change");
                }, 0);
            });
        },


        getStatusMap: function () {
            var vm = this;
            return ServiceUtilityHelper.loadMetaRequest({
                url: vm.getStatusURL,
                $http: vm.$http,
                formatMeta:LogonUserManager.formatStatus,
                postHandle:function(resultList){
                    if(rightBar){
                        rightBar.updateSelectMetaData('logonUser.status', resultList);
                    }
                },
                initValue: vm.content.logonUserUIModel.status,
                element: vm.eleStatus,
                errorHandle: vm.errorHandle
            });
        },


        initSwitchery: function () {
            var elems = Array.prototype.slice.call(document.querySelectorAll('#x_lockUserFlag'));
            elems.forEach(function (html) {
                var switchery = new Switchery(html, {
                    color: '#ED5565',
                    secondaryColor: "#00b19d"
                });
            });
        },

        initSetSwitch: function (content) {
            var eleLockUserFlagArray = $("#x_lockUserFlag");
            if (eleLockUserFlagArray && eleLockUserFlagArray.length > 0) {
                if (content.logonUserUIModel.lockUserFlag && content.logonUserUIModel.lockUserFlag === true) {
                    eleLockUserFlagArray[0].setAttribute("checked", "true");
                    eleLockUserFlagArray.trigger('click');
                }
            }
        },

        loadOrganizationFunctionMeta: function(){
            var vm = this;
            OrganizationManager.loadOrganizationFunctionSelectList({
                $http:vm.$http,
                fnCallBack: function(orgFunctionMapArray){
                    vm.$set(vm, 'orgFunctionMapArray', orgFunctionMapArray);
                    setTimeout(function () {
                        vm.organizationTable.buildWithCache({
                            "pageLength": 5
                        });
                    }, 0);
                }.bind(this)
            });
        },

        formatOrgFunctionClass: function (organizationFunction) {
            var $element = ServiceCollectionsHelper.filterArray(organizationFunction, 'id', this.orgFunctionMapArray);
            if ($element) {
                return $element.iconClass;
            }
        },

        openRightSideBar: function(key){
            NavigationPanelIns.openRightSideBar(RightBarTemplate.TABS.tab2, key);
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'logonUserUIModel', content.logonUserUIModel);
            vm.$set(vm.content, 'userRoleUIModelList', content.userRoleUIModelList);
            vm.$set(vm.content, 'logonUserOrganizationUIModelList', content.logonUserOrganizationUIModelList);
            vm.initSetSwitch(content);
            vm.loadUserTypeList(content);
            var statusPromise = vm.getStatusMap();
            Promise.all([statusPromise]).then(function(value){
                if(rightBar){
                    rightBar.initHelpDocumentList(vm.content.logonUserUIModel.uuid);
                }
            }).catch(function(error){
                vm.errorHandle(error);
            });
            vm.loadOrganizationFunctionMeta();
            vm.loadRoleSelectList(content);
        },

        /**
         * @Overwrite: get page meta configure
         */
        getDefaultPageMeta: function () {
            var vm = this;
            return {
                pageId: 'LogonUserEditor',
                pageCategory: AsyncPage.pageCategory.EDIT,
                labelObject: vm.label,
                parentVue: vm,
                parentContent: vm.content,
                serviceManager: LogonUserManager,
                coreModelId: 'LogonUser',
                i18nPath: 'coreFunction/',
                getDocActionNodeListURL: '../logonUser/getDocActionNodeList.html',
                helpDocumentName: ['LogonUserHelpDocument'],
                processButtonMeta: {
                    save: {
                        formatClass: 'displayForEdit',
                        callback: 'saveModule'
                    },
                    changePassword: {
                        formatClass: 'displayForEdit',
                        callback: 'changePassword'
                    },
                    placeholder: {
                        category: ProcessButtonConstants.placeholderCategory.DOC_ACTION_BTN
                    },
                    exit: {
                        callback: 'exitModule'
                    }
                },
                tabMetaList: [{
                    tabId: 'logonUserSection',
                    tabTitleKey: 'logonUserSection',
                    titleLabelKey: 'logonUserSection',
                    titleHelpKey: 'logonUser.logonUserSection',
                    titleIcon: 'md md-texture content-portlet-title',
                    sectionMetaList: [{
                        sectionId: 'logonUserSection',
                        updatedByUidPath: 'updatedByUUID',
                        updatedByNamePath: 'updatedByName',
                        updatedDatePath: 'updatedDate',
                        messageResponsePath: 'meta.messageResponse',
                        sectionCategory: AsyncSection.sectionCategory.EDIT,
                        parentContentPath: 'logonUserUIModel',
                        tabTitleKey: 'logonUserSection',
                        titleLabelKey: 'logonUserSection',
                        titleHelpKey: 'logonUser.logonUserSection',
                        titleIcon: 'md md-content-paste content-portlet-title',
                        disabled: 'disableNotInInit',
                        fieldMetaList: [{
                            fieldName: 'id',
                            required: true,
                            newRow: true
                        }, {
                            required: true,
                            fieldName: 'name',
                        }, {
                            fieldName: 'status',
                            disabled: true,
                            helpKey: 'logonUser.status',
                            settings: {
                                getMetaDataUrl: vm.getStatusURL,
                                formatMeta: 'formatStatus'
                            },
                            iconArray: 'getStatusIconArray',
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'userType',
                            settings: {
                                getMetaDataUrl: vm.getUserTypeMapURL
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'userType',
                            settings: {
                                getMetaDataUrl: vm.getUserTypeMapURL
                            },
                            fieldType: AbsInput.FIELDTYPE.Select2
                        }, {
                            fieldName: 'lockUserFlag'
                        }, {
                            fieldName: 'note',
                            inputClass: 'col-md-8',
                            newRow: true,
                            rowNumber: 5,
                            disabled: false,
                            fieldType: AbsInput.FIELDTYPE.TextArea
                        }]
                    } ]
                },{
                    tabId: 'organizationSection',
                    tabTitleKey: 'organizationSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'organizationSection',
                        parentContentPath: 'logonUserOrgUIModelList',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        detailedPageUrl: 'LogonUserOrgEditor.html',
                        refItemName: 'logonUserOrgPanel',
                        editModuleFlag: true,
                        editModuleModalFlag: true,
                        tabTitleKey: 'logonUserOrgSection',
                        titleLabelKey: 'logonUserOrgSection',
                        titleHelpKey: 'logonUser.logonUserOrgSection',
                        titleIcon: 'md md-nature-people content-portlet-title',
                        scrollX: true,
                        embedProcessButtonMeta: {
                            addTitle: 'addOrganization',
                            addLabel: 'addOrganization',
                            newModuleModalFlag: true
                        },
                        fieldMetaList: [{
                            fieldName: 'logonUserOrgUIModel.uuid'
                        }, {
                            fieldName: 'logonUserOrgUIModel.organizationId',
                            labelKey: 'logonUserOrg.organizationId',
                            minWidth: '180px'
                        }, {
                            fieldName: 'logonUserOrgUIModel.organizationName',
                            labelKey: 'logonUserOrg.organizationName',
                            minWidth: '180px'
                        }, {
                            fieldName: 'logonUserOrgUIModel.organizationFunctionValue',
                            labelKey: 'logonUserOrg.organizationFunction',
                        }, {
                            fieldName: 'logonUserOrgUIModel.addressInfo',
                            labelKey: 'logonUserOrg.addressInfo',
                        }]
                    }]
                },{
                    tabId: 'authorizationSection',
                    tabTitleKey: 'authorizationSection',
                    editBlock: true,
                    sectionMetaList: [{
                        sectionId: 'authorizationSection',
                        parentContentPath: 'userRoleUIModelList',
                        sectionCategory: AsyncSection.sectionCategory.EMBEDLIST,
                        detailedPageUrl: 'LogonUserOrgEditor.html',
                        refItemName: 'userRolePanel',
                        editModuleFlag: true,
                        editModuleModalFlag: true,
                        tabTitleKey: 'userRoleSection',
                        titleLabelKey: 'userRoleSection',
                        titleHelpKey: 'logonUser.userRoleSection',
                        titleIcon: 'md md-account-child content-portlet-title',
                        scrollX: true,
                        embedProcessButtonMeta: {
                            addTitle: 'addRole',
                            addLabel: 'addRole',
                            newModuleModalFlag: true
                        },
                        fieldMetaList: [{
                            fieldName: 'userRoleUIModel.uuid'
                        }, {
                            fieldName: 'userRoleUIModel.roleName',
                            labelKey: 'userRole.roleName',
                            minWidth: '180px'
                        }, {
                            fieldName: 'userRoleUIModel.roleId',
                            labelKey: 'userRole.roleId',
                            minWidth: '180px'
                        }, {
                            fieldName: 'userRoleUIModel.roleNote',
                            labelKey: 'userRole.roleNote',
                        }]
                    }]
                }]
            };
        },

    }
});
