var rightBar = new Vue({
    el: "#rightBarHoc",
    mixins: [ServiceRightBarPanelHelper.defTimelineMinxin, MaterialManager.labelTemplate],
    data: function () {
        return {
            label: MaterialManager.label.material
        };
    },

    methods: {

        setI18nProperties: function (fnCallback) {
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'MaterialUnit',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        initHelpDocumentList: function (uuid) {
            "use strict";
            var vm = this;
            ServiceRightBarPanelHelper.initHelpDocumentWithAction({
                uuid: uuid,
                vm: vm,
                errorHandle: dataVar.errorHandle,
                helpDocumentName: ['MaterialUnitHelpDocument']
            });
        }
    }
});

var dataVar = new Vue({
    el: "#x_data",
    data: {
        label: MaterialManager.label.materialUnit,
        content: {
            materialUnitUIModel:{
                uuid:'',
                parentNodeUUID:'',
                client:'',
                rootNodeUUID:'',
                refNodeName: '',
                refUUID: '',
                nitName:'',
                ratioToStandard: '',
                barcode: '',
                retailPrice:'',
                purchasePrice:'',
                wholeSalePrice:'',
                memberSalePrice:'',
                mainUnitName: '',
                materialId:'',
                materialName:'',
                unitCost: '',
                refLengthUnit: '',
                refVolumeUnit: '',
                refWeightUnit: '',
                netWeight:'',
                length:'',
                width:'',
                volume:'',
                height:'',
                outboundDeliveryPrice:'',
                ratioToStandardMidComment:'',
                note: ''
            },
            serviceUIMeta: {},
            materialUnitAttachmentUIModelList: []
        },
        cache:{
            material:{
                uuid:'',
                id:'',
                name:''
            }
        },
        attachmentMeta: {
            loadAttachmentURL: '../materialUnit/loadAttachment.html',
            deleteAttachmentURL: '../materialUnit/deleteAttachment.html',
            uploadAttachmentURL: '../materialUnit/uploadAttachment.html',
            uploadAttachmentTextURL: '../materialUnit/uploadAttachmentText.html'
        },
        attachmentLabel: {
            attachmentSection: ''
        },
        author: {
            resourceId: ServiceModuleConstants.Material,
            actionCode: {
                Edit: false,
                PriceInfo: false,
                AuditDoc: false,
                View: false,
                Delete: false,
                Excel: false
            }
        },
        processButtonMeta:[],
        eleUnitName: '#x_unitName',
        eleRatioToStandard: '#x_ratioToStandard',
        eleRefLengthUnit: '#x_refLengthUnit',
        eleRefVolumeUnit: '#x_refVolumeUnit',
        eleRefWeightUnit: '#x_refWeightUnit',
        searchStandardUnitURL:'../standardMaterialUnit/searchModuleService.html',
        loadModuleEditURL: '../materialUnit/loadModuleEditService.html',
        loadMaterialURL: '../material/loadModule.html',
        saveModuleURL: '../materialUnit/saveModuleService.html',
        exitModuleURL: '../materialUnit/exitModule.html',
        getPageHeaderModelListURL: '../materialUnit/getPageHeaderModelList.html',
        newModuleServiceURL: '../materialUnit/newModuleService.html',
        loadStandardUnitSelectListURL: '../material/getStandardUnit.html',
        loadStandardMaterialUnitURL: '../standardMaterialUnit/loadModule.html'
    },

    created: function(){
        var vm = this;
        vm.initSubComponents();
        vm.initAuthorResourceCheck();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('logistics', 'Material');
            this.setI18nProperties(vm.initProcessButtonMeta());
            this.loadModuleEdit();
        });
    },

    methods: {

        initSubComponents: function() {
            "use strict";
            Vue.component("label-help-icon", LabelHelpIcon);
            Vue.component("port-title-help-icon", PortTitleHelpIcon);
            Vue.component("attachment-union", AttachmentUnion);
            Vue.component("page-header-union", PageHeaderUnion);
            Vue.component("material-unit-control", MaterialUnitControl);
            Vue.component("embedded-process-button-core", EmbeddedProcessButtonCore);
            Vue.component("embedded-process-button-array", EmbeddedProcessButtonArray);
            Vue.component("process-button-array", ProcessButtonArray);
        },

        initAuthorResourceCheck: function(){
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm:vm,
                errorHandle:ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initProcessButtonMeta: function () {
            var vm = this;
            var processButtonMeta = {
                save: {
                    formatClass: vm.displayForEdit,
                    callback: vm.saveModule
                },
                exit: {
                    callback: vm.exitModule
                }
            };
            vm.$refs.processButtonArray.convertButtonMetaToArray({
                processButtonMetaArray: processButtonMeta
            });
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true : undefined);
        },

        setI18nCommonProperties: function () {
            ServiceUtilityHelper.setI18nCommonReflective(this.label, $.i18n.prop);
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            ServiceUtilityHelper.setI18nReflective(this.label, $.i18n.prop, true);
        },


        setI18nProperties: function (fnCallback) {
            var vm = this;
            ServiceUtilityHelper.setI18nPropertiesWrapper({
                path: "coreFunction/",
                commonCallback: this.setI18nCommonProperties,
                fnCallback: fnCallback,
                configList: [{
                    name: 'MaterialUnit',
                    callback: this.setNodeI18nPropertiesCore
                }]
            });
        },


        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            //vm.$refs.refBusyLoader.showBusyLoading();
            vm.$refs.control.loadModule({
                baseUUID: baseUUID,
                processMode: processMode,
                errorHandle: vm.errorHandle,
                pageCategory: DocumentConstants.StandardPropety.PageCategory.PAGE,
                postLoadData: function(content){
                    // vm.$refs.refBusyLoader.hideBusyLoading();
                    vm.setModuleToUI(content);
                }
            });
        },

        saveModule: function () {
            var vm = this;
            vm.$refs.control.saveModule();
        },

        errorHandle: function(oData){
            this.$refs.refBusyLoader.hideBusyLoading();
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        refreshEditView: function () {
            var baseUUID = this.content.materialUnitUIModel.uuid;
            window.location.href = genCommonEditURL("MaterialUnitEditor.html", baseUUID);
        },


        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.materialUnitUIModel.parentNodeUUID;
            window.location.href = genCommonEditURL("MaterialEditor.html", baseUUID);
        },


        getPageHeaderModelList: function (uuid, baseUUID) {
            var vm = this;
            vm.$refs.pageHeader.initPageHeader({
                uuid: uuid,
                baseUUID: baseUUID,
                pageHeaderListUrl: vm.getPageHeaderModelListURL,
                fnPageHeaderModel: vm.fnPageHeaderModel
            });
        },

        fnPageHeaderModel: function (pageHeaderModel) {
            if (pageHeaderModel.nodeInstId === 'material') {
                var targetTab = MaterialManager.documentTab.materialUnitSection;
                baseDocURL = genCommonEditURL("MaterialEditor.html", pageHeaderModel.uuid, targetTab);
                pageHeaderModel.pageLink = baseDocURL;
                pageHeaderModel.pageTitle = this.label.materialPageTitle + ":" + this.content.materialUnitUIModel.materialName;
                return pageHeaderModel;
            }
        },

        openRightSideBar: function(key){
            NavigationPanelIns.openRightSideBar(RightBarTemplate.TABS.tab2, key);
        },

        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'materialUnitUIModel', content.materialUnitUIModel);
            vm.$set(vm.content, 'materialUnitAttachmentUIModelList', content.materialUnitAttachmentUIModelList);
            vm.getPageHeaderModelList(vm.content.materialUnitUIModel.uuid, vm.content.materialUnitUIModel.parentNodeUUID);
            rightBar.initHelpDocumentList(vm.content.materialUnitUIModel.uuid);
        }

    }
});
