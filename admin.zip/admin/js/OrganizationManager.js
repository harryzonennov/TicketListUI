/**
 * Should based on ["Common.js", "DocumentOrderMatPopInfo"]
 * @type {{}}
 */
var OrganizationManager = function () {

};

OrganizationManager.label = {
    organization:{
        organType: '',
        organLevel: '',
        refFinOrgId: '',
        parentOrganizationId: '',
        id: '',
        regularType: '',
        accountType: '',
        name: '',
        contactTelephone: '',
        subArea: '',
        contactMobileNumber: '',
        addressInfo: '',
        organizationFunction: '',
        cityName: '',
        streetName: '',
        townZone: '',
        modelTitle:'',
        note: '',
        organizationFunctionId: '',
        organizationFunctionName: '',
        accountantId: '',
        accountantName: '',
        mainContactId: '',
        mainContactName: '',
        organizationSection: '',
        organizationFunctionSection: '',
        mainContactSection: '',
        msgSaveOK: '',
        msgSaveOKComment: '',
        msgConnectFailure: '',
        msgUnknowSystemFailure: '',
        msgLoadDataFailure: '',
        index: '',
        lockFailureMessage: '',
        save: '',
        exit: '',
        quickEdit: '',
        buttonDelete: '',
        close: '',
        deleteWarnTitle: '',
        deleteWarnText: '',
        cancel: '',
        commit: '',
        confirm: '',
        addOrganization: '',
        addOrganizationFunction: '',
        addAccountant: '',
        addMainContact: '',
        addEmployee: '',
        fax: '',
        organizationFunctionValue: '',
        clearSearch: '',
        clearSearchComment: '',
        advancedSearchCondition: '',
        email: '',
        parentOrganizationName: '',
        switchFlag: '',
        buttonEdit: '',
        buttonView: '',
        addOrganizationBarcodeBasicSetting: '',
    },
    organizationBarcodeBasicSetting: {
        id: '',
        name: '',
        ean13CompanyCode: '',
        ean13CountryHead: '',
        note: ''
    },
    logonUserOrg:{
        id:'',
        name:'',
        workRole:'',
        contactMobileNumber:''
    },
    name: '',
    id: '',
    parentOrganizationId:'',
    organizationFunction:'',
    cityName:'',
    addressInfo:'',
    contactTelephone:''
};


OrganizationManager.Constants = {
    getOrganizationFunctionMapURL: '../organization/getOrganizationFunctionMap.html'
};


OrganizationManager.labelTemplate = {
    data: function() {
        return {
            label: {
                "organizationBarcodeBasicSetting": OrganizationManager.label.organizationBarcodeBasicSetting,
                "logonUserOrg":OrganizationManager.label.logonUserOrg
            }
        };
    }
};

/**
 * Definition of Tab on UI
 * @type {{}}
 */
OrganizationManager.documentTab = {
    // inboundDeliverySection:0,
    // approveSection:1,
    // inboundItemListSection:2
};



OrganizationManager.loadOrganizationFunctionSelectList = function (oSettings) {
    var vm = this;
    oSettings.$http.get(OrganizationManager.Constants.getOrganizationFunctionMapURL).then(function (response) {
        if (!JSON.parse(response.body)) {
            // pop up error message
        }
        var orgFunctionMapArray = JSON.parse(response.body).content;
        if(orgFunctionMapArray && orgFunctionMapArray.length > 0){
            orgFunctionMapArray.forEach(function(orgFunctionMap){
                orgFunctionMap.id = orgFunctionMap.id * 1;
            });
        }
        if(oSettings.fnCallBack){
            oSettings.fnCallBack(orgFunctionMapArray);
        }
    });
};

/**
 * @override Get Basic URL for load document root instance.
 * @returns {string}
 */
OrganizationManager.prototype.getLoadDocumentBaseURL = function () {
    "use strict";
    return '../organization/loadModuleViewService.html';
};


/**
 * Constants method: Get URL for load status metadata
 * @returns {*[]}
 */
OrganizationManager.prototype.getStatusURL = function(status) {
    "use strict";
    // return '../logonUser/getStatusMap.html';
};


OrganizationManager.prototype.getI18nWrap = function (fnCallback) {
    ServiceUtilityHelper.setI18nPropertiesWrapper({
        path: "foundation/common/",
        fnCallback: fnCallback,
        commonCallback: OrganizationManager.setI18nCommonProperties,
        configList: [{
            name: 'Organization',
            callback: OrganizationManager.setNodeI18nPropertiesCore
        }]
    });
};

/**
 * @override Set Basic path for i18n function.
 * @returns {string}
 */
OrganizationManager.getI18nPath = function () {
    return "foundation/common/";
};


OrganizationManager.setI18nCommonProperties = function () {
    ServiceUtilityHelper.setI18nCommonReflective(OrganizationManager.label.organization, $.i18n.prop);
};

OrganizationManager.setNodeI18nPropertiesCore = function () {
    ServiceUtilityHelper.setI18nReflective(OrganizationManager.label.organization, $.i18n.prop, true);
};

OrganizationManager.prototype.getDefaultDocumentEditorPage = function(){
    "use strict";
    return "OrganizationEditor.html";
};

OrganizationManager.prototype.getDefaultDocumentItemEditorPage = function(){
    "use strict";
    return undefined;
};

OrganizationManager.prototype.getModelTitle = function(){
    return OrganizationManager.label.organization.modelTitle;
};

OrganizationManager.prototype.getDocumentPopoverContent = function (oSettings) {
    var vm = this;
    var targetSettings = ServiceUtilityHelper.extendObject(oSettings, {
        targetPage: vm.getDefaultDocumentItemEditorPage(),
        url: "../organization/loadModuleViewService.html",
        subPath: 'organizationUIModel',
        label:OrganizationManager.label.organization,
        docType : DocumentConstants.DummyDocumentType.Organization,
        getI18nWrap:vm.getI18nWrap.bind(vm)
    });

    var fieldMetaList = [{
        fieldName:'id',
    },{
        fieldName:'name',
    },{
        fieldName:'organizationFunctionValue',
        fieldKey:'organizationFunction',
        labelKey:'organizationFunction'
    },{
        fieldName: 'contactPerson'
    },{
        fieldName: 'contactTelephone'
    },{
        fieldName: 'parentOrganizationId'
    },{
        fieldName: 'parentOrganizationName'
    }];
    targetSettings['fieldMetaList'] = fieldMetaList;
    DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper(targetSettings);
};
