/*!
 * Important basic tool file, should be imported by every page
 */
/**
 * SE Controller Constant list block: Should be consistent with back end
 * class:platform.foundation.Controller.SEBasicController
 */
var LABEL_PROCESSMODE = "processMode";

var LABEL_ACTIONCODE = "actionCode";

var LABEL_UUIDARRAY = "uuidArray";

var PROCESSMODE_NEW = 1;

var PROCESSMODE_EDIT = 2;

var PROCESSMODE_DISPLAY = 3;

var PROCESSMODE_STANDBY = 4;

var UIFLAG_STANDARD = 1;

var UIFLAG_FRAME = 2;

var UIFLAG_CHOOSER = 3;

var LABEL_TABKEY = "tabKey";

/**
 * JSON View simple response constant, Should be consistent with backend
 * class:platform.foundation.Model.Basic.IServiceJSONBasicErrorCode
 */

var ERROR_CODE_OK = 200;

var ERROR_CODE_UNKNOWN_SYS_ERROR = 200;

var LABEL_SAVESUCCESS = "saveSuccess";

/**
 * This constant is used for later variable <code>processFlag</code>
 * indicate if current window is refresh again because of process
 * action,such as SAVE, or just exit the window, in order to avoid incorrect
 * action
 */
var PROCESS_FLAG_INITIAL = 1;

var PROCESS_FLAG_ACTION = 2;

/**
 * This variable is used to indicate if current window is refresh again
 * because of process action,such as SAVE, or just exit the window, in order
 * to avoid incorrect action
 */
var processFlag = PROCESS_FLAG_INITIAL;

/**
 * This constant is used for system standard switch value
 * should be consistent with backend class <code>platform.foundation.LogicManager.Common.StandardSwitchProxy</code>
 *
 */
var SWITCH_ON = 1;

var SWITCH_OFF = 2;

var SWITCH_INITIAL = 3;

/**
 * This constant is used for system standard message (error) type
 * should be consistent with backend class <code>platform.foundation.LogicManager.Common.StandardErrorTypeProxy</code>
 *
 */
var MESSAGE_TYPE_NOTIFICATION = 1;

var MESSAGE_TYPE_WARNING = 2;

var MESSAGE_TYPE_ERROR = 3;

/**
 * i18n folder constants
 */
var I18N_ROOTPATH = 'i18n/';

/**
 * Get i18n root path
 * @returns {string}
 */
function getI18nRootPath() {
    return I18N_ROOTPATH;
}

/**
 * Get current browser lanuguage
 *
 * @returns {string}
 */
function getLan() {
    if(sessionStorage && sessionStorage.getItem('lanCode')){
        return sessionStorage.getItem('lanCode');
    }
    var language = window.navigator.language;
    if (!language) {
        language = window.navigator.browserLanguage;
    }
    language = language.toLowerCase();
    return language;
}

/**
 * Get current browser lanuguage
 *
 * @returns {string}
 */
function getBrowserLan() {
    var language = window.navigator.language;
    if (!language) {
        language = window.navigator.browserLanguage;
    }
    language = language.replace('-', '_');
    return language;
}

/**
 * Return URL parameters
 * @returns {Array}
 */
function getUrlVars() {
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

/**
 * Get URL parameter value by parameter name
 * @param name
 * @returns {*}
 */
function getUrlVar(name) {
    var resultList = getUrlVars();
    return resultList[name];
}

function pushUrlVar(name, value){
    var newurl = changeURLPar(window.location.href, name, value);
    window.history.pushState(null,null,newurl);
}

function changeURLPar(uri, par, parValue) {
    var pattern = par + '=([^&]*)';
    var replaceText = par + '=' + parValue;
    if (uri.match(pattern)) {// If already has
        var tmp = '/\\' + par + '=[^&]*/';
        tmp = uri.replace(eval(tmp), replaceText);
        return (tmp);
    }
    else {
        if (uri.match('[\?]')) {//If url has other paras
            return uri + '&' + replaceText;
        }
        else {// If url doesn't has paras at all
            return uri + '?' + replaceText;
        }
    }
    return uri + '\n' + par + '\n' + parValue;
}

var urlEncode = function (param, key, encode) {
    if (param == null) return '';
    var paramStr = '';
    var t = typeof (param);
    if (t == 'string' || t == 'number' || t == 'boolean') {
        paramStr += '&' + key + '=' + ((encode == null || encode) ? encodeURIComponent(param) : param);
    } else {
        for (var i in param) {
            var k = key == null ? i : key + (param instanceof Array ? '[' + i + ']' : '.' + i);
            paramStr += urlEncode(param[i], k, encode);
        }
    }
    return paramStr;
};

/**
 * Generate the common Edit url with uuid and set default edit process mode
 * @param baseEditURL
 * @param uuid
 * @returns {string}
 */
function genCommonEditURL(baseEditURL, uuid, tabKey) {
    var paras = {};
    paras.uuid = uuid;
    paras.processMode = PROCESSMODE_EDIT;
    if(tabKey){
        if(typeof tabKey !== "object"){
            paras.tabKey = tabKey;
        }
    }
    var resultURL = baseEditURL + "?" + urlEncode(paras);
    return resultURL;
}

function genUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

function genRamdomPostIndex() {
    var uuid = genUUID();
    return uuid.substring(0, 5);
}


/**
 * Get sub path for common 18n
 * @returns {string}
 */
function getCommonI18nPath() {
    return "foundation/";
}

function getCommonI18n(i18n, callBackFunction) {
    var promise = jQuery.i18n.properties({
        name: 'ComElements', //properties file name
        path: getI18nRootPath() + getCommonI18nPath(), //path for properties files
        mode: 'map', //Using map mode to consume properties files
        cache: true,
        language: getLan(),
        callback: callBackFunction
    });
    return promise;
}



function changeTwoDecimal(x) {
    var f_x = parseFloat(x);
    if (isNaN(f_x)) {
        alert('function:changeTwoDecimal->parameter error');
        return false;
    }
    f_x = Math.round(f_x * 100) / 100;
    return f_x;
}

function formatSelectResult(rawList, idField, textField) {
    if (!rawList || rawList.length === 0) {
        return null;
    }
    var i = 0, compoundFlag = false, element, textFieldArray, len = rawList.length, resultList = [];
    if(textField && textField.split('-').length === 2){
        // in case compound text field
        compoundFlag = true;
        textFieldArray = textField.split('-');
    }
    for (i = 0; i < len; i++) {
        if(compoundFlag === true){
            element = {'id': rawList[i][idField], 'text': rawList[i][textFieldArray[0]] + '-' + rawList[i][textFieldArray[1]] };
            resultList.push(element);
        }else{
            element = {'id': rawList[i][idField], 'text': rawList[i][textField]};
            resultList.push(element);
        }
    }
    return resultList;
}

function formatSearchSelectResult(rawList, idField, textField) {
    var resultList = [];
    resultList = formatSelectResult(rawList, idField, textField);
    if (!resultList || resultList.length === 0) {
        return [];
    }
    resultList.splice(0, 0, {'id': '', 'text': ' '});
    return resultList;
}

function formatSingleArray(rawList, field) {
    if (!rawList || rawList.length == 0) {
        return null;
    }
    var resultList = [], i = 0, len = rawList.length;
    for (i = 0; i < len; i++) {
        resultList.push(rawList[i][field]);
    }
    return resultList;
}

function defaultExitEditor(baseUUID, exitURL, postExitURL, uiFlag) {
    // In case only for process flag initial, just go the exit handler
    if (processFlag == PROCESS_FLAG_INITIAL) {
        // should import js file:ServiceJSONHelper
        var requestData = generateServiceSimpleContentUnion("uuid", baseUUID);
        jQuery.ajax({
            type: "POST",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            url: exitURL,
            async: false,
            data: requestData,
            success: function (data) {
                if (postExitURL) {
                    if (data.errorCode == ERROR_CODE_OK) {
                        defaultEditorPostExit(uiFlag, postExitURL);
                    } else {
                        defaultEditorPostExit(uiFlag, postExitURL);
                    }
                }
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                if (postExitURL) {
                    defaultEditorPostExit(uiFlag, postExitURL);
                }
            }
        });
    } else {
        // For other action Should revert the process flag to initial
        processFlag = PROCESS_FLAG_INITIAL;
    }
}

function defaultEditorPostExit(uiFlag, postExitURL) {
    if (!uiFlag) {
        window.location.href = postExitURL;
    }
    if (uiFlag == UIFLAG_STANDARD) {
        window.location.href = postExitURL;
    }
    // if (uiFlag == UIFLAG_FRAME) {
    //     window.close();
    // }
    // if (uiFlag == UIFLAG_CHOOSER) {
    //     window.close();
    // }
}

function changeSixDecimal(x) {
    var f_x = parseFloat(x);
    if (isNaN(f_x)) {
        alert('function:changeTwoDecimal->parameter error');
        return false;
    }
    f_x = Math.round(f_x * 1000000) / 1000000;
    return f_x;
}


function stringFormat(template, arg) {
    if (!template) {
        return;
    }
    var re = "%S";
    return template.replace(re, arg);
}

stringMultipleFormat = function () {
    if (arguments.length == 0)
        return null;
    var template = arguments[0];
    var re = "%S";
    for (var i = 1; i < arguments.length; i++) {
        template = template.replace(re, arguments[i]);
    }
    return template;
}

function stopLoadingIcon(target, coverObject) {
    if (target) {
        if (coverObject) {
            coverObject.style.opacity = "1";
        } else {
            target.style.opacity = "1";
        }
        spinner.spin();
    }
}

/**
 * Non empty value check the mobile number
 * @param inputVal
 * @returns {boolean}
 */
function checkMobileInput(inputVal) {
    if (!inputVal) {
        return false;
    }
    var mobile = $.trim(inputVal);
    if (!mobile) {
        return false;
    }
    var isMobile = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1})|(14[0-9]{1}))+\d{8})$/;
    if (!isMobile.exec(mobile) && mobile.length != 11) {
        return false;
    } else {
        return true;
    }
}

/**
 * OK with the empty value
 * @param inputVal
 * @returns {boolean}
 */
function checkGenEmptyTelephoneNumber(inputVal) {
    if (!inputVal) {
        return true;
    }
    var isMobile = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1})|(14[0-9]{1}))+\d{8})$/;
    var isPhone = /^(?:(?:0\d{2,3})-)?(?:\d{7,8})(-(?:\d{3,}))?$/;
    if (inputVal.substring(0, 1) == 1) {
        var mobile = $.trim(inputVal);
        if (!isMobile.exec(mobile) && mobile.length != 11) {
            return false;
        }
    }
    // if start with 1. then checking the mobile phone
    else if (inputVal.substring(0, 1) == 0) {
        var telephone = $.trim(inputVal);
        if (!isPhone.test(telephone)) {
            return false;
        }
    }
    else {
        return false;
    }
    return true;
}

/**
 * if the string contains the substring
 * @param string
 * @param substr
 * @param isIgnoreCase
 * @returns {Boolean}
 */
function contains(string, substr, isIgnoreCase) {
    if (isIgnoreCase) {
        string = string.toLowerCase();
        substr = substr.toLowerCase();
    }
    if (string) {
        string = trimString(string);
    }
    if (substr) {
        substr = trimString(substr);
    }
    var startChar = substr.substring(0, 1);
    var strLen = substr.length;
    for (var j = 0; j < string.length - strLen + 1; j++) {
        if (string.charAt(j) == startChar) {
            //if matches start char then start search
            if (string.substring(j, j + strLen) == substr) {
                return true;
            }
        }
    }
    return false;
}


function trimString(string) {
    return string.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
}

/**
 * Filter the correct object instance from parent compound object (probably with sub list attr) by the uuid value,  in reflective way.
 * @param {Object} comInstance: Compound object instance (with sub list attr)
 * @param {String} uuid: value of uuid
 * @returns {*}
 */
function filterListItemByUUIDReflective(comInstance, uuid) {
    return filterListItemByKeyReflective(comInstance, uuid, "uuid");
}

function filterParentServiceModelByUUIDReflective(comInstance, uuid) {
    return filterParentServiceModelByKeyReflective(comInstance, uuid, "uuid");
}

function filterParentServiceModelByKeyReflective(comInstance, key, keyName) {
    if (!comInstance || typeof  comInstance != "object") {
        return;
    }
    if (comInstance[keyName]) {
        if (comInstance[keyName] === key) {
            // In case current model is the flat style.
            return comInstance;
        }
    }
    var result, i, k, keys = Object.keys(comInstance);
    if (keys && keys.length > 0) {
        var keyLength = keys.length;
        for (i = 0; i < keyLength; i++) {
            var attr = comInstance[keys[i]];
            if (checkArrayFlag(attr)) {
                // In case this attribute is sub list
                for (k = 0; k < attr.length; k++) {
                    result = filterParentServiceModelByKeyReflective(attr[k], key, keyName);
                    if (result) {
                        return result;
                    }
                }
            } else {
                if (typeof attr === 'object') {
                    // In case this attribute is object type
                    if (attr && attr[keyName]) {
                        if (attr[keyName] === key) {
                            return comInstance;
                        }
                    }
                }
            }
        }
    }
}

/**
 * Filter the correct object instance from parent compound object (probably with sub list attr) by the key value,  in reflective way.
 * @param {Object} comInstance: Compound object instance (with sub list attr)
 * @param {String} key: key value to filter sub object
 * @param {String} keyName: the name of the key, e.g. uuid
 * @returns {*}
 */
function filterListItemByKeyReflective(comInstance, key, keyName) {
    if (!comInstance || typeof  comInstance != "object") {
        return;
    }
    // In case comInstance is object, then try to match the key value
    if (comInstance[keyName]) {
        if (comInstance[keyName] === key) {
            return comInstance;
        }
    }
    var result, i, k, keys = Object.keys(comInstance);
    if (keys && keys.length > 0) {
        var keyLength = keys.length;
        for (i = 0; i < keyLength; i++) {
            var attr = comInstance[keys[i]];
            if (checkArrayFlag(attr)) {
                // In case this attribute is sub list
                for (k = 0; k < attr.length; k++) {
                    result = filterListItemByKeyReflective(attr[k], key, keyName);
                    if (result) {
                        return result;
                    }
                }
            } else {
                if (typeof attr === 'object') {
                    // In case this attribute is object type
                    result = filterListItemByKeyReflective(attr, key, keyName);
                    if (result) {
                        return result;
                    }
                }
            }
        }
    }
}

/**
 * Check if current instance is array or not.
 * @param instance
 * @returns {boolean}
 */
function checkArrayFlag(instance) {
    if (!instance) {
        return false;
    }
    if (typeof  instance === "object") {
        if (instance instanceof Array) {
            return true;
        }
    }
    return false;
}

function debounce(func, wait, immediate){
    var timeout, args, context, timestamp, result;
    if (null == wait) wait = 100;

    function later() {
        var last = Date.now() - timestamp;

        if (last < wait && last >= 0) {
            timeout = setTimeout(later, wait - last);
        } else {
            timeout = null;
            if (!immediate) {
                result = func.apply(context, args);
                context = args = null;
            }
        }
    };

    var debounced = function(){
        context = this;
        args = arguments;
        timestamp = Date.now();
        var callNow = immediate && !timeout;
        if (!timeout) timeout = setTimeout(later, wait);
        if (callNow) {
            result = func.apply(context, args);
            context = args = null;
        }

        return result;
    };

    debounced.clear = function() {
        if (timeout) {
            clearTimeout(timeout);
            timeout = null;
        }
    };

    debounced.flush = function() {
        if (timeout) {
            result = func.apply(context, args);
            context = args = null;

            clearTimeout(timeout);
            timeout = null;
        }
    };

    return debounced;
};

// Adds compatibility for ES modules
debounce.debounce = debounce;

var substringMatcher = function (strs) {
    return function findMatches(q, cb) {
        var matches, substringRegex;

        // an array that will be populated with substring matches
        matches = [];

        // regex used to determine if a string contains the substring `q`
        substrRegex = new RegExp(q, 'i');

        // iterate through the pool of strings and for any string that
        // contains the substring `q`, add it to the `matches` array
        $.each(strs, function (i, str) {
            if (substrRegex.test(str)) {
                matches.push(str);
            }
        });

        cb(matches);
    };
};


var subModelMatcher = function (modelList, textField) {
    return function findMatches(q, cb) {
        var matches, substringRegex;

        // an array that will be populated with substring matches
        matches = [];

        // regex used to determine if a string contains the substring `q`
        substrRegex = new RegExp(q, 'i');

        // iterate through the pool of strings and for any string that
        // contains the substring `q`, add it to the `matches` array
        $.each(modelList, function (i, model) {
            if (substrRegex.test(model[textField])) {
                matches.push(model);
            }
        });

        cb(matches);
    };
};

Date.prototype.Format = function (fmt) { //author: meizz
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
};

/**
 * Get Date value ('yyyy-mm-dd') from DateTimeValue('"yyyy-MM-dd HH:mm"')
 * @param rawDateTime
 */
var getDateFromDateTime = function (rawDateTime) {
    if (rawDateTime) {
        return rawDateTime.substring(0, 10);
    }
};

/**
 * Get Time value ('HH:mm') from DateTimeValue('"yyyy-MM-dd HH:mm"')
 * @param rawDateTime
 */
var getTimeFromDateTime = function (rawDateTime) {
    if (rawDateTime) {
        return rawDateTime.substring(11);
    }
};

var bindingTagsInput = function($tagsElement, rawValue){
    var array = rawValue.split(',');
    if(!array || array.length === 0){
        return;
    }
    array.forEach(function(value){
        $tagsElement.tagsinput('add', value);
    });
};
/**
 * Generate the DateTimeValue ('"yyyy-MM-dd HH:mm"') by combine date value ('yyyy-mm-dd') and time value ('HH:mm') together
 * @param date
 * @param time
 */
var genDateTime = function (date, time) {
    if (date) {
        if (time) {
            return date + ' ' + time;
        } else {
            return date + ' ' + getCurrentTime();
        }
    }
};




/**
 * Return current time value ('HH:mm')
 * @returns {string}
 */
var getCurrentTime = function () {
    var curDate = new Date();
    var curHours = (curDate.getHours() < 10)? '0' + curDate.getHours():curDate.getHours();
    var curMins = (curDate.getMinutes() < 10)? '0' + curDate.getMinutes():curDate.getMinutes();
    return curHours + ':' + curMins;
};

var initSwitcheryCore = function($element, color, secondaryColor){
    var elems = Array.prototype.slice.call(document.querySelectorAll($element));
    if(elems && elems.length > 0){
        elems.forEach(function (html) {
            var switchery = new Switchery(html, {
                color: color,
                secondaryColor: secondaryColor
            });
        });
    }
};

var initSetSwitchCore = function ($element, value) {
    var eleArray = $($element);
    if (eleArray && eleArray.length > 0) {
        if (value && value === true) {
            eleArray[0].setAttribute("checked", "true");
            eleArray.trigger('click');
        }
    }
};

var clearSearchModel = function(searchModel, initModel){
    if(searchModel){
        var prop;
        for(prop in searchModel){
            if(initModel && initModel[prop]){
                searchModel[prop] = initModel[prop];
                continue;
            }else{
                searchModel[prop] = '';
            }
        }
    }
};

var deepClone = function (data){
    var result = {};
    if(!data || typeof data !== 'object'){
        return;
    }
    var subObject, keys = Object.keys(data);
    var i, len = keys? keys.length: 0;
    for(i = 0; i < len; i++){
        if(typeof data[keys[i]] === "string" || typeof data[keys[i]] === "number"){
            result[keys[i]] = data[keys[i]];
        }
        if(typeof data[keys[i]] === "object" ){
            subObject = deepClone(data[keys[i]]);
            if(subObject){
                result[keys[i]] = subObject;
            }
        }
    }
    return result;
};

var deepCopy = function  (origin, target) {
    if(!origin || typeof origin !== 'object'){
        return;
    }
    var originArray = false;
    originArray = ServiceCollectionsHelper.checkArrayFlag(origin);
    if(originArray === true){
        target = [];
    }else{
        if(!target){
            target = {};
        }
    }
    var keys = Object.keys(origin);
    var i, len = keys? keys.length: 0;
    for(i = 0; i < len; i++){
        if(typeof origin[keys[i]] === "string" || typeof origin[keys[i]] === "number"){
            if(originArray === true){
                target.push(origin[keys[i]]);
            }else{
                target[keys[i]] = origin[keys[i]];
            }
        }
        if(typeof origin[keys[i]] === "object" ){
            target[keys[i]] = deepCopy(origin[keys[i]], target[keys[i]]);
        }
    }
    return target;
};


var clearDefSearchSelectElements = function(elementsList){
    if(elementsList && elementsList.length > 0){
        var i = 0, element, length = elementsList.length;
        for(i = 0; i < length; i++){
            element = elementsList[i];
            if($(element) && $(element).length > 0){
                $(element).val(0);
                $(element).trigger("change");
            }
        }
    }
};

/**
 * Utility method to generate multiple tags value for search
 * @param $tagElement
 * @returns {*}
 */
var getMultSearchTags = function($tagElement){
    var rawTags = $($tagElement).val();
    if(rawTags){
        return rawTags.replace(/,/g ,' ');
    }
};

var Base64 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", encode: function (e) {
        var t = "";
        var n, r, i, s, o, u, a;
        var f = 0;
        e = Base64._utf8_encode(e);
        while (f < e.length) {
            n = e.charCodeAt(f++);
            r = e.charCodeAt(f++);
            i = e.charCodeAt(f++);
            s = n >> 2;
            o = (n & 3) << 4 | r >> 4;
            u = (r & 15) << 2 | i >> 6;
            a = i & 63;
            if (isNaN(r)) {
                u = a = 64
            } else if (isNaN(i)) {
                a = 64
            }
            t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a)
        }
        return t
    }, decode: function (e) {
        var t = "";
        var n, r, i;
        var s, o, u, a;
        var f = 0;
        e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (f < e.length) {
            s = this._keyStr.indexOf(e.charAt(f++));
            o = this._keyStr.indexOf(e.charAt(f++));
            u = this._keyStr.indexOf(e.charAt(f++));
            a = this._keyStr.indexOf(e.charAt(f++));
            n = s << 2 | o >> 4;
            r = (o & 15) << 4 | u >> 2;
            i = (u & 3) << 6 | a;
            t = t + String.fromCharCode(n);
            if (u != 64) {
                t = t + String.fromCharCode(r)
            }
            if (a != 64) {
                t = t + String.fromCharCode(i)
            }
        }
        t = Base64._utf8_decode(t);
        return t
    }, _utf8_encode: function (e) {
        e = e.replace(/\r\n/g, "\n");
        var t = "";
        for (var n = 0; n < e.length; n++) {
            var r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r)
            } else if (r > 127 && r < 2048) {
                t += String.fromCharCode(r >> 6 | 192);
                t += String.fromCharCode(r & 63 | 128)
            } else {
                t += String.fromCharCode(r >> 12 | 224);
                t += String.fromCharCode(r >> 6 & 63 | 128);
                t += String.fromCharCode(r & 63 | 128)
            }
        }
        return t
    }, _utf8_decode: function (e) {
        var t = "";
        var n = 0;
        var r = c1 = c2 = 0;
        while (n < e.length) {
            r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
                n++
            } else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode((r & 31) << 6 | c2 & 63);
                n += 2
            } else {
                c2 = e.charCodeAt(n + 1);
                c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                n += 3
            }
        }
        return t
    }
};


String.prototype.formatString = function(){
    if(arguments.length === 0) return this;
    var param = arguments[0];
    var s = this;
    if(typeof (param) === 'object'){
        for (var key in param){
            s = s.replace(new RegExp("\\{" + key + "\\}", "g"), param[key]);
            return s;
        }
    } else{
        for (var i = 0; i <arguments.length; i++){
            s = s.replace(new RegExp("\\{" + i + "\\}", "g"), arguments[i]);
            return s;
        }
    }
};




