var dataVar = new Vue({
    el: "#x_data",
    data: {
        extensionunionTableId: '#x_table_configureExtensionUnion',
        extensionunionTable: {},
        elementTableId: '#x_table_subSystemConfigureElement',
        elementTable: {},
        label: {
            id: '',
            name: '',
            note: '',
            subScenarioMode: '',
            scenarioModeSwitchProxy: '',
            subScenarioModeSwitchProxy: '',
            standardSystemCategory: '',
            elementType: '',
            scenarioMode: '',
            buttonEdit: '',
            quickEdit: '',
            systemConfigureElementSection: '',
            addSystemConfigureExtensionUnion: '',
            systemConfigureExtensionUnionSection: '',
            addSystemConfigureElement: '',
            msgSaveOK: '',
            msgSaveOKComment: '',
            msgSystemFailure: '',
            msgUnknowSystemFailure: '',
            index: '',
            lockFailureMessage: '',
            parentPageTitle: '',
            pageTitle: '',
            save: '',
            exit: '',
            close: '',
            commit: '',
            systemConfigureCategoryPageTitle:'',
            systemConfigureResourcePageTitle:'',
            systemConfigureElementPageTitle:'',
            systemConfigureExtensionUnion: {
                configureValueId:'',
                configureValueName: '',
                id:'',
                name:'',
                configureSwitchProxy: '',
                configureValue: '',
                refCodeValue: ''
            }
        },
        content: {
            systemConfigureElementUIModel: {
                refNodeName: '',
                refUUID: '',
                elementType: '',
                scenarioMode: '',
                subScenarioMode: '',
                scenarioModeSwitchProxy: '',
                subScenarioModeSwitchProxy: '',
                standardSystemCategory: ''
            },
            systemConfigureElementUIModelList: [],
            systemConfigureExtensionUnionUIModelList: []

        },

        cache: {
            subSystemConfigureElement: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                id: '',
                name: '',
                client: '',
                refNodeName: '',
                refUUID: '',
                scenarioMode: '',
                elementType: ''
            },
            systemConfigureExtensionUnion: {
                uuid: '',
                parentNodeUUID: '',
                rootNodeUUID: '',
                client: '',
                refCodeValueUUID: '',
                refUUID: '',
                refNodeName: '',
                configureValueId:'',
                configureValueName: '',
                id:'',
                name:'',
                configureSwitchProxy: '',
                configureValue: ''
            },
            systemCodeValueUnionUIModelList: [],
            pageHeaderModelList:[]
        },
        author: {
            resourceId: ServiceModuleConstants.SystemConfigureResource,
            actionCode: {
                Edit: false,
                View: false,
                PriceInfo: false,
                Delete: false,
                Excel: false
            }
        },
        newSystemConfigureExtensionUnionServiceURL: '../systemConfigureExtensionUnion/newModuleService.html',
        eleEditSystemConfigureExtensionUnionModal: '#x_eleEditSystemConfigureExtensionUnionModal',
        newSubSystemConfigureElementServiceURL: '../systemConfigureElement/newModuleService.html',
        eleEditSubSystemConfigureElementModal: '#x_eleEditSubSystemConfigureElementModal',
        eleStandardSystemCategory: '#x_standardSystemCategory',
        eleScenarioMode: '#x_scenarioMode',
        eleSubScenarioMode: '#x_subScenarioMode',
        eleEmbedScenarioMode: '#x_embeddedScenarioMode',
        eleEmbedSubScenarioMode: '#x_embeddedSubScenarioMode',
        eleElementType: '#x_elementType',
        eleEmbedElementType: '#x_embeddedElementType',
        eleRefCodeValue: '#x_refCodeValue',
        eleConfigureValue: '#x_configureValue',
        getPageHeaderModelListURL: '../systemConfigureElement/getPageHeaderModelList.html',
        getScenarioModeMapURL: '../systemConfigureCategory/getScenarioModeMap.html',
        getSubScenarioModeMapURL: '../systemConfigureCategory/getSubScenarioModeMap.html',
        getSystemStandardCategoryMapURL: '../systemConfigureCategory/getSystemStandardCategoryMap.html',
        getSystemCodeValueCollectionListURL: '../systemCodeValueCollection/loadModuleListService.html',
        getSystemCodeValueCollectionURL: '../systemCodeValueCollection/loadModuleEditService.html',
        getElementTypeMapURL: '../systemConfigureCategory/getElementTypeMap.html',
        loadModuleEditURL: '../systemConfigureElement/loadModuleEditService.html',
        loadModuleViewURL: '../systemConfigureElement/loadModuleViewService.html',
        saveModuleURL: '../systemConfigureElement/saveModuleService.html',
        exitModuleURL: '../systemConfigureElement/exitEditor.html',
        newModuleServiceURL: '../systemConfigureElement/newModuleService.html'
    },

    created: function () {
        this.initSubComponents();
        this.initAuthorResourceCheck();
    },

    mounted: function () {
        this.$nextTick(function () {
            var vm = this;
            NavigationPanelIns.initNavigation('systemAdmin', 'SystemConfigureResource');
            this.extensionunionTable = new ServiceDataTable(this.extensionunionTableId);
            this.elementTable = new ServiceDataTable(this.elementTableId);
            this.setI18nProperties();
            this.loadModuleEdit();
            this.initSelectConfigure();
        });
    },

    methods: {

        /**
         * Initial register sub component
         */
        initSubComponents: function(){
            "use strict";
            Vue.component("page-header-union", PageHeaderUnion);
        },

        initAuthorResourceCheck: function () {
            "use strict";
            var vm = this;
            ServiceAuthorHelper.initDefaultAuthorObject({
                vm: vm,
                errorHandle: ServiceUtilityHelper.handleErrorUIDefault
            });
        },

        initSelectConfigure: function () {
            var vm = this;
            $(vm.eleStandardSystemCategory).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.systemConfigureElementUIModel, 'standardSystemCategory', $(vm.eleStandardSystemCategory).val());
            });
            $(vm.eleScenarioMode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.systemConfigureElementUIModel, 'scenarioMode', $(vm.eleScenarioMode).val());
            });
            $(vm.eleSubScenarioMode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.systemConfigureElementUIModel, 'subScenarioMode', $(vm.eleSubScenarioMode).val());
            });
            $(vm.eleEmbedScenarioMode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.subSystemConfigureElement, 'scenarioMode', $(vm.eleEmbedScenarioMode).val());
            });
            $(vm.eleEmbedSubScenarioMode).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.subSystemConfigureElement, 'subScenarioMode', $(vm.eleEmbedSubScenarioMode).val());
            });
            $(vm.eleElementType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.content.systemConfigureElementUIModel, 'elementType', $(vm.eleElementType).val());
            });
            $(vm.eleEmbedElementType).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.subSystemConfigureElement, 'elementType', $(vm.eleEmbedElementType).val());
            });
            $(vm.eleRefCodeValue).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                vm.$set(vm.cache.systemConfigureExtensionUnion, 'refCodeValueUUID', $(vm.eleRefCodeValue).val());
                // Logic to set configure value
                vm.getSystemCodeValueUnionSelect($(vm.eleRefCodeValue).val());

            });
            $(vm.eleConfigureValue).on("select2:close", function (e) {
                // Set value to vue from select2 manually by select2's bug
                var refCodeValueUUID = $(vm.eleConfigureValue).val();
                vm.$set(vm.cache.systemConfigureExtensionUnion, 'configureValue', refCodeValueUUID);
                var refCodeValue = ServiceCollectionsHelper.filterArray(refCodeValueUUID, 'uuid', vm.cache.systemCodeValueUnionUIModelList);
                if (refCodeValue) {
                    vm.$set(vm.cache.systemConfigureExtensionUnion, 'configureValueName', refCodeValue.name);
                    vm.$set(vm.cache.systemConfigureExtensionUnion, 'configureValueId', refCodeValue.id);
                }
            });
        },

        setI18nCommonProperties: function () {
            this.label.msgSaveOK = $.i18n.prop('msgSaveOK');
            this.label.msgSaveOKComment = $.i18n.prop('msgSaveOKComment');
            this.label.msgSystemFailure = $.i18n.prop('msgSystemFailure');
            this.label.msgUnknowSystemFailure = $.i18n.prop('msgUnknowSystemFailure');
            this.label.index = $.i18n.prop('index');
            this.label.lockFailureMessage = $.i18n.prop('lockFailureMessage');
            this.label.buttonEdit = $.i18n.prop('edit');
            this.label.quickEdit = $.i18n.prop('quickEdit');
            this.label.save = $.i18n.prop('save');
            this.label.exit = $.i18n.prop('exit');
            this.label.close = $.i18n.prop('close');
            this.label.commit = $.i18n.prop('commit');
            BusyLoader.cleanPageBackground();
        },

        setNodeI18nPropertiesCore: function () {
            this.label.id = $.i18n.prop('id');
            this.label.name = $.i18n.prop('name');
            this.label.note = $.i18n.prop('note');
            this.label.scenarioModeSwitchProxy = $.i18n.prop('scenarioModeSwitchProxy');
            this.label.subScenarioModeSwitchProxy = $.i18n.prop('subScenarioModeSwitchProxy');
            this.label.elementType = $.i18n.prop('elementType');
            this.label.scenarioMode = $.i18n.prop('scenarioMode');
            this.label.subScenarioMode = $.i18n.prop('subScenarioMode');
            this.label.standardSystemCategory = $.i18n.prop('standardSystemCategory');
            this.label.systemConfigureElementSection = $.i18n.prop('systemConfigureElementSection');
            this.label.parentPageTitle = $.i18n.prop('parentPageTitle');
            this.label.pageTitle = $.i18n.prop('pageTitle');
            this.label.addSystemConfigureExtensionUnion = $.i18n.prop('addSystemConfigureExtensionUnion');
            this.label.systemConfigureExtensionUnionSection = $.i18n.prop('systemConfigureExtensionUnionSection');
            this.label.addSystemConfigureElement = $.i18n.prop('addSystemConfigureElement');
            this.label.systemConfigureElementSection = $.i18n.prop('systemConfigureElementSection');
            this.label.systemConfigureCategoryPageTitle = $.i18n.prop('systemConfigureCategoryPageTitle');
            this.label.systemConfigureResourcePageTitle = $.i18n.prop('systemConfigureResourcePageTitle');
            this.label.systemConfigureElementPageTitle = $.i18n.prop('systemConfigureElementPageTitle');
        },

        setI18nExtensionUnionProperties: function () {
            this.label.systemConfigureExtensionUnion.configureValueName = $.i18n.prop('configureValueName');
            this.label.systemConfigureExtensionUnion.configureValueId = $.i18n.prop('configureValueId');
            this.label.systemConfigureExtensionUnion.configureSwitchProxy = $.i18n.prop('configureSwitchProxy');
            this.label.systemConfigureExtensionUnion.configureValue = $.i18n.prop('configureValue');
            this.label.systemConfigureExtensionUnion.name = $.i18n.prop('name');
            this.label.systemConfigureExtensionUnion.id = $.i18n.prop('id');
            this.label.systemConfigureExtensionUnion.refCodeValue = $.i18n.prop('refCodeValue');
        },


        setI18nProperties: function () {
            getCommonI18n(jQuery.i18n, this.setI18nCommonProperties);
            jQuery.i18n.properties({
                name: 'SystemConfigureElement', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setNodeI18nPropertiesCore
            });
            jQuery.i18n.properties({
                name: 'SystemConfigureExtensionUnion', //properties file name
                path: getI18nRootPath() + this.getI18nPath(), //path for properties files
                mode: 'map', //Using map mode to consume properties files
                language: getLan(),
                cache:true,
                callback: this.setI18nExtensionUnionProperties
            });

        },

        getI18nPath: function () {
            return "coreFunction/";
        },

        errorHandle: function (oData) {
            ServiceHttpRequestHelper.handleErrorWithBarWrap(oData, {
                container: $('.main.message-container')
            });
        },

        displayForEdit: function () {
            return DocumentManagerFactory.formatDisplayClass(this.author.actionCode.Edit === true ? true : undefined);
        },

        loadModuleEdit: function () {
            var vm = this;
            var baseUUID = getUrlVar("uuid");
            var processMode = getUrlVar(LABEL_PROCESSMODE) * 1;
            if (processMode === PROCESSMODE_NEW) {
                if ($('.editBlock')) {
                    $('.editBlock').hide();
                }
                baseUUID = getUrlVar("baseUUID");
                var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
                ServiceUtilityHelper.httpRequest({
                    url: vm.newModuleServiceURL,
                    $http: vm.$http,
                    method: 'post',
                    requestData: requestData,
                    errorHandle: vm.errorHandle,
                    postHandle: function (oData) {
                        vm.setModuleToUI(oData.content);
                    }.bind(this)
                });
            }
            if (processMode === PROCESSMODE_EDIT) {
                ServiceUtilityHelper.loadEditModuleDefault({
                    editUrl: this.loadModuleEditURL,
                    viewUrl: this.loadModuleViewURL,
                    uuid: baseUUID,
                    author: vm.author,
                    $http: vm.$http,
                    errorHandle: vm.errorHandle,
                    postSet: vm.setModuleToUI
                });
            }

        },

        saveModule: function () {
            var vm = this;
            if (!$('#x_form_data').parsley().validate()) {
                return;
            }
            ServiceUtilityHelper.httpRequest({
                url: vm.saveModuleURL,
                $http: vm.$http,
                method: 'post',
                requestData: vm.content,
                errorHandle: vm.errorHandle,
                postHandle: function (oData) {
                    $.Notification.notify('success', 'top center', vm.label.msgSaveOK, vm.label.msgSaveOKComment);
                    vm.setModuleToUI(oData.content);
                    var processMode = getUrlVar(LABEL_PROCESSMODE);
                    if (processMode && processMode === PROCESSMODE_NEW) {
                        var baseUUID = vm.content.systemConfigureElementUIModel.uuid;
                        if (baseUUID) {
                            window.location.href = genCommonEditURL("SystemConfigureElementEditor.html", baseUUID);
                        }
                    }
                }.bind(this)
            });
        },

        exitModule: function () {
            var vm = this;
            var baseUUID = vm.content.systemConfigureElementUIModel.parentNodeUUID;
            window.location.href = genCommonEditURL("SystemConfigureResourceEditor.html", baseUUID);

        },

        refreshEditView: function () {
            var baseUUID = this.content.systemConfigureElementUIModel.uuid;
            window.location.href = genCommonEditURL("SystemConfigureElementEditor.html", baseUUID);

        },

        loadScenarioModeList: function (content) {
            var vm = this;
            this.$http.get(this.getScenarioModeMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleScenarioMode).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleScenarioMode).val(content.systemConfigureElementUIModel.scenarioMode);
                    $(vm.eleScenarioMode).trigger("change");
                }, 0);
            });
        },

        loadSubScenarioModeList: function (content) {
            var vm = this;
            this.$http.get(this.getSubScenarioModeMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleSubScenarioMode).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleSubScenarioMode).val(content.systemConfigureElementUIModel.subScenarioMode);
                    $(vm.eleSubScenarioMode).trigger("change");
                }, 0);
            });
        },

        loadEmbeddedScenarioModeList: function (content) {
            var vm = this;
            this.$http.get(this.getScenarioModeMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleEmbedScenarioMode).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleEmbedScenarioMode).val(content.scenarioMode);
                    $(vm.eleEmbedScenarioMode).trigger("change");
                }, 0);
            });
        },

        loadEmbeddedSubScenarioModeList: function (content) {
            var vm = this;
            this.$http.get(this.getSubScenarioModeMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleEmbedSubScenarioMode).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleEmbedSubScenarioMode).val(content.subScenarioMode);
                    $(vm.eleEmbedSubScenarioMode).trigger("change");
                }, 0);
            });
        },

        loadStandardSystemCategoryList: function (content) {
            var vm = this;
            this.$http.get(this.getSystemStandardCategoryMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleStandardSystemCategory).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleStandardSystemCategory).val(content.systemConfigureElementUIModel.standardSystemCategory);
                    $(vm.eleStandardSystemCategory).trigger("change");
                }, 0);
            });
        },

        loadElementTypeList: function (content) {
            var vm = this;
            this.$http.get(this.getElementTypeMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleElementType).select2({
                        data: resultList
                    })
                    // manually set initial value
                    $(vm.eleElementType).val(content.systemConfigureElementUIModel.elementType);
                    $(vm.eleElementType).trigger("change");
                }, 0);
            });
        },

        loadEmbeddedElementTypeList: function (content) {
            var vm = this;
            this.$http.get(this.getElementTypeMapURL).then(function (response) {
                if (!JSON.parse(response.body)) {
                    // pop up error message
                }
                var resultList = JSON.parse(response.body);
                setTimeout(function () {
                    $(vm.eleEmbedElementType).select2({
                        data: resultList
                    });
                    // manually set initial value
                    $(vm.eleElementType).val(content.elementType);
                    $(vm.eleElementType).trigger("change");
                }, 0);
            });
        },

        editSystemConfigureExtensionUnionModal: function (uuid) {
            var vm = this;
            var item = ServiceCollectionsHelper.filterArray(uuid, 'uuid', this.content.systemConfigureExtensionUnionUIModelList);
            if (!item) {
                return;
            }
            this.cache.systemConfigureExtensionUnion = this.copySystemConfigureExtensionUnion(item);
            // manually set initial value
            $(vm.eleRefCodeValue).val(this.cache.systemConfigureExtensionUnion.refCodeValueUUID);
            $(vm.eleRefCodeValue).trigger("change");
            vm.getSystemCodeValueUnionSelect(this.cache.systemConfigureExtensionUnion.refCodeValueUUID);
            $(this.eleEditSystemConfigureExtensionUnionModal).modal('toggle');

        },

        editSystemConfigureExtensionUnion: function (uuid) {
            var vm = this;
            window.location.href = genCommonEditURL("SystemConfigureExtensionUnionEditor.html", uuid);
        },


        getPageHeaderModelList: function(uuid, baseUUID){
            var vm = this;
            vm.$refs.pageHeader.initPageHeader({
                uuid:uuid,
                baseUUID: baseUUID,
                pageHeaderListUrl:vm.getPageHeaderModelListURL,
                fnPageHeaderModel:vm.fnPageHeaderModel
            });
        },

        fnPageHeaderModel:function(pageHeaderModel){
            if (pageHeaderModel.nodeInstId === 'systemConfigureCategory'){
                baseDocURL = genCommonEditURL("SystemConfigureCategoryEditor.html", pageHeaderModel.uuid);
                pageHeaderModel.pageLink = baseDocURL;
                pageHeaderModel.pageTitle = this.label.systemConfigureCategoryPageTitle;
                return pageHeaderModel;
            }
            if (pageHeaderModel.nodeInstId === 'systemConfigureResource'){
                baseDocURL = genCommonEditURL("SystemConfigureResourceEditor.html", pageHeaderModel.uuid);
                pageHeaderModel.pageLink = baseDocURL;
                pageHeaderModel.pageTitle = this.label.systemConfigureResourcePageTitle;
                return pageHeaderModel;
            }
            if (pageHeaderModel.nodeInstId === 'systemConfigureElement'){
                baseDocURL = genCommonEditURL("SystemConfigureElementEditor.html", pageHeaderModel.uuid);
                pageHeaderModel.pageLink = baseDocURL;
                pageHeaderModel.pageTitle = this.label.systemConfigureElementPageTitle;
                return pageHeaderModel;
            }
        },


        addSubSystemConfigureElementModal: function () {
            var baseUUID = this.content.systemConfigureElementUIModel.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            this.$http.post(this.newSubSystemConfigureElementServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                var content = oData.content;
                // In case success.

                this.cache.subSystemConfigureElement = this.copySystemConfigureElement(content, this.cache.subSystemConfigureElement);
                this.loadEmbeddedScenarioModeList(this.cache.subSystemConfigureElement);
                this.loadEmbeddedSubScenarioModeList(this.cache.subSystemConfigureElement);
                this.loadEmbeddedElementTypeList(this.cache.subSystemConfigureElement);
                $(this.eleEditSubSystemConfigureElementModal).modal('toggle');
            }.bind(this));
        },

        editSystemConfigureElementModal: function (uuid) {
            var vm = this;
            var item = ServiceCollectionsHelper.filterArray(uuid, 'uuid', this.content.systemConfigureElementUIModelList);
            if (!item) {
                return;
            }
            this.cache.subSystemConfigureElement = his.copySystemConfigureElement(item);
            // manually set initial value
            this.loadEmbeddedScenarioModeList(this.cache.subSystemConfigureElement);
            this.loadEmbeddedSubScenarioModeList(this.cache.subSystemConfigureElement);
            this.loadEmbeddedElementTypeList(this.cache.subSystemConfigureElement);
            $(this.eleEditSubSystemConfigureElementModal).modal('toggle');

        },

        addSystemConfigureExtensionUnion: function () {
            var paras = {};
            paras.processMode = PROCESSMODE_NEW;
            paras.baseUUID = this.content.systemConfigureElementUIModel.uuid;
            var resultURL = "SystemConfigureExtensionUnionEditor.html" + "?" + urlEncode(paras);
            window.location.href = resultURL;
        },

        setToSystemConfigureExtensionUnion: function () {
            var vm = this;
            var item = ServiceCollectionsHelper.filterArray(this.cache.systemConfigureExtensionUnion.uuid, 'uuid', this.content.systemConfigureExtensionUnionUIModelList);
            if (!item) {
                //In case new Item added
                var newItem = this.copySystemConfigureExtensionUnion(this.cache.systemConfigureExtensionUnion);
                this.content.systemConfigureExtensionUnionUIModelList.push(newItem);
            } else {
                this.copySystemConfigureExtensionUnion(this.cache.systemConfigureExtensionUnion, item);
            }
            $(this.eleEditSystemConfigureExtensionUnionModal).modal('hide');
        },



        setToSubSystemConfigureElement: function () {
            var vm = this;
            var item = ServiceCollectionsHelper.filterArray(this.cache.subSystemConfigureElement.uuid, 'uuid', vm.cache.systemConfigureElementUIModelList);
            if (!item) {
                //In case new Item added
                var newItem = this.copySystemConfigureElement(this.cache.subSystemConfigureElement);
                this.content.systemConfigureElementUIModelList.push(newItem);
            } else {
                this.copySystemConfigureElement(this.cache.subSystemConfigureElement, item);
            }
            $(this.eleEditSubSystemConfigureElementModal).modal('hide');
        },

        copySystemConfigureElement: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refNodeName = origin.refNodeName;
            target.refUUID = origin.refUUID;
            target.scenarioMode = origin.scenarioMode;
            target.elementType = origin.elementType;
            return target;

        },

        copySystemConfigureExtensionUnion: function (origin, target) {
            if (!target) {
                target = {};
            }
            target.uuid = origin.uuid;
            target.parentNodeUUID = origin.parentNodeUUID;
            target.rootNodeUUID = origin.rootNodeUUID;
            target.client = origin.client;
            target.id = origin.id;
            target.name = origin.name;
            target.refCodeValueUUID = origin.refCodeValueUUID;
            target.refUUID = origin.refUUID;
            target.refNodeName = origin.refNodeName;
            target.configureValueName = origin.configureValueName;
            target.configureValueId = origin.configureValueId;
            target.configureSwitchProxy = origin.configureSwitchProxy;
            target.configureValue = origin.configureValue;
            return target;
        },




        addSystemConfigureExtensionUnionModal: function () {
            var vm = this;
            var baseUUID = this.content.systemConfigureElementUIModel.uuid;
            var requestData = generateServiceSimpleContentUnion("baseUUID", baseUUID);
            this.$http.post(this.newSystemConfigureExtensionUnionServiceURL, requestData).then(function (response) {
                var oData = JSON.parse(response.data);
                if (!oData.content) {
                    ServiceHttpRequestHelper.handleErrorCodeWrap(oData);
                    return;
                }
                // manually set initial value
                $(vm.eleRefCodeValue).val(vm.cache.systemConfigureExtensionUnion.refCodeValueUUID);
                $(vm.eleRefCodeValue).trigger("change");
                // In case success.
                this.cache.systemConfigureExtensionUnion = this.copySystemConfigureExtensionUnion(oData.content, this.cache.systemConfigureExtensionUnion);
                $(this.eleEditSystemConfigureExtensionUnionModal).modal('toggle');
            });

        },

        deleteSystemConfigureExtensionUnion: function () {
            var vm = this;
            swal({
                    title: vm.label.deleteWarnTitle,
                    text: vm.label.deleteWarnText,
                    type: "error",
                    showCancelButton: true,
                    cancelButtonText: vm.label.cancel,
                    confirmButtonClass: 'btn btn-action btn-rounded-embedded',
                    cancelButtonClass: 'btn btn-nonAction btn-rounded-embedded',
                    confirmButtonText: vm.label.confirm
                },
                function (isConfirm) {
                    if (isConfirm) {
                        var item = ServiceCollectionsHelper.filterArray(uuid, 'uuid', vm.content.systemConfigureExtensionUnionUIModelList);
                        if (!item) {
                            return;
                        }
                        ServiceCollectionsHelper.removeItemByUUID(uuid, content.systemConfigureExtensionUnionUIModelList);
                    } else {
// do nothing, just return
                    }
                });
        },

        editSystemConfigureExtensionUnion: function (uuid) {

        },

        getSystemCodeValueUnionSelect: function (baseUUID) {
            var vm = this;
            var url = this.getSystemCodeValueCollectionURL + "?&uuid=" + baseUUID;
            if(!baseUUID){
                return;
            }
            this.$http.get(url).then(function (response) {
                var content = JSON.parse(response.body).content
                if (!content) {
                    // pop up error message
                }
                this.cache.systemCodeValueUnionUIModelList = content.systemCodeValueUnionUIModelList;
                vm.$set(vm.cache.systemConfigureExtensionUnion, 'name', content.systemCodeValueCollectionUIModel.name);
                vm.$set(vm.cache.systemConfigureExtensionUnion, 'id', content.systemCodeValueCollectionUIModel.id);
                var resultList = vm.formatCodeValueSelectResult(this.cache.systemCodeValueUnionUIModelList);
                $(vm.eleConfigureValue).empty();
                setTimeout(function () {
                    $(vm.eleConfigureValue).select2({
                        data: resultList
                    });
                }, 0);
            });
        },

        formatCodeValueSelectResult: function (rawList) {
            if (!rawList || rawList.length == 0) {
                return null;
            }
            var i = 0, len = rawList.length, resultList = [];
            for (var i = 0; i < len; i++) {
                var element = {'id': rawList[i]['uuid'], 'text': rawList[i]['id'] + '-' + rawList[i]['name']}
                resultList.push(element);
            }
            return resultList;
        },

        getSystemCodeValueCollection: function () {
            var vm = this;
            this.$http.get(this.getSystemCodeValueCollectionListURL).then(function (response) {
                if (!JSON.parse(response.body).content) {
                    // pop up error message
                }
                var resultList = formatSelectResult(JSON.parse(response.body).content, 'uuid', 'id');
                setTimeout(function () {
                    $(vm.eleRefCodeValue).select2({
                        data: resultList
                    });

                }, 0);
            });
        },


        setModuleToUI: function (content) {
            var vm = this;
            vm.$set(vm.content, 'systemConfigureElementUIModel', content.systemConfigureElementUIModel);
            vm.$set(vm.content, 'systemConfigureElementUIModelList', content.systemConfigureElementUIModelList);
            vm.$set(vm.content, 'systemConfigureExtensionUnionUIModelList', content.systemConfigureExtensionUnionUIModelList);
            vm.getPageHeaderModelList(vm.content.systemConfigureElementUIModel.uuid, vm.content.systemConfigureElementUIModel.parentNodeUUID);
            vm.loadStandardSystemCategoryList(content);
            vm.loadSubScenarioModeList(content);
            vm.loadScenarioModeList(content);
            vm.loadElementTypeList(content);
            vm.getSystemCodeValueCollection();
        }

    }
});
