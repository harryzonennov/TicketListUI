
var BootStrapImageAttach = function () {
    
};

BootStrapImageAttach.IMAGE_PATH = {
    PDF_BIG : "assets/images/pdf_256_2.png",
    DOC_BIG : "assets/images/word_256.png",
    XLS_BIG : "assets/images/excel_256.png",
    XML_BIG : "assets/images/xml_512.png",
};

var BootStrapAttachProxy = function(){

};

BootStrapAttachProxy.prototype.label = {
    attachment: {
        drapUploadExcelMessage: '',
        dragUploadImagePdfMessage: '',
        uploadFileTooBig: '',
        commitUpload: '',
        uploadInvalidFileType: '',
        attachmentTitle: '',
        attachmentDescription: '',
        uploadExcel: '',
        deleteAttachment: '',
        confirm:''
    }
};



/**
 * @override Get i18n Settings' entry method.
 * @returns {string}
 */
BootStrapAttachProxy.prototype.getI18nWrap = function (fnCallback) {
    var vm = this;
    jQuery.i18n.properties({
        name: 'ComElements', //properties file name
        path: getI18nRootPath() + "coreFunction/",
        mode: 'map', //Using map mode to consume properties files
        language: getLan(),
        cache:true,
        callback: function(){
            vm.getI18nCommonMap();
            if(fnCallback && typeof fnCallback === 'function'){
                fnCallback();
            }
        }.bind(this)
    });
};

BootStrapAttachProxy.prototype.getI18nCommonMap = function () {
    this.label.attachment.dragUploadImagePdfMessage = $.i18n.prop('dragUploadImagePdfMessage');
    this.label.attachment.drapUploadExcelMessage = $.i18n.prop('drapUploadExcelMessage');
    this.label.attachment.uploadFileTooBig = $.i18n.prop('uploadFileTooBig2M');
    this.label.attachment.commitUpload = $.i18n.prop('commitUpload');
    this.label.attachment.uploadInvalidFileType = $.i18n.prop('uploadInvalidFileType');
    this.label.attachment.attachmentTitle = $.i18n.prop('attachmentTitle');
    this.label.attachment.attachmentDescription = $.i18n.prop('attachmentDescription');
    this.label.attachment.deleteAttachment = $.i18n.prop('deleteAttachment');
    this.label.attachment.confirm = $.i18n.prop('confirm');
};

BootStrapAttachProxy.prototype.loadAttachBatch = function (attachmentList, loadAttachmentUrl) {
    if (!attachmentList) {
        return;
    }
    var i, rawAttachModal, attachmentModelList = [];
    for (i = 0; i < attachmentList.length; i++) {
        rawAttachModal = attachmentList[i];
        var attachmentModel = {};
        attachmentModel.url = loadAttachmentUrl + '?uuid=' + rawAttachModal.uuid;
        attachmentModel.uuid = rawAttachModal.uuid;
        attachmentModel.title = rawAttachModal.attachmentTitle;
        attachmentModel.description = rawAttachModal.attachmentDescription;
        attachmentModel.fileType = rawAttachModal.fileType;
        attachmentModelList.push(attachmentModel);
    }
    return attachmentModelList;
};

/**
 * Initialization drop zone plugin for attachment uploading
 * @param {object} oSettings
 *         --{function} refreshEditView
 *         --{string} eleAttachmentDropzone
 *         --{string} uploadAttachmentURL
 *         --{string} loadAttachmentUrl
 *         --{array} attachModelList
 *         --{string} deleteAttachmentURL
 *         --{function} deleteAttachmentCallback
 *         --{object} $http
 *         --{object} attachmentDropzone
 */
BootStrapAttachProxy.prototype.initAttachmentPlugin = function (oSettings) {
    var vm = this;

    var defAcceptedFiles = ".pdf, .docx, doc, image/jpeg,image/png,image/gif";
    var eleUploadAttachment = oSettings.eleUploadAttachment? oSettings.eleUploadAttachment:'x_uploadAttachment';

    return new Promise(function(resolve, reject){
        var callBack = function () {
            oSettings.attachmentDropzone = new Dropzone(oSettings.eleAttachmentDropzone, {
                url: oSettings.uploadAttachmentURL,                                      // url to load files to server
                uploadMultiple: true,                                                    // Accept Multiple files upload
                dictDefaultMessage: oSettings.dictDefaultMessage? oSettings.dictDefaultMessage: vm.label.attachment.dragUploadImagePdfMessage,       // Message to show on empty dropzone
                dictFileTooBig: vm.label.attachment.uploadFileTooBig,                    // Error Message when file is too big
                dictInvalidFileType: vm.label.attachment.uploadInvalidFileType,          // Error Message when file type is not accepted
                autoProcessQueue: false,
                maxFilesize: 10,                                                         // Max File Size *(MB)
                acceptedFiles: oSettings.acceptedFiles? oSettings.acceptedFiles: defAcceptedFiles,                  // Accepted file types
                queuecomplete: oSettings.queuecomplete? oSettings.queuecomplete: function(){},                      // file uploaded done call-back function
                init: function () {
                    this.on("success", function (file, responseText) {
                        oSettings.refreshEditView();
                    });
                    this.on("error", function (file, message) {
                        if(oSettings.errorHandle){
                            oSettings.errorHandle({errorMessage: message});
                        }
                        this.removeFile(file);
                    });
                    this.on("addedfile", function (file) {
                        // Create the remove button
                        var removeButton = Dropzone.createElement("<button class='btn btn-rounded waves-effect waves-light'>" +
                            vm.label.attachment.deleteAttachment + "</button>");
                        // Capture the Dropzone instance as closure.
                        var _this = this;
                        // Listen to the click event
                        removeButton.addEventListener("click", function (e) {
                            // Make sure the button click doesn't submit the form:
                            e.preventDefault();
                            e.stopPropagation();
                            // Remove the file preview.
                            _this.removeFile(file);
                            // If you want to the delete the file on the server as well,
                            // you can do the AJAX request here.
                        });
                        // Add the button to the file preview element.
                        file.previewElement.appendChild(removeButton);
                    });
                }
            });
            oSettings.attachmentDropzone.on('addedfile', vm.getDefaultAddedAttachment());
            var attachModelList = [];
            attachModelList = vm.loadAttachBatch(oSettings.attachModelList, oSettings.loadAttachmentUrl);
            var eleCoreArea = '#' + eleUploadAttachment + ' .webdesign.illustrator';
            $(eleCoreArea).empty();
            generateAttachBatch($("#" + eleUploadAttachment ), attachModelList, vm.label.attachment.deleteAttachment, oSettings);

            $(".iconDeleteAttachment").on("click", function (e) {
                var uuid = $(this).children("input").attr("value");
                vm.deleteAttachment(oSettings, uuid);
                e.stopPropagation();
            });

            resolve(oSettings.attachmentDropzone);
        }.bind(this);
        vm.getI18nWrap(callBack);

    });


};

BootStrapAttachProxy.prototype.deleteAttachment =  function (oSettings, uuid) {
    var vm = this;
    var requestData = {};
    requestData.uuid = uuid;
    oSettings.$http.post(oSettings.deleteAttachmentURL, requestData).then(function (response) {
        if(oSettings.deleteAttachmentCallback && typeof  oSettings.deleteAttachmentCallback === 'function'){
            oSettings.deleteAttachmentCallback(response);
        }
    });
};

/**
 * Default Added event function for attachment display
 * @returns {_func}
 */
BootStrapAttachProxy.prototype.getDefaultAddedAttachment = function(){
    var _func = function (file) {
        var ext = file.name.split('.').pop();
        if (ext == "pdf") {
            $(file.previewElement).find(".dz-image img").attr("src", "assets/images/pdf.png");
        } else if (ext.indexOf("doc") != -1) {
            $(file.previewElement).find(".dz-image img").attr("src", "assets/images/word_128.png");
        } else if (ext.indexOf("docx") != -1) {
            $(file.previewElement).find(".dz-image img").attr("src", "assets/images/word_128.png");
        } else if (ext.indexOf("xls") != -1) {
            $(file.previewElement).find(".dz-image img").attr("src", "assets/images/excel_128.png");
        } else if (ext.indexOf("xlsx") != -1) {
            $(file.previewElement).find(".dz-image img").attr("src", "assets/images/excel_128.png");
        }
    };
    return _func;
};

function generateAttachBatch(container, attachmentModelList, deleteTitle, oSettings){
    var ser = new XMLSerializer();
    if(!attachmentModelList || attachmentModelList.length === 0){
        return;
    }
    for(var i = 0; i < attachmentModelList.length; i++){
        var pictureElement = generateBootStrapAttachmentUnion(attachmentModelList[i], deleteTitle, oSettings);
        var htmlContent = ser.serializeToString(pictureElement);
        container.prepend(htmlContent);
    }
}

/**
 * Generate default Bootstrap style Image attachment union
 * @param pictureModel
 * @returns {Element}
 */
function  generateBootStrapAttachmentUnion (attachmentModel, deleteTitle, oSettings) {
    var xmlDoc = document.implementation.createDocument("", "", null);
    // Add li element
    var topElement = xmlDoc.createElement("div");
    var topElementClass = oSettings.topElementClass? oSettings.topElementClass: 'col-sm-6 col-lg-3 col-md-4';
    topElement.setAttribute("class", topElementClass + " webdesign illustrator");
    var thumbElement = xmlDoc.createElement("div");
    thumbElement.setAttribute("class", "gal-detail thumb");
    topElement.appendChild(thumbElement);
    var ahrefElement = xmlDoc.createElement("a");
    ahrefElement.setAttribute("class", "image-popup");
    ahrefElement.setAttribute("target", "_blank");
    thumbElement.appendChild(ahrefElement);

    var imgElement = xmlDoc.createElement("img");
    var hitFlag = false;
    var downloadFlag = false;
    if(attachmentModel.fileType === 'pdf'){
        hitFlag = true;
        imgElement.setAttribute("src", BootStrapImageAttach.IMAGE_PATH.PDF_BIG);
    }
    if(attachmentModel.fileType === 'xml'){
        hitFlag = true;
        downloadFlag = true;
        imgElement.setAttribute("src", BootStrapImageAttach.IMAGE_PATH.XML_BIG);
    }
    if(attachmentModel.fileType === 'jrxml'){
        hitFlag = true;
        downloadFlag = true;
        imgElement.setAttribute("src", BootStrapImageAttach.IMAGE_PATH.XML_BIG);
    }
    if(attachmentModel.fileType === 'doc' || attachmentModel.fileType === 'docx'){
        hitFlag = true;
        imgElement.setAttribute("src", BootStrapImageAttach.IMAGE_PATH.DOC_BIG);
    }
    if(attachmentModel.fileType === 'xls' || attachmentModel.fileType === 'xlsx'){
        hitFlag = true;
        downloadFlag = true;
        imgElement.setAttribute("src", BootStrapImageAttach.IMAGE_PATH.XLS_BIG);
    }
    if(!hitFlag){
        imgElement.setAttribute("src", attachmentModel.url);
    }
    // In case special handing need to download file
    if(downloadFlag === true){
        ahrefElement.setAttribute("href", '');
        $(ahrefElement).click(function(event){
            event.preventDefault();
            oSettings.$http.get(attachmentModel.url).then(function (response) {
                ExcelUploadAttach.showFile(response.body, attachmentModel.title);
            }.bind(this));
            return false;
        });
        // ahrefElement.addEventListener("click", function(event){
        //     oSettings.$http.get(attachmentModel.url).then(function (response) {
        //         ExcelUploadAttach.showFile(response.body, attachmentModel.title);
        //     }.bind(this));
        // });
    }else{
        ahrefElement.setAttribute("href", attachmentModel.url);
    }

    imgElement.setAttribute("class", "thumb-img");
    imgElement.setAttribute("title", attachmentModel.title);
    ahrefElement.appendChild(imgElement);

    var textCenterElemnt = xmlDoc.createElement("h4");
    textCenterElemnt.setAttribute("class", "text-center");
    thumbElement.appendChild(textCenterElemnt);
    var textNode = xmlDoc.createTextNode(attachmentModel.title);
    textCenterElemnt.appendChild(textNode);
    var gaborderElemnt = xmlDoc.createElement("div");
    gaborderElemnt.setAttribute("class", "ga-border");
    thumbElement.appendChild(gaborderElemnt);

    var descriptionElement = xmlDoc.createElement("p");
    descriptionElement.setAttribute("class", "text-muted text-center");
    thumbElement.appendChild(descriptionElement);
    var smallElement = xmlDoc.createElement("small");
    descriptionElement.appendChild(smallElement);
    var smallTextNode = xmlDoc.createTextNode(attachmentModel.description);
    smallElement.appendChild(smallTextNode);

    if(attachmentModel.uuid){
        var deleteButtonWrapper = xmlDoc.createElement("div");
        deleteButtonWrapper.setAttribute("class", "clearfix pull-center m-t-15");
        thumbElement.appendChild(deleteButtonWrapper);
        var deleteButtonElement = xmlDoc.createElement("button");
        deleteButtonWrapper.appendChild(deleteButtonElement);
        deleteButtonElement.setAttribute("type", "button");
        //deleteButtonElement.setAttribute("@click", "deleteAttachment(" + attachmentModel.uuid + ")");
        deleteButtonElement.setAttribute("class", "btn btn-blue btn-rounded waves-effect waves-light iconDeleteAttachment");

        var subInnerUUIDElement = xmlDoc.createElement("input");
        subInnerUUIDElement.setAttribute("type", "hidden");
        subInnerUUIDElement.setAttribute("value", attachmentModel.uuid);
        var subIconElement = xmlDoc.createElement("i");


        var subIconClass = 'glyphicon glyphicon-remove';
        subIconElement.setAttribute("class", subIconClass);
        deleteButtonElement.appendChild(subIconElement);
        var seperatorNode = xmlDoc.createTextNode(" ");
        deleteButtonElement.appendChild(seperatorNode);
        deleteButtonElement.appendChild(subInnerUUIDElement);
        var deleteTextNode = xmlDoc.createTextNode(deleteTitle);
        deleteButtonElement.appendChild(deleteTextNode);
    }

    return topElement;
}

