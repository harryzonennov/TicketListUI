var DocumentOrderMatPopInfo = {};


DocumentOrderMatPopInfo.createPageHeaderLinkToRootDoc = function (xmlDoc, rootDocText, rootDocUrl) {
    "use strict";
    var alinkElement = xmlDoc.createElement("a");
    var labeIdText = xmlDoc.createTextNode(rootDocText);
    if (rootDocUrl) {
        // In case doc url exist, then generate ahref link wrapper element
        alinkElement.setAttribute("class", "linkToBaseDocument");
        alinkElement.setAttribute("href", rootDocUrl);
        alinkElement.append(labeIdText);
        return alinkElement;
    } else {
        // In case no doc url, then only generate normal div wrapper element.
        var divWrapperElement = xmlDoc.createElement("div");
        divWrapperElement.append(labeIdText);
        return divWrapperElement;
    }
};

DocumentOrderMatPopInfo.getPageHeaderArray = function (xmlDoc, pageHeaderModelList) {
    "use strict";
    if (pageHeaderModelList && pageHeaderModelList.length > 0) {
        pageHeaderModelList.sort(function (headerA, headerB) {
            if (headerA.index < headerB.index) {
                return -1;
            } else if (headerA.index > headerB.index) {
                return 1;
            } else {
                return 0;
            }
        });
        var resultList = [];
        for (var i = 0, len = pageHeaderModelList.length; i < len; i++) {
            var liElement = xmlDoc.createElement("li");
            var pageHeaderModel = pageHeaderModelList[i];
            var aLinkElement = DocumentOrderMatPopInfo.createPageHeaderLinkToRootDoc(xmlDoc, pageHeaderModel.pageTitle + ':' + pageHeaderModel.headerName, pageHeaderModel.pageLink);
            liElement.append(aLinkElement);
            resultList.push(liElement);
        }
        return resultList;
    }
};

/**
 * Entry method to generate Document Material Item List multiple-selector pop-up.
 * @param xmlDoc
 * @param parentElement
 * @param labelObjct
 * @param valueObject
 * @param selectOptionCoreElement
 * @param title
 * @param selectTitle
 * @param selectComment
 * @param {Element} selectOptionCoreElement: Core Element for multiple-select
 */
DocumentOrderMatPopInfo.genMaterialItemMultSelectPop = function (xmlDoc, parentElement, labelObject, valueObject,
                                                                 selectOptionCoreElement, title, selectTitle, selectComment, nonSelectComment, propSettings) {
    "use strict";
    // Build Header
    var _header = DocumentOrderMatPopInfo._genPopupPortletHead(xmlDoc, parentElement, title);
    // Build Body
    var _body = DocumentOrderMatPopInfo._genModalBodyMultiSelect(xmlDoc, parentElement, labelObject, valueObject,
        selectOptionCoreElement, selectTitle, selectComment, nonSelectComment, propSettings);


};


DocumentOrderMatPopInfo._filterIconClass = function (iconArray, keyValue) {
    var $element = ServiceCollectionsHelper.filterArray(keyValue, 'id', iconArray);
    if ($element) {
        return $element.iconClass;
    }
};
/**
 *
 * @param oSettings
 *    --{String} targetPage
 *    --{url} url
 *    --{String} subPath
 *    --{Object} label
 *    --{Vue} vm
 *    --{function} getI18nWrap
 *    --{Array} fieldMetaList
 *       --{FieldMeta}
 *           --{String} fieldName
 *           --{String} labelKey
 *           --{String} fieldKey: in case need to set drowndown key
 *           --{String} iconArray: in case need to provided icon array
 *           --{String} fieldName
 *           --{String} listSubPath: need to retrieve value from sub list module by this sub path
 *           --{Number} listValueStragety: stragety to show sub list model value
 *           --{Number} listFirstNum: in case show first several models, set how many first items should be count
 *
 */
DocumentOrderMatPopInfo.getDocumentPopoverContentWrapper = function (oSettings) {
    var uuid = oSettings.uuid;
    var url = oSettings.url;
    if (uuid) {
        url = url + "?uuid=" + uuid;
    }
    var funcGetI18n = oSettings.getI18nWrap ;
    if (oSettings.i18nConfig) {
        funcGetI18n = function(fnCallback) {
            ServiceUtilityHelper.setNodeI18nPropertiesByConfig({
                i18nConfig: oSettings.i18nConfig,
                fnCallback: fnCallback
            });
        };
    }
    funcGetI18n(function () {
        ServiceUtilityHelper.httpRequest({
            url: url,
            $http: oSettings.$http,
            errorHandle: function(ex) {
                ServiceExceptionHelper.handleException({
                    handleCategory:ServiceExceptionHelper.HANDLE_CATEGORY.CONSOLE,
                    exception:ex
                });
                if (oSettings.errorHandle) {
                    oSettings.errorHandle(ex);
                }
            },
            postHandle: function (oData) {
                DocumentOrderMatPopInfo._parseToDocumentWrapper(oData, oSettings);
            }.bind(this)
        });
    }.bind(this));
};


DocumentOrderMatPopInfo._preGenColumnMetaData = function (oSettings) {
    return ServiceUtilityHelper.batchConvertFieldIconArrayRequest({
        $http: oSettings.$http,
    }, oSettings.fieldMetaList);
};

DocumentOrderMatPopInfo._parseToDocumentWrapper = function (oData, oSettings) {
    var promiseList = DocumentOrderMatPopInfo._preGenColumnMetaData(oSettings, oSettings.fieldMetaList);
    if (promiseList && promiseList.length > 0) {
        Promise.all(promiseList).then(function (results) {
            DocumentOrderMatPopInfo._parseToDocumentPost(oData, oSettings);
        });
    } else {
        DocumentOrderMatPopInfo._parseToDocumentPost(oData, oSettings);
    }
};

DocumentOrderMatPopInfo._parseToDocumentPost = function (oData, oSettings) {
    var label = oSettings.label;
    var targetPage = oSettings.targetPage;
    var $popCoreElement = oSettings.$popCoreElement;
    var fnCallBack = oSettings.fnCallBack;
    // Set to cache
    var subPath = oSettings.subPath;
    var serviceUIModel = oData.content;
    if (subPath) {
        serviceUIModel = serviceUIModel[subPath];
    }
    var labelObject = {};
    var targetModel = {};
    if (!oSettings.docIcon) {
        oSettings.docIcon = DocumentManagerFactory.formatDocTypeIconClass(oSettings.docType);
    }
    var paras = {};
    paras.processMode = PROCESSMODE_EDIT;
    paras.uuid = serviceUIModel.uuid;
    var resultURL = targetPage + "?" + urlEncode(paras);
    var serializer = new XMLSerializer();
    var xmlDoc = document.implementation.createDocument("", "", null);
    $popCoreElement.empty();
    var oSetting = ServiceUtilityHelper.extendObject(oSettings, {});
    oSetting.editUrl = resultURL;
    var fieldMetaList = oSettings.fieldMetaList;
    if (oSettings.referenceDate) {
        ServiceCollectionsHelper.traverseList(oSettings.referenceDate.fieldNameList, function (fieldName) {
            var value;
            if (subPath) {
                value = ServiceUtilityHelper.fetchObjValueByPath(serviceUIModel, fieldName);
            } else {
                value = ServiceUtilityHelper.fetchObjValueByPath(oData.content, fieldName);
            }
            if (value) {
                targetModel.referenceDate = value;
            }
        });
    }
    if (oSettings.responsibleByField) {
        if (subPath) {
            value = ServiceUtilityHelper.fetchObjValueByPath(serviceUIModel, oSettings.responsibleByField);
        } else {
            value = ServiceUtilityHelper.fetchObjValueByPath(oData.content, oSettings.responsibleByField);
        }
        if (value) {
            targetModel.responsibleBy = value;
        }
    }
    ServiceCollectionsHelper.traverseList(fieldMetaList, function (fieldMeta, index) {
        var value;
        if (fieldMeta.listSubPath) {
            // In case need to fetch list sub module value
            var listModel = oData.content[fieldMeta.listSubPath];
            if (listModel && listModel.length > 0) {
                value = DocumentOrderMatPopInfo.fetchListSubModelValue(oData.content, fieldMeta);
            }
        } else {
            // In case fetch value from root node or flat sub node
            if (subPath) {
                value = ServiceUtilityHelper.fetchObjValueByPath(serviceUIModel, fieldMeta.fieldName);
            } else {
                value = ServiceUtilityHelper.fetchObjValueByPath(oData.content, fieldMeta.fieldName);
            }
        }
        value = ServiceUtilityHelper.processValueIfTooLong({
            value: value
        }).value;
        targetModel[fieldMeta.fieldName] = value;
        fieldMeta.fieldKey = fieldMeta.fieldKey ? fieldMeta.fieldKey : fieldMeta.fieldName;
        if (fieldMeta.iconArray) {
            var keyValue;
            if (fieldMeta.listSubPath) {
                // In case need to fetch list sub module value
                var listModel = oData.content[fieldMeta.listSubPath];
                if (listModel && listModel.length > 0) {
                    keyValue = DocumentOrderMatPopInfo.fetchListSubModelKey(oData.content, fieldMeta);
                }
            } else {
                // In case fetch value from root node or flat sub node
                if (subPath) {
                    keyValue = ServiceUtilityHelper.fetchObjValueByPath(serviceUIModel, fieldMeta.fieldKey);
                } else {
                    keyValue = ServiceUtilityHelper.fetchObjValueByPath(oData.content, fieldMeta.fieldKey);
                }
            }

            var iconClass = DocumentOrderMatPopInfo._filterIconClass(fieldMeta.iconArray, keyValue);
            if (iconClass) {
                targetModel[fieldMeta.fieldKey] = {
                    value: targetModel[fieldMeta.fieldName],
                    iconClass: iconClass
                };
            }
        }
        fieldMeta.labelKey = fieldMeta.labelKey ? fieldMeta.labelKey : fieldMeta.fieldName;
        if (!fieldMeta.fieldLabel) {
            if (label) {
                fieldMeta.fieldLabel = ServiceUtilityHelper.fetchObjValueByPath(label, fieldMeta.labelKey);
            } else {
                fieldMeta.fieldLabel = fieldMeta.fieldName;
            }
        }
        labelObject[fieldMeta.labelKey] = fieldMeta.fieldLabel;
        // make sure label and value has same key
        if (!targetModel[fieldMeta.labelKey] && targetModel[fieldMeta.fieldKey]) {
            targetModel[fieldMeta.labelKey] = targetModel[fieldMeta.fieldKey];
        }
        if (!targetModel[fieldMeta.labelKey] && targetModel[fieldMeta.fieldName]) {
            targetModel[fieldMeta.labelKey] = targetModel[fieldMeta.fieldName];
        }
        // make sure special field has value
        DocumentOrderMatPopInfo._assignKeyValue(targetModel, fieldMeta.labelKey, 'id', 'parentDocId');
        DocumentOrderMatPopInfo._assignKeyValue(targetModel, fieldMeta.labelKey, 'name', 'name');
        DocumentOrderMatPopInfo._assignKeyValue(targetModel, fieldMeta.labelKey, 'referenceDate');
        DocumentOrderMatPopInfo._assignKeyValue(labelObject, fieldMeta.labelKey, 'id', 'parentDocId');
    });

    var topElement = DocumentOrderMatPopInfo.genSimpleDocPopCore(xmlDoc, labelObject, targetModel, oSetting);
    var htmlContent = serializer.serializeToString(topElement);
    $popCoreElement.prepend(htmlContent);
    if (fnCallBack) {
        fnCallBack();
    }
};

DocumentOrderMatPopInfo.fetchListSubModelValue = function (basicModel, fieldMeta) {
    return DocumentOrderMatPopInfo.fetchListSubModelValueCore(basicModel, fieldMeta, 'fieldName');
};


DocumentOrderMatPopInfo.fetchListSubModelKey = function (basicModel, fieldMeta) {
    return DocumentOrderMatPopInfo.fetchListSubModelValueCore(basicModel, fieldMeta, 'fieldKey');
};


DocumentOrderMatPopInfo.fetchListSubModelValueCore = function (basicModel, fieldMeta, fieldPrefix) {
    var value;
    var listModel = basicModel[fieldMeta.listSubPath];
    if (listModel && listModel.length > 0) {
        if (fieldMeta.listValueStragety === DocumentOrderMatPopInfo.ListItemStragegy.FIRST_ITEM) {
            value = ServiceUtilityHelper.fetchObjValueByPath(listModel[0], fieldMeta[fieldPrefix]);
        }
        if (fieldMeta.listValueStragety === DocumentOrderMatPopInfo.ListItemStragegy.FIRST_MULTI_ITEM) {
            var i = 0, tmpValue,
                len = listModel.length < fieldMeta.listFirstNum ? listModel.length : fieldMeta.listFirstNum;
            for (i = 0; i < len; i++) {
                tmpValue = ServiceUtilityHelper.fetchObjValueByPath(listModel[i], fieldMeta[fieldPrefix]);
                value = value ? value + " " + tmpValue : tmpValue;
            }
        }
        if (fieldMeta.listValueStragety === DocumentOrderMatPopInfo.ListItemStragegy.ALL_ITEM) {
            var j = 0, tmpValue2;
            for (j = 0; j < listModel.length; j++) {
                tmpValue2 = ServiceUtilityHelper.fetchObjValueByPath(listModel[j], fieldMeta[fieldPrefix]);
                value = value ? value + " " + tmpValue2 : tmpValue2;
            }
        }
    }
    return value;
};


DocumentOrderMatPopInfo._assignKeyValue = function (targetModel, fieldKey, targetKey, key2, key3) {
    var hitFlag = DocumentOrderMatPopInfo._assignKeyValueCore(targetModel, fieldKey, targetKey, targetKey);
    if(hitFlag || !key2){
        return;
    }
    hitFlag = DocumentOrderMatPopInfo._assignKeyValueCore(targetModel, fieldKey, key2, targetKey);
    if(hitFlag || !key3){
        return;
    }
    DocumentOrderMatPopInfo._assignKeyValueCore(targetModel, fieldKey, key3, targetKey);

};

DocumentOrderMatPopInfo._assignKeyValueCore = function (targetModel, fieldKey, key, targetKey) {
    if (ServiceUtilityHelper.checkPathContainsKey(fieldKey, key) === true) {
        if (!targetModel[targetKey]) {
            targetModel[targetKey] = targetModel[fieldKey];
            return true;
        }
    }
};

/**
 *
 * @param xmlDoc
 * @param {object}oSetting
 * - {String} editUrl: url to open document order (material item) edit page
 * - {Object} labelObject
 * - {Object} infoObject
 *                 - {String} label
 *                 - {String} value
 */
DocumentOrderMatPopInfo.genSimpleDocPopCore = function (xmlDoc, labelObject, infoObject, oSetting) {
    "use strict";
    var pWrapperElement = xmlDoc.createElement("p");

    var labelIdElement = xmlDoc.createElement("label");
    labelIdElement.setAttribute("class", "popItem-label");
    if (oSetting && oSetting.docIcon) {
        var docIconElement = xmlDoc.createElement("i");
        docIconElement.setAttribute("class", oSetting.docIcon);
        labelIdElement.append(docIconElement);
        var iconSeperate = xmlDoc.createTextNode(" ");
        labelIdElement.append(iconSeperate);
    }
    var labeIdText = xmlDoc.createTextNode(labelObject.id);
    labelIdElement.append(labeIdText);
    pWrapperElement.appendChild(labelIdElement);

    if (infoObject.referenceDate) {
        var tempReferenceDate = infoObject.referenceDate;
        if (tempReferenceDate.length > 10) {
            tempReferenceDate = tempReferenceDate.slice(0, 10);
        }
        var dateLabel = ServiceDOMUtilityHelper.createDefElement({
            element: "label",
            class: "popItem-label pull-right",
            iconClass: "md md-restore content-orange",
            textContent: tempReferenceDate
        });
        pWrapperElement.appendChild(dateLabel);
    }
    var br1Element = xmlDoc.createElement("br");
    pWrapperElement.appendChild(br1Element);

    var ahrefWrapperElement = xmlDoc.createElement("a");
    ahrefWrapperElement.setAttribute("class", "");
    ahrefWrapperElement.setAttribute("target", "_blank");
    ahrefWrapperElement.setAttribute("href", oSetting.editUrl);
    var subjectText, fullTitle;
    if (infoObject.id && infoObject.name) {
        fullTitle = ServiceUtilityHelper.processValueIfTooLong({
            value: infoObject.id + "-" + infoObject.name
        }).value;
        subjectText = xmlDoc.createTextNode(fullTitle);
    } else {
        if (infoObject.id) {
            subjectText = xmlDoc.createTextNode(infoObject.id);
        }
        if (infoObject.name) {
            subjectText = xmlDoc.createTextNode(infoObject.name);
        }
    }
    ahrefWrapperElement.append(subjectText);
    pWrapperElement.appendChild(ahrefWrapperElement);
    var br2Element = xmlDoc.createElement("br");
    pWrapperElement.appendChild(br2Element);

    if (infoObject.responsibleBy) {

        var responsibleByLabel = ServiceDOMUtilityHelper.createDefElement({
            parentElement: pWrapperElement,
            element: "label",
            class: "popItem-label m-t-5",
            iconClass: "md md-perm-contact-cal content-lightBlue",
            textContent: infoObject.responsibleBy
        });
        var br1Element3 = xmlDoc.createElement("br");
        pWrapperElement.appendChild(br1Element3);
    }


    var hr1Element = xmlDoc.createElement("hr");
    pWrapperElement.appendChild(hr1Element);

    var i = 0, _length, keys = Object.keys(labelObject);
    _length = keys ? keys.length : 0;
    for (i = 0; i < _length; i++) {
        if (keys[i] === 'id' || keys[i] === 'name') {
            continue;
        }
        if (ServiceUtilityHelper.checkPathContainsKey(keys[i], 'id') === true) {
            continue;
        }
        // if(ServiceUtilityHelper.checkPathContainsKey(keys[i], 'name') === true){
        //     continue;
        // }
        DocumentOrderMatPopInfo.createLabelValuePair(xmlDoc, pWrapperElement, labelObject[keys[i]], infoObject[keys[i]]);
    }
    return pWrapperElement;

};

DocumentOrderMatPopInfo.createLabelValuePair = function (xmlDoc, parentElement, label, object) {
    "use strict";
    if (!label) {
        return;
    }
    var value;
    var objIcon;
    if (object && typeof object === 'object') {
        objIcon = object.iconClass;
        value = object.value ? object.value : '';
    } else {
        value = object ? object : '';
    }
    // In order to avoid "undefined" value

    var pWrapper = xmlDoc.createElement("p");
    parentElement.append(pWrapper);
    var labelIdElement = xmlDoc.createElement("label");
    labelIdElement.setAttribute("class", "popItem-label");
    var labeIdText = xmlDoc.createTextNode(label);
    labelIdElement.append(labeIdText);
    pWrapper.appendChild(labelIdElement);
    var brElement = xmlDoc.createElement("br");
    pWrapper.appendChild(brElement);

    if (label) {
        var valueElement = xmlDoc.createElement("span");
        valueElement.setAttribute("class", "value-content");
        if (objIcon) {
            ServiceDOMUtilityHelper.createDefElement({
                class: objIcon,
                element: 'i',
                parentElement: valueElement
            });
            ServiceDOMUtilityHelper.createSpaceNode(valueElement);
        }
        var valueText = ServiceDOMUtilityHelper.createTextNode(valueElement, value);
        pWrapper.appendChild(valueElement);
        var br2Element = xmlDoc.createElement("br");
        pWrapper.appendChild(br2Element);
        var hr1Element = xmlDoc.createElement("hr");
        pWrapper.appendChild(hr1Element);
    }

};

/**
 *
 * @param xmlDoc
 * @param {object}oSetting
 * - {String} editUrl: url to open document order (material item) edit page
 * - {String} iconClass: media icon bootstrap class
 * - {String} labelTitle
 * - {String} title
 * - {String} labelMaterial
 * - {String} materialStockKeepUnitId
 * - {String} materialStockKeepUnitName
 * - {Array} textInfoList
 *                 - {String} subTitle
 *                 - {String} textInfo
 *                 - {String} smallTextClass
 */
DocumentOrderMatPopInfo.genDocMatInfoUnion = function (xmlDoc, oSetting) {
    "use strict";
    var ahrefWrapperElement = xmlDoc.createElement("a");
    ahrefWrapperElement.setAttribute("class", "list-group-item bg_belize");
    ahrefWrapperElement.setAttribute("target", "_blank");
    ahrefWrapperElement.setAttribute("href", oSetting.editUrl);

    var divMedia1 = xmlDoc.createElement("div");
    divMedia1.setAttribute("class", "media");
    ahrefWrapperElement.appendChild(divMedia1);
    var icon1Element = xmlDoc.createElement("div");
    icon1Element.setAttribute("class", "pull-left p-r-10");

    var em1Element = xmlDoc.createElement("em");
    em1Element.setAttribute("class", oSetting.iconClass);
    icon1Element.appendChild(em1Element);
    divMedia1.appendChild(icon1Element);

    // Media Body1
    var orderTitle = oSetting.labelTitle + ': ' + oSetting.title;
    var orderIntoInfo = oSetting.labelMaterial + ': ' + oSetting.materialStockKeepUnitId + '--' + oSetting.materialStockKeepUnitName;
    if (oSetting.materialStockKeepUnitId) {
        orderIntoInfo = orderIntoInfo + oSetting.materialStockKeepUnitId;
        if (oSetting.materialStockKeepUnitName) {
            orderIntoInfo = orderIntoInfo + '--' + oSetting.materialStockKeepUnitName;
        }
    } else {
        if (oSetting.materialStockKeepUnitName) {
            orderIntoInfo = orderIntoInfo + oSetting.materialStockKeepUnitName;
        }
    }
    DocumentOrderMatPopInfo._genMediaBodyBlock(xmlDoc, divMedia1, orderTitle, orderIntoInfo);

    if (oSetting.textInfoList && oSetting.textInfoList.length > 0) {
        var i = 0, _textInfo, _textSubTitle, _length = oSetting.textInfoList.length;
        for (i = 0; i < _length; i++) {
            _textInfo = oSetting.textInfoList[i];
            DocumentOrderMatPopInfo._genMediaBodyBlock(xmlDoc, divMedia1, _textInfo.subTitle, _textInfo.textInfo, _textInfo.smallTextClass);
        }
    }
    return ahrefWrapperElement;

};

/**
 * @override: Generate Timeline style HTML code for Recent History list of documents for this material.
 * @param $containerElement
 * @param {Object} headerLabelObj
 *             --{String} headerTitle
 *             --{String} materialSKUId
 *             --{String} materialSKUName
 *             --{String} headerSmallComment
 * @param {string} uuid: uuid of material
 * @param fnSuccess
 */
DocumentOrderMatPopInfo.genDocMatTimelineHeaderUnion = function (xmlDoc, oHeaderLabelObj, iconClass) {
    "use strict";
    var cardboxWrapperElement = xmlDoc.createElement("div");
    cardboxWrapperElement.setAttribute("class", "card-box widget-icon");
    var divWrapperElement = xmlDoc.createElement("div");
    cardboxWrapperElement.appendChild(divWrapperElement);

    var iconElement = xmlDoc.createElement("i");
    iconElement.setAttribute("class", iconClass);
    divWrapperElement.appendChild(iconElement);

    var widWrapperElement = xmlDoc.createElement("div");
    widWrapperElement.setAttribute("class", "wid-icon-info");
    divWrapperElement.appendChild(widWrapperElement);

    var headerTitleElement = xmlDoc.createElement("p");
    headerTitleElement.setAttribute("class", "text-muted m-b-5 font-13 text-uppercase");
    var headerTitleTextNode = xmlDoc.createTextNode(oHeaderLabelObj.headerTitle);
    headerTitleElement.appendChild(headerTitleTextNode);
    widWrapperElement.appendChild(headerTitleElement);

    var materialIdElement = xmlDoc.createElement("div");
    materialIdElement.setAttribute("class", "text-muted m-b-5 font-13 text-uppercase");
    var materialIdLabelNode = xmlDoc.createTextNode("物料编码：");
    materialIdElement.appendChild(materialIdLabelNode);
    var smallTextIdWrapper = xmlDoc.createElement("div");
    smallTextIdWrapper.setAttribute("class", "text-link");
    var materialIdTextNode = xmlDoc.createTextNode(oHeaderLabelObj.materialSKUId);
    materialIdElement.appendChild(smallTextIdWrapper);
    smallTextIdWrapper.appendChild(materialIdTextNode);

    widWrapperElement.appendChild(materialIdElement);

    var materialNameElement = xmlDoc.createElement("div");
    materialNameElement.setAttribute("class", "text-muted m-b-5 font-13 text-uppercase");

    var materialTextLabelNode = xmlDoc.createTextNode("物料名称：");
    materialNameElement.appendChild(materialTextLabelNode);
    var smallTextNameWrapper = xmlDoc.createElement("div");
    smallTextNameWrapper.setAttribute("class", "text-link");
    var materialNameTextNode = xmlDoc.createTextNode(oHeaderLabelObj.materialSKUName);
    materialNameElement.appendChild(smallTextNameWrapper);
    smallTextNameWrapper.appendChild(materialNameTextNode);
    widWrapperElement.appendChild(materialNameElement);

    var h4Element = xmlDoc.createElement("h4");
    h4Element.setAttribute("class", "m-t-0 m-b-5 counter");
    widWrapperElement.appendChild(h4Element);

    if (oHeaderLabelObj.headerSmallComment) {
        var smallTextWrapperElement = xmlDoc.createElement("small");
        smallTextWrapperElement.setAttribute("class", "text-dark");
        var smallTextTextNode = xmlDoc.createTextNode(oHeaderLabelObj.headerSmallComment);
        smallTextWrapperElement.appendChild(smallTextTextNode);
        widWrapperElement.appendChild(smallTextWrapperElement);
    }

    return cardboxWrapperElement;
};

DocumentOrderMatPopInfo.genDocMatTimelineInfoUnion = function (xmlDoc, oSetting) {
    "use strict";
    var timeItemWrapperElement = xmlDoc.createElement("div");
    timeItemWrapperElement.setAttribute("class", "time-item");

    var timeItemInfoElement = xmlDoc.createElement("div");
    timeItemInfoElement.setAttribute("class", "item-info");
    timeItemWrapperElement.appendChild(timeItemInfoElement);
    // Media Body1
    var orderTitle = oSetting.labelTitle + ': ' + oSetting.title;
    var orderIntoInfo = oSetting.labelMaterial + ': ' + oSetting.materialStockKeepUnitId + '--' + oSetting.materialStockKeepUnitName;
    if (oSetting.materialStockKeepUnitId) {
        orderIntoInfo = orderIntoInfo + oSetting.materialStockKeepUnitId;
        if (oSetting.materialStockKeepUnitName) {
            orderIntoInfo = orderIntoInfo + '--' + oSetting.materialStockKeepUnitName;
        }
    } else {
        if (oSetting.materialStockKeepUnitName) {
            orderIntoInfo = orderIntoInfo + oSetting.materialStockKeepUnitName;
        }
    }
    //var pTitleElement = xmlDoc.createElement("p");
    var ahrefWrapperElement = xmlDoc.createElement("a");
    // ahrefWrapperElement.setAttribute("class", "list-group-item bg_belize");
    ahrefWrapperElement.setAttribute("target", "_blank");
    ahrefWrapperElement.setAttribute("href", oSetting.editUrl);
    timeItemInfoElement.appendChild(ahrefWrapperElement);
    //timeItemWrapperElement.appendChild(pTitleElement);
    var titleTextNode = xmlDoc.createTextNode(orderTitle);
    var smallTextWrapper = xmlDoc.createElement("small");
    smallTextWrapper.setAttribute("class", "text-muted");
    smallTextWrapper.append(titleTextNode);
    ahrefWrapperElement.append(smallTextWrapper);


    if (oSetting.textInfoList && oSetting.textInfoList.length > 0) {
        var i = 0, _textInfo, _textSubTitle, _length = oSetting.textInfoList.length;
        var pInfoElement = xmlDoc.createElement("p");
        for (i = 0; i < _length; i++) {
            _textInfo = oSetting.textInfoList[i];
            //DocumentOrderMatPopInfo._genMediaBodyBlock(xmlDoc, timeItemInfoElement, _textInfo.subTitle, _textInfo.textInfo, _textInfo.smallTextClass);
            var subSmallTextWrapper = xmlDoc.createElement("small");
            subSmallTextWrapper.setAttribute("class", "text-inverse");
            var textAmountNode = xmlDoc.createTextNode(_textInfo.textInfo);
            subSmallTextWrapper.appendChild(textAmountNode);
            pInfoElement.appendChild(subSmallTextWrapper);
            var brNode = xmlDoc.createElement("br");
            pInfoElement.appendChild(brNode);
        }
        timeItemInfoElement.appendChild(pInfoElement);
    }
    return timeItemWrapperElement;

};


DocumentOrderMatPopInfo._genMediaBodyBlock = function (xmlDoc, parentElement, h5Title, textInfo, smallClass) {
    "use strict";
    var pWrapperElement = xmlDoc.createElement("p");
    pWrapperElement.setAttribute("class", "m-0");
    var mediaBodyElement = xmlDoc.createElement("div");
    mediaBodyElement.setAttribute("class", "media-body");

    if (h5Title) {
        var requestAmountElement = xmlDoc.createElement("h5");
        requestAmountElement.setAttribute("class", "media-heading");
        var textAmountNode = xmlDoc.createTextNode(h5Title);
        requestAmountElement.appendChild(textAmountNode);
        mediaBodyElement.appendChild(requestAmountElement);
    }

    var pInfoElement = xmlDoc.createElement("p");
    pInfoElement.setAttribute("class", "m-0");
    var smallMatElement = xmlDoc.createElement("small");
    if (smallClass) {
        smallMatElement.setAttribute("class", smallClass);
    }
    var textMatIdNode = xmlDoc.createTextNode(textInfo);
    smallMatElement.appendChild(textMatIdNode);
    pInfoElement.appendChild(smallMatElement);
    mediaBodyElement.appendChild(pInfoElement);
    parentElement.appendChild(mediaBodyElement);
    parentElement.appendChild(pWrapperElement);
};

/**
 * Generate Portlet Style header for modal
 * @param xmlDoc
 * @param parentElement
 * @param title
 * @private
 */
DocumentOrderMatPopInfo._genPopupPortletHead = function (xmlDoc, parentElement, title) {
    "use strict";
    var divPortletHead = xmlDoc.createElement("div");
    divPortletHead.setAttribute("class", "portlet-heading bg-lightgrey");
    var titleElement = xmlDoc.createElement("h3");
    titleElement.setAttribute("class", "portlet-title");
    var titleTextNode = xmlDoc.createTextNode(title);
    titleElement.append(titleTextNode);
    divPortletHead.appendChild(titleElement);
    if (parentElement) {
        parentElement.appendChild(divPortletHead);
    }
    var divPortletWidgets = xmlDoc.createElement("div");
    divPortletWidgets.setAttribute("class", "portlet-widgets");
    var removeButton = xmlDoc.createElement("button");
    removeButton.setAttribute("type", "button");
    removeButton.setAttribute("data-toggle", "remove");
    removeButton.setAttribute("data-dismis", "modal");
    removeButton.setAttribute("aria-hidden", "true");
    var removeIcon = xmlDoc.createElement("i");
    removeIcon.setAttribute("class", "icon-close-round");
    removeButton.appendChild(removeIcon);
    divPortletWidgets.appendChild(removeButton);
    divPortletHead.appendChild(divPortletWidgets);
    var divClear = xmlDoc.createElement("div");
    divClear.setAttribute("class", "clearfix");
    var clearTextNode = xmlDoc.createTextNode("");
    divClear.append(clearTextNode);
    divPortletHead.appendChild(divClear);
    return divPortletHead;

};

/**
 * Build the Multi-Select Modal body part
 * @param xmlDoc
 * @param parentElement
 * @param labelObject
 * @param valueObject
 * @param selectTitle
 * @param selectComment
 * @param nonSelectComment
 * @returns {*}
 * @private
 */
DocumentOrderMatPopInfo._genModalBodyMultiSelect = function (xmlDoc, parentElement, labelObject, valueObject,
                                                             selectOptionCoreElement, selectTitle, selectComment, nonSelectComment, propSettings) {
    "use strict";
    var _propSettings = $.extend(true, {}, propSettings, {
        mdValue: 6
    });
    var divModalBody = DocumentOrderMatPopInfo._genModalBody(xmlDoc, parentElement, labelObject, valueObject, _propSettings);
    var hr = xmlDoc.createElement("hr");
    divModalBody.appendChild(hr);
    var selectTitleLabel = xmlDoc.createElement("label");
    selectTitleLabel.setAttribute("class", "portlet-title");
    var selectTitleNode = xmlDoc.createTextNode(selectTitle);
    selectTitleLabel.appendChild(selectTitleNode);
    divModalBody.appendChild(selectTitleLabel);

    var divRowSelect = xmlDoc.createElement("div");
    divRowSelect.setAttribute("class", "row");
    var divNonSelectWrapper = xmlDoc.createElement("div");
    divNonSelectWrapper.setAttribute("class", "col-md-6");
    divRowSelect.appendChild(divNonSelectWrapper);
    divModalBody.appendChild(divRowSelect);

    var divNonSelectLabel = xmlDoc.createElement("label");
    divNonSelectLabel.setAttribute("class", "select-label");
    var nonSelectCommentNode = xmlDoc.createTextNode(nonSelectComment);
    divNonSelectLabel.appendChild(nonSelectCommentNode);
    divNonSelectWrapper.appendChild(divNonSelectLabel);

    var divSelectWrapper = xmlDoc.createElement("div");
    divSelectWrapper.setAttribute("class", "col-md-6");

    var divSelectLabel = xmlDoc.createElement("label");
    divSelectLabel.setAttribute("class", "select-label");
    var selectCommentNode = xmlDoc.createTextNode(selectComment);
    divSelectLabel.appendChild(selectCommentNode);
    divSelectWrapper.appendChild(divSelectLabel);
    divRowSelect.appendChild(divSelectWrapper);

    var divMultiSelectCore = xmlDoc.createElement("div");
    divMultiSelectCore.setAttribute("id", "x_multiSelectWrapper");
    // Append Selection Option Core Element to 'x_multiSelectWrapper' element
    divMultiSelectCore.appendChild(selectOptionCoreElement);
    divModalBody.appendChild(divMultiSelectCore);
    return divModalBody;

};


DocumentOrderMatPopInfo._genSimpleDivRow = function (xmlDoc) {
    "use strict";
    var divRow = xmlDoc.createElement("div");
    divRow.setAttribute("class", "row");
    return divRow;
};
/**
 * Ultlity method to generate modal body label-value pairs part
 * @param xmlDoc
 * @param parentElement
 * @param {Object}labelObject
 * @param {Object}valueObject
 * @param {Objct} propSettings
 *            --{Number} mdValue
 *            --{boolean} globalEditFlag
 * @param selectTitle
 * @private
 */
DocumentOrderMatPopInfo._genModalBody = function (xmlDoc, parentElement, labelObject, valueObject, propSettings) {
    "use strict";
    if (!labelObject || !valueObject) {
        return;
    }
    var divModalBody = xmlDoc.createElement("div");
    divModalBody.setAttribute("class", "modal-body");
    parentElement.appendChild(divModalBody);
    var i = 0, keys = Object.keys(labelObject), _length = keys.length, divRow, divMd, divForm, _value, _rowMdSum = 0;
    divRow = DocumentOrderMatPopInfo._genSimpleDivRow(xmlDoc);
    divModalBody.appendChild(divRow);
    for (; i < _length; i++) {
        _rowMdSum = _rowMdSum + propSettings.mdValue;
        if (_rowMdSum >= 12) {
            // New Row
            _rowMdSum = 0;
            divRow = DocumentOrderMatPopInfo._genSimpleDivRow(xmlDoc);
            divModalBody.appendChild(divRow);
        }

        divMd = xmlDoc.createElement("div");
        divMd.setAttribute("class", "col-md-" + propSettings.mdValue);
        divRow.appendChild(divMd);

        divForm = xmlDoc.createElement("div");
        divForm.setAttribute("class", "form-group");
        divMd.appendChild(divForm);

        var divLabel = xmlDoc.createElement("label");
        divLabel.setAttribute("class", "col-md-3 control-label");
        var labelTextNode = xmlDoc.createTextNode(labelObject[keys[i]]);
        divLabel.append(labelTextNode);
        divForm.appendChild(divLabel);

        var divValueWrapper = xmlDoc.createElement("div");
        divValueWrapper.setAttribute("class", "col-md-6");

        var inputValue = xmlDoc.createElement("input");
        inputValue.setAttribute("type", "text");
        inputValue.setAttribute("class", "form-control");
        if (!propSettings.globalEditFlag || propSettings.globalEditFlag === false) {
            inputValue.setAttribute("disabled", "true");
        }
        inputValue.setAttribute("value", valueObject[keys[i]]);
        divValueWrapper.appendChild(inputValue);
        divForm.appendChild(divValueWrapper);
    }
    return divModalBody;
};

/**
 * Constants API, return all the fields as labels for Service Document Extend UI model, should be consistent with back-end model
 * @returns {string[]}
 */
DocumentOrderMatPopInfo.genDocFlowLabelFields = function () {
    "use strict";
    var result = [];
    result = ['id', 'name', 'documentType', 'status', 'priorityCode', 'refMaterialSKUId', 'processIndex', 'refMaterialSKUName',
        'referenceDate', 'refMaterialSKUId', 'refMaterialSKUName', 'serialId'];
    return result;
};

/**
 * Constants API, return all the fields as value properties for Service Document Extend UI model, should be consistent with back-end model
 * @returns {string[]}
 */
DocumentOrderMatPopInfo.genDocFlowPropetyFields = function () {
    "use strict";
    var result = [];
    result = ['id', 'uuid', 'parentNodeUUID', 'rootNodeUUID', 'status', 'name', 'statusValue', 'priorityCode', 'priorityCodeValue', 'refMaterialSKUId',
        'processIndex', 'refMaterialSKUUUID', 'refMaterialSKUName', 'referenceDate', 'documentTypeValue', 'documentType', 'refMaterialSKUId',
        'refMaterialSKUName', 'serialId'];
    return result;
};

//TODO obsolete
DocumentOrderMatPopInfo.genDocFlowWidget = function (labelObject, infoObject, widgetActiveFlag) {

    var cardboxClass = "widget-simple card-box";
    if (widgetActiveFlag && widgetActiveFlag === true) {
        cardboxClass = "widget-simple card-box active";
    }
    var cardboxElement = ServiceDOMUtilityHelper.createDefElement({
        class: cardboxClass,
        element: 'div'
    });

    var headerElement = DocumentOrderMatPopInfo.genDocFlowWidgetHeader(cardboxElement, labelObject, infoObject, widgetActiveFlag);
    var sperateElement = ServiceDOMUtilityHelper.createDefElement({
        class: "lean-hr-seperate border-linkblue",
        element: 'div',
        parentElement: cardboxElement
    });
    var contentElement = DocumentOrderMatPopInfo.genDocFlowWidgetContent(cardboxElement, labelObject, infoObject);
    return cardboxElement;

};

DocumentOrderMatPopInfo.genDocFlowWidgetHeader = function (parentElement, labelObject, infoObject, widgetActiveFlag) {

    var clearElement = ServiceDOMUtilityHelper.createDefElement({
        class: "clearfix",
        element: 'div',
        parentElement: parentElement
    });
    var pullLeftElement = ServiceDOMUtilityHelper.createDefElement({
        class: "pull-left",
        element: 'div',
        parentElement: clearElement
    });
    var processNumClass = "popItem-label";
    if (widgetActiveFlag && widgetActiveFlag === true) {
        processNumClass = "popItem-label content-darkblue";
    }
    var processNumWrapper = ServiceDOMUtilityHelper.createDefElement({
        class: processNumClass,
        element: 'h4',
        parentElement: pullLeftElement
    });
    var popItemClass = "fa fa-bookmark-o content-darkblue";
    if (widgetActiveFlag && widgetActiveFlag === true) {
        popItemClass = "fa fa-bookmark content-lightblue";
    }
    ServiceDOMUtilityHelper.createDefElement({
        class: popItemClass,
        element: 'i',
        parentElement: processNumWrapper
    });
    ServiceDOMUtilityHelper.createSpaceNode(processNumWrapper);
    if (infoObject && infoObject.processIndex) {
        var processIndex = infoObject.processIndex.value ? infoObject.processIndex.value : infoObject.processIndex;
        ServiceDOMUtilityHelper.createTextNode(processNumWrapper, processIndex);
    }
    var pullLeftElement = ServiceDOMUtilityHelper.createDefElement({
        class: "pull-left m-l-15",
        element: 'div',
        parentElement: clearElement
    });
    if (infoObject.docType || infoObject.documentType) {
        var docType = infoObject.docType ? infoObject.docType : infoObject.documentType;
        DocumentOrderMatPopInfo.genDocFlowPropertyUnion(pullLeftElement, labelObject.documentType, docType, true);
    }
    if (infoObject.id) {
        DocumentOrderMatPopInfo.genDocFlowPropertyUnion(pullLeftElement, labelObject.id, infoObject.id, true);
    }
    var pullRightElement = ServiceDOMUtilityHelper.createDefElement({
        class: "pull-right m-r-10",
        element: 'div',
        parentElement: clearElement
    });
    if (infoObject.updatedByName) {
        var updatedByName = {value: infoObject.updatedByName, iconClass: 'md md-perm-contact-cal content-darkblue'};
        DocumentOrderMatPopInfo.genDocFlowPropertyUnion(pullRightElement, labelObject.documentType, updatedByName, true, undefined, "cs-admin-union");
    }
    if (infoObject.updatedDate) {
        var updatedDate = {value: infoObject.updatedDate, iconClass: 'md md-history content-orange'};
        DocumentOrderMatPopInfo.genDocFlowPropertyUnion(pullRightElement, labelObject.documentType, updatedDate, true, undefined, "cs-admin-union");
    }
    return clearElement;
};


DocumentOrderMatPopInfo.genTargetUrlUnionPopoverWrapper = function (parentElement, text, targetUrl) {
    var divWrapper = ServiceDOMUtilityHelper.createDefElement({
        class: 'popover-info',
        element: 'span',
        parentElement: parentElement
    });
    var popIconElement = ServiceDOMUtilityHelper.createDefElement({
        class: 'md md-chat content-green',
        element: 'i',
        parentElement: divWrapper
    });
    ServiceDOMUtilityHelper.createSpaceNode(divWrapper);
    var aWrapper = DocumentOrderMatPopInfo.genSimTargetUrlUnion(divWrapper, text, targetUrl);

};

DocumentOrderMatPopInfo.genSimTargetUrlUnion = function (parentElement, text, targetUrl) {
    var aWrapper = ServiceDOMUtilityHelper.createDefElement({
        class: "",
        element: 'a',
        target: '_blank',
        href: targetUrl,
        parentElement: parentElement
    });
    ServiceDOMUtilityHelper.createTextNode(aWrapper, text);
    return aWrapper;
};

DocumentOrderMatPopInfo.genDocFlowWidgetContent = function (parentElement, labelObject, infoObject) {

    var clearElement = ServiceDOMUtilityHelper.createDefElement({
        class: "clearfix",
        element: 'div',
        parentElement: parentElement
    });
    var pullLeftElement = ServiceDOMUtilityHelper.createDefElement({
        class: "pull-left m-t-20",
        element: 'div',
        parentElement: clearElement
    });

    var pullRightElement = ServiceDOMUtilityHelper.createDefElement({
        class: "pull-right m-t-20",
        element: 'div',
        parentElement: clearElement
    });

    var i = 0, _length, keys = Object.keys(labelObject), parentWrapperElement;
    _length = keys ? keys.length : 0;
    var valueClass, pClass;
    for (i = 0; i < _length; i++) {
        if (keys[i] === 'id' || keys[i] === 'name' || keys[i] === 'documentType' || keys[i] === 'priorityCode' || keys[i] === 'status') {
            parentWrapperElement = pullLeftElement;
            if (keys[i] === 'id' || keys[i] === 'documentType') {
                valueClass = 'value-content content-darkblue';
            }
            pClass = undefined;
        } else {
            parentWrapperElement = pullRightElement;
            pClass = undefined;
        }
        DocumentOrderMatPopInfo.genDocFlowPropertyUnion(parentWrapperElement, labelObject[keys[i]], infoObject[keys[i]], false, valueClass, pClass);
    }

    return clearElement;
};

DocumentOrderMatPopInfo._checkGenExpandWrapper = function (parentElement) {
    var divWrapperElement = ServiceDOMUtilityHelper.createDefElement({
        element: 'div',
        class: 'expand-wrapper',
        iconClass: 'ion-chevron-down expand-block content-lightblue',
        parentElement: parentElement
    });
};


DocumentOrderMatPopInfo.genDocFlowPropertyUnion = function (parentElement, label, valueObject, skipLabelFlag, valueClass, pClass) {
    if (!label && !skipLabelFlag) {
        return;
    }
    if (!valueObject) {
        return;
    }
    var pWrapperElement = ServiceDOMUtilityHelper.createDefElement({
        element: 'p',
        class: pClass ? pClass : undefined,
        parentElement: parentElement
    });
    if (skipLabelFlag && skipLabelFlag === true) {
    } else {
        var labelWrapElement = ServiceDOMUtilityHelper.createDefElement({
            class: 'popItem-label',
            element: 'label',
            parentElement: pWrapperElement
        });
        var spanLabelElement = ServiceDOMUtilityHelper.createDefElement({
            class: 'help',
            element: 'span',
            parentElement: labelWrapElement
        });
        // Process label in case too long
        label = ServiceStringHelper.handleContentByLength(label);
        // if(label && label.length > 15){
        //     label = label.slice(0,15) + "...";
        // }
        ServiceDOMUtilityHelper.createTextNode(spanLabelElement, label);

        ServiceDOMUtilityHelper.createDefElement({
            element: 'br',
            parentElement: pWrapperElement
        });
    }

    var targetUrl, iconClass, parentValueElement = pWrapperElement, value = valueObject;
    if (typeof valueObject === 'object') {
        value = valueObject.value;
        targetUrl = valueObject.targetUrl;
        iconClass = valueObject.iconClass;
    }
    if (!value) {
        return;
    }
    if (iconClass) {
        var iconClassElement = ServiceDOMUtilityHelper.createDefElement({
            class: iconClass,
            element: 'i',
            parentElement: pWrapperElement
        });
        ServiceDOMUtilityHelper.createSpaceNode(pWrapperElement);
    }
    if (value.length > 15) {
        value = value.slice(0, 15) + "...";
    }
    if (targetUrl) {
        DocumentOrderMatPopInfo.genTargetUrlUnionPopoverWrapper(pWrapperElement, value, targetUrl);
    } else {
        var targetClass = 'value-content content-darkblue';
        if (valueClass) {
            targetClass = valueClass;
        }
        var spanValueElement = ServiceDOMUtilityHelper.createDefElement({
            class: targetClass,
            element: 'span',
            parentElement: pWrapperElement
        });
        if (value.length > 10) {
            value = value.slice(0, 10) + "...";
        }
        ServiceDOMUtilityHelper.createTextNode(spanValueElement, value);
    }
    //
    return pWrapperElement;
};

DocumentOrderMatPopInfo.ListItemStragegy = {
    FIRST_ITEM: 1,
    FIRST_MULTI_ITEM: 2,
    ALL_ITEM: 3
};



